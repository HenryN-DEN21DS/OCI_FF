
import os
import csv
import json
import logging
import zipfile
import argparse
import xml.etree.ElementTree as ET
from datetime import datetime
from collections import OrderedDict


def read_input_mapping_csv(filename: str) -> list:
    """This function reads the mapping input file as a list of dictionaries. 

    Args:
        filename (str): input filename, important: needs also the '.csv' extension

    Returns:
        list: Returns a list of dictionaries per row. Each dict key
              is the column name with the associated value for each row
    """
    logging.info("Reading input mapping CSV: %s", filename)

    result = []

    reader = csv.DictReader(open(filename))

    for row in reader:
        result.append(row)
        
    return result


def _row_to_list(row_xml: ET.Element, shared_strings: list) -> list:
    """
    Converts a row of XML to a list of cell values.

    Args:
        row_xml (ET.Element): XML element representing the row.
        shared_strings (list): List of shared strings in the document.

    Returns:
        list: List of cell values.
    """
    row_list = []
    
    for cell in row_xml.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        # Look up the value of the cell from the shared strings table
        cell_value = cell.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v')
        
        if cell_value is None:
            cell_result = None
        else:
            text_value = cell_value.text
            if cell.get('t') == 's': # if the cell contains a shared string
                cell_result = shared_strings[int(text_value)]
        row_list.append(cell_result)
    
    return row_list


def xlsx_file_to_list_of_dict(file_name: str, column_list: list) -> list:
    """
    Converts an Excel file to a list of dictionaries, each dictionary representing a row in the Excel file.

    Args:
        file_name (str): Name of the Excel file.
        column_list (str): list of column names in the order you want the dictionary rows returned

    Returns:
        list: List of dictionaries.
    """
    logging.info("Reading name_label_report file: %s", file_name)
    result_list = []
    with zipfile.ZipFile(file_name) as archive:
        
        # Find the shared strings file and parse it
        shared_strings_xml = archive.read('xl/sharedStrings.xml')
        shared_strings_tree = ET.fromstring(shared_strings_xml)
        shared_strings = []
        
        # Loop through each string in the shared strings table and extract the text value
        for si in shared_strings_tree.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si'):
            string_value = si.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t').text
            shared_strings.append(string_value)
        
        # Loop through every sheet to get all data at once
        sheet_files = [filename for filename in archive.namelist() if "/worksheets/" in filename]
            
        for sheet in sheet_files:
                       
            # Find the worksheet data file and parse it
            worksheet_xml = archive.read(sheet)
            worksheet_tree = ET.fromstring(worksheet_xml)
            
            # First row = headers
            first_row = worksheet_tree.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row')[0]
            headers = _row_to_list(first_row, shared_strings)
                 
            # Loop through each row in the worksheet and extract the data
            for row in worksheet_tree.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row')[1:]:
                cell_values = _row_to_list(row, shared_strings)
                row_dict = {k : v for k, v in zip(headers, cell_values)}
                
                sorted_row_dict = OrderedDict((key, row_dict.get(key, None)) for key in column_list)
                
                result_list.append(sorted_row_dict)
                
    logging.info("Finished converting Excel file to list of dictionaries.")
        
    return result_list


def create_conversion_dict(input_file: list, column_list: list) -> dict:
    """This function creates a dictionary that can be used to
       convert the column names of the logical model to the column
       names of the physical data model. 

    Args:
        input_files (str): This argument contains the input file location
        for the label report exports associated with a given mapping that you want to convert.

    Returns:
        dict: A dictionary for each of the logical columns that maps to a physical column.
              If the input of this function only has one file with one row containing:
              | logical_column_name | physical_column_name | logical_table_name | physical_table_name |
              This function returns a dictionary {<logical_table_name>.<logical_column_name> : <physical_table_name>.<physical_column_name>}
    """

    conversion_dict = {}

    list_of_rows = xlsx_file_to_list_of_dict(input_file, column_list)
    
    for row_dict in list_of_rows:
        
        # TODO: Hardcoded column order --> Change to make dynamic
        logical_column_name, physical_column_input, logical_table_name, physical_table_input = row_dict['Attribute Name'], row_dict['Attribute Label'], row_dict['Entity Name'], row_dict['Entity Label']
                
        #For the physical column name, take the 'Name' value if label=empty, and replace all spaces with underscores and make uppercase
        if logical_column_name is not None:
            physical_column_name = (logical_column_name if physical_column_input is None else physical_column_input).replace(" ", "_").upper()
            physical_table_name = (logical_table_name if physical_table_input is None else physical_table_input).replace(" ", "_").upper()
        else:
            continue
                            
        conversion_dict[(logical_table_name + "." + logical_column_name).lower()] = physical_table_name + "." + physical_column_name
    
    return conversion_dict
        

 
def _clean_location_name(location_string: str, conversion_dict: dict, model_conversion: dict) -> list:
    """This function cleans the source- and target location name strings,
    it is neccesary to clean these strings to match them with the accepted
    format that IGC recognizes when importing the mapping file.

    Args:
        location_string (str): Input location string to clean
        env_name (str): Environment name to put at the start of the string

    Returns:
        list: Cleaned location name(s) string in the format: <ENV>.<SCHEMA>.<TABLENAME>.<COLUMNNAME>, if 
              schema name ends with '_PO', it returns both the '_PO' and '_PM' strings in the list
    """
   
    # OLD WAY: This regex takes the ':/' in the location string, finds the next '/' after that and cuts 
    # off that part of the string, resulting in: "<TABLENAME>/<COLUMNNAME>"
    #location_string = re.sub(".*:/(.*?/)", "", location_string)

    # Cut off the part in the location string that contains :/ and everything before it
    location_string = location_string.split(':/')[1]
    
    # Then cut the rest into parts based on '/'
    location_list = location_string.split("/")

    # The first part is the model name, the 2nd and 3rd part are the logical names: <table_name>.<column_name>
    model_name = location_list[0]
    logical_name = location_list[1] + "." + location_list[2]
    
    try:
        physical_schema_name = model_conversion[model_name]
    except:
        physical_schema_name = "GEEN_SCHEMA_GEVONDEN"
        logging.warning("Conversion failed for model: %s", model_name)
    
    try:
        physical_table_column_name = conversion_dict[logical_name.lower()]
    except:
        physical_table_column_name = "LOGISCH_" + logical_name
        logging.warning("Conversion failed for logical column: %s", logical_name)

    physical_full_name = physical_schema_name + "." + physical_table_column_name
        
    logging.debug("Converted location name %s into %s", location_string, physical_full_name)   
    
    column_name = physical_full_name.split(".")[2]
    
    if len(column_name) > 30:
        logging.warning("The column name for result %s exceeds 30 characters, it has a length of %s characters", physical_full_name, len(column_name))
        
    if physical_schema_name == "INT_ZWA_META":
        result = [physical_full_name]
    else:
        result = [physical_full_name, physical_full_name.replace("_PO.", "_PM.")]
    
    return result


def create_mapping_row(source_name: str, target_name: str, mapping_annotation: str, env_string: str, rule_lookup: dict) -> dict:
    
    result = dict()
    
    result["Name"] =  source_name + " > " + target_name
    result["Source Columns"] = env_string + "." + source_name
    result["Target Columns"] = env_string + "." + target_name
    result["Specification Description"] = mapping_annotation

    for rule in rule_lookup.keys():
        if rule in result["Target Columns"]:
            result["Rule"] = rule_lookup[rule]
        else:
            continue

    if "Rule" not in result.keys():
        result["Rule"] = None

    result["Function"] = None

    # Order the dictionary before appending to the result
    result = OrderedDict(sorted(result.items()))
    
    return result


def transform_mapping_rows(mapping_rows: list, env_string: str, rule_lookup: dict, conversion_dict: dict, model_conversion: dict) -> list:
    """This function takes the list of dictionaries from the mapping input file, loops
    over the rows and performs the necessary transformations to make it readable for IGC.    

    Args:
        mapping_rows (list): List of dicts from reading the mapping input file
        env_string (str): The env name to put in front of the location string
        rule_lookup (dict): Dictionary that is used to lookup the associated 'rule' value
        if the target location contains a specific part of a string. For instance, if the
        target location name contains '_H_HK' this dictionary is used to determine the value 
        for the 'rule' field.

    Returns:
        list: A list of dictionaries to write them back as rows to the output csv file,
              same structure as the reading input.
    """

    masked_list = []
    unmasked_list = []

    for row in mapping_rows:

        source_names = _clean_location_name(row["Source Location"], conversion_dict, model_conversion)
        target_names = _clean_location_name(row["Target Location"], conversion_dict, model_conversion)
        
        if len(source_names) == 2 and len(source_names) == len(target_names):            
            unmasked_row = create_mapping_row(source_names[0], target_names[0], row["Mapping Annotation"], env_string, rule_lookup)
            unmasked_list.append(unmasked_row)
            
            masked_row = create_mapping_row(source_names[1], target_names[1], row["Mapping Annotation"], env_string, rule_lookup)
            masked_list.append(masked_row)
            
        elif len(source_names) == 1 and len(source_names) == len(target_names):
            unmasked_row = create_mapping_row(source_names[0], target_names[0], row["Mapping Annotation"], env_string, rule_lookup)
            unmasked_list.append(unmasked_row)
        
        else:
            raise Exception("Found more than 2 source names for row {} > {}".format(row["Source Location"], row["Target Location"]))
        
    return unmasked_list, masked_list


def write_mapping_csv(result_rows: list, env_name: str, filename: str) -> None:
    """This function writes the transformed result row list of dictionaries
    to a new csv file.

    Args:
        result_rows (list): Transformed result row list -> list of dictionaries
        filename (str): Filename for the output csv file to write to

    Returns:
        None
    """
    
    output_location = "./output/{}".format(env_name)
    
    # Create output path if not exists
    if not os.path.exists(output_location):
        os.makedirs(output_location)
    
    with open(output_location + "/" + filename + ".csv", "w",  newline='', encoding="utf-8") as f:
        writer = csv.writer(f, delimiter=',')
        # Write header
        writer.writerow(result_rows[0].keys())
        # Write rows
        for row in result_rows:
            writer.writerow(row.values())
            
    logging.info("Finished writing file: ./output/%s/%s.csv", env_name, filename)
            
    return None



def main(debug=False):
    
    # Create logging folder if not exists
    if not os.path.exists("./logs"):
        os.makedirs("./logs")
        
    # Get current datetime
    current_datetime = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = "./logs/conversion_{}.log".format(current_datetime)
    
    # Configure logging
    logging.basicConfig(level=logging.DEBUG if debug else logging.INFO,
                        format='%(asctime)s - %(levelname)s - %(message)s')
                        
    # Create a file handler and set the log file name
    file_handler = logging.FileHandler(log_filename)
    file_handler.setLevel(logging.DEBUG if debug else logging.INFO)
    file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_formatter)

    # Create a stream handler to print logs to the terminal
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG if debug else logging.INFO)
    stream_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    stream_handler.setFormatter(stream_formatter)

    # Get the root logger and add the handlers
    logger = logging.getLogger()
    
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    logging.info("Mapping Converter started")

    # Define constants for applying rules and using ENVs / Hosts
    ENV_NAMES = {"dev": r'"UWVM2VLOAPP0004\.O-DC\.BA\.UWV\.NL".odim',
                 "test": r'"UWVM2VLTAPP0005\.T-DC\.BA\.UWV\.NL".TDIM',
                 "acc": r'"UWVM3VLAAPP0022\.A-DC\.BA\.UWV\.NL".adim',
                 "prod": r'"UWVM2VLPAPP0021\.P-DC\.BA\.UWV\.NL".pdim'}
    
    RULE_LOOKUP = {"_H_HK": "hubkey", "_L_HK": "linkkey", "_HASHDIFF": "dim_hashdiff", "HASHDIFF_": "hashdiff"}
    
    MODEL_CONVERSION = {"META" : "INT_ZWA_META", "INT_ZWA_PO": "INT_ZWA_PO", "BDV_STG": "INT_ZWA_PO", "INT_ZWA_STG": "INT_ZWA_PO", "INT_ZWA": "INT_ZWA_PO", "OKV IMF": "OKV_IMF_PO", "OKV IMF REF": "OKV_IMF_PO", "Bedrijfszone ZW-Arbo": "BDR_ZWA_PO", "BDR_ZWA": "BDR_ZWA_PO", "OKV_REFERENTIE_DATA":"OKV_REFERENTIE_DATA", "OKV REFERENTIE DATA":"OKV_REFERENTIE_DATA"}
    
    OUTPUT_FILENAMES = {"ZW_ARBO_STG_Mapping_PO": "./mapping_csv/PRESTAGE_STG.csv",
                        "ZW_ARBO_BDV_Mapping_PO": "./mapping_csv/STG_BDV.csv",
                        "ZW_ARBO_DM_Mapping_PO": "./mapping_csv/BDV_DM.csv",
                        "ZW_ARBO_META_Mapping": "./mapping_csv/META.csv"}
                        
    SQLCONVERTER_REPORT_LOCATION = "./sqlconverter_report/sqlconverter_report.xlsx"
    
    # Create conversion dict
    column_list = ["Entity Name", "Entity Label", "Persistent", "Attribute Name", "Attribute Label", "Documentation", "Data Type", "Data Type Qualifier", "Required", "Default Value", "Package Name", "Package Label", "History", "LoadPattern", "Primary Key Name", "Primary Key Label"]
    conversion_dict = create_conversion_dict(SQLCONVERTER_REPORT_LOCATION, column_list)
    
    if debug:
        with open("./output/conversion_dict.json", "w") as f:
            json.dump(conversion_dict, f, indent = 4)

    # Loop through each configuration and convert mappings
    for output_filename, input_filename in OUTPUT_FILENAMES.items():
        
        logging.info("Starting conversion for: %s", output_filename)
        
        # Read mapping input
        mapping_rows = read_input_mapping_csv(input_filename)

        # Create a mapping output file for each environment
        for env_name in list(ENV_NAMES.keys()):
            
            env_string = ENV_NAMES[env_name]
            
            # Create and write result
            unmasked_list, masked_list = transform_mapping_rows(mapping_rows, env_string, RULE_LOOKUP, conversion_dict, MODEL_CONVERSION)
            write_mapping_csv(unmasked_list, env_name, output_filename)
            
            # Also write a masked mapping if exists
            if output_filename.endswith("_PO"):
                write_mapping_csv(masked_list, env_name, output_filename.replace("_PO", "_PM"))
    
    return None


if __name__ == "__main__":
    
    # Parse command-line arguments
    parser = argparse.ArgumentParser(description='Mapping Conversion Script')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    args = parser.parse_args()

    main(args.debug)
