## FAKE data
-----------------------
### Info over Faker:
Faker is een Python package die random data genereert, in het script is deze geconfigureerd voor het creeeren van data passend in het IMF schema gebruikt in de MVP. [meer info over Faker](https://faker.readthedocs.io/en/master/). 


---
## Prerequisites
- Deploymentscript uitgevoerd, IMF database aanwezig
- Aanpassen van de database gegevens in het [python script](create-data_IMF.py) 
- Aanpassen van het IP adres in het [python script](config.py) 


## Deployment
1. Voer het [script](createIMFdata.bat) uit, geef hierin aan hoeveel records je wil per tabel
2. [Vul het metadatamodel en verlaad de data](#Infosphere\README.md)