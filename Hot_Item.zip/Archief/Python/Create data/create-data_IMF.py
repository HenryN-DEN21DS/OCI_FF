#%% #SETUP packages
from secrets import choice
from sqlalchemy import Integer, create_engine, select, MetaData, text
from faker import Faker
from sqlalchemy import func
import sys
import random
import datetime 
from datetime import date
import urllib
import cx_Oracle
import logging
import config

# see logging info https://docs.python.org/3/howto/logging.html
##SET up logging file
logging.basicConfig(filename='logging.log',
                    format='%(asctime)s %(message)s',
                    filemode='w',
                    level=logging.INFO)

##SET up logging to console (output you see)
console = logging.StreamHandler()
console.setLevel(logging.DEBUG)
# set a format which is simpler for console use
formatter = logging.Formatter('%(name)-12s: %(levelname)-8s %(message)s')
console.setFormatter(formatter)
# add the handler to the root logger
logging.getLogger('').addHandler(console)


#CREATE ENGINE for writing to db
today = date.today()
user='system'
pwd='manager'
dsn = cx_Oracle.makedsn(
    config.IP_ADRESS, 1521,
    service_name='xe'
)
engine = create_engine(f'oracle+cx_oracle://{user}:{pwd}@{dsn}')

logging.info('program started and engine is created')

#TODO: Create connection class, that switches from SSMS to oracle connection
##  PARAMS to pass in to connection string, only used for WinAuth
# params = urllib.parse.quote_plus("DRIVER={ODBC Driver 17 for SQL Server};"
#                                  "SERVER=(localdb)\GDRP;"
#                                  "DATABASE=PBD;"
#                                  "Trusted_Connection=yes")

# # CRETE engine to write to db based on params
# engine = create_engine("mssql+pyodbc:///?odbc_connect={}".format(params))


#%% INSTANTIATE metadata class
metadata = MetaData()
# INSTANTIATE faker class
#Faker.seed(0)
faker = Faker(['nl-NL'])

#%%
# REFLECT metadata/schema from existing database
with engine.connect() as conn:
    metadata.reflect(conn, schema='IMF')
     # Log the tables as they are created
#    for table in metadata.tables.keys():
#        logging.info(f"{table} is present in the db")


# CREATE table objects
AOGEVAL = metadata.tables["IMF.ao_geval"]
DK = metadata.tables["IMF.districtkantoor"]
PERSOON = metadata.tables["IMF.persoon"]
WERKGEVER = metadata.tables["IMF.werkgever"]
DIENSTVERBAND = metadata.tables["IMF.dienstverband"]
MEDEWERKER = metadata.tables["IMF.medewerker"]
SECTOR = metadata.tables["IMF.ref_sector"]
FUNCTIE = metadata.tables["IMF.ref_functie"]
VANGNET = metadata.tables["IMF.vangnetcategorie"]



#%%


#%%
class GenerateData:
    
    """
    generate a specific number of records to a target table in the
    database.
    """
    
    def __init__(self):
        """
        define command line arguments.
        """
        if sys.argv[1].lower() == "aogeval":
            self.table = "IMF.ao_geval"
        elif sys.argv[1].lower() == "persoon":
            self.table = "IMF.persoon"
        elif sys.argv[1].lower() == "werkgever":
            self.table = "IMF.werkgever"
        elif sys.argv[1].lower() == "medewerker":
            self.table = "IMF.medewerker"
        else:
            print("deze tabel bestaat niet")
        self.num_records = int(sys.argv[2])
    
    def create_data(self):
        """
        using the faker library, generate data and execute DML.
        """
        logging.info('Data creation started')
        
        if self.table not in metadata.tables.keys():
            return print(f"{self.table} does not exist")
    
        if self.table == "IMF.ao_geval":
            with engine.begin() as conn:
                finr = conn.execute(select([PERSOON.c.finr])).fetchall()
                puikid = conn.execute(select([MEDEWERKER.c.puikid])).fetchall()
                
                for _ in range(self.num_records):
                    bdat_ao = faker.date_time_between(start_date='-10y', end_date='now')
                    duur_ao = faker.random_int(min=2, max=730)
                    time_change_ao = datetime.timedelta(days = duur_ao)
                    random_einddatum_ao = bdat_ao + time_change_ao
                    if bdat_ao < (datetime.datetime.now() - datetime.timedelta(days = 730)):
                        edat_ao = [random_einddatum_ao]
                    else:
                        edat_ao = random.choices(['', random_einddatum_ao], [0.4, 0.6])
                    if edat_ao[0] == '':
                         dat_boek_hm = ''
                         dat_ontv_h_meld =''
                         dat_verz_hmeld =''
                    elif edat_ao[0] > datetime.datetime.now():
                         edat_ao[0] = ''
                         dat_boek_hm = ''
                         dat_ontv_h_meld =''
                         dat_verz_hmeld =''
                    else:
                        duur_hm = faker.random_int(min=2, max=30)
                        time_change_hm = datetime.timedelta(days = duur_hm)
                        dat_boek_hm = random_einddatum_ao + time_change_hm
                        dat_ontv_h_meld = dat_boek_hm + time_change_hm
                        dat_verz_hmeld = dat_ontv_h_meld + time_change_hm 
                    cd_cat_vangnet = int(random.choice(['2', '5', '6', '7', '8', '9', '12', '88', '99', '301', '302', '1', '4', '10', '12', '99']))
                    
                    insert_stmt = AOGEVAL.insert().values(
                        volgnr_ao = faker.unique.bothify(text='##########'),
                        bdat_ao = bdat_ao,
                        edat_ao = edat_ao[0],
                        dat_boek_hm = dat_boek_hm,
                        code_reden_hm = random.randrange(30),
                        cd_toel_reden_hm = random.randrange(40),
                        cd_bron_hm = random.randrange(10),
                        cd_wijze_ontv_hm = random.randrange(3),
                        cd_proces_hmel = random.randrange(10),
                        nr_inbreng_hmel = faker.bothify(text='######'),
                        dat_ontv_h_meld = dat_ontv_h_meld,
                        dat_verz_hmeld = dat_verz_hmeld,
                        cd_diagnose_nw = faker.bothify(text='#####'),
                        cd_cat_vangnet = cd_cat_vangnet,
                        finr = random.choice(finr)[0],
                        puikid = random.choice(puikid)[0]
                        )
                    conn.execute(insert_stmt)
            logging.info(f"{self.num_records} records are generated in table: {self.table}")
            


        if self.table == "IMF.persoon":
           with engine.begin() as conn:
               districtkantoor = conn.execute(select([DK.c.nr_dk])).fetchall()
               
               for _ in range(self.num_records):
                   nr_opdrg = conn.execute(select([WERKGEVER.c.nr_opdrg])).fetchall()
                   geslacht_choice = random.choices(['M','V',faker.bothify(text='??'),faker.bothify(text='?')], [0.4, 0.4, 0.1, 0.1])
                   list_functies = ['Vast contract', 'tijdelijk contract', 'onbekend', 'uitzendkracht']
                   finr_persoon = faker.unique.ssn()
                   
                   insert_stmt_persoon = PERSOON.insert().values(
                       finr = finr_persoon,
                       gebdat = faker.date_of_birth(None,18,66),
                       nm_persoon = faker.name(),
                       geslacht = geslacht_choice[0],
                       nr_dk = random.choice(districtkantoor)[0],
                       )
                   insert_stmt_dienstverband = DIENSTVERBAND.insert().values(
                       cd_contract = faker.unique.bothify(text='########'),
                       bdat_dv = faker.date_this_decade(),
                       edat_dv = '',
                       finr = finr_persoon,
                       nr_opdrg = random.choice(nr_opdrg)[0],
                       soort_dienstverband = random.choice(list_functies)
                       )
                   conn.execute(insert_stmt_persoon)
                   conn.execute(insert_stmt_dienstverband)
           logging.info(f"{self.num_records} records are generated in table: {self.table} en IMF.dienstverband")

        if self.table == "IMF.werkgever":
           with engine.begin() as conn:
               nr_sector = conn.execute(select([SECTOR.c.cd_sector])).fetchall()
               
               for _ in range(self.num_records):
                                      
                   insert_stmt = WERKGEVER.insert().values(
                       nr_opdrg = faker.unique.bothify(text='??########', letters='ABCDEFGHIJKLMNOPQRSTUVWXYZ'),
                       nm_werkgever = faker.company(),
                       kvk = faker.unique.bothify(text='########'),
                       cd_sector = random.choice(nr_sector)[0]
                       )
                   conn.execute(insert_stmt)
           logging.info(f"{self.num_records} records are generated in table: {self.table}")

        if self.table == "IMF.medewerker":
           with engine.begin() as conn:
               nr_dk = conn.execute(select([DK.c.nr_dk])).fetchall()
               cd_functie = conn.execute(select([FUNCTIE.c.cd_functie])).fetchall()
               
               
               for _ in range(self.num_records):
                   
                   geslacht_choice = random.choices(['M','V',faker.bothify(text='??'),faker.bothify(text='?')], [0.4, 0.4, 0.1, 0.1])
                   startdat_dv = faker.date_this_century()
                   duur_dienstverband = faker.random_int(min=8, max=800)
                   time_change_dv = datetime.timedelta(weeks = duur_dienstverband)
                   random_einddatum_dv = startdat_dv + time_change_dv
                   if random_einddatum_dv > date.today():
                       edat_dv = ''
                   else:
                       edat_dv = random_einddatum_dv
                                                         
                   insert_stmt = MEDEWERKER.insert().values(
                       puikid = faker.unique.bothify(text='??####', letters='ABCDEFGHIJKLMNOPQRSTUVWXYZ'),
                       nm_medewerker = faker.name(),
                       geslacht = geslacht_choice[0],
                       bdat_dv = startdat_dv,
                       edat_dv = edat_dv,
                       nr_dk = random.choice(nr_dk)[0],
                       cd_functie = random.choice(cd_functie)[0]
                       )
                   conn.execute(insert_stmt)
           logging.info(f"{self.num_records} records are generated in table: {self.table}")


if __name__ == "__main__":    
    generate_data = GenerateData()   
    generate_data.create_data()
# %%
#from sqlalchemy import Integer, create_engine, select, MetaData, text
#from faker import Faker
#from sqlalchemy import func
#import sys
#import random
#import datetime 
#from datetime import date
#import urllib
#import cx_Oracle
#import logging
#import config
#
#faker = Faker(['nl-NL'])
#
#bdat_dv = faker.date_this_century()
#duur_dienstverband = faker.random_int(min=8, max=800)
#time_change_dv = datetime.timedelta(weeks = duur_dienstverband)
#random_einddatum_dv = bdat_dv + time_change_dv
#if random_einddatum_dv > date.today():
#    edat_dv = ''
#else:
#    edat_dv = random_einddatum_dv
#print(faker.date_this_decade())
#print(edat_dv)
# %%
