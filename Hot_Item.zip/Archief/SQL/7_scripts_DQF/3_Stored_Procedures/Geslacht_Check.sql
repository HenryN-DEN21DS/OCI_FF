CREATE OR REPLACE PROCEDURE META.GESLACHT_CHECK ( SourceTable IN VARCHAR2,
        SourceColumn                                          IN VARCHAR2,
        pkColumn                                              IN VARCHAR2,
        JobName                                               IN VARCHAR2,
        StartPeriod                                           IN DATE    ,
        EndPeriod                                             IN DATE )
AS
Qry           varchar2(500);
HashKey       varchar2(100);
TotalRows     INTEGER;
FaultyRows    INTEGER;
CurrTimestamp TIMESTAMP;
        BEGIN
                EXECUTE IMMEDIATE 'SELECT CURRENT_TIMESTAMP FROM DUAL' INTO CurrTimestamp;
                HashKey := META.GETMD5(JobName || CURRENT_TIMESTAMP || SourceTable || SourceColumn);
                Qry     := 'INSERT INTO META.REPORTING_RESULTS_GESLACHT (VALUE_PK, VALUE_DQ, DATAQUALITY_HK, SYSTEMTIMESTAMP) SELECT ' || pkColumn || ',' || SourceColumn || ', ''' || HashKey || ''',''' || CurrTimestamp || ''' FROM ' || SourceTable || ' WHERE ' || sourceColumn || ' NOT IN(''M'', ''V'')';
                DBMS_OUTPUT.PUT_LINE(QRY);
                EXECUTE IMMEDIATE Qry;
                EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM ' || SourceTable INTO TotalRows;
                Qry := 'SELECT COUNT(*) FROM META.REPORTING_RESULTS_GESLACHT WHERE DATAQUALITY_HK = ' || HashKey;
                EXECUTE IMMEDIATE 'SELECT COUNT(*) FROM META.REPORTING_RESULTS_GESLACHT WHERE DATAQUALITY_HK = ' || '''' || HashKey || '''' INTO FaultyRows;
                EXECUTE IMMEDIATE 'INSERT INTO META.REPORTING_STATS (ROW_COUNT, FAULTY_ROWS, DATAQUALITY_HK, SOURCE_TABLE, DQ_COLUMN, SYSTEMTIMESTAMP, ETL_JOB_NAME, STARTPERIOD, ENDPERIOD) VALUES (:TotalRows, :FaultyRows, :dataquality_hk, :source_table, :dq_column, :current_date, :JobName, :StartPeriod, :EndPeriod)' USING TotalRows,
                FaultyRows                                                                                                                                                                                                                                                                                                                                      ,
                HashKey                                                                                                                                                                                                                                                                                                                                         ,
                SourceTable                                                                                                                                                                                                                                                                                                                                     ,
                SourceColumn                                                                                                                                                                                                                                                                                                                                    ,
                CurrTimestamp                                                                                                                                                                                                                                                                                                                                   ,
                JobName                                                                                                                                                                                                                                                                                                                                         ,                                                                                                                                                                                                                               
                StartPeriod                                                                                                                                                                                                                                                                                                                                     ,
                EndPeriod;
        END GESLACHT_CHECK;

 /