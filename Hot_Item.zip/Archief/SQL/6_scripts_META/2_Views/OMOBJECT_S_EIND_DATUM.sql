CREATE OR REPLACE VIEW META.OMOBJECT_S_EIND_DATUM 
AS 
	with 
		cte 
	as 
	( 
    select 
        sat_tabel.OMOBJECT_H_HASHKEY
    ,   sat_tabel.LAAD_DATUM
    ,	lead(sat_tabel.LAAD_DATUM) over (partition by sat_tabel.OMOBJECT_H_HASHKEY order by sat_tabel.LAAD_DATUM) - INTERVAL '0.000001' SECOND as EIND_DATUM
--,   dateadd(microsecond, -1, lead(sat_tabel.LAAD_DATUM) over (partition by sat_tabel.OMOBJECT_H_HASHKEY order by sat_tabel.LAAD_DATUM)) as EIND_DATUM
    ,   sat_tabel.EVENT_DATUM
    ,   lead(sat_tabel.EVENT_DATUM) over (partition by sat_tabel.OMOBJECT_H_HASHKEY order by sat_tabel.EVENT_DATUM, sat_tabel.LAAD_DATUM) as Lead_EVENT_DATUM
    ,   sat_tabel.HASHDIFF, sat_tabel.BRON, sat_tabel.AUDIT_ID, sat_tabel.OM_NAAM, sat_tabel.BEWAARTERMIJN_INGANGSDATUM, sat_tabel.BEWAARTERMIJN, sat_tabel.BEWAARTERMIJN_EENHEID, sat_tabel.IS_VERWIJDERD
    from META.OMOBJECT_S sat_tabel
	)
select 
    OMOBJECT_H_HASHKEY
,   LAAD_DATUM
,	cast(NVL(EIND_DATUM, timestamp'8888-12-31 00:00:00') as timestamp) as EIND_DATUM
--,   cast(ifnull(EIND_DATUM, cast('8888-12-31' as timestamp_ntz(6))) as timestamp_ntz(6)) as EIND_DATUM
,   case
        when EIND_DATUM is NULL
        then 1
        else 0
    end as IS_GELDIG 
,   EVENT_DATUM
,   cast(case 
 	 when Lead_EVENT_DATUM = EVENT_DATUM 
 	 then EVENT_DATUM 
 	 when Lead_EVENT_DATUM is null 
 	 then timestamp'8888-12-31 00:00:00' 
 	 else Lead_EVENT_DATUM - INTERVAL '0.000001' SECOND
 	-- else dateadd(microsecond, -1, Lead_EVENT_DATUM) 
 end as timestamp) as EVENT_EIND_DATUM
,   case 
 	 when Lead_EVENT_DATUM is null 
 	 then 1 
 	 else 0 
 end as IS_GELDIG_EVENT
,   HASHDIFF, BRON, AUDIT_ID, OM_NAAM, BEWAARTERMIJN_INGANGSDATUM, BEWAARTERMIJN, BEWAARTERMIJN_EENHEID, IS_VERWIJDERD
from cte;