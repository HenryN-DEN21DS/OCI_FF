CREATE OR REPLACE VIEW META.DBOBJ_DBOBJ_MS_D_EIND_DATUM 
	AS 
		with 
			cte 
		as 
	( 
    select 
        sat_tabel.DBOBJECT_DBOBJECT_L_HASHKEY, sat_tabel.DIAGRAM_NAAM
    ,   sat_tabel.LAAD_DATUM
    ,   lead(sat_tabel.LAAD_DATUM) over (partition by sat_tabel.DBOBJECT_DBOBJECT_L_HASHKEY, sat_tabel.DIAGRAM_NAAM order by sat_tabel.LAAD_DATUM) - INTERVAL '0.000001' SECOND as EIND_DATUM
    --,   dateadd(microsecond, -1, lead(sat_tabel.LAAD_DATUM) over (partition by sat_tabel.DBOBJECT_DBOBJECT_L_HASHKEY, sat_tabel.DIAGRAM_NAAM order by sat_tabel.LAAD_DATUM)) as EIND_DATUM
    ,   sat_tabel.EVENT_DATUM
    ,   lead(sat_tabel.EVENT_DATUM) over (partition by sat_tabel.DBOBJECT_DBOBJECT_L_HASHKEY, sat_tabel.DIAGRAM_NAAM order by sat_tabel.EVENT_DATUM, sat_tabel.LAAD_DATUM) as Lead_EVENT_DATUM
    ,   sat_tabel.HASHDIFF, sat_tabel.BRON, sat_tabel.AUDIT_ID, sat_tabel.IS_VERWIJDERD
    from META.DBOBJECT_DBOBJECT_MS_DIAGRAM sat_tabel    
	) 
select 
    DBOBJECT_DBOBJECT_L_HASHKEY, DIAGRAM_NAAM
,   LAAD_DATUM
,   cast(nvl(EIND_DATUM, timestamp'8888-12-31 00:00:00') as timestamp) as EIND_DATUM
,   case
        when EIND_DATUM is NULL
        then 1
        else 0
    end as IS_GELDIG 
,   EVENT_DATUM
,   cast(case 
 	 when Lead_EVENT_DATUM = EVENT_DATUM 
 	 then EVENT_DATUM 
 	 when Lead_EVENT_DATUM is null 
 	 then timestamp'8888-12-31 00:00:00' 
 	 else Lead_EVENT_DATUM - INTERVAL '0.000001' SECOND 
 end as timestamp) as EVENT_EIND_DATUM
,   case 
 	 when Lead_EVENT_DATUM is null 
 	 then 1 
 	 else 0 
 end as IS_GELDIG_EVENT
,   HASHDIFF, BRON, AUDIT_ID, IS_VERWIJDERD
from cte;
