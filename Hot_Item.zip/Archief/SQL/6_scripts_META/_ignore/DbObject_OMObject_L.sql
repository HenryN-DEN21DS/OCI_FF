CREATE TABLE  META.DbObject_OMObject_L(
	DbObject_OMObject_L_HashKey char(32) NOT NULL,
	LoadDate TIMESTAMP(6) NOT NULL,
	RecordSource varchar(200) NOT NULL,
	AuditID varchar(50) NOT NULL,
	DbObject_H_HashKey char(32) NOT NULL,
	OMObject_H_HashKey char(32) NOT NULL,
	CONSTRAINT PK_DbObject_OMObject_L  PRIMARY KEY(DbObject_OMObject_L_HashKey),
	CONSTRAINT FK_DbObj_OMObj_L_DbObj_H FOREIGN KEY (DbObject_H_HashKey) REFERENCES META.DbObject_H (DbObject_H_HashKey),
	CONSTRAINT FK_DbObj_OMObj_L_OMObj_H FOREIGN KEY (OMObject_H_HashKey) REFERENCES META.OMObject_H (OMObject_H_HashKey)
);