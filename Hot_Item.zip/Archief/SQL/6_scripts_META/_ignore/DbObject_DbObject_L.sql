

CREATE TABLE  META.DbObject_DbObject_L(
	DbObject_DbObject_L_HashKey char(32) NOT NULL,
	LoadDate TIMESTAMP(6) NOT NULL,
	RecordSource varchar(200) NOT NULL,
	AuditID varchar(50) NOT NULL,
	DbObject_H_HashKey char(32) NOT NULL,
	DbObject_H_HashKey_Verwijst char(32) NOT NULL,
	CONSTRAINT PK_DbObject_DbObject_L  PRIMARY KEY (DbObject_DbObject_L_HashKey),
	CONSTRAINT FK_DbObj_DbObj_L_DbObj_H FOREIGN KEY (DbObject_H_HashKey) REFERENCES META.DbObject_H (DbObject_H_HashKey),
	CONSTRAINT FK_DbObj_DbObj_L_DbObj_H_Verw FOREIGN KEY (DbObject_H_HashKey_Verwijst) REFERENCES META.DbObject_H (DbObject_H_HashKey)
);