CREATE TABLE  META.DbObject_H(
	DbObject_H_HashKey char(32) NOT NULL,
	TabelNaam        VARCHAR (500) NOT NULL,
    SchemaNaam        VARCHAR (500) NOT NULL,
    DatabaseNaam        VARCHAR (500) NOT NULL,	--Toevoeging: IS dit nodig?
	HostNaam        VARCHAR (500) NOT NULL,		--Toevoeging: IS dit nodig?
	LoadDate TIMESTAMP(6) NOT NULL,
	RecordSource varchar(200) NOT NULL,
	AuditID varchar(50) NOT NULL,
	CONSTRAINT PK_DbObject_H  PRIMARY KEY(DbObject_H_HashKey, TabelNaam, SchemaNaam, DatabaseNaam, HostNaam)
);