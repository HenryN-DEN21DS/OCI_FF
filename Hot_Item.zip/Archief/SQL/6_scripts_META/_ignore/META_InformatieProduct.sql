CREATE TABLE  META.META_InformatieProduct (
    InformatieProduct	      VARCHAR (50)  NOT NULL,
    Omschrijving            VARCHAR (255)     NULL,
	Doel                    VARCHAR (255)     NULL,
	Grondslag               VARCHAR (255)     NULL,
    IsOptInVanToepassing    NUMBER (3)       NOT NULL,
	IsOptOutVanToepassing   NUMBER (3)       NOT NULL,
    CONSTRAINT PK_InformatieProduct  PRIMARY KEY (InformatieProduct)
);