CREATE TABLE  META.DbObject_OMObject_S (
    DbObject_OMObject_L_HashKey CHAR (32)     NOT NULL,
    LoadDate                    TIMESTAMP(6) NOT NULL,
    EventDate                   TIMESTAMP(6) NOT NULL,
    EndDate                     TIMESTAMP(6) NULL,
    HashDiff                    CHAR (32)     NOT NULL,
    RecordSource                VARCHAR (200) NOT NULL,
    AuditID                     VARCHAR (50)  NOT NULL,
    IsDeleted                   NUMBER (3)       DEFAULT 0 NOT NULL,
    CONSTRAINT PK_DbObject_OMObject_S  PRIMARY KEY (DbObject_OMObject_L_HashKey, LoadDate),
    CONSTRAINT FK_DbObj_OMObj_S_DbObj_OMObj_L FOREIGN KEY (DbObject_OMObject_L_HashKey) REFERENCES META.DbObject_OMObject_L (DbObject_OMObject_L_HashKey)
);