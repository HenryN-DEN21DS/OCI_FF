CREATE TABLE  META.DbObject_OMObject_MS_Diagram (
    DbObject_OMObject_L_HashKey CHAR (32)     NOT NULL,
    DiagramNaam                 VARCHAR (500) NOT NULL,
    LoadDate                    TIMESTAMP(6) NOT NULL,
    EventDate                   TIMESTAMP(6) NOT NULL,
    EndDate                     TIMESTAMP(6) NULL,
    HashDiff                    CHAR (32)     NOT NULL,
    RecordSource                VARCHAR (200) NOT NULL,
    AuditID                     VARCHAR (50)  NOT NULL,
    IsDeleted                   NUMBER (3)       DEFAULT 0 NOT NULL,
    CONSTRAINT PK_DbObject_OMObject_MS_Dia  PRIMARY KEY (DbObject_OMObject_L_HashKey, DiagramNaam, LoadDate),
    CONSTRAINT FK_DbOb_OMOb_MS_D_DbOb_OMOb_L FOREIGN KEY (DbObject_OMObject_L_HashKey) REFERENCES META.DbObject_OMObject_L (DbObject_OMObject_L_HashKey)
);