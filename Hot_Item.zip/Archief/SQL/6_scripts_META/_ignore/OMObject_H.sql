CREATE TABLE META.OMObject_H(
	OMObject_H_HashKey char(32) NOT NULL,
	LoadDate TIMESTAMP(6) NOT NULL,
	RecordSource varchar(200) NOT NULL,
	AuditID varchar(50) NOT NULL,
	OMOBJECT_ID varchar(50) NOT NULL,
	CONSTRAINT PK_OMObject_H  PRIMARY KEY (OMObject_H_HashKey)
);