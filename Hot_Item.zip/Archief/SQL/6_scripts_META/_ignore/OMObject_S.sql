CREATE TABLE META.OMObject_S (
    OMObject_H_HashKey        CHAR (32)     NOT NULL,
    LoadDate                  TIMESTAMP(6) NOT NULL,
    EventDate                 TIMESTAMP(6) NOT NULL,
    EndDate                   TIMESTAMP(6) NULL,
    HashDiff                  CHAR (32)     NOT NULL,
    RecordSource              VARCHAR (200) NOT NULL,
    AuditID                   VARCHAR (50)  NOT NULL,
    OM_NAAM                    VARCHAR (500) NULL,
    BewaartermijnIngangsdatum VARCHAR (500) NULL,
    Bewaartermijn             VARCHAR (500) NULL,
    BewaartermijnEenheid      VARCHAR (500) NULL,
    IsDeleted                 NUMBER (3)       DEFAULT 0 NOT NULL,
    CONSTRAINT PK_OMObject_S  PRIMARY KEY (OMObject_H_HashKey, LoadDate),
    CONSTRAINT FK_OMObject_S_OMObject_H FOREIGN KEY (OMObject_H_HashKey) REFERENCES META.OMObject_H (OMObject_H_HashKey)
);