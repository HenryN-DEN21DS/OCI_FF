CREATE TABLE  META.Housekeeping_ToBeDeleted(
    FBDOMNaam   VARCHAR (500)   NOT NULL,
    TabelNaam   VARCHAR (500)   NOT NULL,
    RunDatetime TIMESTAMP(6)   DEFAULT cast(SYSDATE as timestamp(6)) NOT NULL,
    Total       INT             NOT NULL,
    ToBeDeleted INT             NOT NULL,
    Percentage  DECIMAL (18, 2) NOT NULL,
    CONSTRAINT PK_EDW_Housekeeping_ToBeDel  PRIMARY KEY (FBDOMNaam, TabelNaam, RunDatetime)
);