CREATE USER META
  IDENTIFIED BY manager
  DEFAULT TABLESPACE users
  TEMPORARY TABLESPACE temp
  QUOTA UNLIMITED ON users;

GRANT create session TO META;
GRANT create table TO META;
GRANT create view TO META;
GRANT create any trigger TO META;
GRANT create any procedure TO META;
GRANT create sequence TO META;
GRANT create synonym TO META;