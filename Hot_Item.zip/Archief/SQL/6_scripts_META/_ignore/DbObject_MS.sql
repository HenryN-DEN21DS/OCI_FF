CREATE TABLE  META.DbObject_MS (
    DbObject_H_HashKey   CHAR (32)     NOT NULL,
    PARTITIE_AANDUIDING   VARCHAR (50)  NOT NULL,
    LoadDate             TIMESTAMP(6) NOT NULL,
    EventDate            TIMESTAMP(6) NOT NULL,
    EndDate              TIMESTAMP(6) NULL,
    HashDiff             CHAR (32)     NOT NULL,
    RecordSource         VARCHAR (200) NOT NULL,
    AuditID              VARCHAR (50)  NOT NULL,
    BewaartermijnEenheid VARCHAR (50)  NOT NULL,
    Bewaartermijn        INT           NOT NULL,
    IsDeleted            NUMBER (3)       DEFAULT 0 NOT NULL,
    CONSTRAINT PK_DbObject_MS  PRIMARY KEY (DbObject_H_HashKey, PARTITIE_AANDUIDING, LoadDate),
    CONSTRAINT FK_DbObject_MS_DbObject_H FOREIGN KEY (DbObject_H_HashKey) REFERENCES META.DbObject_H (DbObject_H_HashKey)
);