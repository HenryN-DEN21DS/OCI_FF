CREATE OR REPLACE VIEW  META.BEWAARTERMIJNENSTMT_VW AS
WITH CTE_BEWAARTERMIJNEN AS
( SELECT *
  FROM META.BEWAARTERMIJNEN_VW
  WHERE BWT_MAX_DATUM IS NOT NULL  -- ALLEEN OBJECTEN MET EEN VALIDE BEWAARTERMIJN
  AND BWT_DK_ISSUE  IS     NULL  -- GEEN ANDERE DQ ISSUES (BWT SAT GEVONDEN, GEEN PARTITITIE MISMATCH, ETC)
)
, CTE_STMT AS
( SELECT BTN.*
    	, 	CASE
				WHEN BTN.TESCHONENTABELTYPE = 'SAT'  THEN 1
				WHEN BTN.TESCHONENTABELTYPE = 'LINK' THEN 2
				WHEN BTN.TESCHONENTABELTYPE = 'HUB'  THEN 3
				WHEN BTN.TESCHONENTABELTYPE = 'BWT'  THEN 4
				ELSE 5
       		END	AS STMT_VOLGORDE
       , 	'INSERT INTO META.HOUSEKEEPING_WORDT_VERWIJDERD (FBDOM_NAAM, TABEL_NAAM, TIJDSTIP_UITGEVOERD, TOTAAL, WORDT_VERWIJDERD, PERCENTAGE) '                                 || CHR(10) ||
	        'SELECT SUB.OM_NAAM '                                                                                                                                || CHR(10) ||
			'     , SUB.TABEL_NAAM '                                                                                                                             || CHR(10) ||
			'     , SUB.TIJDSTIP_UITGEVOERD '                                                                                                                           || CHR(10) ||
			'     , SUB.TOTAAL '                                                                                                                                 || CHR(10) ||
			'     , NVL(SUB.WORDT_VERWIJDERD, 0) AS WORDT_VERWIJDERD '                                                                                                 	|| CHR(10) ||
			'     , CASE WHEN SUB.TOTAAL > 0 THEN (CAST(SUB.WORDT_VERWIJDERD  AS DECIMAL(18,2)) / CAST(SUB.TOTAAL  AS DECIMAL(18,2))) * 100 ELSE 0 END AS PERCENTAGE ' || CHR(10) ||
	        '  FROM ( SELECT ''' || BTN.OM_NAAM || ''' AS OM_NAAM' 																		            || CHR(10) ||
			'              , ''' || BTN.TE_SCHONEN_TABEL_SCHEMA || '.' || BTN.TE_SCHONEN_TABEL_NAAM || ''' AS TABEL_NAAM'						                        || CHR(10) ||
			'              , SYSDATE AS TIJDSTIP_UITGEVOERD'																				                            || CHR(10) ||
			'	           , COUNT(*) AS TOTAAL'																							                        || CHR(10) ||
	        '              , SUM(CASE WHEN BWT.' || BTN.BWT_HASHKEY  || ' IS NOT NULL THEN 1 ELSE 0 END) AS WORDT_VERWIJDERD'	                                        || CHR(10) ||
	        '           FROM      ' || BTN.TE_SCHONEN_TABEL_SCHEMA || '.' || BTN.TE_SCHONEN_TABEL_NAAM || ' TGT ' 							                        || CHR(10) ||
			CASE
			 WHEN BTN.BWT_RELATIE_TYPE = 'LINKSAT OP LINK ZONDER BWT SAT'
			      -- EXTRA TUSSENSTAP NODIG
			 THEN '           LEFT JOIN ' || BTN.PARENT_SCHEMA || '.' || BTN.PARENT_NAAM || ' PAR '	                   					                           || CHR(10) ||
			      '                  ON PAR.' || BTN.PARENT_HASHKEY || ' = TGT.' || BTN.TE_SCHONEN_TABEL_HASHKEY	                                                   || CHR(10) ||
	               '           LEFT JOIN ' || BTN.BWT_SCHEMA || '.' || BTN.BWT_NAAM || '_EIND_DATUM BWT '						                                       || CHR(10) ||
			       '                  ON BWT.' || BTN.BWT_HASHKEY || ' = PAR.' || BTN.BWT_HASHKEY  												                   || CHR(10)
			 ELSE '           LEFT JOIN ' || BTN.BWT_SCHEMA || '.' || BTN.BWT_NAAM || '_EIND_DATUM BWT '						                                           || CHR(10) ||
			       '                  ON BWT.' || BTN.BWT_HASHKEY || ' = TGT.' || BTN.BWT_HASHKEY  					                                       || CHR(10)
			END                                                                                                                                                ||
			'                 AND BWT.IS_GELDIG = 1 '                                                                                                          || CHR(10) ||
			'                 AND BWT.INGANGSDATUM_BWT <= TIMESTAMP''' || TO_CHAR(BTN.BWT_MAX_DATUM, 'YYYY-MM-DD HH24:MI:SS') || '''' ||
			CASE
			  -- CHECKEN OF PARTITIE GESPECIFICEERD IS
			 WHEN BTN.TE_SCHONEN_TABEL_PARTITIE IS NOT NULL
			 THEN ' ' || CHR(10) || '                 AND BWT.PARTITIE_AANDUIDING = ''' || BTN.TE_SCHONEN_TABEL_PARTITIE || ''' '
			 ELSE ''
			END                                                                                                                                                 || CHR(10) ||
            '       ) SUB'                                                                                                                                     || CHR(10) || CHR(10)
       AS WORDT_VERWIJDERD_STMT
	   ,	CASE
             -- CHECKEN OF TE SCHONEN TABEL BWT SAT BETREFT
	         WHEN BTN.TESCHONENTABELTYPE = 'BWT'
			      -- DELETE OBV HASHKEYS DIE NIET (MEER) IN PARENT VOORKOMEN; ROBUUSTER DAN OP DATUM
			 THEN 'DELETE'                                                                                                              		|| CHR(10) ||
                  'FROM      ' || BTN.TE_SCHONEN_TABEL_SCHEMA || '.' || BTN.TE_SCHONEN_TABEL_NAAM || ' BWT '                                          || CHR(10) ||
				  'WHERE BWT.' || BTN.BWT_HASHKEY || ' NOT IN (SELECT ' || BTN.PARENT_HASHKEY || ' FROM ' || BTN.PARENT_SCHEMA || '.' || BTN.PARENT_NAAM || ');'
			 ELSE 'DELETE '                                                                                                              	 	|| CHR(10) ||
	              'FROM      ' || BTN.TE_SCHONEN_TABEL_SCHEMA || '.' || BTN.TE_SCHONEN_TABEL_NAAM || ' TGT ' 								         	|| CHR(10) ||
				  'WHERE EXISTS' || CHR(10) ||
	              CASE
					WHEN BTN.BWT_RELATIE_TYPE = 'LINKSAT OP LINK ZONDER BWT SAT'
					     -- EXTRA TUSSENSTAP NODIG
					THEN ' (SELECT ' || BTN.PARENT_HASHKEY																						|| CHR(10) ||
						 ' FROM '   || BTN.PARENT_SCHEMA || '.' || BTN.PARENT_NAAM || ' PAR '	                   					             	|| CHR(10) ||
					     ' INNER JOIN ' || BTN.BWT_SCHEMA || '.' || BTN.BWT_NAAM || '_EIND_DATUM BWT '						                        || CHR(10) ||
			             '            ON BWT.' || BTN.BWT_HASHKEY || ' = PAR.' || BTN.BWT_HASHKEY  											    || CHR(10)
			        ELSE ' (SELECT 	' || BTN.BWT_HASHKEY														 									|| CHR(10) ||
			        	 ' FROM ' || BTN.BWT_SCHEMA || '.' || BTN.BWT_NAAM || '_EIND_DATUM BWT '						                         		|| CHR(10) ||
			        	 ' WHERE 1 = 1'																											|| CHR(10)
				  END                                                                                                                        	||
			      ' AND BWT.IS_GELDIG = 1 '                                                                                           			|| CHR(10) ||
			      ' AND BWT.INGANGSDATUM_BWT <= TIMESTAMP''' || TO_CHAR(BTN.BWT_MAX_DATUM, 'YYYY-MM-DD HH24:MI:SS') || ''''           					||
			      CASE
			        -- CHECKEN OF PARTITIE GESPECIFICEERD IS
			        WHEN BTN.TE_SCHONEN_TABEL_PARTITIE IS NOT NULL
			        THEN ' ' || CHR(10) || ' AND BWT.PARTITIEAANDUID = ''' || BTN.TE_SCHONEN_TABEL_PARTITIE || ''') BWT'
			        ELSE ');'
			      END	|| CHR(10) ||
			      CASE
			      WHEN BTN.BWT_RELATIE_TYPE = 'LINKSAT OP LINK ZONDER BWT SAT'
			      				      	THEN 'WHERE BWT.' || BTN.PARENT_HASHKEY || ' = TGT.' || BTN.TE_SCHONEN_TABEL_HASHKEY || ';'
                	ELSE 'WHERE BWT.' || BTN.BWT_HASHKEY || ' = TGT.' || BTN.TE_SCHONEN_TABEL_HASHKEY || ';'
                  END
            END
		AS VERWIJDER_STMT
		, 	'INSERT INTO META.HOUSEKEEPING_LOG (FBDOM_NAAM, TABEL_NAAM, TIJDSTIP_UITGEVOERD, AANTAL_VERWIJDERD) '                                 || CHR(10) ||
	        'SELECT SUB.OM_NAAM '                                                                                                                                || CHR(10) ||
			'     , SUB.TABEL_NAAM '                                                                                                                             || CHR(10) ||
			'     , SUB.TIJDSTIP_UITGEVOERD '                                                                                                                           || CHR(10) ||
			'     , NVL(SUB.AANTAL_VERWIJDERD, 0) AS AANTAL_VERWIJDERD '                                                                                                 || CHR(10) ||
	        '  FROM ( SELECT ''' || BTN.OM_NAAM || ''' AS OM_NAAM' 																		            || CHR(10) ||
			'              , ''' || BTN.TE_SCHONEN_TABEL_SCHEMA || '.' || BTN.TE_SCHONEN_TABEL_NAAM || ''' AS TABEL_NAAM'						                        || CHR(10) ||
			'              , SYSDATE AS TIJDSTIP_UITGEVOERD'																				                            || CHR(10) ||
	        '              , SUM(CASE WHEN BWT.' || BTN.OM_NAAM  || '_HASHKEY IS NOT NULL THEN 1 ELSE 0 END) AS AANTAL_VERWIJDERD'	                                        || CHR(10) ||
	        '           FROM      ' || BTN.TE_SCHONEN_TABEL_SCHEMA || '.' || BTN.TE_SCHONEN_TABEL_NAAM || ' TGT ' 							                        || CHR(10) ||
			CASE
			 WHEN BTN.BWT_RELATIE_TYPE = 'LINKSAT OP LINK ZONDER BWT SAT'
			      -- EXTRA TUSSENSTAP NODIG
			 THEN '           LEFT JOIN ' || BTN.PARENT_SCHEMA || '.' || BTN.PARENT_NAAM || ' PAR '	                   					                           || CHR(10) ||
			      '                  ON PAR.' || BTN.PARENT_HASHKEY || ' = TGT.' || BTN.TE_SCHONEN_TABEL_HASHKEY	                                                   || CHR(10) ||
	               '           LEFT JOIN ' || BTN.BWT_SCHEMA || '.' || BTN.BWT_NAAM || '_EIND_DATUM BWT '						                                       || CHR(10) ||
			       '                  ON BWT.' || BTN.BWT_HASHKEY || ' = PAR.' || BTN.BWT_HASHKEY  												                   || CHR(10)
			 ELSE '           LEFT JOIN ' || BTN.BWT_SCHEMA || '.' || BTN.BWT_NAAM || '_EIND_DATUM BWT '						                                           || CHR(10) ||
			       '                  ON BWT.' || BTN.BWT_HASHKEY || ' = TGT.' || BTN.BWT_HASHKEY  					                                       		   || CHR(10)
			END                                                                                                                                                	   ||
			'                 AND BWT.IS_GELDIG = 1 '                                                                                                          	   || CHR(10) ||
			'                 AND BWT.INGANGSDATUM_BWT <= TIMESTAMP''' || TO_CHAR(BTN.BWT_MAX_DATUM, 'YYYY-MM-DD HH24:MI:SS') || '''' ||
			CASE
			  -- CHECKEN OF PARTITIE GESPECIFICEERD IS
			 WHEN BTN.TE_SCHONEN_TABEL_PARTITIE IS NOT NULL
			 THEN ' ' || CHR(10) || '                 AND BWT.PARTITIE_AANDUIDING = ''' || BTN.TE_SCHONEN_TABEL_PARTITIE || ''' '
			 ELSE ''
			END                                                                                                                                                 || CHR(10) ||
            '       ) SUB'  
		AS VERWIJDER_LOG_STMT
    FROM CTE_BEWAARTERMIJNEN BTN
)
SELECT *
  FROM CTE_STMT
;