CREATE TABLE  META.OMObject_MS_Diagram (
    OMObject_H_HashKey CHAR (32)     NOT NULL,
    DiagramNaam        VARCHAR (500) NOT NULL,
    LoadDate           TIMESTAMP(6) NOT NULL,
    EventDate          TIMESTAMP(6) NOT NULL,
    EndDate            TIMESTAMP(6) NULL,
    HashDiff           CHAR (32)     NOT NULL,
    RecordSource       VARCHAR (200) NOT NULL,
    AuditID            VARCHAR (50)  NOT NULL,
    IsDeleted          NUMBER (3)       DEFAULT 0 NOT NULL,
    CONSTRAINT PK_OMObject_MS_Diagram  PRIMARY KEY (OMObject_H_HashKey, DiagramNaam, LoadDate),
    CONSTRAINT FK_OMObject_MS_DIA_OMObject_H FOREIGN KEY (OMObject_H_HashKey) REFERENCES META.OMObject_H (OMObject_H_HashKey)
);