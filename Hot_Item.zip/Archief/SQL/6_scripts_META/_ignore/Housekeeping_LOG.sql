CREATE TABLE  META.Housekeeping_LOG (
    FBDOMNaam    VARCHAR (500) NOT NULL,
    TabelNaam    VARCHAR (500) NOT NULL,
    RunDatetime  TIMESTAMP(6) NOT NULL,
    DeletedCount INT           NOT NULL,
    CONSTRAINT PK_EDW_Housekeeping_LOG  PRIMARY KEY (FBDOMNaam, TabelNaam, RunDatetime)
);