CREATE OR REPLACE VIEW RDV_IMF.MEDEWERKER_S_BWT_EIND_DATUM AS 
with cte as 
( 
    select 
        sat_tabel.MEDEWERKER_H_HASHKEY
    ,   sat_tabel.LAAD_DATUM
    ,   lead(sat_tabel.LAAD_DATUM) over (partition by sat_tabel.MEDEWERKER_H_HASHKEY order by sat_tabel.LAAD_DATUM) - INTERVAL '0.000001' SECOND as EIND_DATUM
    ,   null as EVENT_DATUM
    ,   null as Lead_EVENT_DATUM
    ,   sat_tabel.HASHDIFF, sat_tabel.BRON, sat_tabel.AUDIT_ID, sat_tabel.INGANGSDATUM_BWT
    from RDV_IMF.MEDEWERKER_S_BWT sat_tabel
) 
select 
    MEDEWERKER_H_HASHKEY
,   LAAD_DATUM
,   cast(NVL(EIND_DATUM, TIMESTAMP '8888-12-31 00:00:00') as timestamp(6)) as EIND_DATUM
,   case
        when EIND_DATUM is NULL
        then 1
        else 0
    end as IS_GELDIG 
,   LAAD_DATUM as EVENT_DATUM
,   cast(NVL(EIND_DATUM, TIMESTAMP '8888-12-31 00:00:00') as timestamp(6)) as EVENT_EIND_DATUM
,   case 
 	 when EIND_DATUM is null 
 	 then 1 
 	 else 0 
 end as IS_GELDIG_EVENT
,   HASHDIFF, BRON, AUDIT_ID, INGANGSDATUM_BWT
from cte;