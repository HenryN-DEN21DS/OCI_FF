CREATE OR REPLACE PROCEDURE RDV_IMF.GRANT_SELECT(
    username VARCHAR2,
    grantee VARCHAR2)
AS
BEGIN
    FOR r IN (
        SELECT owner, table_name AS tab_name
		FROM all_tables
		WHERE owner = username
		--UNION SELECT owner, view_name AS tab_name FROM all_views WHERE owner = username
    )
    LOOP
        EXECUTE IMMEDIATE
            'GRANT SELECT, INSERT ON '||r.owner||'.'||r.tab_name||' to ' || grantee;
    END LOOP;
END;
/
