CREATE OR REPLACE VIEW STG_META.MAPPINGS_VW (
        MAPPING_SPECIFICATIE_NAAM
      , MAPPING_NAAM
      , SOURCE_NAAM_VOLLEDIG
	  , SOURCE_HOST_NAAM	
	  , SOURCE_DATABASE_NAAM
	  , SOURCE_SCHEMA_NAAM  
	  , SOURCE_TABEL_NAAM   
      , SOURCE_KOLOM_NAAM   
      , TARGET_NAAM_VOLLEDIG
      , TARGET_HOST_NAAM    
      , TARGET_DATABASE_NAAM
      , TARGET_SCHEMA_NAAM  
      , TARGET_TABEL_NAAM   
      , TARGET_KOLOM_NAAM   
      , REGEL_NAAM
      , MAPPING_OMSCHRIJVING
      , EXTRACTIEDATUM_XMETA
      , AUDIT_ID
      , DBATTRIBUUT_H_HASHKEY_SOURCE
      , DBATTRIBUUT_H_HASHKEY_TARGET
      , MAPPING_SPECIFICATIE_H_HK
      , DBATTRIBUUT_DBATTRIBUUT_L_HK
	  , HASHDIFF_MAPPING
	  , BRON
	  , LAAD_DATUM
	  , EIND_DATUM
   )  AS 
WITH CTE AS (
	SELECT
		CAST(upper(ltrim(rtrim(MAPPING_SPECIFICATIE_NAAM))) as varchar(500)) as MAPPINGSPECIFICATIE_BK
	,	MAPPING_NAAM
    , 	SOURCE_NAAM_VOLLEDIG
	,	CAST(upper(ltrim(rtrim(SOURCE_HOST_NAAM))) as varchar(500)) as SOURCE_HOST_NAAM_BK
	,	CAST(upper(ltrim(rtrim(SOURCE_DATABASE_NAAM))) as varchar(500)) as SOURCE_DATABASE_NAAM_BK
	,	CAST(upper(ltrim(rtrim(SOURCE_SCHEMA_NAAM))) as varchar(500)) as SOURCE_SCHEMA_NAAM_BK
	,	CAST(upper(ltrim(rtrim(SOURCE_TABEL_NAAM))) as varchar(500)) as SOURCE_TABEL_NAAM_BK
	,	CAST(upper(ltrim(rtrim(SOURCE_KOLOM_NAAM))) as varchar(500)) as SOURCE_KOLOM_NAAM_BK
    , 	TARGET_NAAM_VOLLEDIG
	,	CAST(upper(ltrim(rtrim(TARGET_HOST_NAAM))) as varchar(500)) as TARGET_HOST_NAAM_BK
	,	CAST(upper(ltrim(rtrim(TARGET_DATABASE_NAAM))) as varchar(500)) as TARGET_DATABASE_NAAM_BK
	,	CAST(upper(ltrim(rtrim(TARGET_SCHEMA_NAAM))) as varchar(500)) as TARGET_SCHEMA_NAAM_BK
	,	CAST(upper(ltrim(rtrim(TARGET_TABEL_NAAM))) as varchar(500)) as TARGET_TABEL_NAAM_BK
	,	CAST(upper(ltrim(rtrim(TARGET_KOLOM_NAAM))) as varchar(500)) as TARGET_KOLOM_NAAM_BK
    , 	REGEL_NAAM
    , 	MAPPING_OMSCHRIJVING
	,	cast(DECODE (trim(EXTRACTIEDATUM_XMETA), '', TIMESTAMP'1900-01-01 00:00:00', EXTRACTIEDATUM_XMETA) as timestamp(6)) as EVENT_DATUM
	FROM STG_META.MAPPINGS_PRESTAGE_VW mpv
	WHERE RowNumber = 1
)
SELECT 
	CTE.*
,	'-1'	as AUDIT_ID
,	CASE
		WHEN
		NVL(SOURCE_HOST_NAAM_BK, '')		|| '|' ||
		NVL(SOURCE_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(SOURCE_SCHEMA_NAAM_BK, '')		|| '|' ||
		NVL(SOURCE_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(SOURCE_KOLOM_NAAM_BK, '')
		= '||||'
		THEN 'ffffffffffffffffffffffffffffffff'
		ELSE
		STG_META.getMD5(
					NVL(SOURCE_HOST_NAAM_BK, '')		|| '|' ||
					NVL(SOURCE_DATABASE_NAAM_BK, '')	|| '|' ||
					NVL(SOURCE_SCHEMA_NAAM_BK, '')		|| '|' ||
					NVL(SOURCE_TABEL_NAAM_BK, '')		|| '|' ||
					NVL(SOURCE_KOLOM_NAAM_BK, '')
					)
	END AS DBATTRIBUUT_H_HASHKEY_SOURCE
,	CASE
		WHEN
		NVL(TARGET_HOST_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(TARGET_SCHEMA_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_KOLOM_NAAM_BK, '')
		= '||||'
		THEN 'ffffffffffffffffffffffffffffffff'
		ELSE
		STG_META.getMD5(
					NVL(TARGET_HOST_NAAM_BK, '')		|| '|' ||
					NVL(TARGET_DATABASE_NAAM_BK, '')	|| '|' ||
					NVL(TARGET_SCHEMA_NAAM_BK, '')		|| '|' ||
					NVL(TARGET_TABEL_NAAM_BK, '')		|| '|' ||
					NVL(TARGET_KOLOM_NAAM_BK, '')
					)
	END AS DBATTRIBUUT_H_HASHKEY_TARGET
,	CASE
		WHEN NVL(MAPPINGSPECIFICATIE_BK, '') = ''
		THEN 'ffffffffffffffffffffffffffffffff'
		ELSE STG_META.getMD5(NVL(MAPPINGSPECIFICATIE_BK, ''))
	END AS MAPPING_SPECIFICATIE_H_HK
,	CASE
		WHEN
		NVL(SOURCE_HOST_NAAM_BK, '')		|| '|' ||
		NVL(SOURCE_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(SOURCE_SCHEMA_NAAM_BK, '')		|| '|' ||
		NVL(SOURCE_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(SOURCE_KOLOM_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_HOST_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(TARGET_SCHEMA_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_KOLOM_NAAM_BK, '')		|| '|' ||
		NVL(MAPPINGSPECIFICATIE_BK, '')
		= '||||||||||'
		THEN 'ffffffffffffffffffffffffffffffff'
		ELSE
		STG_META.getMD5(
					NVL(SOURCE_HOST_NAAM_BK, '')		|| '|' ||
					NVL(SOURCE_DATABASE_NAAM_BK, '')	|| '|' ||
					NVL(SOURCE_SCHEMA_NAAM_BK, '')		|| '|' ||
					NVL(SOURCE_TABEL_NAAM_BK, '')		|| '|' ||
					NVL(SOURCE_KOLOM_NAAM_BK, '')		|| '|' ||
					NVL(TARGET_HOST_NAAM_BK, '')		|| '|' ||
					NVL(TARGET_DATABASE_NAAM_BK, '')	|| '|' ||
					NVL(TARGET_SCHEMA_NAAM_BK, '')		|| '|' ||
					NVL(TARGET_TABEL_NAAM_BK, '')		|| '|' ||
					NVL(TARGET_KOLOM_NAAM_BK, '')		|| '|' ||
					NVL(MAPPINGSPECIFICATIE_BK, '')
					)
	END AS DBATTRIBUUT_DBATTRIBUUT_L_HK
,	STG_META.getMD5(
		NVL(SOURCE_HOST_NAAM_BK, '')		|| '|' ||
		NVL(SOURCE_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(SOURCE_SCHEMA_NAAM_BK, '')		|| '|' ||
		NVL(SOURCE_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(SOURCE_KOLOM_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_HOST_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(TARGET_SCHEMA_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(TARGET_KOLOM_NAAM_BK, '')		|| '|' ||
		NVL(MAPPINGSPECIFICATIE_BK, '')		|| '|' ||
		NVL(MAPPING_NAAM, '') 				|| '|' ||
		NVL(REGEL_NAAM, '') 				|| '|' ||
		NVL(MAPPING_OMSCHRIJVING , '')
	) as HASHDIFF_MAPPING
,	cast('<bron:>' as varchar(200)) as BRON
,	cast(SYSDATE as timestamp(6)) as LAAD_DATUM
,	cast(null as timestamp(6)) as EIND_DATUM
FROM CTE;