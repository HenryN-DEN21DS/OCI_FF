CREATE OR REPLACE VIEW STG_META.DB_ATTRIBUUT_VW AS
with CTE                                        as
    (
        SELECT
            cast(upper(ltrim(rtrim(HOST_NAAM))) as     varchar(500)) as HOST_NAAM_BK
          , cast(upper(ltrim(rtrim(DATABASE_NAAM))) as varchar(500)) as DATABASE_NAAM_BK
          , cast(upper(ltrim(rtrim(TABEL_NAAM))) as    varchar(500)) as TABEL_NAAM_BK
          , cast(upper(ltrim(rtrim(SCHEMA_NAAM))) as   varchar(500)) as SCHEMA_NAAM_BK
          , cast(upper(ltrim(rtrim(KOLOM_NAAM))) as    varchar(500)) as KOLOM_NAAM_BK
          , cast(DECODE (trim(EXTRACTIEDATUM_XMETA), '', TIMESTAMP'1900-01-01 00:00:00', EXTRACTIEDATUM_XMETA) as timestamp(6)) as EVENT_DATUM
          , cast(PARTITIE_AANDUIDING as               varchar(50))  as PARTITIE_AANDUIDING
            --, cast(DATA_TYPE AS varchar(500) AS DATA_TYPE
          , cast(MIN_LENGTE AS      number)       AS MIN_LENGTE
          , CAST(MAX_LENGTE AS      NUMBER)       AS MAX_LENGTE
          , CAST(NULL_TOEGESTAAN AS NUMBER)       AS NULL_TOEGESTAAN
          , CAST(DEFAULT_WAARDE AS  VARCHAR(500)) AS DEFAULT_WAARDE
          , CAST(PRIMARY_KEY AS     VARCHAR(500)) AS PRIMARY_KEY
          , CAST(FOREIGN_KEY AS     VARCHAR(500)) AS FOREIGN_KEY
          , 'ONB'                                 as BESTANDSNAAM
        from
            STG_META.DB_ATTRIBUUT_prestage_vw
        where
            RowNumber = 1
    )
SELECT
    CTE.HOST_NAAM_BK
  , CTE.DATABASE_NAAM_BK
  , CTE.TABEL_NAAM_BK
  , CTE.SCHEMA_NAAM_BK
  , CTE.KOLOM_NAAM_BK
  , CTE.EVENT_DATUM
  , CTE.PARTITIE_AANDUIDING
  , CTE.BESTANDSNAAM
  , CTE.MIN_LENGTE
  , CTE.MAX_LENGTE
  , CTE.NULL_TOEGESTAAN
  , CTE.DEFAULT_WAARDE
  , CTE.PRIMARY_KEY
  , CTE.FOREIGN_KEY
  , '-1' as AUDIT_ID
  , case
        when NVL(HOST_NAAM_BK, '') 		|| '|' ||
			 NVL(DATABASE_NAAM_BK, '') 	|| '|' || 
			 NVL(SCHEMA_NAAM_BK, '') 	|| '|' ||  
			 NVL(TABEL_NAAM_BK, '') = '|||'
            then 'ffffffffffffffffffffffffffffffff'
            else STG_META.getMD5( 
								  NVL(HOST_NAAM_BK, '') 	|| '|' || 
								  NVL(DATABASE_NAAM_BK, '') || '|' || 
								  NVL(SCHEMA_NAAM_BK, '') 	|| '|' || 
								  NVL(TABEL_NAAM_BK, '')
								 )
    END AS DBOBJECT_H_HASHKEY
  , case
        when NVL(HOST_NAAM_BK, '') 		|| '|' || 
			 NVL(DATABASE_NAAM_BK, '') 	|| '|' || 
			 NVL(SCHEMA_NAAM_BK, '') 	|| '|' || 
			 NVL(TABEL_NAAM_BK, '') 	|| '|' || 
			 NVL(KOLOM_NAAM_BK, '') = '||||'
            then 'ffffffffffffffffffffffffffffffff'
            else STG_META.getMD5( 
								  NVL(HOST_NAAM_BK, '') 	|| '|' || 
								  NVL(DATABASE_NAAM_BK, '') || '|' || 
								  NVL(SCHEMA_NAAM_BK, '') 	|| '|' || 
								  NVL(TABEL_NAAM_BK, '') 	|| '|' || 
								  NVL(KOLOM_NAAM_BK, '')
								)
    END AS DBATTRIBUUT_H_HASHKEY
  , case
        when NVL(HOST_NAAM_BK, '') 		|| '|' || 
			 NVL(DATABASE_NAAM_BK, '') 	|| '|' || 
			 NVL(SCHEMA_NAAM_BK, '') 	|| '|' || 
			 NVL(TABEL_NAAM_BK, '') 	|| '|' || 
			 NVL(HOST_NAAM_BK, '') 		|| '|' ||
			 NVL(DATABASE_NAAM_BK, '') 	|| '|' || 
			 NVL(SCHEMA_NAAM_BK, '') 	|| '|' ||
			 NVL(TABEL_NAAM_BK, '') 	|| '|' || 
			 NVL(KOLOM_NAAM_BK, '') = '||||||||'
            then 'ffffffffffffffffffffffffffffffff'
            else STG_META.getMD5( 
								  NVL(HOST_NAAM_BK, '') 	|| '|' || 
								  NVL(DATABASE_NAAM_BK, '') || '|' || 
								  NVL(SCHEMA_NAAM_BK, '') 	|| '|' || 
								  NVL(TABEL_NAAM_BK, '') 	|| '|' || 
								  NVL(HOST_NAAM_BK, '') 	|| '|' || 
								  NVL(DATABASE_NAAM_BK, '') || '|' || 
								  NVL(SCHEMA_NAAM_BK, '') 	|| '|' || 
								  NVL(TABEL_NAAM_BK, '') 	|| '|' || 
								  NVL(KOLOM_NAAM_BK, '')
								)
    END AS DBOBJECT_DBATTRIBUUT_L_HASHKEY
  , STG_META.getMD5( 
					NVL(MIN_LENGTE, '') 		|| '|' || 
					NVL(MAX_LENGTE, '') 		|| '|' || 
					NVL(NULL_TOEGESTAAN, '') 	|| '|' || 
					NVL(DEFAULT_WAARDE, '') 	|| '|' || 
					NVL(PRIMARY_KEY, '') 		|| '|' || 
					NVL(FOREIGN_KEY, '') 
					) AS HASHDIFF_DBATTRIBUUT
  , cast('<bron:>' AS varchar(200))                                                                                                                                                                         as BRON
  , cast(SYSDATE AS   timestamp(6))                                                                                                                                                                         as LAAD_DATUM
  , cast(null AS      timestamp(6))                                                                                                                                                                         as EIND_DATUM
FROM
    CTE
;