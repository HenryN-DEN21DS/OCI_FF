create or replace view STG_META.DB_BWT_Diagram_vw as
with CTE as (
select
	cast(upper(ltrim(rtrim(TABEL_NAAM))) as varchar(500)) as TABEL_NAAM_BK
,	cast(upper(ltrim(rtrim(TABEL_SCHEMA))) as varchar(500)) as TABEL_SCHEMA_BK
,	cast(DECODE (trim(EXTRACTIEDATUM_XMETA), '', TIMESTAMP'1900-01-01 00:00:00', EXTRACTIEDATUM_XMETA) as timestamp(6)) as EVENT_DATUM
,	cast(DIAGRAM_NAAM as varchar(500)) as DIAGRAM_NAAM
,	'ONB' as bestandsnaam
from STG_META.DB_BWT_prestage_vw
)
select
	cte.*
,	'-1'	as AUDIT_ID
,	case
		when 
		NVL(TABEL_SCHEMA_BK, '')			|| '|' ||
		'|' 							|| '|' ||
		NVL(TABEL_NAAM_BK, '') 
		= '|'
		then 'ffffffffffffffffffffffffffffffff'
		else 
		STG_META.getMD5(	
			NVL(TABEL_SCHEMA_BK, '')|| '|' ||
			NVL(TABEL_NAAM_BK, ''))
	END 
	AS DBOBJECT_H_HASHKEY
,	STG_META.getMD5(
		NVL(TABEL_SCHEMA_BK, '') 		|| '|' ||
		NVL(TABEL_NAAM_BK, '') 			|| '|' || 
		NVL(DIAGRAM_NAAM, '')
	) as HASHDIFF_DBOBJECT
,	cast('<bron:>' as varchar(200)) as BRON
,	cast(SYSDATE as timestamp(6)) as LAAD_DATUM
,	cast(null as timestamp(6)) as EIND_DATUM
FROM CTE;