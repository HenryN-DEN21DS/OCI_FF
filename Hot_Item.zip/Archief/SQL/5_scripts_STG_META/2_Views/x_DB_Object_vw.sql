CREATE OR REPLACE VIEW STG_META.DB_OBJECT_VW AS 
  with CTE as (
select
	cast(upper(ltrim(rtrim(HOST_NAAM))) as varchar(500)) as HOST_NAAM_BK
,	cast(upper(ltrim(rtrim(DATABASE_NAAM))) as varchar(500)) as DATABASE_NAAM_BK
,	cast(upper(ltrim(rtrim(TABEL_NAAM))) as varchar(500)) as TABEL_NAAM_BK
,	cast(upper(ltrim(rtrim(SCHEMA_NAAM))) as varchar(500)) as SCHEMA_NAAM_BK
,	cast(DECODE (trim(EXTRACTIEDATUM_XMETA), '', TIMESTAMP'1900-01-01 00:00:00', EXTRACTIEDATUM_XMETA) as timestamp(6)) as EVENT_DATUM
,	cast(PARTITIE_AANDUIDING as varchar(50)) as PARTITIE_AANDUIDING
,	'ONB' as BESTANDSNAAM
from STG_META.DB_OBJECT_prestage_vw
where RowNumber = 1
)
SELECT
	CTE.HOST_NAAM_BK, CTE.DATABASE_NAAM_BK, CTE.TABEL_NAAM_BK, CTE.SCHEMA_NAAM_BK, CTE.EVENT_DATUM, CTE.PARTITIE_AANDUIDING, CTE.BESTANDSNAAM
,	'-1'	as AUDIT_ID
,	case
		when
		NVL(HOST_NAAM_BK, '')			|| '|' ||
		NVL(DATABASE_NAAM_BK, '')		|| '|' ||
		NVL(SCHEMA_NAAM_BK, '')			|| '|' ||
		NVL(TABEL_NAAM_BK, '')
		= '|||'
		then 'ffffffffffffffffffffffffffffffff'
		else
		STG_META.getMD5(
			NVL(HOST_NAAM_BK, '')		|| '|' ||
			NVL(DATABASE_NAAM_BK, '')	|| '|' ||
			NVL(SCHEMA_NAAM_BK, '')		|| '|' ||
			NVL(TABEL_NAAM_BK, ''))
	END
	AS DBOBJECT_H_HASHKEY
,	STG_META.getMD5(
		NVL(HOST_NAAM_BK, '')			|| '|' ||
		NVL(DATABASE_NAAM_BK, '')		|| '|' ||
		NVL(SCHEMA_NAAM_BK, '') 		|| '|' ||
		NVL(TABEL_NAAM_BK, '') 			|| '|' ||
		NVL(PARTITIE_AANDUIDING, '')
	) as HASHDIFF_DBOBJECT
,	cast('<bron:>' as varchar(200)) as BRON
,	cast(SYSDATE as timestamp(6)) as LAAD_DATUM
,	cast(null as timestamp(6)) as EIND_DATUM
FROM CTE;