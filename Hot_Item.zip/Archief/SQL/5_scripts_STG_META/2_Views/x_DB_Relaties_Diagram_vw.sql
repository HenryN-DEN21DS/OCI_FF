create or replace view STG_META.DB_Relaties_Diagram_vw as
with CTE as (
SELECT
	cast(DIAGRAM_NAAM as varchar(500)) as DIAGRAM_NAAM
,	cast(upper(ltrim(rtrim(PARENT_NAAM))) as varchar(500)) as TABEL_NAAM_BK_VerwijstNaar
,	cast(upper(ltrim(rtrim(CHILD_NAAM))) as varchar(500)) as TABEL_NAAM_BK
,	cast(upper(ltrim(rtrim(CHILD_SCHEMA))) as varchar(500)) as TABEL_SCHEMA_BK
,	cast(upper(ltrim(rtrim(PARENT_SCHEMA))) as varchar(500)) as TABEL_SCHEMA_BK_VerwijstNaar
,	cast(DECODE (trim(EXTRACTIEDATUM_XMETA), '', TIMESTAMP'1900-01-01 00:00:00', EXTRACTIEDATUM_XMETA) as timestamp(6)) as EVENT_DATUM
,	'ONB' as bestandsnaam
from STG_META.DB_Relaties_prestage_vw
)
select
	cte.*
,	'-1'	as AUDIT_ID
,	case
		when 
		NVL(TABEL_SCHEMA_BK, '')			|| '|' ||
		'|' 							|| '|' ||
		NVL(TABEL_NAAM_BK, '') 
		= '|'
		then 'ffffffffffffffffffffffffffffffff'
		else 
		STG_META.getMD5(	
			NVL(TABEL_SCHEMA_BK, '')|| '|' ||
			NVL(TABEL_NAAM_BK, ''))
	END 
	AS DBOBJECT_H_HASHKEY
,	case
		when 
		NVL(TABEL_SCHEMA_BK_VerwijstNaar, '')			|| '|' ||
		'|' 											|| '|' ||
		NVL(TABEL_NAAM_BK_VerwijstNaar, '') 
		= '|'
		then 'ffffffffffffffffffffffffffffffff'
		else 
		STG_META.getMD5(	
			NVL(TABEL_SCHEMA_BK_VerwijstNaar, '')		|| '|' ||
			NVL(TABEL_NAAM_BK_VerwijstNaar, ''))
	END 
	AS DBOBJECT_H_HASHKEY_Verwijst
,	STG_META.getMD5(
			NVL(TABEL_SCHEMA_BK, '') 					|| '|' ||
			'|' 										|| '|' ||
			NVL(TABEL_NAAM_BK, '') 						|| '|' ||
			'|' 										|| '|' ||
			NVL(TABEL_SCHEMA_BK_VerwijstNaar, '')		|| '|' ||
			'|' 										|| '|' ||
			NVL(TABEL_NAAM_BK_VerwijstNaar, '')
	)as DBOBJECT_DBOBJECT_L_HASHKEY
,	STG_META.getMD5(
			NVL(TABEL_SCHEMA_BK, '') 					|| '|' ||
			'|' 										|| '|' ||
			NVL(TABEL_NAAM_BK, '')						|| '|' ||
			'|' 										|| '|' ||
			NVL(TABEL_SCHEMA_BK_VerwijstNaar, '')		|| '|' || 
			'|'											|| '|' ||
			NVL(TABEL_NAAM_BK_VerwijstNaar, '') 			|| '|' ||
			NVL(DIAGRAM_NAAM, '') 
		) as HASHDIFF_DBOBJECT_DBOBJECT
,	cast('<bron:>' as varchar(200)) as BRON
,	cast(SYSDATE as timestamp(6)) as LAAD_DATUM
,	cast(null as timestamp(6)) as EIND_DATUM
FROM CTE;