-- XMETA.VW_DB_OBJECTEN_BWT source
CREATE OR REPLACE VIEW XMETA.VW_DB_OBJECTEN_BWT AS
WITH BWT                                        AS
    (
        SELECT
            hs.NAME_XMETA                             AS TABEL_HOST
          , db.NAME_XMETA                             AS TABEL_DATABASE
          , ad.NAME_XMETA                             AS TABEL_SCHEMA
          , A3.NAME_XMETA                             AS TABEL_NAAM
          , RIGHT(A1.XMETA_REPOS_OBJECT_ID_XMETA, 10) AS OMOBJECT_ID
          , A1.NAME_XMETA                             AS OM_NAAM
          , NVL(ac.VALUE_XMETA, ac2.VALUE_XMETA)      AS Bewaartermijn
        FROM
            XMETA.GlossaryExtensions_Classification A0
            INNER JOIN
                XMETA.GlossaryExtensions_BusinessConcept_has_Classification_classifiedBy_BusinessConcept A2
                ON
                    A0.xmeta_repos_object_id_xmeta = A2.classifiedBy_BusinessConcept_xmeta
            INNER JOIN
                XMETA.GlossaryExtensions_BusinessTerm A1
                ON
                    A2.has_Classification_xmeta = A1.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.GlossaryExtensions_Classification_classifies_Object_refFrom_classifies_Object A4
                ON
                    A0.xmeta_repos_object_id_xmeta = A4.classifies_Object_xmeta
            INNER JOIN
                XMETA.ASCLModel_DataCollection A3
                ON
                    A4.refFrom_classifies_Object_xmeta = A3.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.ASCLMODEL_DATASCHEMA ad
                ON
                    A3.CONTAINER_RID = ad.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN
                XMETA.ASCLMODEL_DATABASE db
                ON
                    db.XMETA_REPOS_OBJECT_ID_XMETA = ad.CONTAINER_RID
            INNER JOIN
                XMETA.ASCLMODEL_HOSTSYSTEM hs
                ON
                    hs.XMETA_REPOS_OBJECT_ID_XMETA = db.CONTAINER_RID
            INNER JOIN
                XMETA.VWASCLCUSTOMATTRIBUTE_CUSTOMSINGLEVAL AS vc
                ON
                    vc.OBJECTRID_XMETA = A1.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMATTRIBUTEVAL_OF_CUSTOMATTRIBUTE_REFFROM_OF_CUSTOMATTRIBUTE ac3
                ON
                    vc.XMETA_REPOS_OBJECT_ID_XMETA = ac3.OF_CUSTOMATTRIBUTE_XMETA
            INNER JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMATTRIBUTE a
                ON
                    ac3.REFFROM_OF_CUSTOMATTRIBUTE_XMETA = a.XMETA_REPOS_OBJECT_ID_XMETA
            FULL JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMTEXTVAL ac
                ON
                    vc.XMETA_REPOS_OBJECT_ID_XMETA = ac.XMETA_REPOS_OBJECT_ID_XMETA
            FULL JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMSTRINGVAL ac2
                ON
                    vc.XMETA_REPOS_OBJECT_ID_XMETA = ac2.XMETA_REPOS_OBJECT_ID_XMETA
        WHERE
            a.NAME_XMETA = 'Bewaartermijn'
    )
  , BE AS
    (
        SELECT
            ad.NAME_XMETA                             AS TABEL_SCHEMA
          , A3.NAME_XMETA                             AS TABEL_NAAM
          , RIGHT(A1.XMETA_REPOS_OBJECT_ID_XMETA, 10) AS OMOBJECT_ID
          , A1.NAME_XMETA                             AS OM_NAAM
          , NVL(ac.VALUE_XMETA, ac2.VALUE_XMETA)      AS BEWAARTERMIJN_EENHEID
        FROM
            XMETA.GlossaryExtensions_Classification A0
            INNER JOIN
                XMETA.GlossaryExtensions_BusinessConcept_has_Classification_classifiedBy_BusinessConcept A2
                ON
                    A0.xmeta_repos_object_id_xmeta = A2.classifiedBy_BusinessConcept_xmeta
            INNER JOIN
                XMETA.GlossaryExtensions_BusinessTerm A1
                ON
                    A2.has_Classification_xmeta = A1.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.GlossaryExtensions_Classification_classifies_Object_refFrom_classifies_Object A4
                ON
                    A0.xmeta_repos_object_id_xmeta = A4.classifies_Object_xmeta
            INNER JOIN
                XMETA.ASCLModel_DataCollection A3
                ON
                    A4.refFrom_classifies_Object_xmeta = A3.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.ASCLMODEL_DATASCHEMA ad
                ON
                    A3.CONTAINER_RID = ad.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN
                XMETA.VWASCLCUSTOMATTRIBUTE_CUSTOMSINGLEVAL AS vc
                ON
                    vc.OBJECTRID_XMETA = A1.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMATTRIBUTEVAL_OF_CUSTOMATTRIBUTE_REFFROM_OF_CUSTOMATTRIBUTE ac3
                ON
                    vc.XMETA_REPOS_OBJECT_ID_XMETA = ac3.OF_CUSTOMATTRIBUTE_XMETA
            INNER JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMATTRIBUTE a
                ON
                    ac3.REFFROM_OF_CUSTOMATTRIBUTE_XMETA = a.XMETA_REPOS_OBJECT_ID_XMETA
            FULL JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMTEXTVAL ac
                ON
                    vc.XMETA_REPOS_OBJECT_ID_XMETA = ac.XMETA_REPOS_OBJECT_ID_XMETA
            FULL JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMSTRINGVAL ac2
                ON
                    vc.XMETA_REPOS_OBJECT_ID_XMETA = ac2.XMETA_REPOS_OBJECT_ID_XMETA
        WHERE
            a.NAME_XMETA = 'Bewaartermijn Eenheid'
    )
  , BS AS
    (
        SELECT
            ad.NAME_XMETA                             AS TABEL_SCHEMA
          , A3.NAME_XMETA                             AS TABEL_NAAM
          , RIGHT(A1.XMETA_REPOS_OBJECT_ID_XMETA, 10) AS OMOBJECT_ID
          , A1.NAME_XMETA                             AS OM_NAAM
          , NVL(ac.VALUE_XMETA, ac2.VALUE_XMETA)      AS BEWAARTERMIJN_INGANGSDATUM
        FROM
            XMETA.GlossaryExtensions_Classification A0
            INNER JOIN
                XMETA.GlossaryExtensions_BusinessConcept_has_Classification_classifiedBy_BusinessConcept A2
                ON
                    A0.xmeta_repos_object_id_xmeta = A2.classifiedBy_BusinessConcept_xmeta
            INNER JOIN
                XMETA.GlossaryExtensions_BusinessTerm A1
                ON
                    A2.has_Classification_xmeta = A1.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.GlossaryExtensions_Classification_classifies_Object_refFrom_classifies_Object A4
                ON
                    A0.xmeta_repos_object_id_xmeta = A4.classifies_Object_xmeta
            INNER JOIN
                XMETA.ASCLModel_DataCollection A3
                ON
                    A4.refFrom_classifies_Object_xmeta = A3.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.ASCLMODEL_DATASCHEMA ad
                ON
                    A3.CONTAINER_RID = ad.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN
                XMETA.VWASCLCUSTOMATTRIBUTE_CUSTOMSINGLEVAL AS vc
                ON
                    vc.OBJECTRID_XMETA = A1.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMATTRIBUTEVAL_OF_CUSTOMATTRIBUTE_REFFROM_OF_CUSTOMATTRIBUTE ac3
                ON
                    vc.XMETA_REPOS_OBJECT_ID_XMETA = ac3.OF_CUSTOMATTRIBUTE_XMETA
            INNER JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMATTRIBUTE a
                ON
                    ac3.REFFROM_OF_CUSTOMATTRIBUTE_XMETA = a.XMETA_REPOS_OBJECT_ID_XMETA
            FULL JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMTEXTVAL ac
                ON
                    vc.XMETA_REPOS_OBJECT_ID_XMETA = ac.XMETA_REPOS_OBJECT_ID_XMETA
            FULL JOIN
                XMETA.ASCLCUSTOMATTRIBUTE_CUSTOMSTRINGVAL ac2
                ON
                    vc.XMETA_REPOS_OBJECT_ID_XMETA = ac2.XMETA_REPOS_OBJECT_ID_XMETA
        WHERE
            a.NAME_XMETA = 'Bewaartermijn Startdatum'
    )
SELECT
    CAST(BWT.TABEL_HOST AS                VARCHAR(500))              TABEL_HOST
  , CAST(BWT.TABEL_DATABASE AS            VARCHAR(500))              TABEL_DATABASE
  , CAST(BWT.TABEL_SCHEMA AS              VARCHAR(500))              TABEL_SCHEMA
  , CAST(BWT.TABEL_NAAM AS                VARCHAR(500))              TABEL_NAAM
  , CAST(BWT.OMOBJECT_ID AS               VARCHAR(50))               OMOBJECT_ID
  , CAST(BWT.OM_NAAM AS                   VARCHAR(500))              OM_NAAM
  , CAST(BWT.Bewaartermijn AS             VARCHAR(500))              Bewaartermijn
  , CAST(BE.BEWAARTERMIJN_EENHEID AS      VARCHAR(500))              BEWAARTERMIJN_EENHEID
  , CAST(BS.BEWAARTERMIJN_INGANGSDATUM AS VARCHAR(500))              BEWAARTERMIJN_INGANGSDATUM
  , CAST('A' AS                           VARCHAR(500))              DIAGRAM_NAAM
  , CAST(CURRENT TIMESTAMP AS 			  TIMESTAMP(6)) 			 EXTRACTIEDATUM_XMETA
FROM
    BWT
    JOIN
        BE
        ON
            BWT.TABEL_SCHEMA    = BE.TABEL_SCHEMA
            AND BWT.TABEL_NAAM  = BE.TABEL_NAAM
            AND BWT.OMOBJECT_ID = BE.OMOBJECT_ID
    JOIN
        BS
        ON
            BWT.TABEL_SCHEMA    = BS.TABEL_SCHEMA
            AND BWT.TABEL_NAAM  = BS.TABEL_NAAM
            AND BWT.OMOBJECT_ID = BS.OMOBJECT_ID
;