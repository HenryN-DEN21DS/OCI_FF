CREATE USER STG_META
  IDENTIFIED BY manager
  DEFAULT TABLESPACE users
  TEMPORARY TABLESPACE temp
  QUOTA UNLIMITED ON users;

GRANT create session TO STG_META;
GRANT create table TO STG_META;
GRANT create view TO STG_META;
GRANT create any trigger TO STG_META;
GRANT create any procedure TO STG_META;
GRANT create sequence TO STG_META;
GRANT create synonym TO STG_META;