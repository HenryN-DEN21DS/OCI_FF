CREATE OR REPLACE FUNCTION STG_META.getMD5(in_string IN VARCHAR2)
RETURN VARCHAR2
AS
cln_md5raw RAW(2000);
out_raw RAW(16);
BEGIN
cln_md5raw := utl_raw.Cast_to_raw(Concat(in_string, '|')); dbms_obfuscation_toolkit.Md5(input => cln_md5raw, checksum => out_raw); -- return hex version (32 length)
RETURN Rawtohex(out_raw);
END;