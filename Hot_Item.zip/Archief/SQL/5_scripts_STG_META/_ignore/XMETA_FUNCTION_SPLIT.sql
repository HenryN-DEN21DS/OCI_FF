CREATE FUNCTION XMETA.SPLIT
 (
	 pos       INT
   , delimeter CHAR
   , string    VARCHAR(255)
 ) LANGUAGE SQL RETURNS VARCHAR(255) DETERMINISTIC NO EXTERNAL ACTION
BEGIN
	ATOMIC
	DECLARE x INT;
	DECLARE s INT;
	DECLARE e INT;
	SET x = 0;
	SET s = 0;
	SET e = 0;
	
	WHILE (x < pos) DO
		SET s = locate(delimeter, string, s + 1);
		IF s  = 0 THEN
			RETURN NULL
		END IF;
		SET x = x + 1;
	END WHILE;
	SET e     = locate(delimeter, string, s + 1);
	IF s     >= e THEN
		SET e = LENGTH(string) + 1;
	END IF;
	RETURN SUBSTR(string, s + 1, e - s -1);
END;