  WITH primary_keys AS
    (
        SELECT
            df.XMETA_REPOS_OBJECT_ID_XMETA      AS DATAFIELD_ID
          , NVL(ac1.NAME_XMETA, ac2.NAME_XMETA) AS PRIMARY_KEY
        FROM
            XMETA.ASCLMODEL_DATAFIELD df
            LEFT JOIN
                XMETA.ASCLMODEL_KEYCOMPONENT ak1
                ON
                    --REGEXP_SUBTR bevat geen spatie maar SOH in de tweede declaratie, '[^]+[^]'
                    --Het is niet te zien in het script. Kopieer naar notepad++ voor SOH karakter.
                    ak1.XMETA_REPOS_OBJECT_ID_XMETA = TO_CHAR(REGEXP_SUBSTR(df.USEDAS_KEYCOMPONENT_XMETA,'[^]+[^]',1,1))
            LEFT JOIN
                XMETA.ASCLMODEL_CANDIDATEKEY ac1
                ON
                    ac1.XMETA_REPOS_OBJECT_ID_XMETA = ak1.OF_KEY_XMETA
            LEFT JOIN
                XMETA.ASCLMODEL_KEYCOMPONENT ak2
                ON
                    ak2.XMETA_REPOS_OBJECT_ID_XMETA = TO_CHAR(REGEXP_SUBSTR(df.USEDAS_KEYCOMPONENT_XMETA,'[^]+[^]',1,1))
            LEFT JOIN
                XMETA.ASCLMODEL_CANDIDATEKEY ac2
                ON
                    ac2.XMETA_REPOS_OBJECT_ID_XMETA = ak2.OF_KEY_XMETA
    )
  , foreign_keys AS
    (
        SELECT
            df.XMETA_REPOS_OBJECT_ID_XMETA      AS DATAFIELD_ID
          , NVL(af1.NAME_XMETA, af2.NAME_XMETA) AS FOREIGN_KEY
          , hs2.NAME_XMETA 						AS FK_PARENT_HOST
          , db2.NAME_XMETA 						AS FK_PARENT_DATABASE
          , ds2.NAME_XMETA 						AS FK_PARENT_SCHEMA
          , dc2.NAME_XMETA 						AS FK_PARENT_NAAM
          , df2.NAME_XMETA 					    AS FK_PARENT_KOLOM
        FROM
            XMETA.ASCLMODEL_DATAFIELD df
            LEFT JOIN
                XMETA.ASCLMODEL_KEYCOMPONENT ak1
                ON
                    ak1.XMETA_REPOS_OBJECT_ID_XMETA = TO_CHAR(REGEXP_SUBSTR(df.USEDAS_KEYCOMPONENT_XMETA,'[^]+[^]',1,1))
            LEFT JOIN
                XMETA.ASCLMODEL_FOREIGNKEY af1
                ON
                    af1.XMETA_REPOS_OBJECT_ID_XMETA = ak1.OF_KEY_XMETA
            LEFT JOIN
                XMETA.ASCLMODEL_KEYCOMPONENT ak2
                ON
                    ak2.XMETA_REPOS_OBJECT_ID_XMETA = TO_CHAR(REGEXP_SUBSTR(df.USEDAS_KEYCOMPONENT_XMETA,'[^]+[^]',1,1))
            LEFT JOIN
                XMETA.ASCLMODEL_FOREIGNKEY af2
                ON
                    af2.XMETA_REPOS_OBJECT_ID_XMETA = ak2.OF_KEY_XMETA
		   LEFT JOIN 
            	XMETA.ASCLMODEL_DATAFIELD df2
            	ON 
            		NVL(ak1.REFERENCES_DATAFIELD_XMETA, ak2.REFERENCES_DATAFIELD_XMETA) = df2.XMETA_REPOS_OBJECT_ID_XMETA
            JOIN
        		XMETA.ASCLMODELDATACOLLECTIN dc2
        		ON
            		dc2.XMETA_REPOS_OBJECT_ID_XMETA = df2.CONTAINER_RID
                    JOIN
		        XMETA.ASCLMODEL_DATASCHEMA ds2
		        ON
		            ds2.XMETA_REPOS_OBJECT_ID_XMETA = dc2.CONTAINER_RID
		    JOIN
		        XMETA.ASCLMODEL_DATABASE db2
		        ON
		            db2.XMETA_REPOS_OBJECT_ID_XMETA = ds2.CONTAINER_RID
		    JOIN
		        XMETA.ASCLMODEL_HOSTSYSTEM hs2
		        ON
		            hs2.XMETA_REPOS_OBJECT_ID_XMETA = db2.CONTAINER_RID
         WHERE NVL(af1.NAME_XMETA, af2.NAME_XMETA) IS NOT NULL
    )
SELECT
    CAST(hs.NAME_XMETA || '.' || db.NAME_XMETA || '.' || ds.NAME_XMETA || '.' || dc.NAME_XMETA || '.' || df.NAME_XMETA AS VARCHAR(500)) AS VOLLEDIGE_NAAM
  , CAST(db.NAME_XMETA || '.' || ds.NAME_XMETA || '.' || dc.NAME_XMETA || '.' || df.NAME_XMETA AS VARCHAR(500)) AS MAPPING_NAAM
  , CAST(hs.NAME_XMETA AS          VARCHAR(500))              AS HOST_NAAM
  , CAST(db.NAME_XMETA AS          VARCHAR(500))              AS DATABASE_NAAM
  , CAST(ds.NAME_XMETA AS          VARCHAR(500))              AS SCHEMA_NAAM
  , CAST(dc.name_XMETA AS          VARCHAR(500))              AS TABEL_NAAM
  , CAST(df.NAME_XMETA AS          VARCHAR(500))              AS KOLOM_NAAM
  , CAST(df.DEFAULTVALUE_XMETA AS  VARCHAR(100))              AS DEFAULT_WAARDE
  , CAST(df.MINIMUMLENGTH_XMETA AS INTEGER)                   AS MIN_LENGTE
  , CAST(df.MAXIMUMLENGTH_XMETA AS INTEGER)                   AS MAX_LENGTE
  , CAST(df.ISNULLABLE_XMETA AS    SMALLINT)                  AS NULL_TOEGESTAAN
  , CAST(pk.PRIMARY_KEY AS         VARCHAR(500))              AS PRIMARY_KEY 
  , CAST(fk.FOREIGN_KEY AS         VARCHAR(500))              AS FOREIGN_KEY
  , CAST(fk.FK_PARENT_HOST AS 	   VARCHAR(500))              AS FK_PARENT_HOST
  , CAST(fk.FK_PARENT_DATABASE AS  VARCHAR(500))          	  AS FK_PARENT_DATABASE
  , CAST(fk.FK_PARENT_SCHEMA AS    VARCHAR(500))              AS FK_PARENT_SCHEMA
  , CAST(fk.FK_PARENT_NAAM AS 	   VARCHAR(500))              AS FK_PARENT_NAAM
  , CAST(fk.FK_PARENT_KOLOM AS 	   VARCHAR(500))              AS FK_PARENT_KOLOM
  , CAST(CURRENT_TIMESTAMP AS 	   TIMESTAMP(6)) 			  AS EXTRACTIEDATUM_XMETA
FROM
    XMETA.ASCLMODEL_DATAFIELD df
    JOIN
        XMETA.ASCLMODELDATACOLLECTIN dc
        ON
            dc.XMETA_REPOS_OBJECT_ID_XMETA = df.CONTAINER_RID
	
    JOIN
        XMETA.ASCLMODEL_DATASCHEMA ds
        ON
            ds.XMETA_REPOS_OBJECT_ID_XMETA = dc.CONTAINER_RID
    JOIN
        XMETA.ASCLMODEL_DATABASE db
        ON
            db.XMETA_REPOS_OBJECT_ID_XMETA = ds.CONTAINER_RID
    JOIN
        XMETA.ASCLMODEL_HOSTSYSTEM hs
        ON
            hs.XMETA_REPOS_OBJECT_ID_XMETA = db.CONTAINER_RID
    LEFT JOIN
        primary_keys pk
        ON
            df.XMETA_REPOS_OBJECT_ID_XMETA = pk.DATAFIELD_ID
    LEFT JOIN
        foreign_keys fk
        ON
            df.XMETA_REPOS_OBJECT_ID_XMETA = fk.DATAFIELD_ID
    WHERE ds.NAME_XMETA = 'INT_ZWA_PO'