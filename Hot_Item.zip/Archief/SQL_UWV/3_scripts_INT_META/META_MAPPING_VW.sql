CREATE OR REPLACE FORCE EDITIONABLE VIEW INT_ZWA_META.META_MAPPING_VW (
        MAPPING_SPECIFICATIE_NAAM
      , MAPPING_NAAM
      , BRON_NAAM_VOLLEDIG
	  , BRON_HOST_NAAM	
	  , BRON_DATABASE_NAAM
	  , BRON_SCHEMA_NAAM  
	  , BRON_TABEL_NAAM   
      , BRON_KOLOM_NAAM   
      , DOEL_NAAM_VOLLEDIG
      , DOEL_HOST_NAAM    
      , DOEL_DATABASE_NAAM
      , DOEL_SCHEMA_NAAM  
      , DOEL_TABEL_NAAM   
      , DOEL_KOLOM_NAAM   
      , REGEL_NAAM
      , MAPPING_OMSCHRIJVING
      , DIM_DATUM_AANMAAK
      , AUDIT_ID
      , DIM_DBATTRIBUUT_H_HK_BRON
      , DIM_DBATTRIBUUT_H_HK_DOEL
      , DIM_MAPPING_SPEC_H_HK
      , DIM_DBATTR_DBATTR_L_HK
	  , DIM_HASHDIFF_MAPPING
	  , DIM_BRON
	  , LAAD_DATUM
	  , DIM_EIND_DATUM
   )  AS 
WITH CTE AS (
	SELECT
		CAST(upper(ltrim(rtrim(MAPPING_SPECIFICATIE_NAAM))) as varchar(500)) as MAPPINGSPECIFICATIE_BK
	,	MAPPING_NAAM
    , 	BRON_NAAM_VOLLEDIG
	,	CAST(upper(ltrim(rtrim(BRON_HOST_NAAM))) as varchar(500)) as BRON_HOST_NAAM_BK
	,	CAST(upper(ltrim(rtrim(BRON_DATABASE_NAAM))) as varchar(500)) as BRON_DATABASE_NAAM_BK
	,	CAST(upper(ltrim(rtrim(BRON_SCHEMA_NAAM))) as varchar(500)) as BRON_SCHEMA_NAAM_BK
	,	CAST(upper(ltrim(rtrim(BRON_TABEL_NAAM))) as varchar(500)) as BRON_TABEL_NAAM_BK
	,	CAST(upper(ltrim(rtrim(BRON_KOLOM_NAAM))) as varchar(500)) as BRON_KOLOM_NAAM_BK
    , 	DOEL_NAAM_VOLLEDIG
	,	CAST(upper(ltrim(rtrim(DOEL_HOST_NAAM))) as varchar(500)) as DOEL_HOST_NAAM_BK
	,	CAST(upper(ltrim(rtrim(DOEL_DATABASE_NAAM))) as varchar(500)) as DOEL_DATABASE_NAAM_BK
	,	CAST(upper(ltrim(rtrim(DOEL_SCHEMA_NAAM))) as varchar(500)) as DOEL_SCHEMA_NAAM_BK
	,	CAST(upper(ltrim(rtrim(DOEL_TABEL_NAAM))) as varchar(500)) as DOEL_TABEL_NAAM_BK
	,	CAST(upper(ltrim(rtrim(DOEL_KOLOM_NAAM))) as varchar(500)) as DOEL_KOLOM_NAAM_BK
    , 	REGEL_NAAM
    , 	MAPPING_OMSCHRIJVING
	,	cast(DECODE (trim(DIM_DATUM_AANMAAK), '', TIMESTAMP'1900-01-01 00:00:00', DIM_DATUM_AANMAAK) as timestamp(6)) as EVENT_DATUM
	FROM INT_ZWA_META.STG_META_MAPPING_VW mpv
	WHERE RowNumber = 1
)
SELECT 
	CTE.*
,	'-1'	as DIM_AUDIT_ID
,	CASE
		WHEN
		NVL(BRON_HOST_NAAM_BK, '')		|| '|' ||
		NVL(BRON_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(BRON_SCHEMA_NAAM_BK, '')	|| '|' ||
		NVL(BRON_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(BRON_KOLOM_NAAM_BK, '')
		= '||||'
		THEN 'ffffffffffffffffffffffffffffffff'
		ELSE
		CAST(STANDARD_HASH((
					NVL(BRON_HOST_NAAM_BK, '')		|| '|' ||
					NVL(BRON_DATABASE_NAAM_BK, '')	|| '|' ||
					NVL(BRON_SCHEMA_NAAM_BK, '')	|| '|' ||
					NVL(BRON_TABEL_NAAM_BK, '')		|| '|' ||
					NVL(BRON_KOLOM_NAAM_BK, '')
					), 'MD5') AS CHAR(32))
	END AS DIM_DBATTRIBUUT_H_HK_BRON
,	CASE
		WHEN
		NVL(DOEL_HOST_NAAM_BK, '')		|| '|' ||
		NVL(DOEL_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(DOEL_SCHEMA_NAAM_BK, '')	|| '|' ||
		NVL(DOEL_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(DOEL_KOLOM_NAAM_BK, '')
		= '||||'
		THEN 'ffffffffffffffffffffffffffffffff'
		ELSE
		CAST(STANDARD_HASH((
					NVL(DOEL_HOST_NAAM_BK, '')		|| '|' ||
					NVL(DOEL_DATABASE_NAAM_BK, '')	|| '|' ||
					NVL(DOEL_SCHEMA_NAAM_BK, '')	|| '|' ||
					NVL(DOEL_TABEL_NAAM_BK, '')		|| '|' ||
					NVL(DOEL_KOLOM_NAAM_BK, '')
					), 'MD5') AS CHAR(32))
	END AS DIM_DBATTRIBUUT_H_HK_DOEL
,	CASE
		WHEN NVL(MAPPINGSPECIFICATIE_BK, '') = ''
		THEN 'ffffffffffffffffffffffffffffffff'
		ELSE CAST(STANDARD_HASH(NVL(MAPPINGSPECIFICATIE_BK, ''), 'MD5') AS CHAR(32))
	END AS DIM_MAPPING_SPEC_H_HK
,	CASE
		WHEN
		NVL(BRON_HOST_NAAM_BK, '')		|| '|' ||
		NVL(BRON_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(BRON_SCHEMA_NAAM_BK, '')	|| '|' ||
		NVL(BRON_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(BRON_KOLOM_NAAM_BK, '')		|| '|' ||
		NVL(DOEL_HOST_NAAM_BK, '')		|| '|' ||
		NVL(DOEL_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(DOEL_SCHEMA_NAAM_BK, '')	|| '|' ||
		NVL(DOEL_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(DOEL_KOLOM_NAAM_BK, '')		|| '|' ||
		NVL(MAPPINGSPECIFICATIE_BK, '')
		= '||||||||||'
		THEN 'ffffffffffffffffffffffffffffffff'
		ELSE
		CAST(STANDARD_HASH((
					NVL(BRON_HOST_NAAM_BK, '')		|| '|' ||
					NVL(BRON_DATABASE_NAAM_BK, '')	|| '|' ||
					NVL(BRON_SCHEMA_NAAM_BK, '')	|| '|' ||
					NVL(BRON_TABEL_NAAM_BK, '')		|| '|' ||
					NVL(BRON_KOLOM_NAAM_BK, '')		|| '|' ||
					NVL(DOEL_HOST_NAAM_BK, '')		|| '|' ||
					NVL(DOEL_DATABASE_NAAM_BK, '')	|| '|' ||
					NVL(DOEL_SCHEMA_NAAM_BK, '')	|| '|' ||
					NVL(DOEL_TABEL_NAAM_BK, '')		|| '|' ||
					NVL(DOEL_KOLOM_NAAM_BK, '')		|| '|' ||
					NVL(MAPPINGSPECIFICATIE_BK, '')
					), 'MD5') AS CHAR(32))
	END AS DIM_DBATTR_DBATTR_L_HK
,	STANDARD_HASH((
		NVL(BRON_HOST_NAAM_BK, '')		|| '|' ||
		NVL(BRON_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(BRON_SCHEMA_NAAM_BK, '')	|| '|' ||
		NVL(BRON_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(BRON_KOLOM_NAAM_BK, '')		|| '|' ||
		NVL(DOEL_HOST_NAAM_BK, '')		|| '|' ||
		NVL(DOEL_DATABASE_NAAM_BK, '')	|| '|' ||
		NVL(DOEL_SCHEMA_NAAM_BK, '')	|| '|' ||
		NVL(DOEL_TABEL_NAAM_BK, '')		|| '|' ||
		NVL(DOEL_KOLOM_NAAM_BK, '')		|| '|' ||
		NVL(MAPPINGSPECIFICATIE_BK, '')	|| '|' ||
		NVL(MAPPING_NAAM, '') 			|| '|' ||
		NVL(REGEL_NAAM, '') 			|| '|' ||
		NVL(MAPPING_OMSCHRIJVING , '')
	), 'MD5') as DIM_HASHDIFF_MAPPING
,	cast('<bron:>' as varchar(200)) as BRON
,	cast(SYSDATE as timestamp(6)) as LAAD_DATUM
,	cast(null as timestamp(6)) as DIM_EIND_DATUM
FROM CTE;