  CREATE OR REPLACE FORCE EDITIONABLE VIEW "INT_ZWA_META"."XMETA_VW_MAPPINGEXTENSION" ("MAPPINGSPEC_NAME", "MAPPING_NAME", "SOURCE_FULLNAME", "SOURCE_TABLE", "SOURCE_COLUMN", "TARGET_FULLNAME", "TARGET_TABLE", "TARGET_COLUMN", "RULE_NAME", "DESCRIPTION") AS 
  SELECT
        -- mm.CONTAINER_RID
        --, mpd.XMETA_REPOS_OBJECT_ID_XMETA
        CAST(mpd.NAME_XMETA AS varchar(255)) AS MAPPINGSPEC_NAME ,
        CAST(mm.NAME_XMETA AS  varchar(255)) AS MAPPING_NAME
        --, SUBSTR(mm.SOURCES_XMETA, 2, LENGTH(mm.SOURCES_XMETA) - 2) AS CLEAN_SOURCE
                                                                                  ,
        CAST(md_source.OBJECTIDENTIFIER_XMETA AS                                                                                    varchar(255)) AS SOURCE_FULLNAME ,
        TO_CHAR(regexp_substr(md_source.OBJECTIDENTIFIER_XMETA, '[^.]+[^.]+', 1, 3)) || '.' || TO_CHAR(regexp_substr(md_source.OBJECTIDENTIFIER_XMETA, '[^.]+[^.]+', 1, 4)) AS SOURCE_TABLE,
        CAST(md_source.OBJECTNAME_XMETA AS                                                                                          varchar(255)) AS SOURCE_COLUMN   
        --, SUBSTR(mm.TARGETS_XMETA, 2, LENGTH(mm.TARGETS_XMETA) - 2) AS CLEAN_TARGET
                                                                                  ,
        CAST(md_target.OBJECTIDENTIFIER_XMETA AS                                                                                  varchar(255)) AS TARGET_FULLNAME ,
        TO_CHAR(regexp_substr(md_source.OBJECTIDENTIFIER_XMETA, '[^.]+[^.]+', 1, 3)) || '.' || TO_CHAR(regexp_substr(md_source.OBJECTIDENTIFIER_XMETA, '[^.]+[^.]+', 1, 4)) AS TARGET_TABLE,
        
        CAST(md_target.OBJECTNAME_XMETA AS                                                                                        varchar(255)) AS TARGET_COLUMN   ,
        CAST(mm.XFORM_XMETA AS                                                                                                    varchar(255)) AS RULE_NAME       ,
        CAST(mm.DESCRIPTION_XMETA AS                                                                                              varchar(255)) AS DESCRIPTION
FROM
        XMETA.MWBEXTENSIONS_MAPPING mm
JOIN
        XMETA.MWBEXTENSIONSMAPPINGDC mpd
ON
        TO_CHAR(mm.CONTAINER_RID) = TO_CHAR(mpd.XMETA_REPOS_OBJECT_ID_XMETA)
JOIN
        XMETA.MWBEXTENSNSMPPNGDSGNTR md_source
ON
        TO_CHAR(SUBSTR(mm.SOURCES_XMETA, 2, 64)) = TO_CHAR(md_source.XMETA_REPOS_OBJECT_ID_XMETA)
JOIN
        XMETA.MWBEXTENSNSMPPNGDSGNTR md_target
ON
        TO_CHAR(SUBSTR(mm.TARGETS_XMETA, 2, 64)) = TO_CHAR(md_target.XMETA_REPOS_OBJECT_ID_XMETA);
