
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "INT_ZWA_META"."XMETA_OM_OBJECTEN_BWT_VW" ("TABEL_HOST", "TABEL_DATABASE", "TABEL_SCHEMA", "TABEL_NAAM", "OMOBJECT_ID", "OM_NAAM", "BEWAARTERMIJN", "BEWAARTERMIJN_EENHEID", "BEWAARTERMIJN_INGANGSDATUM", "AANMAAKDATUM", "MODIFICATIEDATUM",  "EXTRACTIEDATUM_XMETA") AS 
  WITH BWT                                        AS
    (
        SELECT
          hs.NAME_XMETA                                     AS TABEL_HOST
          , db.NAME_XMETA                                   AS TABEL_DATABASE
          , ad.NAME_XMETA                             		AS TABEL_SCHEMA
          , A3.NAME_XMETA                             		AS TABEL_NAAM
          , SUBSTR(A1.XMETA_REPOS_OBJECT_ID_XMETA,-10,10)   AS OMOBJECT_ID
          , A1.NAME_XMETA                            		AS OM_NAAM
          , acs.VALUE_XMETA                                 AS BEWAARTERMIJN
		  , TO_TIMESTAMP('1970-01-01', 'YYYY-MM-DD') + NUMTODSINTERVAL((A1.XMETA_CREATION_TIMESTAMP_XMETA)/1000, 'SECOND')	AS AANMAAKDATUM
		  , TO_TIMESTAMP('1970-01-01', 'YYYY-MM-DD') + NUMTODSINTERVAL((A1.XMETAMODIFICATIONTIMESTAMPXMET)/1000, 'SECOND')	AS MODIFICATIEDATUM
		  , cat.NAME_XMETA									AS CATEGORIE_TERM

        FROM
            XMETA.GLOSSARYXTNSNSCLSSFCTN A0
            INNER JOIN
                XMETA.GCTNCLSSFDBYBSNSSCNCPT A2
                ON
                    A0.xmeta_repos_object_id_xmeta = A2.CLASSIFIEDBYBUSINESSCONCEPTXMT
            INNER JOIN
                XMETA.GLOSSARYXTNSNSBSNSSTRM A1
                ON
                    A2.has_Classification_xmeta = A1.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.GFSBJCTRFFRMCLSSFSBJCT A4
                ON
                    A0.xmeta_repos_object_id_xmeta = A4.classifies_Object_xmeta
            INNER JOIN
                XMETA.ASCLMODELDATACOLLECTIN A3
                ON
                    A4.REFFROMCLASSIFIESOBJECTXMETA = A3.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.ASCLMODEL_DATASCHEMA ad
                ON
                    A3.CONTAINER_RID = ad.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN
                XMETA.ASCLMODEL_DATABASE db
                ON
                    TO_CHAR(db.XMETA_REPOS_OBJECT_ID_XMETA) = TO_CHAR(ad.CONTAINER_RID)
            INNER JOIN
                XMETA.ASCLMODEL_HOSTSYSTEM hs
                ON
                    TO_CHAR(hs.XMETA_REPOS_OBJECT_ID_XMETA) = TO_CHAR(db.CONTAINER_RID)
                      
            INNER JOIN 
                XMETA.GLSSRYXTNSNSBSNSSCTGRY cat
                ON
                    cat.XMETA_REPOS_OBJECT_ID_XMETA = A1.CONTAINER_RID
            
            INNER JOIN 
                XMETA.ASCLCSTMTTRBTCSTMTXTVL ACS
                ON
                    acs.OBJECTRID_XMETA = A1.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN 
                XMETA.AMTTRBTRFFRMFCSTMTTRBT att
                ON
                    att.OF_CUSTOMATTRIBUTE_XMETA = acs.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN 
                XMETA.ASCLCSTMTTRBTCSTMTTRBT ca
                ON
                    ca.XMETA_REPOS_OBJECT_ID_XMETA = att.REFFROMOFCUSTOMATTRIBUTEXMETA
           where ca.NAME_XMETA = 'Bewaartermijn'
    )
  , BE AS
    (
        SELECT
          hs.NAME_XMETA                                     AS TABEL_HOST
          , db.NAME_XMETA                                   AS TABEL_DATABASE
          , ad.NAME_XMETA                             		AS TABEL_SCHEMA
          , A3.NAME_XMETA                             		AS TABEL_NAAM
          , SUBSTR(A1.XMETA_REPOS_OBJECT_ID_XMETA,-10,10)   AS OMOBJECT_ID
          , A1.NAME_XMETA                            		AS OM_NAAM
          , acs.VALUE_XMETA                                 AS BEWAARTERMIJN_EENHEID
		  , cat.NAME_XMETA									AS CATEGORIE_TERM

        FROM
            XMETA.GLOSSARYXTNSNSCLSSFCTN A0
            INNER JOIN
                XMETA.GCTNCLSSFDBYBSNSSCNCPT A2
                ON
                    A0.xmeta_repos_object_id_xmeta = A2.CLASSIFIEDBYBUSINESSCONCEPTXMT
            INNER JOIN
                XMETA.GLOSSARYXTNSNSBSNSSTRM A1
                ON
                    A2.has_Classification_xmeta = A1.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.GFSBJCTRFFRMCLSSFSBJCT A4
                ON
                    A0.xmeta_repos_object_id_xmeta = A4.classifies_Object_xmeta
            INNER JOIN
                XMETA.ASCLMODELDATACOLLECTIN A3
                ON
                    A4.REFFROMCLASSIFIESOBJECTXMETA = A3.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.ASCLMODEL_DATASCHEMA ad
                ON
                    A3.CONTAINER_RID = ad.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN
                XMETA.ASCLMODEL_DATABASE db
                ON
                    TO_CHAR(db.XMETA_REPOS_OBJECT_ID_XMETA) = TO_CHAR(ad.CONTAINER_RID)
            INNER JOIN
                XMETA.ASCLMODEL_HOSTSYSTEM hs
                ON
                    TO_CHAR(hs.XMETA_REPOS_OBJECT_ID_XMETA) = TO_CHAR(db.CONTAINER_RID)
                      
            INNER JOIN 
                XMETA.GLSSRYXTNSNSBSNSSCTGRY cat
                ON
                    cat.XMETA_REPOS_OBJECT_ID_XMETA = A1.CONTAINER_RID
            
            INNER JOIN 
                XMETA.ALCSTMTTRBTCSTMSTRNGVL ACS
                ON
                    acs.OBJECTRID_XMETA = A1.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN 
                XMETA.AMTTRBTRFFRMFCSTMTTRBT att
                ON
                    att.OF_CUSTOMATTRIBUTE_XMETA = acs.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN 
                XMETA.ASCLCSTMTTRBTCSTMTTRBT ca
                ON
                    ca.XMETA_REPOS_OBJECT_ID_XMETA = att.REFFROMOFCUSTOMATTRIBUTEXMETA
           where ca.NAME_XMETA = 'Bewaartermijn Eenheid'
       
    )
  , BS AS
    (
        SELECT
          hs.NAME_XMETA                                     AS TABEL_HOST
          , db.NAME_XMETA                                   AS TABEL_DATABASE
          , ad.NAME_XMETA                             		AS TABEL_SCHEMA
          , A3.NAME_XMETA                             		AS TABEL_NAAM
          , SUBSTR(A1.XMETA_REPOS_OBJECT_ID_XMETA,-10,10)   AS OMOBJECT_ID
          , A1.NAME_XMETA                            		AS OM_NAAM
          , acs.VALUE_XMETA                                 AS BEWAARTERMIJN_INGANGSDATUM
		  , cat.NAME_XMETA									AS CATEGORIE_TERM

        FROM
            XMETA.GLOSSARYXTNSNSCLSSFCTN A0
            INNER JOIN
                XMETA.GCTNCLSSFDBYBSNSSCNCPT A2
                ON
                    A0.xmeta_repos_object_id_xmeta = A2.CLASSIFIEDBYBUSINESSCONCEPTXMT
            INNER JOIN
                XMETA.GLOSSARYXTNSNSBSNSSTRM A1
                ON
                    A2.has_Classification_xmeta = A1.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.GFSBJCTRFFRMCLSSFSBJCT A4
                ON
                    A0.xmeta_repos_object_id_xmeta = A4.classifies_Object_xmeta
            INNER JOIN
                XMETA.ASCLMODELDATACOLLECTIN A3
                ON
                    A4.REFFROMCLASSIFIESOBJECTXMETA = A3.xmeta_repos_object_id_xmeta
            INNER JOIN
                XMETA.ASCLMODEL_DATASCHEMA ad
                ON
                    A3.CONTAINER_RID = ad.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN
                XMETA.ASCLMODEL_DATABASE db
                ON
                    TO_CHAR(db.XMETA_REPOS_OBJECT_ID_XMETA) = TO_CHAR(ad.CONTAINER_RID)
            INNER JOIN
                XMETA.ASCLMODEL_HOSTSYSTEM hs
                ON
                    TO_CHAR(hs.XMETA_REPOS_OBJECT_ID_XMETA) = TO_CHAR(db.CONTAINER_RID)
                      
            INNER JOIN 
                XMETA.GLSSRYXTNSNSBSNSSCTGRY cat
                ON
                    cat.XMETA_REPOS_OBJECT_ID_XMETA = A1.CONTAINER_RID
            
            INNER JOIN 
                XMETA.ASCLCSTMTTRBTCSTMTXTVL ACS
                ON
                    acs.OBJECTRID_XMETA = A1.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN 
                XMETA.AMTTRBTRFFRMFCSTMTTRBT att
                ON
                    att.OF_CUSTOMATTRIBUTE_XMETA = acs.XMETA_REPOS_OBJECT_ID_XMETA
            INNER JOIN 
                XMETA.ASCLCSTMTTRBTCSTMTTRBT ca
                ON
                    ca.XMETA_REPOS_OBJECT_ID_XMETA = att.REFFROMOFCUSTOMATTRIBUTEXMETA
           where ca.NAME_XMETA = 'Bewaartermijn Startdatum'
    )
SELECT
    CAST(BWT.TABEL_HOST AS                VARCHAR(500))              TABEL_HOST
  , CAST(BWT.TABEL_DATABASE AS            VARCHAR(500))              TABEL_DATABASE
  , CAST(BWT.TABEL_SCHEMA AS              VARCHAR(500))              TABEL_SCHEMA
  , CAST(BWT.TABEL_NAAM AS                VARCHAR(500))              TABEL_NAAM
  , CAST(BWT.OMOBJECT_ID AS               VARCHAR(50))               OMOBJECT_ID
  , CAST(BWT.OM_NAAM AS                   VARCHAR(500))              OM_NAAM
  , CAST(BWT.BEWAARTERMIJN AS             VARCHAR(500))              BEWAARTERMIJN
  , CAST(BE.BEWAARTERMIJN_EENHEID AS      VARCHAR(500))              BEWAARTERMIJN_EENHEID
  , CAST(BS.BEWAARTERMIJN_INGANGSDATUM AS VARCHAR(500))              BEWAARTERMIJN_INGANGSDATUM
--  , CAST('A' AS                           VARCHAR(500))              DIAGRAM_NAAM
  , CAST(BWT.AANMAAKDATUM AS 		  	  TIMESTAMP(6))				 AANMAAKDATUM
  , CAST(BWT.MODIFICATIEDATUM AS 		  TIMESTAMP(6))				 MODIFICATIEDATUM
  , CAST(CURRENT_TIMESTAMP AS 			  TIMESTAMP(6)) 			 EXTRACTIEDATUM_XMETA
FROM
    BWT
    JOIN
        BE
        ON
            BWT.TABEL_SCHEMA    = BE.TABEL_SCHEMA
            AND BWT.TABEL_NAAM  = BE.TABEL_NAAM
            AND BWT.OMOBJECT_ID = BE.OMOBJECT_ID
    JOIN
        BS
        ON
            BWT.TABEL_SCHEMA    = BS.TABEL_SCHEMA
            AND BWT.TABEL_NAAM  = BS.TABEL_NAAM
            AND BWT.OMOBJECT_ID = BS.OMOBJECT_ID;



  GRANT SELECT ON "INT_ZWA_META"."XMETA_OM_OBJECTEN_BWT_VW" TO "RO_INT_ZWA_META";
