## Prerequisites
- Deploymentscript uitgevoerd, IGC bijgewerkt
- Data gecreeerd met de Faker module  


## Metadatamodel vullen
1. Maak de benodigde views op de XMETA database met de scripts:
   1. [XMETA_FUNCTION_SPLIT](SQL/5_scripts_STG_META/_ignore/XMETA_FUNCTION_SPLIT.sql)
   2. [XMETA_VW_DB_ATTRIBUTEN](SQL/5_scripts_STG_META/_ignore/XMETA_VW_DB_ATTRIBUTEN.sql)
   3. [XMETA_VW_DB_OBJECTEN_BWT](SQL/5_scripts_STG_META/_ignore/XMETA_VW_DB_OBJECTEN_BWT.sql)
   4. [XMETA_VW_MAPPINGS](SQL/5_scripts_STG_META/_ignore/XMETA_VW_MAPPINGS.sql)
2. Draai de job P0_PreLoadStageTables in DataStage, deze vult de tabellen in STG_META
   NB. Connectie strings in DataStage moeten nog aangepast en geparametriseerd worden
3. Compile de procedures in STG_META
4. Start de ZZ_MAIN_PROCEDURE in STG_META, deze vult het metadatamodel in META 

## Data verladen
1. Draai de job M00_Main_Seq, deze verlaad de data van IMF naar STG_IMF (waarbij de hashkeys worden gecreeerd), en vervolgens wordt het datavaultmodel geladen in RDV_IMF
   NB. Connectie strings in DataStage moeten nog aangepast en geparametriseerd worden

### Privacy by Design
1. Start de procedures in RDV_IMF SAT_MEDEWERKER_TO_BWT en SAT_PERSOON_TO_BWT om de sat bewaartermijnen voor persoon en medewerker te vullen
2. Nu kan er housekeeping gedaan worden op de bewaartermijnen door de procedure USP_HOUSEKEEPING in META te starten. Vul de Querymode in: 'N' om een overzicht te krijgen van wat er gebeurt, 'Y' om daadwerkelijk te verwijderen. De Objectnaam vul je in als 'IMF_*OBJECTNAAM*'.

### Datakwaliteitscontroles (in eerste instantie opgezet om de waarde van de kolom geslacht te checken)
1. Deze kan uitgevoerd worden met de job in DataStage (06 - DataQuality)
2. Of door de procedure GESLACHT_CHECK uit te voeren in META, datum als volgt invoeren: DATE 'yyyy-MM-dd' 