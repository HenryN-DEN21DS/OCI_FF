
--------------------------------------------------------
---  ddl for view bdr_taak_dv
--------------------------------------------------------

create or replace force view bdr_taak_dv 
as 
with cte as 
(
	select 
		ht.dim_taak_h_hk 
		, ht.activiteitcode
		, st.activiteit_omschrijving
		, st.dim_is_verwijderd    
	from
		int_zwa_po.dv_taak_h ht
	join int_zwa_po.dv_taak_s_vw st 
	on st.dim_taak_h_hk = ht.dim_taak_h_hk
	where st.dim_is_geldig = 1
)

select 
	  row_number() over(order by dim_taak_h_hk) 						as dim_taak_key 
	, dim_taak_h_hk 													as taak_hashkey
	, activiteitcode 													as taakcode
	, activiteit_omschrijving 											as taak     
from cte
where coalesce(cte.dim_is_verwijderd,0) = 0

union all

select
	dim_id 																as dim_taak_key
	, hashkey 															as taak_hashkey
	, omschrijving_kort 												as taakcode
	, omschrijving_lang 												as taak
from int_zwa_meta.dim_dummy_records_vw;

