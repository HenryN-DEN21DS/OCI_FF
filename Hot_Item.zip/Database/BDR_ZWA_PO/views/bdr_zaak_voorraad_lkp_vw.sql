
--------------------------------------------------------
---  ddl for view bdr_zaak_voorraad_lkp_vw
--------------------------------------------------------

create or replace force view bdr_zaak_voorraad_lkp_vw 							as 
  with snapshots as
  (
  -- welke foto's moeten we nog maken
  select * from bdr_snapshot_dt a
  where 1=1
  --and not exists (select 1 from bdr_zaak_voorraad_stg b where a.dim_snapshot_key = b.dim_snapshot_key)
  and snapshot_type = 'Actueel'
  ),
  actueel as (-- kopie van de prestageview, maar wordt hier uitgevoerd voor de actuele snapshot
	select 
		  sp.dim_datum_key_ultimo_periode 									  as dim_datum_key
		, sp.dim_snapshot_key  
		, zaak.dim_zaak_h_hk				                                  as dim_zaak_h_hk
		, team.dim_team_h_hk				                                  as dim_team_h_hk_verantwoordelijk
		, 1 															      as aantal_voorraad
		, trunc((
			cast(sp.snapshot_datum_tm as date) - 
			cast(zaak.begindatum_ao as date)
			)) 															      as ouderdom
		, trunc((
			cast(sp.snapshot_datum_tm as date) - 
			cast(zaak.begindatum_ao as date)
			)) 															      as verzuimduur_tot_rapportagemoment	
	from
		 int_zwa_po.dv_zaak_h zaak
	join int_zwa_po.dv_zaak_s_vw sat 
        on  sat.dim_zaak_h_hk = zaak.dim_zaak_h_hk
	join snapshots sp 
        on  sp.snapshot_datum between sat.dim_aanmaak_datum and sat.dim_eind_datum
        and coalesce(sat.einddatum_ao, sp.snapshot_datum_tm+1) > sp.snapshot_datum_tm
        and trunc(zaak.begindatum_ao) <= sp.snapshot_datum_tm
	left join int_zwa_po.dv_verantwteambijzaak_l team 
		on team.dim_zaak_h_hk = zaak.dim_zaak_h_hk
	left join int_zwa_po.dv_verantwteambijzaak_s_vw sz 
		on sz.dim_verantwteambijzaak_l_hk = team.dim_verantwteambijzaak_l_hk 
		and sp.snapshot_datum between sz.dim_aanmaak_datum	and sz.dim_eind_datum
	where zaak.begindatum_ao is not null
    and zaak.begindatum_ao >= to_date('01-01-2019', 'DD-MM-YYYY')
)

-- de historie vanuit de stg-tabel
	select 
	  coalesce(stg.dim_datum_key,-1)    												as dim_datum_key
	, coalesce(stg.dim_snapshot_key,-1)  												as dim_snapshot_key
	, coalesce(zaak.dim_zaak_key,-1)    												as dim_zaak_key
	, coalesce(vteam.dim_team_key, -1)													as dim_team_key_verantwoordelijk
	, coalesce(oud.dim_ouderdomscategorie_key,-1) 									    as dim_ouderdomscategorie_key
	, stg.aantal_voorraad												                as aantal_voorraad
	, stg.ouderdom																		as ouderdom
	, stg.verzuimduur_tot_rapportagemoment												as verzuimduur_tot_rapportagemoment

from bdr_zaak_voorraad_stg stg
left join bdr_zaak_dt zaak
	on zaak.zaak_hashkey = stg.dim_zaak_h_hk
left join bdr_team_dt vteam 
	on vteam.team_hashkey = stg.dim_team_h_hk_verantwoordelijk	    
left join bdr_ouderdomscat_voorraad_dt oud 
	on stg.ouderdom between ouderdom_vanaf and ouderdom_tm
    
UNION ALL

--dezelfde code als in eerste union-deel, maar stg vervangen door de actueel-cte
	select 
	  coalesce(stg.dim_datum_key,-1)    												as dim_datum_key
	, coalesce(stg.dim_snapshot_key,-1)  												as dim_snapshot_key
	, coalesce(zaak.dim_zaak_key,-1)    												as dim_zaak_key
	, coalesce(vteam.dim_team_key, -1)													as dim_team_key_verantwoordelijk
	, coalesce(oud.dim_ouderdomscategorie_key,-1) 									    as dim_ouderdomscategorie_key
	, stg.aantal_voorraad												                as aantal_voorraad
	, stg.ouderdom																		as ouderdom
	, stg.verzuimduur_tot_rapportagemoment												as verzuimduur_tot_rapportagemoment

from actueel stg
left join bdr_zaak_dt zaak
	on zaak.zaak_hashkey = stg.dim_zaak_h_hk
left join bdr_team_dt vteam 
	on vteam.team_hashkey = stg.dim_team_h_hk_verantwoordelijk	    
left join bdr_ouderdomscat_voorraad_dt oud 
	on stg.ouderdom between ouderdom_vanaf and ouderdom_tm;

