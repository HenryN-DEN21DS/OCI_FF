
--------------------------------------------------------
---  ddl for view bdr_zaak_dv
--------------------------------------------------------

create or replace force view bdr_zaak_dv 									as 
    with cte as(
	select 
		  hz.dim_zaak_h_hk
        , sz.uzs_aanvraagid
        , sz.uzs_gevalsvolgnr
		, hz.contractcode
		, hz.buitenlandse_instellingsnr
		, hz.begindatum_ao
        , sz.datum_ontvangst_ao_melding
        , sz.datum_boeking_ao
        , sz.eerste_of_tweede_lijn
        , sz.datum_overdracht_ck
        , sz.datum_ziekmeld_door_verzekerde
        , sz.eerste_contactmoment
        , sz.datum_plausibel
        , sz.indicatie_plausibel
        , sz.maximum_datum_ziektewet
        , sz.dat_uda_ezwb
        , sz.dat_nuda_ezwb
        , sz.datum_ontvangst_hersteldmelding
        , sz.datum_boeking_hersteldmelding
        , sz.einddatum_ao
        , sz.code_vangnetcategorie_imf
        , sz.vangnetcategorie_imf
        , sz.code_vangnetcategorie_bb
        , sz.vangnetcategorie_bb
        , sz.code_vangnetcategorie_szw
        , sz.vangnetcategorie_szw
        , sz.code_ag_traject
        , sz.ag_traject
        , sz.code_bron_hersteldmelding
        , sz.bron_hersteldmelding
        , sz.code_uitstroomoorzaak
        , sz.uitstroomoorzaak
        , sz.code_reden_einde_recht
        , sz.reden_einde_recht
        , sz.ind_eigenrisicodrager
        , sz.ind_slapend
        , sz.ind_gdbm

	from
		int_zwa_po.dv_zaak_h hz
	join int_zwa_po.dv_zaak_s_vw sz on hz.dim_zaak_h_hk = sz.dim_zaak_h_hk     
	where sz.dim_is_geldig = 1
	and hz.begindatum_ao >= to_date('01-01-2019', 'DD-MM-YYYY'))

	select 
		  row_number() over(order by dim_zaak_h_hk) 					as dim_zaak_key
		, dim_zaak_h_hk as zaak_hashkey
        , uzs_aanvraagid
        , uzs_gevalsvolgnr
		, contractcode
		, buitenlandse_instellingsnr
		, begindatum_ao
        , datum_ontvangst_ao_melding
        , datum_boeking_ao
        , eerste_of_tweede_lijn
        , datum_overdracht_ck
        , datum_ziekmeld_door_verzekerde
        , eerste_contactmoment
        , datum_plausibel
        , indicatie_plausibel
        , maximum_datum_ziektewet
        , dat_uda_ezwb
        , dat_nuda_ezwb
        , datum_ontvangst_hersteldmelding
        , datum_boeking_hersteldmelding
        , einddatum_ao
        , code_vangnetcategorie_imf
        , vangnetcategorie_imf
        , code_vangnetcategorie_bb
        , vangnetcategorie_bb
        , code_vangnetcategorie_szw
        , vangnetcategorie_szw
        , code_ag_traject
        , ag_traject
        , code_bron_hersteldmelding
        , bron_hersteldmelding
        , code_uitstroomoorzaak
        , uitstroomoorzaak
        , code_reden_einde_recht
        , reden_einde_recht
        , ind_eigenrisicodrager
        , ind_slapend
        , ind_gdbm

	from cte 

	union all

select
		  dim_id 														as dim_zaak_key
		, hashkey 														as zaak_hashkey
		, nummer 														as uzs_aanvraagid
		, nummer 														as uzs_gevalsvolgnr
		, omschrijving_kort 											as contractcode
		, omschrijving_kort 											as buitenlandse_instellingsnr
		, dim_geldig_vanaf 												as begindatum_ao
		, dim_geldig_vanaf 												as datum_ontvangst_ao_melding
		, dim_geldig_vanaf 												as datum_boeking_ao
        , omschrijving_lang                                             as eerste_of_tweede_lijn
		, dim_geldig_vanaf 												as datum_overdracht_ck
		, dim_geldig_vanaf 												as datum_ziekmeld_door_verzekerde
		, dim_geldig_vanaf 												as eerste_contactmoment
		, dim_geldig_vanaf 												as datum_plausibel
		, omschrijving_kort 											as indicatie_plausibel
		, dim_geldig_tm 												as maximum_datum_ziektewet
		, dim_geldig_tm 												as dat_uda_ezwb
		, dim_geldig_tm 												as dat_nuda_ezwb
		, dim_geldig_tm 												as datum_ontvangst_hersteldmelding
		, dim_geldig_tm 												as datum_boeking_hersteldmelding
		, dim_geldig_tm 												as einddatum_ao
		, omschrijving_lang 											as code_vangnetcategorie_imf
		, omschrijving_lang 											as vangnetcategorie_imf
		, omschrijving_lang 											as code_vangnetcategorie_bb
		, omschrijving_lang 											as vangnetcategorie_bb
		, omschrijving_lang 											as code_vangnetcategorie_szw
		, omschrijving_lang 											as vangnetcategorie_szw
		, omschrijving_lang 											as code_ag_traject
		, omschrijving_lang 											as ag_traject
		, omschrijving_lang 											as code_bron_hersteldmelding
		, omschrijving_lang 											as bron_hersteldmelding
		, omschrijving_lang 											as code_uitstroomoorzaak
		, omschrijving_lang 											as uitstroomoorzaak
		, omschrijving_lang 											as code_reden_einde_recht
		, omschrijving_lang 											as reden_einde_recht
		, omschrijving_kort 											as ind_eigenrisicodrager
		, omschrijving_kort 											as ind_slapend
        , omschrijving_kort 											as ind_gdbm
	from int_zwa_meta.dim_dummy_records_vw;
