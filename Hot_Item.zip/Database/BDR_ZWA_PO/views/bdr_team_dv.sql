
--------------------------------------------------------
---  ddl for view bdr_team_dv
--------------------------------------------------------

create or replace force view bdr_team_dv 										as 
  with cte as (
	select 
		  ht.dim_team_h_hk
		, ht.teamnummer
		, st.teamnaam
		, ht.districtskantoor_nr
		, st.districtskantoor_naam
		, st.districtskantoor_sorteervolgnr
		, st.regio_nr
		, st.regio_naam
		, st.regio_sorteervolgnr
		, st.dim_is_verwijderd    
	from
		int_zwa_po.dv_team_h ht
	join int_zwa_po.dv_team_s_vw st on st.dim_team_h_hk = ht.dim_team_h_hk
	where st.dim_is_geldig = 1)

	select 
		  row_number() over(order by dim_team_h_hk ) 					as dim_team_key 
		, dim_team_h_hk as team_hashkey
		, teamnummer
		, teamnaam
		, districtskantoor_nr
		, districtskantoor_naam
		, districtskantoor_sorteervolgnr
		, regio_nr
		, regio_naam
		, regio_sorteervolgnr           
	from cte
	where coalesce(cte.dim_is_verwijderd,0) = 0

	union all

	select
		  dim_id 														as dim_team_key
		, hashkey 														as team_hashkey
		, omschrijving_kort 											as teamnummer
		, omschrijving_lang 											as teamnaam
		, omschrijving_kort 											as districtskantoor_nr
		, omschrijving_lang 											as districtskantoor_naam
		, nummer 														as districtskantoor_sorteervolgnr
		, nummer 														as regio_nr
		, omschrijving_lang 											as regio_naam
		, nummer 														as regio_sorteervolgnr
	from int_zwa_meta.dim_dummy_records_vw;
