
--------------------------------------------------------
---  ddl for view bdr_zaak_uitstroom_vw
--------------------------------------------------------

create or replace force view bdr_zaak_uitstroom_vw 							as 
  with cte as (
	select 
		  coalesce(dz.dim_zaak_key, -1)                                 as dim_zaak_key
		, sp.dim_snapshot_key
		, coalesce(dt.dim_datum_key, -1)    							as dim_datum_key
		, coalesce(vt.dim_team_key, -1)                                 as dim_team_key_verantwoordelijk
		, 1 															as aantal_uitstroom
		, trunc((
			cast(dz.einddatum_ao as date) - 
			cast(hz.begindatum_ao as date)
			)) 															as verzuimduur
	from
		 int_zwa_po.dv_zaak_h hz
	join int_zwa_po.dv_zaak_s_vw sz 
        on  sz.dim_zaak_h_hk = hz.dim_zaak_h_hk      
	join bdr_snapshot_dt sp 
        on  sz.datum_boeking_hersteldmelding between sp.snapshot_datum_vanaf and sp.snapshot_datum_tm 
        and sp.snapshot_datum between sz.dim_aanmaak_datum and sz.dim_eind_datum
	left join int_zwa_po.dv_verantwteambijzaak_l l
        on  l.dim_zaak_h_hk = hz.dim_zaak_h_hk 
    left join int_zwa_po.dv_verantwteambijzaak_s_vw vts
        on l.dim_verantwteambijzaak_l_hk = vts.dim_verantwteambijzaak_l_hk
        and sp.snapshot_datum  between vts.dim_aanmaak_datum and vts.dim_eind_datum
    -- lookups in de dimensies
	left join bdr_zaak_dt dz 
        on  hz.dim_zaak_h_hk = dz.zaak_hashkey
	left join bdr_datum_dt dt 
        on  dt.datum = trunc(sz.datum_boeking_hersteldmelding)
	left join bdr_team_dt vt 
        on  vt.team_hashkey = l.dim_team_h_hk
	where   sz.einddatum_ao is not null 
        and hz.begindatum_ao is not null
        and hz.begindatum_ao >= to_date('01-01-2019', 'DD-MM-YYYY')
)

	select
		  dim_datum_key
		, dim_snapshot_key
		, dim_zaak_key
		, dim_team_key_verantwoordelijk
		, aantal_uitstroom
		, verzuimduur
	from cte;
