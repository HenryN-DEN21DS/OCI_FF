
--------------------------------------------------------
---  ddl for view bdr_taakinzaak_voorraad_lkp_vw
--------------------------------------------------------

  create or replace force view bdr_taakinzaak_voorraad_lkp_vw   as 
  with snapshots as
  (
  -- welke foto's moeten we nog maken
  select * from bdr_snapshot_dt a
  where 1=1
  --and not exists (select 1 from bdr_taakinzaak_voorraad_stg b where a.dim_snapshot_key = b.dim_snapshot_key)
  and snapshot_type = 'Actueel'
  ),
Actueel as
(--dit is een kopie van de definitie in de pstg-view. Hier wordt ie uitgevoerd voor de actuele snapshot
select		
	  coalesce(dat.dim_datum_key,-1)    												as dim_datum_key
	, coalesce(sp.dim_snapshot_key,-1)  												as dim_snapshot_key
	, l.dim_zaak_h_hk            	   													as dim_zaak_h_hk 
	, l.dim_taakinzaak_l_hk 									            			as dim_taakinzaak_l_hk 
	, l.dim_taak_h_hk            		   												as dim_taak_h_hk
	, lt.dim_team_h_hk    												                as dim_team_h_hk_verantwoordelijk
	, l.dim_team_h_hk                 	  												as dim_team_h_hk_taak
	, 1 																                as aantal_voorraad
	, trunc((
		cast(sp.snapshot_datum_tm 		as date) - 
		cast(s.datum_boeking_activiteit as date)
	))                                                                                  as ouderdom
    --select *
from int_zwa_po.dv_taakinzaak_l l
join int_zwa_po.dv_zaak_h zaak on zaak.dim_zaak_h_hk = l.dim_zaak_h_hk
join int_zwa_po.dv_taakinzaak_s_vw s on s.dim_taakinzaak_l_hk = l.dim_taakinzaak_l_hk
join snapshots sp
	on  sp.snapshot_datum_tm >= trunc(l.datum_initiele_boeking_act) 
    and sp.snapshot_datum between s.dim_aanmaak_datum and s.dim_eind_datum                          --fotomoment
    and s.datum_activiteit_plan is not null
    and coalesce(s.datum_activiteit_realisatie, sp.snapshot_datum_tm + 1) >= sp.snapshot_datum_tm --wel gepland, nog niet uitgevoerd.
left join bdr_datum_dt dat 
	on dat.datum = trunc(l.datum_initiele_boeking_act)
left join int_zwa_po.dv_verantwteambijzaak_l lt 
	on lt.dim_zaak_h_hk = l.dim_zaak_h_hk
left join int_zwa_po.dv_verantwteambijzaak_s_vw sz 
	on sz.dim_verantwteambijzaak_l_hk = lt.dim_verantwteambijzaak_l_hk 
	and sp.snapshot_datum between sz.dim_aanmaak_datum	and sz.dim_eind_datum
where 1=1
    and zaak.begindatum_ao >= to_date('01-01-2019', 'DD-MM-YYYY')
)
  select		
	  coalesce(stg.dim_datum_key,-1)    									            as dim_datum_key
	, coalesce(stg.dim_snapshot_key,-1)  												as dim_snapshot_key
	, coalesce(zaak.dim_zaak_key,-1)    												as dim_zaak_key
	, coalesce(tiz.dim_taakinzaak_key,-1) 												as dim_taakinzaak_key 
	, coalesce(taak.dim_taak_key,-1)    												as dim_taak_key
	, coalesce(vteam.dim_team_key, -1)													as dim_team_key_verantwoordelijk
	, coalesce(teamt.dim_team_key,-1)    												as dim_team_key_taak
	, coalesce(oud.dim_ouderdomscategorie_key,-1) 									    as dim_ouderdomscategorie_key
	, stg.aantal_voorraad												                as aantal_voorraad
	, stg.ouderdom																		as ouderdom
	
from bdr_taakinzaak_voorraad_stg stg
left join bdr_taakinzaak_dt tiz
	on stg.dim_taakinzaak_l_hk = tiz.dim_taakinzaak_l_hk
left join bdr_zaak_dt zaak
	on zaak.zaak_hashkey = stg.dim_zaak_h_hk
left join bdr_taak_dt taak 
	on taak.taak_hashkey = stg.dim_taak_h_hk 
left join bdr_team_dt teamt 
	on teamt.team_hashkey = stg.dim_team_h_hk_taak
left join bdr_team_dt vteam 
	on vteam.team_hashkey = stg.dim_team_h_hk_verantwoordelijk	
left join bdr_ouderdomscat_voorraad_dt oud 
	on ouderdom between ouderdom_vanaf and ouderdom_tm
    
UNION ALL

  select		
	  coalesce(stg.dim_datum_key,-1)    									            as dim_datum_key
	, coalesce(stg.dim_snapshot_key,-1)  												as dim_snapshot_key
	, coalesce(zaak.dim_zaak_key,-1)    												as dim_zaak_key
	, coalesce(tiz.dim_taakinzaak_key,-1) 												as dim_taakinzaak_key 
	, coalesce(taak.dim_taak_key,-1)    												as dim_taak_key
	, coalesce(vteam.dim_team_key, -1)													as dim_team_key_verantwoordelijk
	, coalesce(teamt.dim_team_key,-1)    												as dim_team_key_taak
	, coalesce(oud.dim_ouderdomscategorie_key,-1) 									    as dim_ouderdomscategorie_key
	, stg.aantal_voorraad												                as aantal_voorraad
	, stg.ouderdom																		as ouderdom
	
from actueel stg
left join bdr_taakinzaak_dt tiz
	on stg.dim_taakinzaak_l_hk = tiz.dim_taakinzaak_l_hk
left join bdr_zaak_dt zaak
	on zaak.zaak_hashkey = stg.dim_zaak_h_hk
left join bdr_taak_dt taak 
	on taak.taak_hashkey = stg.dim_taak_h_hk 
left join bdr_team_dt teamt 
	on teamt.team_hashkey = stg.dim_team_h_hk_taak
left join bdr_team_dt vteam 
	on vteam.team_hashkey = stg.dim_team_h_hk_verantwoordelijk	
left join bdr_ouderdomscat_voorraad_dt oud 
	on ouderdom between ouderdom_vanaf and ouderdom_tm
;
