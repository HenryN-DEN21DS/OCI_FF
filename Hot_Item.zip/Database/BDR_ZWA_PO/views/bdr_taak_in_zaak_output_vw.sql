
--------------------------------------------------------
---  ddl for view bdr_taak_in_zaak_output_vw
--------------------------------------------------------

create or replace force view bdr_taak_in_zaak_output_vw as 
select		
	  coalesce(dat.dim_datum_key, -1)												   as dim_datum_key
	, coalesce(sp.dim_snapshot_key, -1) 											   as dim_snapshot_key
	, coalesce(zaak.dim_zaak_key, -1) 												   as dim_zaak_key 
	, coalesce(tiz.dim_taakinzaak_key, -1) 											   as dim_taakinzaak_key 
	, coalesce(taak.dim_taak_key, -1) 												   as dim_taak_key
	, coalesce(teamv.dim_team_key, -1) 												   as dim_team_key_verantwoordelijk
	, coalesce(teamt.dim_team_key, -1) 												   as dim_team_key_taak
	, 1 																               as aantal_output
from int_zwa_po.dv_taakinzaak_l l
join int_zwa_po.dv_zaak_h zaak
    on zaak.dim_zaak_h_hk = l.dim_zaak_h_hk
join int_zwa_po.dv_taakinzaak_s_vw stz 
	on stz.dim_taakinzaak_l_hk = stz.dim_taakinzaak_l_hk
join bdr_zwa_po.bdr_snapshot_dt sp 
	on stz.datum_activiteit_realisatie between snapshot_datum_vanaf and snapshot_datum_tm
    and sp.snapshot_datum between stz.dim_aanmaak_datum and stz.dim_eind_datum
left join int_zwa_po.dv_verantwteambijzaak_l lt
	on lt.dim_zaak_h_hk = l.dim_zaak_h_hk
left join int_zwa_po.dv_verantwteambijzaak_s_vw sz 
	on sz.dim_verantwteambijzaak_l_hk = lt.dim_verantwteambijzaak_l_hk 
	and sp.snapshot_datum between sz.dim_aanmaak_datum and sz.dim_eind_datum
left join  bdr_zwa_po.bdr_taakinzaak_dt tiz
	on l.dim_taakinzaak_l_hk = tiz.dim_taakinzaak_l_hk
left join bdr_zwa_po.bdr_datum_dt dat 
	on dat.datum = trunc(stz.datum_activiteit_realisatie)
left join bdr_zwa_po.bdr_zaak_dt zaak 
	on zaak.zaak_hashkey = l.dim_zaak_h_hk
left join bdr_zwa_po.bdr_taak_dt taak 
	on taak.taak_hashkey = l.dim_taak_h_hk  
left join bdr_zwa_po.bdr_team_dt teamv
	on teamv.team_hashkey = lt.dim_team_h_hk 
left join bdr_zwa_po.bdr_team_dt teamt
	on teamt.team_hashkey = l.dim_team_h_hk 
where stz.datum_activiteit_realisatie is not null
    and zaak.begindatum_ao >= to_date('01-01-2019', 'DD-MM-YYYY')
;


