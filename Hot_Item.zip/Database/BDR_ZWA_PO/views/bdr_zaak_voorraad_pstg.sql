
--------------------------------------------------------
---  ddl for view bdr_zaak_voorraad_pstg
--------------------------------------------------------

create or replace force view bdr_zaak_voorraad_pstg as 
  with snapshots as
  (
  -- welke foto's moeten we nog maken
  select * from bdr_snapshot_dt a
  where not exists (select 1 from bdr_zaak_voorraad_stg b where a.dim_snapshot_key = b.dim_snapshot_key)
  and snapshot_type = 'Historisch'
  ),
  cte as (
	select 
		  sp.dim_datum_key_ultimo_periode 									  as dim_datum_key
		, sp.dim_snapshot_key  
		, zaak.dim_zaak_h_hk				                                  as dim_zaak_h_hk
		, team.dim_team_h_hk				                                  as dim_team_h_hk_verantwoordelijk
		, 1 															      as aantal_voorraad
		, trunc((
			cast(sp.snapshot_datum_tm as date) - 
			cast(zaak.begindatum_ao as date)
			)) 															      as ouderdom
		, trunc((
			cast(sp.snapshot_datum_tm as date) - 
			cast(zaak.begindatum_ao as date)
			)) 															      as verzuimduur_tot_rapportagemoment	
	from
		 int_zwa_po.dv_zaak_h zaak
	join int_zwa_po.dv_zaak_s_vw sat 
        on  sat.dim_zaak_h_hk = zaak.dim_zaak_h_hk
	join snapshots sp 
        on  sp.snapshot_datum between sat.dim_aanmaak_datum and sat.dim_eind_datum
        and coalesce(sat.einddatum_ao, sp.snapshot_datum_tm+1) > sp.snapshot_datum_tm
        and trunc(zaak.begindatum_ao) <= sp.snapshot_datum_tm
	left join int_zwa_po.dv_verantwteambijzaak_l team 
		on team.dim_zaak_h_hk = zaak.dim_zaak_h_hk
	left join int_zwa_po.dv_verantwteambijzaak_s_vw sz 
		on sz.dim_verantwteambijzaak_l_hk = team.dim_verantwteambijzaak_l_hk 
		and sp.snapshot_datum between sz.dim_aanmaak_datum	and sz.dim_eind_datum
	where zaak.begindatum_ao is not null
    and zaak.begindatum_ao >= to_date('01-01-2019', 'DD-MM-YYYY')
)

	select
		  dim_datum_key
		, dim_snapshot_key
		, dim_zaak_h_hk
		, dim_team_h_hk_verantwoordelijk
		, aantal_voorraad
		, ouderdom
		, verzuimduur_tot_rapportagemoment

	from cte
