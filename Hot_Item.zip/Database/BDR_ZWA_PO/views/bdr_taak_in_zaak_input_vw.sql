--------------------------------------------------------
--  ddl for view bdr_taak_in_zaak_input_vw
--------------------------------------------------------

create or replace force view bdr_taak_in_zaak_input_vw as 
  
select		
  coalesce(dat.dim_datum_key, -1)				                                      as	dim_datum_key
, sp.dim_snapshot_key												                  as 	dim_snapshot_key
, coalesce(zaak.dim_zaak_key, -1)                                                     as	dim_zaak_key 
, coalesce(tiz.dim_taakinzaak_key, -1)                                                as 	dim_taakinzaak_key 
, coalesce(taak.dim_taak_key, -1) 												      as	dim_taak_key
, coalesce(teamv.dim_team_key, -1)                                                    as	dim_team_key_verantwoordelijk
, coalesce(teamt.dim_team_key, -1)                                                    as	dim_team_key_taak
, 1       		                                                                      as	aantal_input
from int_zwa_po.dv_taakinzaak_l l
join int_zwa_po.dv_zaak_h zaak
    on zaak.dim_zaak_h_hk = l.dim_zaak_h_hk
join int_zwa_po.dv_taakinzaak_s_vw stz                              
        on  stz.dim_taakinzaak_l_hk = l.dim_taakinzaak_l_hk
join bdr_zwa_po.bdr_snapshot_dt sp          						
        on  l.datum_initiele_boeking_act between sp.snapshot_datum_vanaf and sp.snapshot_datum_tm  -- in de rapportageperiode
        and sp.snapshot_datum between stz.dim_aanmaak_datum and stz.dim_eind_datum                 -- de situatie op het moment dat het snapshot gemaakt werd
-- verantwoordelijk team
left join int_zwa_po.dv_verantwteambijzaak_l lt
        on  lt.dim_zaak_h_hk = l.dim_zaak_h_hk
left join int_zwa_po.dv_verantwteambijzaak_s_vw sz 					
        on  sz.dim_verantwteambijzaak_l_hk = lt.dim_verantwteambijzaak_l_hk 
        and sp.snapshot_datum between sz.dim_aanmaak_datum and sz.dim_eind_datum
left join bdr_zwa_po.bdr_team_dt teamv            					
        on  teamv.team_hashkey = lt.dim_team_h_hk 
--
-- team dat de taak uitvoert
left join bdr_zwa_po.bdr_team_dt teamT            					
        on  teamt.team_hashkey = l.dim_team_h_hk 
--
left join bdr_zwa_po.bdr_taakinzaak_dt tiz
        on  l.dim_taakinzaak_l_hk = tiz.dim_taakinzaak_l_hk
left join bdr_zwa_po.bdr_datum_dt dat
        on  dat.datum = trunc(l.datum_initiele_boeking_act)
left join bdr_zwa_po.bdr_zaak_dt zaak
        on  zaak.zaak_hashkey = l.dim_zaak_h_hk
left join bdr_zwa_po.bdr_taak_dt taak
        on  taak.taak_hashkey = l.dim_taak_h_hk  
where stz.datum_activiteit_plan is not null  -- zonder geplande datum noemen we het geen input
    and zaak.begindatum_ao >= to_date('01-01-2019', 'DD-MM-YYYY')
;
