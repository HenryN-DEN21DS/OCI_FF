--------------------------------------------------------
--  Verwijder tabel bdr_zaak_voorraad_stg als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_ZAAK_VOORRAAD_STG')

--------------------------------------------------------
--  DDL for Table bdr_zaak_voorraad_stg
--------------------------------------------------------
create table bdr_zaak_voorraad_stg
(
  	dim_datum_key                   	number not null,
	dim_snapshot_key                	number not null,
	dim_team_h_hk_verantwoordelijk  	varchar2(99 char) not null,
	dim_zaak_h_hk                   	varchar2(99 char) not null,
	aantal_voorraad                 	number default on null 1,
	ouderdom                        	number,
	verzuimduur_tot_rapportagemoment	number
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column bdr_zaak_voorraad_stg.verzuimduur_tot_rapportagemoment is 'Verzuimduur op het moment van deze voorraadbepaling. Er is dus nog geen hersteldmelding!'
/
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index feit_zaak_voorraad_stage_tb_pk_idx on bdr_zaak_voorraad_stg (dim_datum_key, dim_snapshot_key, dim_team_h_hk_verantwoordelijk, dim_zaak_h_hk)
/

--------------------------------------------------------
--  Constraints for Table bdr_zaak_voorraad_stg
--------------------------------------------------------

alter table bdr_zaak_voorraad_stg add constraint feit_zaak_voorraad_stage_tb_pk primary key (dim_datum_key, dim_snapshot_key, dim_team_h_hk_verantwoordelijk, dim_zaak_h_hk) using index feit_zaak_voorraad_stage_tb_pk_idx enable
/