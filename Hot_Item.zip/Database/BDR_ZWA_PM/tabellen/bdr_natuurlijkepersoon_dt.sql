--------------------------------------------------------
--  Verwijder tabel bdr_natuurlijkepersoon_dt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_NATUURLIJKEPERSOON_DT')

--------------------------------------------------------
--  DDL for Table bdr_natuurlijkepersoon_dt
--------------------------------------------------------
create table bdr_natuurlijkepersoon_dt
(
  	dim_natuurlijkepersoon_key    	number not null,
	natuurlijkepersoon_hashkey    	varchar2(99 char) not null,
	bsn                           	varchar2(99 char) not null,
	domicilie_postcode            	varchar2(9 char),
	domicilie_postcode_gebied     	varchar2(9 char),
	geboortedatum                 	timestamp,
	status_persoon                	varchar2(9 char),
	verpleeg_adres_land           	varchar2(99 char),
	verpleeg_adres_land_nr        	varchar2(9 char),
	verpleeg_adres_postcode       	varchar2(9 char),
	verpleeg_adres_postcode_gebied	varchar2(9 char),
	verpleeg_instelling           	varchar2(99 char),
	verpleeg_instelling_code      	varchar2(9 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table bdr_natuurlijkepersoon_dt
--------------------------------------------------------

