--------------------------------------------------------
--  Verwijder tabel etl_hulp_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('ETL_HULP_TB')

--------------------------------------------------------
--  DDL for Table etl_hulp_tb
--------------------------------------------------------
create table etl_hulp_tb
(
  	hashkey	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table etl_hulp_tb
--------------------------------------------------------

