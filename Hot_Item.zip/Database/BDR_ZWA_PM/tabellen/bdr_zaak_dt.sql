--------------------------------------------------------
--  Verwijder tabel bdr_zaak_dt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_ZAAK_DT')

--------------------------------------------------------
--  DDL for Table bdr_zaak_dt
--------------------------------------------------------
create table bdr_zaak_dt
(
  	dim_zaak_key                   	number not null,
	zaak_hashkey                   	varchar2(99 char) not null,
	ag_traject                     	varchar2(99 char),
	begindatum_ao                  	timestamp not null,
	bron_hersteldmelding           	varchar2(99 char),
	buitenlandse_instellingsnr     	varchar2(9 char),
	code_ag_traject                	varchar2(99 char),
	code_bron_hersteldmelding      	varchar2(99 char),
	code_reden_einde_recht         	varchar2(9 char),
	code_uitstroomoorzaak          	varchar2(99 char),
	code_vangnetcategorie_bb       	varchar2(99 char),
	code_vangnetcategorie_imf      	varchar2(99 char),
	code_vangnetcategorie_szw      	varchar2(99 char),
	contractcode                   	varchar2(9 char) not null,
	dat_nuda_ezwb                  	timestamp,
	dat_uda_ezwb                   	timestamp,
	datum_boeking_ao               	timestamp,
	datum_boeking_hersteldmelding  	timestamp,
	datum_ontvangst_ao_melding     	timestamp,
	datum_ontvangst_hersteldmelding	timestamp,
	datum_overdracht_ck            	timestamp,
	datum_plausibel                	timestamp,
	datum_ziekmeld_door_verzekerde 	timestamp,
	eerste_contactmoment           	timestamp,
	eerste_of_tweede_lijn          	varchar2(99 char) not null,
	einddatum_ao                   	timestamp,
	ind_eigenrisicodrager          	varchar2(9 char),
	ind_gdbm                       	varchar2(9 char),
	ind_slapend                    	varchar2(9 char),
	indicatie_plausibel            	varchar2(9 char),
	maximum_datum_ziektewet        	timestamp,
	reden_einde_recht              	varchar2(9 char),
	uitstroomoorzaak               	varchar2(99 char),
	uzs_aanvraagid                 	number,
	uzs_gevalsvolgnr               	number,
	vangnetcategorie_bb            	varchar2(99 char),
	vangnetcategorie_imf           	varchar2(99 char),
	vangnetcategorie_szw           	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column bdr_zaak_dt.contractcode is '00 kenmerk wordt niet toegepast.  
10 Vrijwillig verzekerden                          
15 oud verplicht verzekerden                            
20 Zieke werklozen                                  
40 Krankenkasse                   
41 Belgische zaken                
42 EEG                            
43 Verdragslanden                 
60 Consult SMZ 
NB  Bij 00 is de relatie tussen persoon en ao-geval een 
                         dienstverband, bij de overige is een standaard
                         contract van toepassing.'
/

comment on column bdr_zaak_dt.eerste_contactmoment is 'Een eerste contact telt als eerste contact als Persoon aanwezig was en met een UWV-er sprak.'
/

comment on column bdr_zaak_dt.datum_overdracht_ck is 'Een eerste contact telt als eerste contact als Persoon aanwezig was en met een UWV-er sprak.'
/

comment on column bdr_zaak_dt.datum_plausibel is 'Een eerste contact telt als eerste contact als Persoon aanwezig was en met een UWV-er sprak.'
/

comment on column bdr_zaak_dt.ind_gdbm is 'Geen Duurzaam Benutbare Mogelijkheden'
/

comment on column bdr_zaak_dt.maximum_datum_ziektewet is 'Een eerste contact telt als eerste contact als Persoon aanwezig was en met een UWV-er sprak.'
/

comment on column bdr_zaak_dt.zaak_hashkey is 'Dit attribuut is nodig om vanuit het Feit eenvoudig de juiste dim-key te kunnen opzoeken. Laat dit attribuut niet zien in het gegevensvenster.'
/
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dimensie_zaak_pk_idx on bdr_zaak_dt (dim_zaak_key)
/

--------------------------------------------------------
--  Constraints for Table bdr_zaak_dt
--------------------------------------------------------

alter table bdr_zaak_dt add constraint dimensie_zaak_pk primary key (dim_zaak_key) using index dimensie_zaak_pk_idx enable
/