--------------------------------------------------------
--  Verwijder tabel bdr_team_dt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_TEAM_DT')

--------------------------------------------------------
--  DDL for Table bdr_team_dt
--------------------------------------------------------
create table bdr_team_dt
(
  	dim_team_key                  	number not null,
	team_hashkey                  	varchar2(99 char) not null,
	districtskantoor_naam         	varchar2(99 char),
	districtskantoor_nr           	varchar2(9 char) not null,
	districtskantoor_sorteervolgnr	number,
	regio_naam                    	varchar2(99 char),
	regio_nr                      	number,
	regio_sorteervolgnr           	number,
	teamnaam                      	varchar2(99 char),
	teamnummer                    	varchar2(9 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column bdr_team_dt.team_hashkey is 'Dit attribuut is nodig om vanuit het Feit eenvoudig de juiste dim-key te kunnen opzoeken. Laat dit attribuut niet zien in het gegevensvenster.'
/
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dimensie_team_pk_idx on bdr_team_dt (dim_team_key)
/

--------------------------------------------------------
--  Constraints for Table bdr_team_dt
--------------------------------------------------------

alter table bdr_team_dt add constraint dimensie_team_pk primary key (dim_team_key) using index dimensie_team_pk_idx enable
/