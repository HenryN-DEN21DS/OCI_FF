--------------------------------------------------------
--  Verwijder tabel bdr_snapshot_dt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_SNAPSHOT_DT')

--------------------------------------------------------
--  DDL for Table bdr_snapshot_dt
--------------------------------------------------------
create table bdr_snapshot_dt
(
  	dim_snapshot_key            	number not null,
	dim_datum_key_ultimo_periode	number not null,
	periode_type                	varchar2(99 char),
	snapshot_datum              	timestamp,
	snapshot_datum_tm           	timestamp,
	snapshot_datum_vanaf        	timestamp,
	snapshot_periode            	number,
	snapshot_type               	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column bdr_snapshot_dt.periode_type is 'Maand / Week / Dag'
/

comment on column bdr_snapshot_dt.snapshot_type is 'Historisch / Actueel'
/
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dm_zw_arbo_snapshot_dt_pk_idx on bdr_snapshot_dt (dim_snapshot_key)
/

--------------------------------------------------------
--  Constraints for Table bdr_snapshot_dt
--------------------------------------------------------

alter table bdr_snapshot_dt add constraint dm_zw_arbo_snapshot_dt_pk primary key (dim_snapshot_key) using index dm_zw_arbo_snapshot_dt_pk_idx enable
/