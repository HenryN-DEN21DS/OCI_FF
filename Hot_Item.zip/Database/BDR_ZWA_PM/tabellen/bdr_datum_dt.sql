--------------------------------------------------------
--  Verwijder tabel bdr_datum_dt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_DATUM_DT')

--------------------------------------------------------
--  DDL for Table bdr_datum_dt
--------------------------------------------------------
create table bdr_datum_dt
(
  	dim_datum_key          	number not null,
	dagnaam                	varchar2(9 char),
	dagnummer_jaar         	number,
	dagnummer_maand        	number,
	dagnummer_week         	number,
	datum                  	date,
	eerste_dag_van_de_week 	date,
	feestdag_indicatie     	varchar2(9 char),
	ind_maand_eind         	varchar2(9 char),
	ind_week_begin         	varchar2(9 char),
	ind_weekend            	varchar2(9 char),
	jaar_dagen             	number,
	jaarkwartaal_nummer    	number,
	jaarmaand_nummer       	number,
	jaartal                	number,
	jaartertaal_nummer     	number,
	jaarweek_nummer        	number,
	kwartaal               	varchar2(9 char),
	kwartaal_nummer        	number,
	laatste_dag_van_de_week	date,
	maand_dagen            	number,
	maand_nummer           	number,
	maandnaam              	varchar2(9 char),
	seizoennaam            	varchar2(9 char),
	tertaal                	varchar2(9 char),
	tertaal_nummer         	number,
	week_nummer            	number
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dim_datum_pk_idx on bdr_datum_dt (dim_datum_key)
/

--------------------------------------------------------
--  Constraints for Table bdr_datum_dt
--------------------------------------------------------

alter table bdr_datum_dt add constraint dim_datum_pk primary key (dim_datum_key) using index dim_datum_pk_idx enable
/