--------------------------------------------------------
--  Verwijder tabel bdr_taakinzaak_dt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_TAAKINZAAK_DT')

--------------------------------------------------------
--  DDL for Table bdr_taakinzaak_dt
--------------------------------------------------------
create table bdr_taakinzaak_dt
(
  	dim_taakinzaak_key         	number not null,
	dim_taakinzaak_l_hk        	varchar2(99 char) not null,
	aanleiding_activiteit      	varchar2(99 char),
	aanwezigheid_persoon       	varchar2(99 char),
	code_aanleiding_activiteit 	varchar2(9 char),
	code_aanwezigheid_persoon  	varchar2(9 char),
	code_conclusie_activiteit  	varchar2(9 char),
	code_functie_medewerker    	varchar2(99 char),
	code_status_activiteit     	varchar2(9 char),
	conclusie_activiteit       	varchar2(99 char),
	datum_activiteit_plan      	timestamp,
	datum_activiteit_realisatie	timestamp,
	datum_boeking_activiteit   	timestamp,
	datum_initiele_boeking_act 	timestamp,
	datum_oproep               	timestamp,
	functie_medewerker         	varchar2(99 char),
	naam_medewerker            	varchar2(99 char),
	status_activiteit          	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dimensie_taakinzaak_tb_pk_idx on bdr_taakinzaak_dt (dim_taakinzaak_key)
/

--------------------------------------------------------
--  Constraints for Table bdr_taakinzaak_dt
--------------------------------------------------------

alter table bdr_taakinzaak_dt add constraint dimensie_taakinzaak_tb_pk primary key (dim_taakinzaak_key) using index dimensie_taakinzaak_tb_pk_idx enable
/