--------------------------------------------------------
--  Verwijder tabel bdr_taakinzaak_voorraad_stg als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_TAAKINZAAK_VOORRAAD_STG')

--------------------------------------------------------
--  DDL for Table bdr_taakinzaak_voorraad_stg
--------------------------------------------------------
create table bdr_taakinzaak_voorraad_stg
(
  	dim_datum_key                 	number not null,
	dim_snapshot_key              	number not null,
	dim_taak_h_hk                 	varchar2(99 char) not null,
	dim_taakinzaak_l_hk           	varchar2(99 char) not null,
	dim_team_h_hk_taak            	varchar2(99 char) not null,
	dim_team_h_hk_verantwoordelijk	varchar2(99 char) not null,
	dim_zaak_h_hk                 	varchar2(99 char) not null,
	aantal_voorraad               	number default on null 1,
	ouderdom                      	number
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index feit_taak_in_zaak_voorraad_stage_tb_pk_idx on bdr_taakinzaak_voorraad_stg (dim_datum_key, dim_snapshot_key, dim_taakinzaak_l_hk, dim_taak_h_hk, dim_team_h_hk_taak, dim_team_h_hk_verantwoordelijk, dim_zaak_h_hk)
/

--------------------------------------------------------
--  Constraints for Table bdr_taakinzaak_voorraad_stg
--------------------------------------------------------

alter table bdr_taakinzaak_voorraad_stg add constraint feit_taak_in_zaak_voorraad_stage_tb_pk primary key (dim_datum_key, dim_snapshot_key, dim_taakinzaak_l_hk, dim_taak_h_hk, dim_team_h_hk_taak, dim_team_h_hk_verantwoordelijk, dim_zaak_h_hk) using index feit_taak_in_zaak_voorraad_stage_tb_pk_idx enable
/