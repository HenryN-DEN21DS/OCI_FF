--------------------------------------------------------
--  Verwijder tabel bdr_ouderdomscat_voorraad_dt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_OUDERDOMSCAT_VOORRAAD_DT')

--------------------------------------------------------
--  DDL for Table bdr_ouderdomscat_voorraad_dt
--------------------------------------------------------
create table bdr_ouderdomscat_voorraad_dt
(
  	dim_ouderdomscategorie_key	number not null,
	ouderdom_tm               	number,
	ouderdom_vanaf            	number,
	ouderdomscategorie        	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dimensie_ouderdomscategorie_voorraad_pk_idx on bdr_ouderdomscat_voorraad_dt (dim_ouderdomscategorie_key)
/

--------------------------------------------------------
--  Constraints for Table bdr_ouderdomscat_voorraad_dt
--------------------------------------------------------

alter table bdr_ouderdomscat_voorraad_dt add constraint dimensie_ouderdomscategorie_voorraad_pk primary key (dim_ouderdomscategorie_key) using index dimensie_ouderdomscategorie_voorraad_pk_idx enable
/