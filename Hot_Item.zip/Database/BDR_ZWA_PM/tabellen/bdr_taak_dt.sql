--------------------------------------------------------
--  Verwijder tabel bdr_taak_dt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_TAAK_DT')

--------------------------------------------------------
--  DDL for Table bdr_taak_dt
--------------------------------------------------------
create table bdr_taak_dt
(
  	dim_taak_key	number not null,
	taak_hashkey	varchar2(99 char) not null,
	taak        	varchar2(999 char),
	taakcode    	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column bdr_taak_dt.taak_hashkey is 'Dit attribuut is nodig om vanuit het Feit eenvoudig de juiste dim-key te kunnen opzoeken. Laat dit attribuut niet zien in het gegevensvenster.'
/
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dimensie_taak_dt_pk_idx on bdr_taak_dt (dim_taak_key)
/

--------------------------------------------------------
--  Constraints for Table bdr_taak_dt
--------------------------------------------------------

alter table bdr_taak_dt add constraint dimensie_taak_dt_pk primary key (dim_taak_key) using index dimensie_taak_dt_pk_idx enable
/