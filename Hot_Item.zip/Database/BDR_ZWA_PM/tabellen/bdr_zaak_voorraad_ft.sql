--------------------------------------------------------
--  Verwijder tabel bdr_zaak_voorraad_ft als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_ZAAK_VOORRAAD_FT')

--------------------------------------------------------
--  DDL for Table bdr_zaak_voorraad_ft
--------------------------------------------------------
create table bdr_zaak_voorraad_ft
(
  	dim_datum_key                   	number not null,
	dim_ouderdomscategorie_key      	number not null,
	dim_snapshot_key                	number not null,
	dim_zaak_key                    	number not null,
	dim_team_key_verantwoordelijk   	number not null,
	aantal_voorraad                 	number default on null 1,
	ouderdom                        	number,
	verzuimduur_tot_rapportagemoment	number
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column bdr_zaak_voorraad_ft.verzuimduur_tot_rapportagemoment is 'Verzuimduur op het moment van deze voorraadbepaling. Er is dus nog geen hersteldmelding!'
/
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index feit_zaak_voorraad_tb_pk_idx on bdr_zaak_voorraad_ft (dim_datum_key, dim_ouderdomscategorie_key, dim_snapshot_key, dim_team_key_verantwoordelijk, dim_zaak_key)
/

--------------------------------------------------------
--  Constraints for Table bdr_zaak_voorraad_ft
--------------------------------------------------------

alter table bdr_zaak_voorraad_ft add constraint feit_zaak_voorraad_tb_pk primary key (dim_datum_key, dim_ouderdomscategorie_key, dim_snapshot_key, dim_team_key_verantwoordelijk, dim_zaak_key) using index feit_zaak_voorraad_tb_pk_idx enable
/