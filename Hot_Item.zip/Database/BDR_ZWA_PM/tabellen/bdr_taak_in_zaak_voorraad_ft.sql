--------------------------------------------------------
--  Verwijder tabel bdr_taak_in_zaak_voorraad_ft als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('BDR_TAAK_IN_ZAAK_VOORRAAD_FT')

--------------------------------------------------------
--  DDL for Table bdr_taak_in_zaak_voorraad_ft
--------------------------------------------------------
create table bdr_taak_in_zaak_voorraad_ft
(
  	dim_datum_key                	number not null,
	dim_ouderdomscategorie_key   	number not null,
	dim_snapshot_key             	number not null,
	dim_taak_key                 	number not null,
	dim_taakinzaak_key           	number not null,
	dim_zaak_key                 	number not null,
	dim_team_key_taak            	number not null,
	dim_team_key_verantwoordelijk	number not null,
	aantal_voorraad              	number default on null 1,
	ouderdom                     	number
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index feit_taak_in_zaak_voorraad_tb_pk_idx on bdr_taak_in_zaak_voorraad_ft (dim_datum_key, dim_ouderdomscategorie_key, dim_snapshot_key, dim_taakinzaak_key, dim_taak_key, dim_team_key_taak, dim_team_key_verantwoordelijk, dim_zaak_key)
/

--------------------------------------------------------
--  Constraints for Table bdr_taak_in_zaak_voorraad_ft
--------------------------------------------------------

alter table bdr_taak_in_zaak_voorraad_ft add constraint feit_taak_in_zaak_voorraad_tb_pk primary key (dim_datum_key, dim_ouderdomscategorie_key, dim_snapshot_key, dim_taakinzaak_key, dim_taak_key, dim_team_key_taak, dim_team_key_verantwoordelijk, dim_zaak_key) using index feit_taak_in_zaak_voorraad_tb_pk_idx enable
/