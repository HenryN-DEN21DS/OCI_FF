
--------------------------------------------------------
---  ddl for view bdr_zaak_dv
--------------------------------------------------------

create or replace force view bdr_natuurlijkepersoon_dv 									as 
  with cte as(
	select 
		  ph.dim_natuurlijkepersoon_h_hk
		, ph.bsn
        , ps.status_persoon
        , ps.geboortedatum
        , ps.domicilie_postcode_gebied
        , ps.domicilie_postcode
        , ps.verpleeg_adres_postcode_gebied
        , ps.verpleeg_adres_postcode
        , ps.verpleeg_adres_land_nr
        , ps.verpleeg_adres_land
        , ps.verpleeg_instelling_code
        , ps.verpleeg_instelling
	from
		int_zwa_pm.dv_natuurlijkepersoon_h ph
	left join int_zwa_pm.dv_natuurlijkepersoon_s_vw ps on ps.dim_natuurlijkepersoon_h_hk = ph.dim_natuurlijkepersoon_h_hk     
	where ps.dim_is_geldig = 1)

	select 
		  row_number() over(order by dim_natuurlijkepersoon_h_hk) 					as dim_natuurlijkepersoon_key
		, dim_natuurlijkepersoon_h_hk as natuurlijkepersoon_hashkey
		, bsn
		, status_persoon
		, geboortedatum
		, domicilie_postcode_gebied
		, domicilie_postcode
        , verpleeg_adres_postcode_gebied
        , verpleeg_adres_postcode
        , verpleeg_adres_land_nr
		, verpleeg_adres_land
		, verpleeg_instelling_code
		, verpleeg_instelling
	from cte 

	union all

	select
		  dim_id 														as dim_natuurlijkepersoon_key
		, hashkey 														as natuurlijkepersoon_hashkey
		, omschrijving_kort 											as bsn
		, omschrijving_kort 											as status_persoon
		, dim_geldig_vanaf 											    as geboortedatum
		, omschrijving_kort 											as domicilie_postcode_gebied
		, omschrijving_kort 											as domicilie_postcode
        , omschrijving_kort                                             as verpleeg_adres_postcode_gebied
        , omschrijving_kort                                             as verpleeg_adres_postcode
		, omschrijving_kort 											as verpleeg_adres_land_nr
		, omschrijving_lang 											as verpleeg_adres_land
        , omschrijving_kort                                             as verpleeg_instelling_code
		, omschrijving_lang 											as verpleeg_instelling
	from int_zwa_meta.dim_dummy_records_vw
    ;
