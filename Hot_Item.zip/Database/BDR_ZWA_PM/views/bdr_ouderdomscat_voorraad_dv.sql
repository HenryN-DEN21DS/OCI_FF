
--------------------------------------------------------
---  ddl for view bdr_ouderdomscat_voorraad_dv
--------------------------------------------------------

create or replace force view bdr_ouderdomscat_voorraad_dv as 
with dat as 
(
	select
		--1 dim_ouderdomscategorie_key
		'<= 13 weken' 													as ouderdomscategorie
		, 0 ouderdom_vanaf
		, 13*7 ouderdom_tm
	from dual
	union all 
	select
		'13 tm 52 weken' 												as ouderdomscategorie
		, 13*7+1 ouderdom_vanaf
		, 52*7 ouderdom_tm
	from dual
	union all
	select 
		'> 52 weken' 													as ouderdomscategorie
		, 52*7+1 ouderdom_vanaf
		, 104*7 ouderdom_tm
	from dual
	union all
	select 
		'> 2 jaar' 														as ouderdomscategorie
		, 104*7+1 ouderdom_vanaf
		, 50*104*7 ouderdom_tm
	from dual
	union all
	select 
		'Onbekend' 														as ouderdomscategorie
		, -99999 ouderdom_vanaf
		, -1 ouderdom_tm
	from dual
)
select row_number() over(order by ouderdom_vanaf ) 
as 
	dim_ouderdomscategorie_key
	, cast (ouderdomscategorie as varchar2(99)) 						as ouderdomscategorie
	, ouderdom_vanaf
	, ouderdom_tm
from dat

union all
select
	dim_id 																as dim_ouderdomscategorie_key
	,omschrijving_lang 													as ouderdomscategorie
	,nummer 															as ouderdom_vanaf
	,nummer 															as ouderdom_tm
from int_zwa_meta.dim_dummy_records_vw;
