
--------------------------------------------------------
---  ddl for view bdr_datum_dv
--------------------------------------------------------

create or replace force view bdr_datum_dv 
as
select 
	  dt.datum_id 														as dim_datum_key
	, dt.datum
	, dt.dagnaam
	, dt.dagnummer_week
	, dt.dagnummer_maand
	, dt.dagnummer_jaar
	, dt.ind_weekend
	, dt.week_nummer
	, dt.jaarweek_nummer
	, dt.eerste_dag_van_de_week
	, dt.laatste_dag_van_de_week
	, dt.ind_week_begin
	, dt.maandnaam
	, dt.maand_nummer
	, dt.jaarmaand_nummer
	, dt.maand_dagen
	, case when dt.dagnummer_maand = dt.maand_dagen 
		then 'J'
		else 'N' end 													as ind_maand_eind
	, dt.kwartaal_nummer
	, dt.kwartaal
	, dt.jaarkwartaal_nummer
	, dt.tertaal_nummer
	, dt.tertaal
	, dt.jaartertaal_nummer
	, dt.jaartal
	, dt.jaar_dagen
	, dt.seizoennaam
	, dt.feestdag_indicatie
from bdr_conforme_dimensies.bdr_datum_dt dt

UNION ALL

	select
		dim_id           			as dim_datum_key,
		dim_geldig_vanaf            as datum,
		omschrijving_lang           as dagnaam,
		nummer           			as dagnummer_week,
		nummer           			as dagnummer_maand,
		nummer           			as dagnummer_jaar,
		omschrijving_lang           as ind_weekend,
		nummer           			as week_nummer,
		nummer           			as jaarweek_nummer,
		dim_geldig_vanaf           	as eerste_dag_van_de_week,
		dim_geldig_vanaf           	as laatste_dag_van_de_week,
		omschrijving_lang           as ind_week_begin,
		omschrijving_lang           as maandnaam,
		nummer           			as maand_nummer,
		nummer           			as jaarmaand_nummer,
		nummer           			as maand_dagen,
		omschrijving_kort           as ind_maand_eind,
		nummer           			as kwartaal_nummer,
		omschrijving_lang           as kwartaal,
		nummer           			as jaarkwartaal_nummer,
		nummer           			as tertaal_nummer,
		omschrijving_lang           as tertaal,
		nummer           			as jaartertaal_nummer,
		nummer           			as jaartal,
		nummer           			as jaar_dagen,
		omschrijving_lang           as seizoennaam,
		omschrijving_lang           as feestdag_indicatie
	from int_zwa_meta.dim_dummy_records_vw

;
