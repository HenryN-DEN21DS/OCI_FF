--------------------------------------------------------
--  ddl for view bdr_taakinzaak_dv
--------------------------------------------------------

create or replace force view bdr_taakinzaak_dv as
with cte_dv as (
select l.dim_taakinzaak_l_hk 
, l.datum_initiele_boeking_act
, st.datum_boeking_activiteit
, st.code_aanleiding_activiteit
, st.aanleiding_activiteit
, st.datum_activiteit_plan
, st.datum_activiteit_realisatie
, st.datum_oproep
, st.code_aanwezigheid_persoon
, st.aanwezigheid_persoon
, st.code_functie_medewerker
, st.functie_medewerker
, st.naam_medewerker
, st.code_status_activiteit
, st.status_activiteit
, st.code_conclusie_activiteit
, st.conclusie_activiteit
, st.dim_is_verwijderd 
from
int_zwa_pm.dv_taakinzaak_l l
join int_zwa_pm.dv_taakinzaak_s_vw st on st.dim_taakinzaak_l_hk = l.dim_taakinzaak_l_hk and dim_is_geldig = 1
where 1=1
and l.datum_initiele_boeking_act >= to_date('01-01-2019', 'dd-mm-yyyy')
)

select row_number() over(order by dim_taakinzaak_l_hk ) as dim_taakinzaak_key
, dim_taakinzaak_l_hk 
, datum_initiele_boeking_act
, datum_boeking_activiteit
, code_aanleiding_activiteit
, aanleiding_activiteit
, datum_activiteit_plan
, datum_activiteit_realisatie
, datum_oproep
, code_aanwezigheid_persoon
, aanwezigheid_persoon
, code_functie_medewerker
, functie_medewerker
, naam_medewerker
, code_status_activiteit
, status_activiteit
, code_conclusie_activiteit
, conclusie_activiteit
from cte_dv 
where coalesce(cte_dv.dim_is_verwijderd,0) = 0

union all

select
nummer as dim_taakinzaak_key
, hashkey as dim_taakinzaak_l_hk
, dim_geldig_vanaf as datum_initiele_boeking_act
, dim_geldig_vanaf as datum_boeking_activiteit
, omschrijving_kort as code_aanleiding_activiteit
, omschrijving_lang as aanleiding_activiteit
, dim_geldig_vanaf as datum_activiteit_plan
, dim_geldig_tm as datum_activiteit_realisatie
, dim_geldig_vanaf as datum_oproep
, omschrijving_kort as code_aanwezigheid_persoon
, omschrijving_lang as aanwezigheid_persoon
, omschrijving_kort as code_functie_medewerker
, omschrijving_lang as functie_medewerker
, omschrijving_lang as naam_medewerker
, omschrijving_kort as code_status_activiteit
, omschrijving_lang as status_activiteit
, omschrijving_kort as code_conclusie_activiteit
, omschrijving_lang as conclusie_activiteit
from int_zwa_meta.dim_dummy_records_vw
;

