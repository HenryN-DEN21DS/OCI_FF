
--------------------------------------------------------
---  ddl for view bdr_snapshot_dv
--------------------------------------------------------

create or replace force view bdr_snapshot_dv as 
with snapshots as
(
	select 
		  dat.datum_id 													    as dim_datum_key_ultimo_periode
		, ss.dim_snapshot_id
        , periode_type
		, snapshot_periode
        , snapshot_datum
		, snapshot_datum_vanaf
		, cast(dat.datum + 1 - interval '0.000001' second  as timestamp)    as snapshot_datum_tm
		, 'Historisch'                                                      as snapshot_type
	from bdr_conforme_dimensies.bdr_snapshot_dm ss
	join bdr_conforme_dimensies.bdr_datum_dt dat 
		on ss.snapshot_periode = dat.jaarmaand_nummer
		and dat.dagnummer_maand = maand_dagen
	where       ss.periode_type = 'MAAND'                                      
	union all
	select 
		  dat.datum_id                                                      as dim_datum_key_ultimo_periode
		, dim_snapshot_id
        , periode_type
		, snapshot_periode
        , snapshot_datum
		, snapshot_datum_vanaf
		, cast(dat.datum  + 1 - interval '0.000001' second as timestamp)    as snapshot_datum_tm
		, 'Historisch'                                                      as snapshot_type
	from bdr_conforme_dimensies.bdr_snapshot_dm ss
	join bdr_conforme_dimensies.bdr_datum_dt dat 
		on ss.snapshot_periode = dat.jaarweek_nummer
		and trunc(dat.laatste_dag_van_de_week) = dat.datum
	where ss.periode_type = 'WEEK'
    /*
    1 Actueel record toevoegen, voor 'alltimes'.
    Gevolg: actuele voorraadstand per 'vandaag', geen 'actuele versie' per rapportageperiode
    */
    union all
	select 
		  dat.datum_id as dim_datum_key_ultimo_periode
		, -1*(row_number() over(order by 1) + 99991231) 				    as dim_snapshot_id
		, 'ALTIJD'                                                          as periode_type
        , 999999                                                            as snapshot_periode
        , sysdate 						                                    as snapshot_datum
        , to_date('01-01-2020','dd-mm-yyyy')                                as snapshot_datum_vanaf
		, sysdate                                                           as snapshot_datum_tm
		, 'Actueel'                                                         as snapshot_type
        from bdr_conforme_dimensies.bdr_datum_dt dat
        where dat.datum = trunc(sysdate)
	union all
	select 
		  dat.datum_id as dim_datum_key_ultimo_periode
		, -1*(row_number() over(order by 1) + 99991231) 				    as dim_snapshot_id
		, periode_type
        , snapshot_periode
        , sysdate 						                                    as snapshot_datum
        , snapshot_datum_vanaf
		, cast(dat.datum as timestamp) + 1 - interval '0.000001' second     as snapshot_datum_tm
		, 'Actueel'                                                         as snapshot_type
	from bdr_conforme_dimensies.bdr_snapshot_dm ss
	join bdr_conforme_dimensies.bdr_datum_dt dat 
		on ss.snapshot_periode = dat.jaarmaand_nummer
		and dat.dagnummer_maand = maand_dagen
	where ss.periode_type = 'MAAND'      
    and 1=2 -- tijdelijk uitzetten
	union all
	select 
	    dat.datum_id as dim_datum_key_ultimo_periode
	  , (row_number() over(order by 1)  + 99991231) 					    as dim_snapshot_id
	  , periode_type
      , snapshot_periode
	  , sysdate                                                             as snapshot_datum
      , snapshot_datum_vanaf
	  , cast(dat.datum as timestamp) + 1 - interval '0.000001' second 	    as snapshot_datum_tm
	  , 'Actueel'                                                           as snapshot_type
	from bdr_conforme_dimensies.bdr_snapshot_dm ss
	join bdr_conforme_dimensies.bdr_datum_dt dat 
		on ss.snapshot_periode = dat.jaarweek_nummer
		and trunc(dat.laatste_dag_van_de_week) = dat.datum
	where ss.periode_type = 'WEEK'    
    and 1=2 -- tijdelijk uitzetten
	union all
	select 
		  dat.datum_id 													    as dim_datum_key_ultimo_periode
		, -2147483642 													    as dim_snapshot_id
		, 'DAG' 														    as periode_type
		, to_number(to_char(sysdate, 'yyyymmdd')) 						    as snapshot_periode
		, sysdate 														    as snapshot_datum
		, cast(dat.datum as date) 										    as snapshot_datum_vanaf
		, cast(dat.datum as timestamp) + 1 - interval '0.000001' second	    as snapshot_datum_tm
		, 'Actueel' 													    as snapshot_type
	from bdr_conforme_dimensies.bdr_datum_dt dat
	where dat.datum = trunc(sysdate)

)
select 
	  dim_datum_key_ultimo_periode
	, dim_snapshot_id 													as dim_snapshot_key
	, periode_type
	, snapshot_periode
	, cast(snapshot_datum as timestamp(6)) 								as snapshot_datum
	, cast(snapshot_datum_vanaf as timestamp(6)) 						as snapshot_datum_vanaf
	, snapshot_datum_tm
	, cast(snapshot_type as varchar2(99)) 								as snapshot_type
from snapshots
where 1=1
and snapshot_datum_vanaf >= to_date('01-01-2020','dd-mm-yyyy')
and snapshot_datum_tm <= sysdate
;