--------------------------------------------------------
--  File created - maandag-juni-05-2023   
--------------------------------------------------------
REM INSERTING into INT_ZWA_META.STG_META_DUMMY_TB
SET DEFINE OFF;
