create or replace PROCEDURE "DQ_MAIN_SEQ" AS 
  dqCheckName VARCHAR2(255);
  dqSyntax VARCHAR2(255); 
  tableName VARCHAR2(25);
  schemaName VARCHAR2(255);
  sourceColumn VARCHAR2(255);
  sqlStatement VARCHAR2(4000);
  dbAttribuutHashkey VARCHAR2(4000);

BEGIN

  FOR o IN (SELECT DQ.DQ_REGEL, DS.DQ_PROCEDURE, DS.DQ_SYNTAX, DBA.TABEL_NAAM, DBA.KOLOM_NAAM, DBA.SCHEMA_NAAM, DQ.DIM_DQREGEL_H_HK
            FROM INT_ZWA_META.DV_DQREGEL_DBATTRIBUUT_L DQDBL
            JOIN INT_ZWA_META.DV_DQ_REGEL_H DQ ON DQDBL.DIM_DQREGEL_H_HK = DQ.DIM_DQREGEL_H_HK
            JOIN INT_ZWA_META.DV_DQ_REGEL_S DS ON DQDBL.DIM_DQREGEL_H_HK = DS.DIM_DQREGEL_H_HK
            JOIN INT_ZWA_META.DV_DBATTRIBUUT_H DBA ON DQDBL.DIM_DBATTRIBUUT_H_HK = DBA.DIM_DBATTRIBUUT_H_HK)
  LOOP
    BEGIN
      dqCheckName := o.DQ_PROCEDURE;
      dqSyntax := o.DQ_SYNTAX;
      tableName := o.TABEL_NAAM;
      schemaName := o.SCHEMA_NAAM;
      sourceColumn := o.KOLOM_NAAM;
      
      SELECT DIM_DBATTRIBUUT_H_HK 
      INTO dbAttribuutHashkey
      FROM INT_ZWA_META.DV_DBATTRIBUUT_H 
      WHERE SCHEMA_NAAM = schemaName AND KOLOM_NAAM = sourceColumn AND TABEL_NAAM = tableName;
      
      DBMS_OUTPUT.PUT_LINE(dbAttribuutHashkey);
      DBMS_OUTPUT.PUT_LINE(o.DIM_DQREGEL_H_HK);
      DBMS_OUTPUT.PUT_LINE(dqCheckName);
      DBMS_OUTPUT.PUT_LINE(dqSyntax);
      DBMS_OUTPUT.PUT_LINE(schemaName);
      DBMS_OUTPUT.PUT_LINE(tableName);
      DBMS_OUTPUT.PUT_LINE(sourceColumn);
      
      sqlStatement := 'BEGIN INT_ZWA_META.' || dqCheckName || '(:dqSyntax, :schemaName, :tableName, :sourceColumn, :dbAttributeHashKey, :DQRuleHashKey); END;';
      EXECUTE IMMEDIATE sqlStatement
      USING IN dqSyntax, IN schemaName, IN tableName, IN sourceColumn, IN dbAttribuutHashkey, IN o.DIM_DQREGEL_H_HK; 
    EXCEPTION WHEN OTHERS THEN 
      DBMS_OUTPUT.PUT_LINE(sqlStatement);
    END;
    CONTINUE;
  END LOOP;
END DQ_MAIN_SEQ;