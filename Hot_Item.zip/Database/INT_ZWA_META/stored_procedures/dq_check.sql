--------------------------------------------------------
--  DDL for Procedure DQ_CHECK
--------------------------------------------------------
set define off;

  CREATE OR REPLACE EDITIONABLE PROCEDURE "INT_ZWA_META"."DQ_CHECK" ( 
        DqSyntax                                              IN VARCHAR2,
        SchemaName                                            IN VARCHAR2,
        SourceTable                                           IN VARCHAR2,
        SourceColumn                                          IN VARCHAR2,
        DBAttributeHashKey                                    IN VARCHAR2,
        DQRuleHashKey                                         IN VARCHAR2)
AS
Qry           varchar2(5000);
CurrTimestamp TIMESTAMP;
dbattribuutHashkey VARCHAR2(4000);
targetTable VARCHAR2(200);
joinQuery VARCHAR2(5000);
bkColsQuery VARCHAR2(5000);
BEGIN

        DBMS_OUTPUT.PUT_LINE(SourceTable);
        DBMS_OUTPUT.PUT_LINE(SourceColumn);

SELECT DIM_DBATTRIBUUT_H_HK 
INTO dbattribuutHashkey
FROM dv_dbattribuut_h
WHERE tabel_naam = SourceTable AND kolom_naam = SourceColumn AND SCHEMA_NAAM = SchemaName;

        DBMS_OUTPUT.PUT_LINE(dbattribuutHashkey);
        
SELECT FROMConditie, bk_cols, tabel_naam 
INTO joinQuery, bkColsQuery, TargetTable
FROM (--HUB SATS
select --, fk_bron_att.tabel_naam, fk_doel_att.tabel_naam, 
fk_bron_att.schema_naam || '.' || fk_bron_att.tabel_naam || listagg(distinct ' join ' || fk_doel_att.schema_naam || '.' ||fk_doel_att.tabel_naam || ' on ' || fk_bron_att.tabel_naam || '.' || fk_bron_att.kolom_naam || ' = ' || fk_doel_att.tabel_naam || '.' || fk_doel_att.kolom_naam) within group (order by fk_doel_att.kolom_naam) AS FROMConditie
, listagg(distinct '''' || hubatt.kolom_naam || ': '' || coalesce(to_char(' || hubatt.tabel_naam || '.' || hubatt.kolom_naam || '), ''<geen waarde>'')', ' || '' | '' ||') within group (order by hubatt.kolom_naam) as bk_cols
, fk_doel_att.tabel_naam AS tabel_naam
, att.dim_dbattribuut_h_HK AS dim_dbattribuut_h_hk
from dv_dbattribuut_h att
join dv_dbattribuut_s_vw atts on atts.dim_dbattribuut_h_hk = att.dim_dbattribuut_h_hk and atts.dim_is_geldig = 1
join dv_dbobject_dbattribuut_l ao on ao.dim_dbattribuut_h_hk = att.dim_dbattribuut_h_HK
join DV_DBOBJECT_DBATTRIBUUT_S_VW aos on aos.DIM_DBOBJECT_DBATTRIBUUT_L_HK = ao.DIM_DBOBJECT_DBATTRIBUUT_L_HK and aos.dim_is_geldig = 1
join dv_dbobject_H attobj on attobj.dim_dbobject_h_hk = ao.dim_dbobject_h_hk
join dv_dbobject_s_vw attobjs on attobjs.dim_dbobject_h_hk = attobj.dim_dbobject_h_hk and attobjs.dim_is_geldig = 1 -- Objecttype kan hier bepaald worden (SAT)
--
join dv_dbobject_dbattribuut_l aoa on aoa.dim_dbobject_h_hk = attobj.dim_dbobject_h_hk -- 'broertjes en zusjes' van het gecontroleerde attribuut (incl. ikzelf)
join DV_DBOBJECT_DBATTRIBUUT_S_VW aoas on aoas.DIM_DBOBJECT_DBATTRIBUUT_L_HK = aoa.DIM_DBOBJECT_DBATTRIBUUT_L_HK and aoas.dim_is_geldig = 1
join dv_foreign_key_l fk on aoa.dim_dbattribuut_h_HK = fk.dim_dbattribuut_h_HK_bron --welke daarvan zitten in de foreign key
join dv_foreign_key_s_vw fks on fks.DIM_FOREIGN_KEY_L_HK = fk.DIM_FOREIGN_KEY_L_HK and fks.dim_is_geldig = 1

join dv_dbattribuut_h fk_bron_att on fk_bron_att.dim_dbattribuut_h_hk = fk.dim_dbattribuut_h_HK_bron -- van de fk-attributen de naam e.d.
join dv_dbattribuut_s_vw fk_bron_atts on fk_bron_att.dim_dbattribuut_h_hk = fk_bron_atts.dim_dbattribuut_h_hk and fk_bron_atts.dim_is_geldig = 1
join dv_dbattribuut_h fk_doel_att on fk_doel_att.dim_dbattribuut_h_hk = fk.dim_dbattribuut_h_HK_doel -- het attribuut 'aan de andere kant' van de fk-relatie (in de hub dus)
join dv_dbattribuut_s_vw fk_doel_atts on fk_doel_att.dim_dbattribuut_h_hk = fk_doel_atts.dim_dbattribuut_h_hk and fk_doel_atts.dim_is_geldig = 1

join dv_dbobject_dbattribuut_l fka on fka.dim_dbattribuut_h_HK = fk.dim_dbattribuut_h_HK_doel -- object(naam) 'van de overkant' bepalen
join DV_DBOBJECT_DBATTRIBUUT_S_VW fkas on fkas.DIM_DBOBJECT_DBATTRIBUUT_L_HK = fka.DIM_DBOBJECT_DBATTRIBUUT_L_HK and fkas.dim_is_geldig = 1 --geldigheidscheck
join dv_dbobject_s_vw parobjtype on parobjtype.dim_dbobject_h_hk = fka.dim_dbobject_h_hk and parobjtype.dim_is_geldig = 1 -- de kenmerken van het parentobject

join dv_dbobject_dbattribuut_l parobj on parobj.dim_dbobject_h_hk = fka.dim_dbobject_h_hk -- dit vindt alle attributen van het parentobject (hub in dit geval)
join DV_DBOBJECT_DBATTRIBUUT_S_VW parobjs on parobjs.DIM_DBOBJECT_DBATTRIBUUT_L_HK = parobj.DIM_DBOBJECT_DBATTRIBUUT_L_HK and parobjs.dim_is_geldig = 1 --geldigheidscheck
join dv_dbattribuut_h hubatt on hubatt.dim_dbattribuut_h_hk = parobj.dim_dbattribuut_h_hk and hubatt.kolom_naam not like 'DIM%' --zoek de bk-cols in de hub erbij
join dv_dbattribuut_s_vw hubatts on HUBatts.dim_dbattribuut_h_hk = hubatt.dim_dbattribuut_h_hk and hubatts.dim_is_geldig = 1
where 1=1
and attobjs.objecttype = 'SAT'
and parobjtype.objecttype = 'HUB'
group by fk_bron_att.schema_naam, att.kolom_naam, fk_bron_att.tabel_naam, fk_bron_att.tabel_naam, fk_bron_att.kolom_naam, fk_doel_att.tabel_naam, fk_doel_att.kolom_naam, att.dim_dbattribuut_h_HK 

UNION ALL

--LINK SATS
select --, fk_bron_att.tabel_naam, fk_doel_att.tabel_naam, fk_bron_att.tabel_naam || '.' || fk_bron_att.kolom_naam || ' = ' || fk_doel_att.tabel_naam || '.' || fk_doel_att.kolom_naam
fk_bron_att.schema_naam || '.' || fk_bron_att.tabel_naam || listagg(distinct ' join ' || fk_doel_att.tabel_naam || ' on ' || fk_bron_att.tabel_naam || '.' || fk_bron_att.kolom_naam || ' = ' || fk_doel_att.tabel_naam || '.' || fk_doel_att.kolom_naam) within group (order by fk_doel_att.kolom_naam) -- sat naar link
  || listagg(distinct ' join ' || hubfk_att.tabel_naam || ' on ' || linkfk_att.tabel_naam || '.' || linkfk_att.kolom_naam || ' = ' || hubfk_att.tabel_naam || '.' || hubfk_att.kolom_naam) within group (order by hubfk_att.tabel_naam, hubfk_att.kolom_naam) --link naar hubs (hubfk_att)
        AS FROMConditie
,   listagg(distinct case when hubattn.kolom_naam is not null then '''' || hubattn.kolom_naam || ': '' || coalesce(to_char(' || hubattn.tabel_naam || '.' || hubattn.kolom_naam || '), ''<geen waarde>'')' end, ' || '' | '' ||' ) within group (order by hubattn.tabel_naam, hubattn.kolom_naam) -- hub-atts (hubattn)
  || 
  listagg(distinct case when linkatt.kolom_naam is not null then ' || '' | '' || ' || '''' || linkatt.kolom_naam || ': '' || coalesce(to_char(' || linkatt.tabel_naam || '.' || linkatt.kolom_naam || '), ''<geen waarde>'')' end, ' || '' | '' ||' ) within group (order by linkatt.kolom_naam) --link bks
        as bk_cols
, fk_doel_att.tabel_naam
, att.dim_dbattribuut_h_HK
from dv_dbattribuut_h att
join dv_dbattribuut_s_vw atts on atts.dim_dbattribuut_h_hk = att.dim_dbattribuut_h_hk and atts.dim_is_geldig = 1
join dv_dbobject_dbattribuut_l ao on ao.dim_dbattribuut_h_hk = att.dim_dbattribuut_h_HK
join DV_DBOBJECT_DBATTRIBUUT_S_VW aos on aos.DIM_DBOBJECT_DBATTRIBUUT_L_HK = ao.DIM_DBOBJECT_DBATTRIBUUT_L_HK and aos.dim_is_geldig = 1
join dv_dbobject_H attobj on attobj.dim_dbobject_h_hk = ao.dim_dbobject_h_hk
join dv_dbobject_s_vw attobjs on attobjs.dim_dbobject_h_hk = attobj.dim_dbobject_h_hk and attobjs.dim_is_geldig = 1 -- Objecttype kan hier bepaald worden (SAT)
--
join dv_dbobject_dbattribuut_l aoa on aoa.dim_dbobject_h_hk = attobj.dim_dbobject_h_hk -- 'broertjes en zusjes' van het gecontroleerde attribuut (incl. ikzelf)
join DV_DBOBJECT_DBATTRIBUUT_S_VW aoas on aoas.DIM_DBOBJECT_DBATTRIBUUT_L_HK = aoa.DIM_DBOBJECT_DBATTRIBUUT_L_HK and aoas.dim_is_geldig = 1
join dv_foreign_key_l fk on aoa.dim_dbattribuut_h_HK = fk.dim_dbattribuut_h_HK_bron --welke daarvan zitten in de foreign key
join dv_foreign_key_s_vw fks on fks.DIM_FOREIGN_KEY_L_HK = fk.DIM_FOREIGN_KEY_L_HK and fks.dim_is_geldig = 1

join dv_dbattribuut_h fk_bron_att on fk_bron_att.dim_dbattribuut_h_hk = fk.dim_dbattribuut_h_HK_bron -- van de fk-attributen de naam e.d.
join dv_dbattribuut_s_vw fk_bron_atts on fk_bron_att.dim_dbattribuut_h_hk = fk_bron_atts.dim_dbattribuut_h_hk and fk_bron_atts.dim_is_geldig = 1
join dv_dbattribuut_h fk_doel_att on fk_doel_att.dim_dbattribuut_h_hk = fk.dim_dbattribuut_h_HK_doel -- het attribuut 'aan de andere kant' van de fk-relatie (in de link dus)
join dv_dbattribuut_s_vw fk_doel_atts on fk_doel_att.dim_dbattribuut_h_hk = fk_doel_atts.dim_dbattribuut_h_hk and fk_doel_atts.dim_is_geldig = 1

join dv_dbobject_dbattribuut_l fka on fka.dim_dbattribuut_h_HK = fk.dim_dbattribuut_h_HK_doel -- object(naam) 'van de overkant' bepalen
join DV_DBOBJECT_DBATTRIBUUT_S_VW fkas on fkas.DIM_DBOBJECT_DBATTRIBUUT_L_HK = fka.DIM_DBOBJECT_DBATTRIBUUT_L_HK and fkas.dim_is_geldig = 1 --geldigheidscheck
join dv_dbobject_s_vw parobjtype on parobjtype.dim_dbobject_h_hk = fka.dim_dbobject_h_hk and parobjtype.dim_is_geldig = 1 -- de kenmerken van het parentobject

join dv_dbobject_dbattribuut_l parobj on parobj.dim_dbobject_h_hk = fka.dim_dbobject_h_hk -- dit vindt alle attributen van het parentobject (link in dit geval)
join DV_DBOBJECT_DBATTRIBUUT_S_VW parobjs on parobjs.DIM_DBOBJECT_DBATTRIBUUT_L_HK = parobj.DIM_DBOBJECT_DBATTRIBUUT_L_HK and parobjs.dim_is_geldig = 1 --geldigheidscheck
left join dv_dbattribuut_h linkatt on linkatt.dim_dbattribuut_h_hk = parobj.dim_dbattribuut_h_hk and linkatt.kolom_naam not like 'DIM%' --zoek de bk-cols in de link erbij
left join dv_dbattribuut_s_vw linkatts on linkatts.dim_dbattribuut_h_hk = linkatt.dim_dbattribuut_h_hk and linkatts.dim_is_geldig = 1

-- extra tov hubsat
-- vindt de hubattributen waarnaar wordt verwezen vanuit de link
join dv_dbobject_dbattribuut_l parobj2 on parobj2.dim_dbobject_h_hk = fka.dim_dbobject_h_hk -- dit vindt alle attributen van het parentobject (link in dit geval)
join DV_DBOBJECT_DBATTRIBUUT_S_VW parobjs2 on parobjs2.DIM_DBOBJECT_DBATTRIBUUT_L_HK = parobj2.DIM_DBOBJECT_DBATTRIBUUT_L_HK and parobjs2.dim_is_geldig = 1 --geldigheidscheck
join dv_foreign_key_l fkl on fkl.dim_dbattribuut_h_HK_bron = parobj2.dim_dbattribuut_h_HK --naar welke hubatts wordt verwezen door de link?
join dv_foreign_key_s_vw fkls on fkls.DIM_FOREIGN_KEY_L_HK = fkl.DIM_FOREIGN_KEY_L_HK and fkls.dim_is_geldig = 1
join dv_dbattribuut_h linkfk_att on linkfk_att.dim_dbattribuut_h_hk = fkl.dim_dbattribuut_h_HK_bron -- het attribuut 'aan deze kant' van de fk-relatie (in de link dus)
join dv_dbattribuut_s_vw linkfk_atts on linkfk_atts.dim_dbattribuut_h_hk = linkfk_att.dim_dbattribuut_h_hk and linkfk_atts.dim_is_geldig = 1
join dv_dbattribuut_h hubfk_att on hubfk_att.dim_dbattribuut_h_hk = fkl.dim_dbattribuut_h_HK_doel -- het attribuut 'aan de andere kant' van de fk-relatie (in de hub dus)
join dv_dbattribuut_s_vw hubfk_atts on hubfk_atts.dim_dbattribuut_h_hk = hubfk_att.dim_dbattribuut_h_hk and hubfk_atts.dim_is_geldig = 1


--vindt alle bk attributen van de hubs waarnaar verwezen wordt
join dv_dbobject_dbattribuut_l hubfkatt on hubfkatt.dim_dbattribuut_h_HK = fkl.dim_dbattribuut_h_HK_doel  -- vindt het hubobject
join DV_DBOBJECT_DBATTRIBUUT_S_VW hubfkatts on hubfkatts.DIM_DBOBJECT_DBATTRIBUUT_L_HK = hubfkatt.DIM_DBOBJECT_DBATTRIBUUT_L_HK and hubfkatts.dim_is_geldig = 1 --geldigheidscheck
join dv_dbobject_dbattribuut_l hubatt on hubatt.dim_dbobject_h_hk = hubfkatt.dim_dbobject_h_hk --dit vindt alle hubattributen
join dv_dbattribuut_h hubattn on hubattn.dim_dbattribuut_h_hk = hubatt.dim_dbattribuut_h_hk and hubattn.kolom_naam not like 'DIM%' --beperk tot  de bk-cols in de hubs 
join dv_dbattribuut_s_vw hubattns on hubattns.dim_dbattribuut_h_hk = hubattn.dim_dbattribuut_h_hk and hubattns.dim_is_geldig = 1 --geldigheidscheck

where 1=1
and attobjs.objecttype = 'SAT'
and parobjtype.objecttype = 'LINK'
group by fk_bron_att.schema_naam, att.kolom_naam, fk_bron_att.tabel_naam, fk_bron_att.kolom_naam, fk_doel_att.tabel_naam, fk_doel_att.kolom_naam, att.dim_dbattribuut_h_HK 

UNION ALL

--HUBS
select --, fk_bron_att.tabel_naam, fk_doel_att.tabel_naam, 
att.schema_naam || '.' || att.tabel_naam AS FROMConditie
, listagg(distinct '''' || hubatt.kolom_naam || ': '' || coalesce(to_char(' || hubatt.tabel_naam || '.' || hubatt.kolom_naam || '), ''<geen waarde>'')', ' || '' | '' ||') within group (order by hubatt.kolom_naam) as bk_cols
, att.tabel_naam
, att.dim_dbattribuut_h_HK
from dv_dbattribuut_h att
join dv_dbattribuut_s_vw atts on atts.dim_dbattribuut_h_hk = att.dim_dbattribuut_h_hk and atts.dim_is_geldig = 1
join dv_dbobject_dbattribuut_l ao on ao.dim_dbattribuut_h_hk = att.dim_dbattribuut_h_HK
join DV_DBOBJECT_DBATTRIBUUT_S_VW aos on aos.DIM_DBOBJECT_DBATTRIBUUT_L_HK = ao.DIM_DBOBJECT_DBATTRIBUUT_L_HK and aos.dim_is_geldig = 1
join dv_dbobject_H attobj on attobj.dim_dbobject_h_hk = ao.dim_dbobject_h_hk
join dv_dbobject_s_vw attobjs on attobjs.dim_dbobject_h_hk = attobj.dim_dbobject_h_hk and attobjs.dim_is_geldig = 1 -- Objecttype kan hier bepaald worden (SAT)
--
join dv_dbobject_dbattribuut_l aoa on aoa.dim_dbobject_h_hk = attobj.dim_dbobject_h_hk -- 'broertjes en zusjes' van het gecontroleerde attribuut (incl. ikzelf)
join DV_DBOBJECT_DBATTRIBUUT_S_VW aoas on aoas.DIM_DBOBJECT_DBATTRIBUUT_L_HK = aoa.DIM_DBOBJECT_DBATTRIBUUT_L_HK and aoas.dim_is_geldig = 1
join dv_dbattribuut_h hubatt on hubatt.dim_dbattribuut_h_hk = aoa.dim_dbattribuut_h_hk and hubatt.kolom_naam not like 'DIM%' --zoek de bk-cols in de hub erbij
join dv_dbattribuut_s_vw hubatts on HUBatts.dim_dbattribuut_h_hk = hubatt.dim_dbattribuut_h_hk and hubatts.dim_is_geldig = 1
where 1=1
and attobjs.objecttype = 'HUB'
group by att.schema_naam, att.tabel_naam, att.kolom_naam, att.tabel_naam, att.dim_dbattribuut_h_HK --, fk_bron_att.tabel_naam, fk_bron_att.kolom_naam, fk_doel_att.tabel_naam, fk_doel_att.kolom_naam

UNION ALL

--LINKS
select --, fk_bron_att.tabel_naam, fk_doel_att.tabel_naam, fk_bron_att.tabel_naam || '.' || fk_bron_att.kolom_naam || ' = ' || fk_doel_att.tabel_naam || '.' || fk_doel_att.kolom_naam
att.schema_naam || '.' || att.tabel_naam 
  || listagg(distinct ' join ' || hubfk_att.schema_naam || '.' || hubfk_att.tabel_naam || ' on ' || linkfk_att.tabel_naam || '.' || linkfk_att.kolom_naam || ' = ' || hubfk_att.tabel_naam || '.' || hubfk_att.kolom_naam) within group (order by hubfk_att.tabel_naam, hubfk_att.kolom_naam) --link naar hubs (hubfk_att)
        AS FROMConditie
,   listagg(distinct case when hubattn.kolom_naam is not null then '''' || hubattn.kolom_naam || ': '' || coalesce(to_char(' || hubattn.tabel_naam || '.' || hubattn.kolom_naam || '), ''<geen waarde>'')' end, ' || '' | '' ||' ) within group (order by hubattn.tabel_naam, hubattn.kolom_naam) -- hub-atts (hubattn)
  || 
  listagg(distinct case when linkatt.kolom_naam is not null then ' || '' | '' || ' || '''' || linkatt.kolom_naam || ': '' || coalesce(to_char(' || linkatt.tabel_naam || '.' || linkatt.kolom_naam || '), ''<geen waarde>'')' end, ' || '' | '' ||' ) within group (order by linkatt.kolom_naam) --link bks
        as bk_cols
, att.tabel_naam
, att.dim_dbattribuut_h_HK
from dv_dbattribuut_h att
join dv_dbattribuut_s_vw atts on atts.dim_dbattribuut_h_hk = att.dim_dbattribuut_h_hk and atts.dim_is_geldig = 1
join dv_dbobject_dbattribuut_l ao on ao.dim_dbattribuut_h_hk = att.dim_dbattribuut_h_HK
join DV_DBOBJECT_DBATTRIBUUT_S_VW aos on aos.DIM_DBOBJECT_DBATTRIBUUT_L_HK = ao.DIM_DBOBJECT_DBATTRIBUUT_L_HK and aos.dim_is_geldig = 1
join dv_dbobject_H attobj on attobj.dim_dbobject_h_hk = ao.dim_dbobject_h_hk
join dv_dbobject_s_vw attobjs on attobjs.dim_dbobject_h_hk = attobj.dim_dbobject_h_hk and attobjs.dim_is_geldig = 1 -- Objecttype kan hier bepaald worden (LINK)
--
join dv_dbobject_dbattribuut_l parobj on parobj.dim_dbobject_h_hk = attobj.dim_dbobject_h_hk -- dit vindt alle attributen van het object (link in dit geval)
join DV_DBOBJECT_DBATTRIBUUT_S_VW parobjs on parobjs.DIM_DBOBJECT_DBATTRIBUUT_L_HK = parobj.DIM_DBOBJECT_DBATTRIBUUT_L_HK and parobjs.dim_is_geldig = 1 --geldigheidscheck
left join dv_dbattribuut_h linkatt on linkatt.dim_dbattribuut_h_hk = parobj.dim_dbattribuut_h_hk and linkatt.kolom_naam not like 'DIM%' --zoek de bk-cols in de link erbij
left join dv_dbattribuut_s_vw linkatts on linkatts.dim_dbattribuut_h_hk = linkatt.dim_dbattribuut_h_hk and linkatts.dim_is_geldig = 1

-- vindt de hubattributen waarnaar wordt verwezen vanuit de link
join dv_dbobject_dbattribuut_l parobj2 on parobj2.dim_dbobject_h_hk = attobj.dim_dbobject_h_hk -- dit vindt alle attributen van het object (link in dit geval)
join DV_DBOBJECT_DBATTRIBUUT_S_VW parobjs2 on parobjs2.DIM_DBOBJECT_DBATTRIBUUT_L_HK = parobj2.DIM_DBOBJECT_DBATTRIBUUT_L_HK and parobjs2.dim_is_geldig = 1 --geldigheidscheck
join dv_foreign_key_l fkl on fkl.dim_dbattribuut_h_HK_bron = parobj2.dim_dbattribuut_h_HK --naar welke hubatts wordt verwezen door de link?
join dv_foreign_key_s_vw fkls on fkls.DIM_FOREIGN_KEY_L_HK = fkl.DIM_FOREIGN_KEY_L_HK and fkls.dim_is_geldig = 1
join dv_dbattribuut_h linkfk_att on linkfk_att.dim_dbattribuut_h_hk = fkl.dim_dbattribuut_h_HK_bron -- het attribuut 'aan deze kant' van de fk-relatie (in de link dus)
join dv_dbattribuut_s_vw linkfk_atts on linkfk_atts.dim_dbattribuut_h_hk = linkfk_att.dim_dbattribuut_h_hk and linkfk_atts.dim_is_geldig = 1
join dv_dbattribuut_h hubfk_att on hubfk_att.dim_dbattribuut_h_hk = fkl.dim_dbattribuut_h_HK_doel -- het attribuut 'aan de andere kant' van de fk-relatie (in de hub dus)
join dv_dbattribuut_s_vw hubfk_atts on hubfk_atts.dim_dbattribuut_h_hk = hubfk_att.dim_dbattribuut_h_hk and hubfk_atts.dim_is_geldig = 1

--vindt alle bk attributen van de hubs waarnaar verwezen wordt
join dv_dbobject_dbattribuut_l hubfkatt on hubfkatt.dim_dbattribuut_h_HK = fkl.dim_dbattribuut_h_HK_doel  -- vindt het hubobject
join DV_DBOBJECT_DBATTRIBUUT_S_VW hubfkatts on hubfkatts.DIM_DBOBJECT_DBATTRIBUUT_L_HK = hubfkatt.DIM_DBOBJECT_DBATTRIBUUT_L_HK and hubfkatts.dim_is_geldig = 1 --geldigheidscheck
join dv_dbobject_dbattribuut_l hubatt on hubatt.dim_dbobject_h_hk = hubfkatt.dim_dbobject_h_hk --dit vindt alle hubattributen
join dv_dbattribuut_h hubattn on hubattn.dim_dbattribuut_h_hk = hubatt.dim_dbattribuut_h_hk and hubattn.kolom_naam not like 'DIM%' --beperk tot  de bk-cols in de hubs 
join dv_dbattribuut_s_vw hubattns on hubattns.dim_dbattribuut_h_hk = hubattn.dim_dbattribuut_h_hk and hubattns.dim_is_geldig = 1 --geldigheidscheck

where 1=1
and attobjs.objecttype = 'LINK'
group by att.schema_naam, att.tabel_naam, att.kolom_naam, att.tabel_naam , att.dim_dbattribuut_h_HK --, fk_bron_att.kolom_naam, fk_doel_att.tabel_naam, fk_doel_att.kolom_naam
)
WHERE dim_dbattribuut_h_hk = dbattribuutHashkey 
;

        DELETE FROM INT_ZWA_META.PRESTG_DQBEVINDINGEN_TB WHERE DIM_DQREGEL_H_HK = DQRuleHashKey;

        EXECUTE IMMEDIATE 'SELECT CURRENT_TIMESTAMP FROM DUAL' INTO CurrTimestamp;

Qry := 'INSERT INTO PRESTG_DQBEVINDINGEN_TB (DIM_DQREGEL_H_HK, DIM_DBATTRIBUUT_H_HK, DATUM_BEVINDING, FOUTIEVE_WAARDE, OBJECT_BK) ' ||
       'SELECT ''' || DQRuleHashKey || ''', ''' || DBAttributeHashKey || ''', ''' || CurrTimestamp || ''', ' || sourceColumn || ', ' || bkColsQuery ||
      -- ' FROM ' || SchemaName || '.' || SourceTable ||
      -- ' INNER JOIN ' || SchemaName || '.' || TargetTable || ' ON ' || joinQuery ||
      ' FROM ' || joinQuery || 
      ' WHERE ' || sourceColumn || ' ' || DqSyntax;
       DBMS_OUTPUT.PUT_LINE(Qry);
        EXECUTE IMMEDIATE Qry; 
        
END DQ_CHECK;