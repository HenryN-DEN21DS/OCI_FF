--------------------------------------------------------
--  Verwijder tabel etl_run_log_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('ETL_RUN_LOG_TB')

--------------------------------------------------------
--  DDL for Table etl_run_log_tb
--------------------------------------------------------
create table etl_run_log_tb
(
  	etl_id 					number generated always as identity minvalue 1 maxvalue 9999999999999999999999999999 increment by 1 start with 1 nocache  noorder  nocycle  nokeep  noscale,
	proces_naam 			varchar2(99 char), 
	proces_datum 			date default sysdate, 
	status_voorafgaanden 	varchar2(99 char), 
	proces_status 			varchar2(99 char), 
	run_start_tijd 			timestamp (6), 
	run_eind_tijd 			timestamp (6)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column etl_run_log_tb.etl_id is 'ETL ID van de ETL verwerking';
/
comment on column etl_run_log_tb.proces_naam is 'Naam van de ETL verwerking';
/
comment on column etl_run_log_tb.proces_datum is 'Proces datum van de ETL verwerking';
/
comment on column etl_run_log_tb.status_voorafgaanden is 'Overall status van voorafgaande ETL verwerking(en)';
/
comment on column etl_run_log_tb.proces_status is 'Status van de ETL verwerking';
/
comment on column etl_run_log_tb.run_start_tijd is 'Tijdstip van start van de ETL verwerking';
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------


--------------------------------------------------------
--  Constraints for Table dv_omobject_s
--------------------------------------------------------

--alter table etl_run_log_tb modify (etl_id not null enable);
--/
--alter table etl_run_log_tb add constraint etl_run_log_ck check (proces_status in ('Afgebroken', 'Gereset', 'Klaar', 'Lopend')) enable;
--/

