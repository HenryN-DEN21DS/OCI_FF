--------------------------------------------------------
--  Verwijder tabel dv_dbobject_dbattribuut_l als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DBOBJECT_DBATTRIBUUT_L')

--------------------------------------------------------
--  DDL for Table dv_dbobject_dbattribuut_l
--------------------------------------------------------
create table dv_dbobject_dbattribuut_l
(
  	dim_dbattribuut_h_hk         	varchar2(99 char) not null,
	dim_dbobject_dbattribuut_l_hk	varchar2(99 char) not null,
	dim_dbobject_h_hk            	varchar2(99 char) not null,
	dim_aanmaak_datum            	timestamp not null,
	dim_bron                     	varchar2(999 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_dbobject_dbattribuut_l_pk_idx on dv_dbobject_dbattribuut_l (dim_dbobject_dbattribuut_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dbobject_dbattribuut_l
--------------------------------------------------------

alter table dv_dbobject_dbattribuut_l add constraint dv_dbobject_dbattribuut_l_pk primary key (dim_dbobject_dbattribuut_l_hk) using index dv_dbobject_dbattribuut_l_pk_idx enable
/