--------------------------------------------------------
--  Verwijder tabel dv_foreign_key_l als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_FOREIGN_KEY_L')

--------------------------------------------------------
--  DDL for Table dv_foreign_key_l
--------------------------------------------------------
create table dv_foreign_key_l
(
  	dim_dbattribuut_h_hk_bron	varchar2(99 char),
	dim_dbattribuut_h_hk_doel	varchar2(99 char),
	dim_foreign_key_l_hk     	varchar2(99 char) not null,
	dim_aanmaak_datum        	timestamp not null,
	dim_bron                 	varchar2(999 char) not null,
	foreign_key_naam         	varchar2(99 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_foreign_key_l_pk_idx on dv_foreign_key_l (dim_foreign_key_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_foreign_key_l
--------------------------------------------------------

alter table dv_foreign_key_l add constraint dv_foreign_key_l_pk primary key (dim_foreign_key_l_hk) using index dv_foreign_key_l_pk_idx enable
/