--------------------------------------------------------
--  Verwijder tabel dqbevindingen_l als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DQBEVINDINGEN_L')

--------------------------------------------------------
--  DDL for Table dqbevindingen_l
--------------------------------------------------------
create table dqbevindingen_l
(
  	dim_dbattribuut_h_hk  	varchar2(99 char) not null,
	dim_dqbevindingen_l_hk	varchar2(99 char) not null,
	dim_dqregel_h_hk      	varchar2(99 char) not null,
	dim_aanmaak_datum     	timestamp not null,
	dim_bron              	varchar2(999 char) not null,
	datum_bevinding       	timestamp,
	object_bk             	varchar2(99 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dqbevindingen__l_pk_idx on dqbevindingen_l (dim_dqbevindingen_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dqbevindingen_l
--------------------------------------------------------

alter table dqbevindingen_l add constraint dqbevindingen__l_pk primary key (dim_dqbevindingen_l_hk) using index dqbevindingen__l_pk_idx enable
/