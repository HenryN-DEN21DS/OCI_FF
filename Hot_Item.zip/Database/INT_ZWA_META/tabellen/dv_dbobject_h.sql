--------------------------------------------------------
--  Verwijder tabel dv_dbobject_h als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DBOBJECT_H')

--------------------------------------------------------
--  DDL for Table dv_dbobject_h
--------------------------------------------------------
create table dv_dbobject_h
(
  	dim_dbobject_h_hk	varchar2(99 char) not null,
	dim_aanmaak_datum	timestamp not null,
	dim_bron         	varchar2(999 char) not null,
	database_naam    	varchar2(999 char) not null,
	host_naam        	varchar2(999 char) not null,
	schema_naam      	varchar2(999 char) not null,
	tabel_naam       	varchar2(999 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_dbobject_h_pk_idx on dv_dbobject_h (dim_dbobject_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dbobject_h
--------------------------------------------------------

alter table dv_dbobject_h add constraint dv_dbobject_h_pk primary key (dim_dbobject_h_hk) using index dv_dbobject_h_pk_idx enable
/