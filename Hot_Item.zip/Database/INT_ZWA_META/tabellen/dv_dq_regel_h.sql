--------------------------------------------------------
--  Verwijder tabel dv_dq_regel_h als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DQ_REGEL_H')

--------------------------------------------------------
--  DDL for Table dv_dq_regel_h
--------------------------------------------------------
create table dv_dq_regel_h
(
  	dim_dqregel_h_hk 	varchar2(99 char) not null,
	dim_aanmaak_datum	timestamp not null,
	dim_bron         	varchar2(999 char) not null,
	dq_regel         	varchar2(99 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_dqregel_h_pk_idx on dv_dq_regel_h (dim_dqregel_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dq_regel_h
--------------------------------------------------------

alter table dv_dq_regel_h add constraint dv_dqregel_h_pk primary key (dim_dqregel_h_hk) using index dv_dqregel_h_pk_idx enable
/