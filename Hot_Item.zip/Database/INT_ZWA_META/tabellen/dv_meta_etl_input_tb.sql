--------------------------------------------------------
--  Verwijder tabel dv_meta_etl_input_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_META_ETL_INPUT_TB')

--------------------------------------------------------
--  DDL for Table dv_meta_userstatus_tb
--------------------------------------------------------
create table dv_meta_etl_input_tb
(
	mapping_specificatie	varchar(4000),
	input_user_status   	varchar(4000),
	insert_stmt         	varchar(4000),
    stmt                    varchar(4000)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/



--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table dv_meta_etl_input_tb
--------------------------------------------------------

