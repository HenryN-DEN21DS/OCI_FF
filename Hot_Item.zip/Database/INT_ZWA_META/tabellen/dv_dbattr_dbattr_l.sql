--------------------------------------------------------
--  Verwijder tabel dv_dbattr_dbattr_l als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DBATTR_DBATTR_L')

--------------------------------------------------------
--  DDL for Table dv_dbattr_dbattr_l
--------------------------------------------------------
create table dv_dbattr_dbattr_l
(
  	dim_dbattr_dbattr_l_hk       	varchar2(99 char) not null,
	dim_dbattribuut_h_hk_bron    	varchar2(99 char) not null,
	dim_dbattribuut_h_hk_doel    	varchar2(99 char) not null,
	dim_mapping_specificatie_h_hk	varchar2(99 char) not null,
	dim_aanmaak_datum            	timestamp not null,
	dim_bron                     	varchar2(999 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_dbattr_dbattr_l_pk_idx on dv_dbattr_dbattr_l (dim_dbattr_dbattr_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dbattr_dbattr_l
--------------------------------------------------------

alter table dv_dbattr_dbattr_l add constraint dv_dbattr_dbattr_l_pk primary key (dim_dbattr_dbattr_l_hk) using index dv_dbattr_dbattr_l_pk_idx enable
/