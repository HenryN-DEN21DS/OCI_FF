--------------------------------------------------------
--  Verwijder tabel stg_meta_mapping_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('STG_META_MAPPING_TB')

--------------------------------------------------------
--  DDL for Table stg_meta_mapping_tb
--------------------------------------------------------
create table stg_meta_mapping_tb
(
  	dim_dbattr_dbattr_l_hk       	varchar2(99 char) not null,
	dim_dbattribuut_h_hk_bron    	varchar2(99 char) not null,
	dim_dbattribuut_h_hk_doel    	varchar2(99 char) not null,
	dim_mapping_specificatie_h_hk	varchar2(99 char) not null,
	dim_dummy                    	varchar2(9 char),
	dim_extractiedatum_xmeta     	timestamp,
	dim_hashdiff_dbattr_dbattr   	varchar2(99 char) not null,
	dim_hashdiff_mapping_spec    	varchar2(99 char) not null,
	bron_database_naam           	varchar2(999 char),
	bron_host_naam               	varchar2(999 char),
	bron_kolom_naam              	varchar2(999 char),
	bron_naam_volledig           	varchar2(999 char),
	bron_schema_naam             	varchar2(999 char),
	bron_tabel_naam              	varchar2(999 char),
	doel_database_naam           	varchar2(999 char),
	doel_host_naam               	varchar2(999 char),
	doel_kolom_naam              	varchar2(999 char),
	doel_naam_volledig           	varchar2(999 char),
	doel_schema_naam             	varchar2(999 char),
	doel_tabel_naam              	varchar2(999 char),
	mapping_naam                 	varchar2(999 char),
	mapping_omschrijving         	varchar2(999 char),
	mapping_specificatie_naam    	varchar2(999 char),
	regel_naam                   	varchar2(999 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table stg_meta_mapping_tb
--------------------------------------------------------

