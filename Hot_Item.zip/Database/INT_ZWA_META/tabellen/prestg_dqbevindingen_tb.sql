--------------------------------------------------------
--  Verwijder tabel prestg_dqbevindingen_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('PRESTG_DQBEVINDINGEN_TB')

--------------------------------------------------------
--  DDL for Table prestg_dqbevindingen_tb
--------------------------------------------------------
create table prestg_dqbevindingen_tb
(
  	dim_dbattribuut_h_hk	varchar2(99 char) not null,
	dim_dqregel_h_hk    	varchar2(99 char) not null,
	datum_bevinding     	timestamp,
	foutieve_waarde     	varchar2(99 char),
	object_bk           	varchar2(999 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table prestg_dqbevindingen_tb
--------------------------------------------------------

