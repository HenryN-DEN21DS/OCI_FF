--------------------------------------------------------
--  Verwijder tabel stg_meta_dbattribuut_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('STG_META_DBATTRIBUUT_TB')

--------------------------------------------------------
--  DDL for Table stg_meta_dbattribuut_tb
--------------------------------------------------------
create table stg_meta_dbattribuut_tb
(
  	dim_dbattribuut_h_hk             	varchar2(99 char) not null,
	dim_dbobject_dbattribuut_l_hk    	varchar2(99 char) not null,
	dim_dbobject_h_hk                	varchar2(99 char) not null,
	primary_key                      	varchar2(999 char),
	dim_dummy                        	varchar2(9 char),
	dim_extractiedatum_xmeta         	timestamp,
	dim_hashdiff_dbattribuut         	varchar2(99 char) not null,
	dim_hashdiff_dbobject            	varchar2(99 char) not null,
	dim_hashdiff_dbobject_dbattribuut	varchar2(99 char) not null,
	data_type                        	varchar2(99 char),
	database_naam                    	varchar2(999 char),
	default_waarde                   	varchar2(999 char),
	host_naam                        	varchar2(999 char),
	kolom_naam                       	varchar2(999 char),
	mapping_naam                     	varchar2(999 char),
	max_lengte                       	number,
	min_lengte                       	number,
	null_toegestaan                  	number,
	objecttype                       	varchar2(99 char),
	schema_naam                      	varchar2(999 char),
	tabel_naam                       	varchar2(999 char),
	volledige_naam                   	varchar2(999 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table stg_meta_dbattribuut_tb
--------------------------------------------------------

