--------------------------------------------------------
--  Verwijder tabel dv_omobject_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_OMOBJECT_S')

--------------------------------------------------------
--  DDL for Table dv_omobject_s
--------------------------------------------------------
create table dv_omobject_s
(
  	dim_omobject_h_hk         	varchar2(99 char) not null,
	dim_aanmaak_datum         	timestamp not null,
	dim_bron                  	varchar2(999 char) not null,
	dim_hashdiff              	varchar2(99 char) not null,
	dim_is_verwijderd         	number default on null 0 not null,
	bewaartermijn             	varchar2(999 char),
	bewaartermijn_eenheid     	varchar2(999 char),
	bewaartermijn_ingangsdatum	varchar2(999 char),
	om_naam                   	varchar2(999 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_omobject_s_pk_idx on dv_omobject_s (dim_aanmaak_datum, dim_omobject_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_omobject_s
--------------------------------------------------------

alter table dv_omobject_s add constraint dv_omobject_s_pk primary key (dim_aanmaak_datum, dim_omobject_h_hk) using index dv_omobject_s_pk_idx enable
/