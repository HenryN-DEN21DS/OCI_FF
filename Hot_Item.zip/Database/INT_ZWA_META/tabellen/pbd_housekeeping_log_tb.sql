--------------------------------------------------------
--  Verwijder tabel pbd_housekeeping_log_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('PBD_HOUSEKEEPING_LOG_TB')

--------------------------------------------------------
--  DDL for Table pbd_housekeeping_log_tb
--------------------------------------------------------
create table pbd_housekeeping_log_tb
(
  	aantal_records_initieel   	number,
	aantal_records_na_schoning	number,
	om_naam                   	varchar2(999 char) not null,
	run_id                    	varchar2(999 char),
	tabel_naam                	varchar2(999 char) not null,
	tijdstip_uitgevoerd       	timestamp not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table pbd_housekeeping_log_tb
--------------------------------------------------------

