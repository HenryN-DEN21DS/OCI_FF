--------------------------------------------------------
--  Verwijder tabel dv_mapping_specificatie_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_MAPPING_SPECIFICATIE_S')

--------------------------------------------------------
--  DDL for Table dv_mapping_specificatie_s
--------------------------------------------------------
create table dv_mapping_specificatie_s
(
  	dim_mapping_specificatie_h_hk	varchar2(99 char) not null,
	dim_aanmaak_datum            	timestamp not null,
	dim_bron                     	varchar2(999 char) not null,
	dim_dummy                    	varchar2(9 char),
	dim_hashdiff                 	varchar2(99 char) not null,
	dim_is_verwijderd            	number default on null 0 not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_mapping_specificatie_s_pk_idx on dv_mapping_specificatie_s (dim_aanmaak_datum, dim_mapping_specificatie_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_mapping_specificatie_s
--------------------------------------------------------

alter table dv_mapping_specificatie_s add constraint dv_mapping_specificatie_s_pk primary key (dim_aanmaak_datum, dim_mapping_specificatie_h_hk) using index dv_mapping_specificatie_s_pk_idx enable
/