--------------------------------------------------------
--  Verwijder tabel dv_dqregel_dbattribuut_l als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DQREGEL_DBATTRIBUUT_L')

--------------------------------------------------------
--  DDL for Table dv_dqregel_dbattribuut_l
--------------------------------------------------------
create table dv_dqregel_dbattribuut_l
(
  	dim_dbattribuut_h_hk        	varchar2(99 char) not null,
	dim_dqregel_dbattribuut_l_hk	varchar2(99 char) not null,
	dim_dqregel_h_hk            	varchar2(99 char) not null,
	dim_aanmaak_datum           	timestamp not null,
	dim_bron                    	varchar2(999 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_dqregel_dbattribuut_l_pk_idx on dv_dqregel_dbattribuut_l (dim_dqregel_dbattribuut_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dqregel_dbattribuut_l
--------------------------------------------------------

alter table dv_dqregel_dbattribuut_l add constraint dv_dqregel_dbattribuut_l_pk primary key (dim_dqregel_dbattribuut_l_hk) using index dv_dqregel_dbattribuut_l_pk_idx enable
/