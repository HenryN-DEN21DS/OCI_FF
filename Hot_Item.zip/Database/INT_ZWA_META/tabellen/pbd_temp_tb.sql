--------------------------------------------------------
--  Verwijder tabel pbd_temp_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('PBD_TEMP_TB')

--------------------------------------------------------
--  DDL for Table pbd_temp_tb
--------------------------------------------------------
create table pbd_temp_tb
(
  	hashkey	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table pbd_temp_tb
--------------------------------------------------------

