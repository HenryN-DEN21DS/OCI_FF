--------------------------------------------------------
--  Verwijder tabel pbd_housekeeping_wordt_verwijderd_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('PBD_HOUSEKEEPING_WORDT_VERWIJDERD_TB')

--------------------------------------------------------
--  DDL for Table pbd_housekeeping_wordt_verwijderd_tb
--------------------------------------------------------
create table pbd_housekeeping_wordt_verwijderd_tb
(
  	om_naam            	varchar2(999 char) not null,
	percentage         	number,
	tabel_naam         	varchar2(999 char) not null,
	tijdstip_uitgevoerd	timestamp not null,
	totaal             	number,
	wordt_verwijderd   	number
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table pbd_housekeeping_wordt_verwijderd_tb
--------------------------------------------------------

