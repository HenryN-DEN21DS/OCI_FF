--------------------------------------------------------
--  Verwijder tabel dv_dbattribuut_h als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DBATTRIBUUT_H')

--------------------------------------------------------
--  DDL for Table dv_dbattribuut_h
--------------------------------------------------------
create table dv_dbattribuut_h
(
  	dim_dbattribuut_h_hk	varchar2(99 char) not null,
	dim_aanmaak_datum   	timestamp,
	dim_bron            	varchar2(999 char),
	database_naam       	varchar2(999 char),
	host_naam           	varchar2(999 char),
	kolom_naam          	varchar2(999 char),
	schema_naam         	varchar2(999 char),
	tabel_naam          	varchar2(999 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_dbattribuut_h_pk_idx on dv_dbattribuut_h (dim_dbattribuut_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dbattribuut_h
--------------------------------------------------------

alter table dv_dbattribuut_h add constraint dv_dbattribuut_h_pk primary key (dim_dbattribuut_h_hk) using index dv_dbattribuut_h_pk_idx enable
/