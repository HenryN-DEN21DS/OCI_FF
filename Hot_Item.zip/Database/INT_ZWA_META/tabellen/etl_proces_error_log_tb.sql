
--------------------------------------------------------
--  Verwijder tabel etl_proces_error_log_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('ETL_PROCES_ERROR_LOG_TB')

--------------------------------------------------------
--  DDL for Table etl_proces_error_log_tb
--------------------------------------------------------
create table etl_proces_error_log_tb
(
  	proces_error_log_id 		number generated always as identity minvalue 1 maxvalue 9999999999999999999999999999 increment by 1 start with 1 nocache  noorder  nocycle  nokeep  noscale, 
	proces_naam 				varchar2(99 char), 
	error_tijd 					timestamp (6), 
	error_tekst 				varchar2(999 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------


--------------------------------------------------------
--  Constraints for Table etl_proces_error_log_tb
--------------------------------------------------------

