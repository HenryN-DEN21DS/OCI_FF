--------------------------------------------------------
--  Verwijder tabel dv_meta_userstatus_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_META_USERSTATUS_TB')

--------------------------------------------------------
--  DDL for Table dv_meta_userstatus_tb
--------------------------------------------------------
create table dv_meta_userstatus_tb
(
  	input_user_status   	varchar2(4000 char),
	insert_stmt         	varchar2(4000 char),
	mapping_specificatie	varchar2(4000 char),
	select_stmt         	varchar2(4000 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table dv_meta_userstatus_tb
--------------------------------------------------------

