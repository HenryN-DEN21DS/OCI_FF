--------------------------------------------------------
--  Verwijder tabel dv_dqregel_dbattribuut_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DQREGEL_DBATTRIBUUT_S')

--------------------------------------------------------
--  DDL for Table dv_dqregel_dbattribuut_s
--------------------------------------------------------
create table dv_dqregel_dbattribuut_s
(
  	dim_dqregel_dbattribuut_l_hk	varchar2(99 char) not null,
	dim_aanmaak_datum           	timestamp not null,
	dim_bron                    	varchar2(999 char) not null,
	dim_dummy                   	varchar2(9 char),
	dim_hashdiff                	varchar2(99 char) not null,
	dim_is_verwijderd           	number default on null 0 not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_dqregel_dbattribuut_s_pk_idx on dv_dqregel_dbattribuut_s (dim_aanmaak_datum, dim_dqregel_dbattribuut_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dqregel_dbattribuut_s
--------------------------------------------------------

alter table dv_dqregel_dbattribuut_s add constraint dv_dqregel_dbattribuut_s_pk primary key (dim_aanmaak_datum, dim_dqregel_dbattribuut_l_hk) using index dv_dqregel_dbattribuut_s_pk_idx enable
/