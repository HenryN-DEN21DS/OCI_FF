--------------------------------------------------------
--  Verwijder tabel dv_dbattr_dbattr_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DBATTR_DBATTR_S')

--------------------------------------------------------
--  DDL for Table dv_dbattr_dbattr_s
--------------------------------------------------------
create table dv_dbattr_dbattr_s
(
  	dim_dbattr_dbattr_l_hk	varchar2(99 char) not null,
	dim_aanmaak_datum     	timestamp not null,
	dim_bron              	char(999) not null,
	dim_hashdiff          	varchar2(99 char) not null,
	dim_is_verwijderd     	number default on null 0 not null,
	mapping_naam          	varchar2(999 char),
	mapping_omschrijving  	varchar2(999 char),
	regel_naam            	varchar2(999 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_dbattr_dbattr_s_pk_idx on dv_dbattr_dbattr_s (dim_aanmaak_datum, dim_dbattr_dbattr_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dbattr_dbattr_s
--------------------------------------------------------

alter table dv_dbattr_dbattr_s add constraint dv_dbattr_dbattr_s_pk primary key (dim_aanmaak_datum, dim_dbattr_dbattr_l_hk) using index dv_dbattr_dbattr_s_pk_idx enable
/