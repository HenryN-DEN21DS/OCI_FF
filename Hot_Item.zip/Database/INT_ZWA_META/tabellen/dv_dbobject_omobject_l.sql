--------------------------------------------------------
--  Verwijder tabel dv_dbobject_omobject_l als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DBOBJECT_OMOBJECT_L')

--------------------------------------------------------
--  DDL for Table dv_dbobject_omobject_l
--------------------------------------------------------
create table dv_dbobject_omobject_l
(
  	dim_dbobject_h_hk         	varchar2(99 char) not null,
	dim_dbobject_omobject_l_hk	varchar2(99 char) not null,
	dim_omobject_h_hk         	varchar2(99 char) not null,
	dim_aanmaak_datum         	timestamp not null,
	dim_bron                  	varchar2(999 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dim_dbobject_omobject_l_hk_idx on dv_dbobject_omobject_l (dim_dbobject_omobject_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dbobject_omobject_l
--------------------------------------------------------

alter table dv_dbobject_omobject_l add constraint dim_dbobject_omobject_l_hk primary key (dim_dbobject_omobject_l_hk) using index dim_dbobject_omobject_l_hk_idx enable
/