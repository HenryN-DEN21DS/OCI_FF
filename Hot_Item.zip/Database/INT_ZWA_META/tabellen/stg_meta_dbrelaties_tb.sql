--------------------------------------------------------
--  Verwijder tabel stg_meta_dbrelaties_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('STG_META_DBRELATIES_TB')

--------------------------------------------------------
--  DDL for Table stg_meta_dbrelaties_tb
--------------------------------------------------------
create table stg_meta_dbrelaties_tb
(
  	dim_dbattribuut_h_hk_bron     	varchar2(99 char) not null,
	dim_dbattribuut_h_hk_doel     	varchar2(99 char) not null,
	dim_dbobject_dbobject_l_hk    	varchar2(99 char) not null,
	dim_dbobject_h_hk_bron        	varchar2(99 char) not null,
	dim_dbobject_h_hk_doel        	varchar2(99 char) not null,
	dim_foreign_key_l_hk          	varchar2(99 char) not null,
	dim_hashdiff_foreign_key      	varchar2(99 char) not null,
	foreign_key                   	varchar2(999 char),
	primary_key                   	varchar2(999 char),
	dim_dummy                     	varchar2(9 char),
	dim_extractiedatum_xmeta      	timestamp,
	dim_hashdiff_dbobject_dbobject	varchar2(99 char) not null,
	database_naam                 	varchar2(999 char),
	host_naam                     	varchar2(999 char),
	kolom_naam                    	varchar2(999 char),
	parent_database               	varchar2(999 char),
	parent_host                   	varchar2(999 char),
	parent_kolom                  	varchar2(999 char),
	parent_schema                 	varchar2(999 char),
	parent_tabel                  	varchar2(999 char),
	schema_naam                   	varchar2(999 char),
	tabel_naam                    	varchar2(999 char),
	volledige_naam                	varchar2(999 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table stg_meta_dbrelaties_tb
--------------------------------------------------------

