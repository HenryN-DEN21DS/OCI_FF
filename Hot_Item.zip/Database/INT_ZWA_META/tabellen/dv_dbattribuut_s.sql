--------------------------------------------------------
--  Verwijder tabel dv_dbattribuut_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_DBATTRIBUUT_S')

--------------------------------------------------------
--  DDL for Table dv_dbattribuut_s
--------------------------------------------------------
create table dv_dbattribuut_s
(
  	dim_dbattribuut_h_hk	varchar2(99 char) not null,
	primary_key         	varchar2(999 char),
	dim_aanmaak_datum   	timestamp not null,
	dim_bron            	varchar2(99 char) not null,
	dim_hashdiff        	varchar2(99 char) not null,
	dim_is_verwijderd   	number default on null 0 not null,
	data_type           	varchar2(99 char),
	default_waarde      	varchar2(999 char),
	max_lengte          	number,
	min_lengte          	number,
	null_toegestaan     	number
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_dbattribuut_s_pk_idx on dv_dbattribuut_s (dim_aanmaak_datum, dim_dbattribuut_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_dbattribuut_s
--------------------------------------------------------

alter table dv_dbattribuut_s add constraint dv_dbattribuut_s_pk primary key (dim_aanmaak_datum, dim_dbattribuut_h_hk) using index dv_dbattribuut_s_pk_idx enable
/