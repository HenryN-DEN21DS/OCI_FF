--------------------------------------------------------
--  Verwijder tabel stg_meta_dq_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('STG_META_DQ_TB')

--------------------------------------------------------
--  DDL for Table stg_meta_dq_tb
--------------------------------------------------------
create table stg_meta_dq_tb
(
  	dim_dbattribuut_h_hk            	varchar2(99 char) not null,
	dim_dqregel_h_hk                	varchar2(99 char) not null,
	dqregel_dbattribuut_l_hk        	varchar2(99 char) not null,
	dim_dummy                       	varchar2(9 char),
	dim_hashdiff_dqregel            	varchar2(99 char) not null,
	dim_hashdiff_dqregel_dbattribuut	varchar2(99 char) not null,
	database_naam                   	varchar2(999 char),
	dq_procedure                    	varchar2(99 char),
	dq_regel                        	varchar2(999 char),
	dq_syntax                       	varchar2(999 char),
	host_naam                       	varchar2(999 char),
	kolom_naam                      	varchar2(999 char),
	regel_beschrijving              	varchar2(999 char),
	schema_naam                     	varchar2(999 char),
	tabel_naam                      	varchar2(999 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table stg_meta_dq_tb
--------------------------------------------------------

