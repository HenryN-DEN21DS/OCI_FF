--------------------------------------------------------
--  Verwijder tabel dv_mapping_specificatie_h als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_MAPPING_SPECIFICATIE_H')

--------------------------------------------------------
--  DDL for Table dv_mapping_specificatie_h
--------------------------------------------------------
create table dv_mapping_specificatie_h
(
  	dim_mapping_specificatie_h_hk	varchar2(99 char) not null,
	dim_aanmaak_datum            	timestamp not null,
	dim_bron                     	varchar2(999 char) not null,
	mapping_specificatie_naam    	varchar2(99 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index dv_mapping_specificatie_h_pk_idx on dv_mapping_specificatie_h (dim_mapping_specificatie_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_mapping_specificatie_h
--------------------------------------------------------

alter table dv_mapping_specificatie_h add constraint dv_mapping_specificatie_h_pk primary key (dim_mapping_specificatie_h_hk) using index dv_mapping_specificatie_h_pk_idx enable
/