--------------------------------------------------------
--  Verwijder tabel stg_meta_omobjecten_bwt_tb als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('STG_META_OMOBJECTEN_BWT_TB')

--------------------------------------------------------
--  DDL for Table stg_meta_omobjecten_bwt_tb
--------------------------------------------------------
create table stg_meta_omobjecten_bwt_tb
(
  	dim_dbobject_h_hk             	varchar2(99 char) not null,
	dim_dbobject_omobject_l_hk    	varchar2(99 char) not null,
	dim_omobject_h_hk             	varchar2(99 char) not null,
	dim_dummy                     	varchar2(9 char),
	dim_extractiedatum_xmeta      	timestamp,
	dim_hashdiff_dbobject_omobject	varchar2(99 char) not null,
	dim_hashdiff_omobject         	varchar2(99 char) not null,
	bewaartermijn                 	varchar2(99 char),
	bewaartermijn_eenheid         	varchar2(99 char),
	bewaartermijn_ingangsdatum    	varchar2(999 char),
	database_naam                 	varchar2(99 char),
	host_naam                     	varchar2(99 char),
	om_naam                       	varchar2(99 char),
	omobject_id                   	varchar2(99 char),
	schema_naam                   	varchar2(99 char),
	tabel_naam                    	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table stg_meta_omobjecten_bwt_tb
--------------------------------------------------------

