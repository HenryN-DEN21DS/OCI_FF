
--------------------------------------------------------
---  ddl for view meta_bewaartermijnenstmt_vw
--------------------------------------------------------


  create or replace force view meta_bewaartermijnenstmt_vw as 
  with cte_bewaartermijnen as
( select *
  from meta_bewaartermijnen_vw
  where bwtmaxdatum is not null  -- alleen objecten met een valide bewaartermijn
  and bwtdqissue  is     null  -- geen andere dq issues (bwt sat gevonden, geen partititie mismatch, etc)

)
, cte_stmt as
( select btn.*
    	, 	case
				when btn.teschonentabeltype = 'Sat'  then 1
				when btn.teschonentabeltype = 'Link' then 2
				when btn.teschonentabeltype = 'Hub'  then 3
				when btn.teschonentabeltype = 'Bwt'  then 4
				else 5
       		end	as stmtvolgorde
       , 	'insert into int_zwa_meta.pbd_housekeeping_wordt_verwijderd_tb (om_naam, tabel_naam, tijdstip_uitgevoerd, totaal, wordt_verwijderd, percentage) '                                 || chr(10) ||
	        'select sub.omnaam '                                                                                                                                || chr(10) ||
			'     , sub.tabelnaam '                                                                                                                             || chr(10) ||
			'     , sub.tijdstip_uitgevoerd '                                                                                                                           || chr(10) ||
			--'     , sub.totaal '                                                                                                                                 || chr(10) ||
            '     , (select count(*) from ' ||  btn.teschonentabelschema || '.' || btn.teschonentabelnaam ||  ') as totaal'                                                      || chr(10) ||
			'     , nvl(sub.wordt_verwijderd, 0) as wordt_verwijderd '                                                                                                 || chr(10) ||
			'     , cast( case when (select count(*) from ' ||  btn.teschonentabelschema || '.' || btn.teschonentabelnaam ||  ') > 0 
                        then (nvl(sub.wordt_verwijderd, 0) / (select count(*) from ' ||  btn.teschonentabelschema || '.' || btn.teschonentabelnaam ||  ')) * 100 else 0 end as decimal(6,2)) as percentage ' || chr(10) ||
	        '  from ( select ''' || btn.omnaam || ''' as omnaam' 																		                        || chr(10) ||
			'              , ''' || btn.teschonentabelschema || '.' || btn.teschonentabelnaam || ''' as tabelnaam'						                        || chr(10) ||
			'              , sysdate as tijdstip_uitgevoerd'																				                            || chr(10) ||
			--'	           , count(*) as totaal'																							                        || chr(10) ||
	        '              , sum(case when bwt.' || btn.bwthashkey || ' is not null then 1 else 0 end) as wordt_verwijderd'	                                        || chr(10) ||
	        '           from      ' || btn.teschonentabelschema || '.' || btn.teschonentabelnaam || ' tgt ' 							                        || chr(10) ||
			case
			 when btn.bwtrelatietype = 'OMDBDB2' and teschonentabeltype in ('Sat', 'Bwt') --'linksat op link aan hub met bwt sat'
			      -- extra tussenstap nodig
			 then '          join ' || btn.parentschema || '.' || btn.parentnaam || ' par '	                   					                        || chr(10) ||
			      '                  on par.' || btn.parenthashkey || ' = tgt.' || btn.teschonentabelhashkey	                                                || chr(10) ||
	              '          join ' || btn.bwtschema || '.' || btn.bwtnaam || '_vw bwt '						                                        || chr(10) ||
			      '                  on bwt.' || btn.bwthashkey || ' = par.' || btn.parenttodvhashkey  												            || chr(10)
			 else '          join ' || btn.bwtschema || '.' || btn.bwtnaam || '_vw bwt '						                                        || chr(10) ||
			      '                  on bwt.' || btn.bwthashkey || ' = tgt.' || btn.teschonentabelhashkey  							                            || chr(10)
			end                                                                                                                                                 ||
			'                 and bwt.dim_is_geldig = 1 '                                                                                                           || chr(10) ||
			'                 and bwt.dim_ingangsdatum_bwt <= timestamp''' || to_char(btn.bwtmaxdatum, 'YYYY-MM-DD HH24:MI:SS') || '''' ||
            '       ) sub;'                                                                                                                                     || chr(10) || chr(10)
       as wordt_verwijderd_stmt		
            ,'delete from      ' || btn.teschonentabelschema || '.' || btn.teschonentabelnaam || ' tgt ' 							                        || chr(10) ||
             'where tgt.' || btn.teschonentabelhashkey || ' in ' || chr(10) ||
             '(select tgt.' || btn.teschonentabelhashkey || ' from      ' || btn.teschonentabelschema || '.' || btn.teschonentabelnaam || ' tgt ' 							                        || chr(10) ||
                        case
                         when btn.bwtrelatietype = 'OMDBDB2' and teschonentabeltype in ('Sat', 'Bwt') --'linksat op link aan hub met bwt sat'
                              -- extra tussenstap nodig
                         then '          join ' || btn.parentschema || '.' || btn.parentnaam || ' par '	                   					                        || chr(10) ||
                              '                  on par.' || btn.parenthashkey || ' = tgt.' || btn.teschonentabelhashkey	                                                || chr(10) ||
                              '          join ' || btn.bwtschema || '.' || btn.bwtnaam || '_vw bwt '						                                        || chr(10) ||
                              '                  on bwt.' || btn.bwthashkey || ' = par.' || btn.parenttodvhashkey  												            || chr(10)
                         else '          join ' || btn.bwtschema || '.' || btn.bwtnaam || '_vw bwt '						                                        || chr(10) ||
                              '                  on bwt.' || btn.bwthashkey || ' = tgt.' || btn.teschonentabelhashkey  							                            || chr(10)
                        end                                                                                                                                                 ||
                        '                 and bwt.dim_is_geldig = 1 '                                                                                                           || chr(10) ||
                        '                 and bwt.dim_ingangsdatum_bwt <= timestamp''' || to_char(btn.bwtmaxdatum, 'YYYY-MM-DD HH24:MI:SS') || ''');'
            as verwijder_stmt
    from cte_bewaartermijnen btn
)
select *
  from cte_stmt
order by stmtvolgorde, parentnaam, teschonentabelnaam;
