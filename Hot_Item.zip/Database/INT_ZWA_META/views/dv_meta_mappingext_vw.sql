
--------------------------------------------------------
-- ddl for view dv_meta_mappingext_vw
--------------------------------------------------------

  create or replace force view int_zwa_meta.dv_meta_mappingext_vw as 
  with cte_me as
(select *
from int_zwa_meta.dv_meta_mapping_vw
)
,
cte_stg_hashkeys as
(select distinct me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
-- hier worden alle onderdelen van de keys en hashdiffs bij elkaar gebracht
,cast('standard_hash(coalesce(''''||x.'||listagg(distinct me.bron_kolom_naam ||' ,'''')' , '||''|''||coalesce(''''||x.') 
		within group (order by me.bron_kolom_naam asc) over (partition by me.doel_naam_volledig) ||',''MD5'') as '||me.doel_kolom_naam ||''  
		as varchar2(4000))  
		as sql_deel_stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_STG'  escape '\' and me.regel_naam is not null)
,
cte_stg_insert as
(select distinct me.*
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam ||'(' || (listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' ||
    ' values (:' || (listagg(distinct 
        (case 
        when me.regel_naam is null 
        then me.bron_kolom_naam
        else me.doel_kolom_naam
        end
        )
        , ',:') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_STG'  escape '\'  and bron_schema_naam <> 'OKV_IMF_PO' and bron_schema_naam <> 'OKV_IMF_PM')
,
cte_stg as
(select 
distinct 
cte_stg_hashkeys.*, cte_stg_insert.insert_stmt
from cte_stg_hashkeys 
left join cte_stg_insert
on cte_stg_hashkeys.doel_tabel = cte_stg_insert.doel_tabel)
,
cte_hub_hashkeys as
(select distinct me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
, '' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_HUB'  escape '\' and me.regel_naam is not null)
,
cte_hub_insert as
(select distinct me.*
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam ||'(dim_aanmaak_datum,dim_bron,' || (listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' ||
    ' values (:dim_aanmaak_datum,:dim_bron,:' || (listagg(distinct 
        (case 
        when me.regel_naam is null 
        then me.bron_kolom_naam
        else me.doel_kolom_naam
        end
        )
        , ',:') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_HUB'  escape '\')
,
cte_hub as
(select distinct cte_hub_hashkeys.*, cte_hub_insert.insert_stmt
from cte_hub_hashkeys 
left join cte_hub_insert
on cte_hub_hashkeys.doel_tabel = cte_hub_insert.doel_tabel)
,
cte_sat_hashkeys as
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
, '' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_SAT'  escape '\' and (me.regel_naam = 'hubkey' or me.regel_naam = 'linkkey'))
,
cte_sat_dim_hashdiff as
(select distinct 
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_hashdiff_naam
,me.doel_kolom_naam as doel_hashdiff_naam
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
, '' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_SAT'  escape '\' and me.regel_naam = 'dim_hashdiff' )
,
cte_sat_beschr as -- selecteren van alle beschrijvende kolommen van de sat
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,listagg(distinct(me.bron_kolom_naam), ',') within group (order by me.bron_kolom_naam) over (partition by me.doel_tabel_naam) as bron_hashdiff_cols
,listagg(distinct(me.doel_kolom_naam), ',') within group (order by me.doel_kolom_naam) over (partition by me.doel_tabel_naam) as doel_hashdiff_cols
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
, '' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_SAT'  escape '\' and me.regel_naam is null) 
,
cte_sat_insert as
(select distinct
me.*
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam ||'(dim_aanmaak_datum,dim_bron,dim_is_verwijderd,' || (listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' ||
    ' values (:dim_aanmaak_datum,:dim_bron,:dim_is_verwijderd,:' || (listagg(distinct 
        (case 
        when me.regel_naam is null 
        then me.bron_kolom_naam
        else me.doel_kolom_naam
        end
        )
        , ',:') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_SAT'  escape '\')
,
cte_sat as --samenvoegen van de verschillende onderdelen van de sat 
(select distinct
s1.mapping_specificatie as mapping_specificatie
,s1.bron_tabel as bron_tabel
,s1.doel_tabel as doel_tabel
,s1.bron_key_kolom as bron_key_kolom
,s1.doel_key_kolom as doel_key_kolom
,s2.bron_hashdiff_cols || '~' || s2.doel_hashdiff_cols || '~' ||s3.bron_hashdiff_naam || '~' ||s3.doel_hashdiff_naam as stmt -- de parameters hashdiff_kolommen en hahsdiff_key zitten in select_stmt
,s1.bron_schema as bron_schema
,s1.doel_schema as doel_schema
, cte_sat_insert.insert_stmt
from cte_sat_hashkeys s1
join cte_sat_beschr s2
on s1.doel_tabel = s2.doel_tabel
join cte_sat_dim_hashdiff s3
on s3.doel_tabel = s2.doel_tabel
left join cte_sat_insert
on s1.doel_tabel = cte_sat_insert.doel_tabel
)
,
cte_lnk_linkkeys as --selecteren van de primary keys van de link tabellen
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
, '' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_LNK'  escape '\' and me.regel_naam = 'linkkey'
)
,
cte_lnk_insert as
(select distinct
me.*
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam ||'(dim_aanmaak_datum, dim_bron,' || (listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' ||
    ' values (:dim_aanmaak_datum,:dim_bron,:' || (listagg(distinct 
        (case 
        when me.regel_naam is null 
        then me.bron_kolom_naam
        else me.doel_kolom_naam
        end
        )
        , ',:') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_LNK'  escape '\')
,
cte_lnk as -- samenvoegen van de link onderdelen
(select distinct
c1.mapping_specificatie as mapping_specificatie
,c1.bron_tabel as bron_tabel
,c1.doel_tabel as doel_tabel
,c1.bron_key_kolom as bron_key_kolom
,c1.doel_key_kolom as doel_key_kolom
, '' as stmt
,c1.bron_schema as bron_schema
,c1.doel_schema as doel_schema
, cte_lnk_insert.insert_stmt
from cte_lnk_linkkeys c1
left join cte_lnk_insert
on c1.doel_tabel = cte_lnk_insert.doel_tabel
)
,
cte_dim_dimkeys as --selecteren van de primary keys van de dim tabellen
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_DIM'  escape '\' and me.regel_naam = 'dimkey'
)
,
cte_dim_insert as
(select distinct 
me.*
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'select * from ' ||me.bron_schema_naam || '.' || me.bron_tabel_naam as stmt
,'insert into ' || me.doel_tabel_naam ||'(' ||(listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' ||
    ' values (:' || (listagg(distinct 
        (case 
        when me.regel_naam is null 
        then me.bron_kolom_naam
        else me.doel_kolom_naam
        end
        )
        , ',:') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' 
as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_DIM'  escape '\'
)
,
cte_dim as -- samenvoegen van de dim onderdelen
(select distinct
c1.mapping_specificatie as mapping_specificatie
,c1.bron_tabel as bron_tabel
,c1.doel_tabel as doel_tabel
,c1.bron_key_kolom as bron_key_kolom
,c1.doel_key_kolom as doel_key_kolom
, cte_dim_insert.stmt  as stmt
,c1.bron_schema as bron_schema
,c1.doel_schema as doel_schema
, cte_dim_insert.insert_stmt
from cte_dim_dimkeys c1
left join cte_dim_insert
on c1.doel_tabel = cte_dim_insert.doel_tabel
)
,
cte_fct_keys as --selecteren van de primary keys van de fct tabellen
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,listagg(distinct me.bron_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam) as  bron_key_kolom
,listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam) as doel_key_kolom
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_FCT'  escape '\' and me.regel_naam = 'fctkey'
)
,
cte_fct_insert as
(select distinct 
me.*
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'select * from ' ||me.bron_schema_naam || '.' || me.bron_tabel_naam as stmt
,'insert into ' || me.doel_tabel_naam ||'(' ||(listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' ||
    ' values (:' || (listagg(distinct 
        (case 
        when me.regel_naam is null 
        then me.bron_kolom_naam
        else me.doel_kolom_naam
        end
        )
        , ',:') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' 
as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_FCT'  escape '\'
)
,
cte_fct as -- samenvoegen van de fct onderdelen
(select distinct
c1.mapping_specificatie as mapping_specificatie
,c1.bron_tabel as bron_tabel
,c1.doel_tabel as doel_tabel
,c1.bron_key_kolom as bron_key_kolom
,c1.doel_key_kolom as doel_key_kolom
, cte_fct_insert.stmt  as stmt
,c1.bron_schema as bron_schema
,c1.doel_schema as doel_schema
, cte_fct_insert.insert_stmt
from cte_fct_keys c1
left join cte_fct_insert
on c1.doel_tabel = cte_fct_insert.doel_tabel
)
select
cte_stg.mapping_specificatie
,cte_stg.bron_tabel
,cte_stg.doel_tabel
,cte_stg.bron_key_kolom
,cte_stg.doel_key_kolom
,cast('select x.*,' ||listagg(distinct cte_stg.sql_deel_stmt,',') within group (order by cte_stg.doel_tabel) over (partition by cte_stg.doel_tabel)|| ' from ' ||cte_stg.bron_tabel||' x' as varchar2(4000)) as stmt
,cte_stg.bron_schema
,cte_stg.doel_schema
,cte_stg.insert_stmt
from cte_stg
union all
select
cte_hub.mapping_specificatie
,cte_hub.bron_tabel
,cte_hub.doel_tabel
,cte_hub.bron_key_kolom
,cte_hub.doel_key_kolom
,cte_hub.stmt
,cte_hub.bron_schema
,cte_hub.doel_schema
,cte_hub.insert_stmt
from cte_hub
union all
select
cte_sat.mapping_specificatie
,cte_sat.bron_tabel
,cte_sat.doel_tabel
,cte_sat.bron_key_kolom
,cte_sat.doel_key_kolom
,cte_sat.stmt
,cte_sat.bron_schema
,cte_sat.doel_schema
,cte_sat.insert_stmt
from cte_sat
union all
select
cte_lnk.mapping_specificatie
,cte_lnk.bron_tabel
,cte_lnk.doel_tabel
,cte_lnk.bron_key_kolom
,cte_lnk.doel_key_kolom
,cte_lnk.stmt
,cte_lnk.bron_schema
,cte_lnk.doel_schema
,cte_lnk.insert_stmt
from cte_lnk
union all
select
cte_dim.mapping_specificatie
,cte_dim.bron_tabel
,cte_dim.doel_tabel
,cte_dim.bron_key_kolom
,cte_dim.doel_key_kolom
,cte_dim.stmt
,cte_dim.bron_schema
,cte_dim.doel_schema
,cte_dim.insert_stmt
from cte_dim
union all
select
cte_fct.mapping_specificatie
,cte_fct.bron_tabel
,cte_fct.doel_tabel
,cte_fct.bron_key_kolom
,cte_fct.doel_key_kolom
,cte_fct.stmt
,cte_fct.bron_schema
,cte_fct.doel_schema
,cte_fct.insert_stmt
from cte_fct;

