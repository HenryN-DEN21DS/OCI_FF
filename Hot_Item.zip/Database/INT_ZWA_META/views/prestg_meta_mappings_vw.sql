create or replace force view prestg_meta_mappings_vw as 
  with cte as
  (select
        '0' as dim_dummy
        , case
        when doel_tabel_naam like 'STG\_%' escape '\' or doel_tabel_naam like 'PRESTG\_%' escape '\' then doel_schema_naam || '_STG'
        when doel_tabel_naam like '%\_H' escape '\' then doel_schema_naam ||'_HUB'
        when (doel_tabel_naam like '%\_S' escape '\' or doel_tabel_naam like '%\_S\_BWT' escape '\') then doel_schema_naam ||'_SAT'
        when doel_tabel_naam like '%\_L' escape '\' then doel_schema_naam ||'_LNK'
        when doel_tabel_naam like '%\_DT' escape '\' then doel_schema_naam ||'_DIM'
        when doel_tabel_naam like '%\_FT' escape '\' then doel_schema_naam ||'_FCT'
        when doel_schema_naam like 'BDR\_%' escape '\' and doel_tabel_naam like '%\_STG' escape '\' then doel_schema_naam ||'_FCT_STG'
        end as mapping_specificatie_naam
      , mapping_naam
      , bron_naam_volledig
	  , bron_host_naam	
	  , bron_database_naam
	  , bron_schema_naam  
	  , bron_tabel_naam   
      , bron_kolom_naam   
      , doel_naam_volledig
      , doel_host_naam    
      , doel_database_naam
      , doel_schema_naam  
      , doel_tabel_naam   
      , doel_kolom_naam   
      , case
                when doel_schema_naam like 'BDR\_%' escape '\' and doel_tabel_naam like '%\_DT' escape '\' and doel_kolom_naam like '%\_KEY%' escape '\' then 'dimkey'
                when doel_schema_naam like 'BDR\_%' escape '\' and doel_tabel_naam like '%\_FT' escape '\' and doel_kolom_naam like '%\_KEY%' escape '\' then 'fctkey'
                when doel_schema_naam like 'BDR\_%' escape '\' and doel_tabel_naam like '%\_STG' escape '\' and doel_kolom_naam like 'DIM\_%' escape '\' then 'fctkey'
                when doel_schema_naam not like 'BDR\_%' escape '\' and doel_kolom_naam like '%\_H\_HK%' escape '\' then 'hubkey'
                when doel_schema_naam not like 'BDR\_%' escape '\' and doel_kolom_naam like '%\_L\_HK%' escape '\' then 'linkkey'
                when doel_schema_naam not like 'BDR\_%' escape '\' and doel_kolom_naam like '%\_HASHDIFF' escape '\' and (doel_tabel_naam like '%\_S' escape '\' or doel_tabel_naam like '%\_S\_BWT' escape '\') then 'dim_hashdiff'
                when doel_schema_naam not like 'BDR\_%' escape '\' and doel_kolom_naam like '%\_HASHDIFF\_%' escape '\' and (doel_tabel_naam not like '%\_S' escape '\' or doel_tabel_naam not like '%\_S\_BWT' escape '\')  then 'hashdiff' 
       end as regel_naam
      , mapping_omschrijving
	  , aanmaakdatum
	  , modificatiedatum
      , extractiedatum_xmeta as dim_extractiedatum_xmeta
  , row_number() over (partition by bron_naam_volledig, doel_naam_volledig, mapping_specificatie_naam order by
                       modificatiedatum desc) as rownumber
from
    int_zwa_meta.xmeta_mapping_vw)
    select * from cte where rownumber = 1;


