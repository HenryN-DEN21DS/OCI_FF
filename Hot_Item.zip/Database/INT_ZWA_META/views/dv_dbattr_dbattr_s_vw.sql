create or replace force view dv_dbattr_dbattr_s_vw as 

with cte as (select sat_tabel.dim_dbattr_dbattr_l_hk
, sat_tabel.dim_aanmaak_datum
, sat_tabel.mapping_naam
, sat_tabel.regel_naam
, sat_tabel.mapping_omschrijving
, sat_tabel.dim_hashdiff
, sat_tabel.dim_bron
, sat_tabel.dim_is_verwijderd, lead(sat_tabel.dim_aanmaak_datum) over (partition by sat_tabel.dim_dbattr_dbattr_l_hk order by sat_tabel.dim_aanmaak_datum) - interval '0.000001' second as dim_eind_datum 
from dv_dbattr_dbattr_s sat_tabel)

select dim_dbattr_dbattr_l_hk
, dim_aanmaak_datum
, mapping_naam
, regel_naam
, mapping_omschrijving
, dim_hashdiff
, dim_bron
, dim_is_verwijderd, cast(nvl(dim_eind_datum, timestamp'8888-12-31 00:00:00') as timestamp) as dim_eind_datum, case  when dim_eind_datum is null   then 1  else 0 end as dim_is_geldig  
	from cte where cte.dim_is_verwijderd = 0;
