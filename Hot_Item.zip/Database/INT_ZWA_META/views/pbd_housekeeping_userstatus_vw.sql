
  create or replace force view pbd_housekeeping_userstatus_vw as 
  with wvs as (
	select distinct 
		  teschonentabelschema
		, stmtvolgorde
		, wordt_verwijderd_stmt
	from meta_bewaartermijnenstmt_vw)
	, vs as (
		select 
			  distinct teschonentabelschema
			, stmtvolgorde
			, verwijder_stmt
			, teschonentabelnaam
			, omnaam
		from meta_bewaartermijnenstmt_vw)

select
	  wvs.wordt_verwijderd_stmt || '~' || wvs.teschonentabelschema      as input_user_status
	, row_number() over(partition by wvs.teschonentabelschema  order by  wvs.stmtvolgorde)          	
																		as volgorde
	, 'WORDT_VERWIJDERD'                                                as type_stmt
    , teschonentabelschema                                              as schema
from wvs
union all
select
	  vs.verwijder_stmt || '~' || vs.teschonentabelschema || '~' || vs.teschonentabelnaam || '~' || vs.omnaam     
																		as input_user_status
	, row_number() over(partition by vs.teschonentabelschema  order by  vs.stmtvolgorde)                        
																		as volgorde
	, 'VERWIJDER'                                                       as type_stmt
    , teschonentabelschema                                              as schema
from vs;

