--------------------------------------------------------
--  ddl for view etl_input_vw
--------------------------------------------------------

  create or replace force view etl_input_vw as 
  with  
cte_stg as 
(select 
me.*
from etl_mappingext_vw me
where me.mapping_specificatie like  '%\_STG'  escape '\' and me.doel_schema not like 'BDR\_%' escape '\'
)
, cte_hub as
(select 
me.*
from etl_mappingext_vw me
where me.mapping_specificatie like  '%\_HUB'  escape '\'
)
, cte_link as  
(select 
me.*
from etl_mappingext_vw me
where me.mapping_specificatie like  '%\_LNK'  escape '\' 
)
, cte_sat as 
(select 
me.*
from etl_mappingext_vw me
where me.mapping_specificatie like  '%\_SAT'  escape '\' 
)
, cte_dim as 
(select 
me.*
from etl_mappingext_vw me
where me.mapping_specificatie like  '%\_DIM'  escape '\' 
)
, cte_fct_stg as 
(select 
me.*
from etl_mappingext_vw me
where me.mapping_specificatie like  '%\_FCT\_STG'  escape '\' 
)
, cte_fct as 
(select 
me.*
from etl_mappingext_vw me
where me.mapping_specificatie like  '%\_FCT'  escape '\' 
)

select distinct
  s.mapping_specificatie
, ' '|| '~' ||
  s.doel_tabel || '~' ||
  ' ' || '~' ||
  ' ' || '~' || 
  s.bron_schema || '~' || 
  s.doel_schema as input_user_status
, s.insert_stmt
, s.stmt
from cte_stg s

union all

select distinct
hub.mapping_specificatie
,hub.bron_tabel || '~' || 
hub.doel_tabel || '~' || 
hub.bron_key_kolom || '~' || 
hub.doel_key_kolom || '~' || 
hub.bron_schema || '~' || 
hub.doel_schema as input_user_status
,hub.insert_stmt
,hub.stmt
from cte_hub hub

union all

select distinct
l.mapping_specificatie
,l.bron_tabel || '~' ||
l.doel_tabel || '~' ||
l.bron_key_kolom || '~' ||
l.doel_key_kolom || '~' || 
l.bron_schema || '~' || 
l.doel_schema as input_user_status
,l.insert_stmt
,l.stmt
from cte_link l

union all

select distinct
sat.mapping_specificatie
,sat.bron_tabel || '~' || 
sat.doel_tabel || '~' || 
sat.bron_key_kolom || '~' || 
sat.doel_key_kolom || '~' || 
sat.bron_schema || '~' || 
sat.doel_schema as input_user_status
,sat.insert_stmt
,sat.stmt
from cte_sat sat

union all

select distinct
dim.mapping_specificatie
,dim.bron_tabel || '~' ||
dim.doel_tabel || '~' ||
dim.bron_key_kolom || '~' ||
dim.doel_key_kolom || '~' ||
dim.bron_schema || '~' || 
dim.doel_schema as input_user_status
,dim.insert_stmt
,dim.stmt
from cte_dim dim

union all

select distinct
fs.mapping_specificatie
,fs.bron_tabel || '~' ||
fs.doel_tabel || '~' ||
fs.bron_key_kolom || '~' ||
fs.doel_key_kolom || '~' ||
fs.bron_schema || '~' || 
fs.doel_schema as input_user_status
,fs.insert_stmt
,fs.stmt
from cte_fct_stg fs

union all

select distinct
fct.mapping_specificatie
,fct.bron_tabel || '~' ||
fct.doel_tabel || '~' ||
fct.bron_key_kolom || '~' ||
fct.doel_key_kolom || '~' ||
fct.bron_schema || '~' || 
fct.doel_schema as input_user_status
,fct.insert_stmt
,fct.stmt
from cte_fct fct;

