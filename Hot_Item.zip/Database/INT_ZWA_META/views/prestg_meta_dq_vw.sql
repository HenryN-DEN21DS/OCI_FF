
  create or replace force view int_zwa_meta.prestg_meta_dq_vw  as 
  select
    pmda.volledige_naam,
    pmda.host_naam,
    pmda.database_naam,
    pmda.schema_naam,
    pmda.tabel_naam,
    pmda.kolom_naam,
    mdrvw.dq_regel,
    mdrvw.dq_syntax,
    mdrvw.dq_procedure,
    mdrvw.regel_beschrijving,
    '0' as dim_dummy
from
    prestg_meta_db_attributen_vw pmda
join
    meta_dqregel_vw mdrvw
on
    pmda.volledige_naam = mdrvw.volledige_naam;
