
--------------------------------------------------------
---  ddl for view xmeta_dbattributen_vw
--------------------------------------------------------

create or replace force view xmeta_dbattributen_vw as 
  with primary_keys as (
    select
          df.xmeta_repos_object_id_xmeta      							as datafield_id
        , nvl(ac1.name_xmeta, ac2.name_xmeta) 							as primary_key
    from
        xmeta.asclmodel_datafield df
    left join xmeta.asclmodel_keycomponent ak1
        on
            --REGEXP_SUBTR bevat geen spatie maar SOH in de tweede declaratie, '[^]+[^]'
            --Het is niet te zien in het script. Kopieer naar notepad++ voor SOH karakter.
            ak1.xmeta_repos_object_id_xmeta = to_char(regexp_substr(df.usedas_keycomponent_xmeta,'[^]+[^]',1,1))
    left join xmeta.asclmodel_candidatekey ac1
        on ac1.xmeta_repos_object_id_xmeta = ak1.of_key_xmeta
    left join xmeta.asclmodel_keycomponent ak2
        on ak2.xmeta_repos_object_id_xmeta = to_char(regexp_substr(df.usedas_keycomponent_xmeta,'[^]+[^]',1,2))
    left join xmeta.asclmodel_candidatekey ac2
        on ac2.xmeta_repos_object_id_xmeta = ak2.of_key_xmeta
    )
		, foreign_keys as
    (
    select
          df.xmeta_repos_object_id_xmeta      							as datafield_id
        , nvl(af1.name_xmeta, af2.name_xmeta) 							as foreign_key
        , hs2.name_xmeta 												as fk_parent_host
        , db2.name_xmeta 												as fk_parent_database
        , ds2.name_xmeta 												as fk_parent_schema
        , dc2.name_xmeta 												as fk_parent_tabel
        , df2.name_xmeta 					    						as fk_parent_kolom
    from
        xmeta.asclmodel_datafield df
    left join xmeta.asclmodel_keycomponent ak1
        on ak1.xmeta_repos_object_id_xmeta = to_char(regexp_substr(df.usedas_keycomponent_xmeta,'[^]+[^]',1,1))
    left join xmeta.asclmodel_foreignkey af1
        on af1.xmeta_repos_object_id_xmeta = ak1.of_key_xmeta
    left join xmeta.asclmodel_keycomponent ak2
        on ak2.xmeta_repos_object_id_xmeta = to_char(regexp_substr(df.usedas_keycomponent_xmeta,'[^]+[^]',1,2))
    left join xmeta.asclmodel_foreignkey af2
        on af2.xmeta_repos_object_id_xmeta = ak2.of_key_xmeta
	left join xmeta.asclmodel_datafield df2
        on nvl(ak1.references_datafield_xmeta, ak2.references_datafield_xmeta) = df2.xmeta_repos_object_id_xmeta
    join xmeta.asclmodeldatacollectin dc2
        on dc2.xmeta_repos_object_id_xmeta = df2.container_rid
    join xmeta.asclmodel_dataschema ds2
		on ds2.xmeta_repos_object_id_xmeta = dc2.container_rid
	join xmeta.asclmodel_database db2
		on db2.xmeta_repos_object_id_xmeta = ds2.container_rid
	join xmeta.asclmodel_hostsystem hs2
		on hs2.xmeta_repos_object_id_xmeta = db2.container_rid
    where nvl(af1.name_xmeta, af2.name_xmeta) is not null
    )
	select
		-- cast(hs.name_xmeta || '.' || db.name_xmeta || '.' || ds.name_xmeta || '.' || dc.name_xmeta || '.' || df.name_xmeta as varchar(999)) as volledige_naam
		  cast((regexp_substr(hs.name_xmeta,'[^.]+',1,1)) || '.' || db.name_xmeta || '.' || ds.name_xmeta || '.' || dc.name_xmeta || '.' || df.name_xmeta 
																		as varchar(999)) 
																		as volledige_naam
		, cast(db.name_xmeta || '.' || ds.name_xmeta || '.' || dc.name_xmeta || '.' || df.name_xmeta as varchar(999)) 
																		as mapping_naam
		--  , cast(hs.name_xmeta as          varchar(999))              as host_naam
		, to_char(regexp_substr(hs.name_xmeta,'[^.]+',1,1)) 			as host_naam
		, cast(db.name_xmeta as          varchar(999))              	as database_naam
		, cast(ds.name_xmeta as          varchar(999))              	as schema_naam
		, cast(dc.name_xmeta as          varchar(999))              	as tabel_naam
		, cast(df.name_xmeta as          varchar(999))              	as kolom_naam
		, cast(df.nativetype_xmeta as    varchar(999))              	as data_type
		, cast(df.defaultvalue_xmeta as  varchar(999))              	as default_waarde
		, cast(df.minimumlength_xmeta as integer)                   	as min_lengte
		, cast(df.maximumlength_xmeta as integer)                   	as max_lengte
		, cast(df.isnullable_xmeta as    smallint)                  	as null_toegestaan
		, cast(pk.primary_key as         varchar(999))              	as primary_key 
		, cast(fk.foreign_key as         varchar(999))              	as foreign_key
		, to_char(regexp_substr(fk.fk_parent_host,'[^.]+',1,1)) 		as fk_parent_host
		--  , cast(fk.fk_parent_host as 	   varchar(999))              as fk_parent_host
		, cast(fk.fk_parent_database as  varchar(999))          	  	as fk_parent_database
		, cast(fk.fk_parent_schema as    varchar(999))              	as fk_parent_schema
		, cast(fk.fk_parent_tabel as 	   varchar(999))              	as fk_parent_tabel
		, cast(fk.fk_parent_kolom as 	   varchar(999))              	as fk_parent_kolom
		, cast(to_timestamp('1970-01-01', 'YYYY-MM-DD') + numtodsinterval((df.xmeta_creation_timestamp_xmeta)/1000, 'SECOND')	as timestamp(6)) 
																		as aanmaakdatum
		, cast(to_timestamp('1970-01-01', 'YYYY-MM-DD') + numtodsinterval((df.xmetamodificationtimestampxmet)/1000, 'SECOND')	as timestamp(6)) 
																		as modificatiedatum
		, cast(current_timestamp as 	   timestamp(6)) 			  	as extractiedatum_xmeta
	from xmeta.asclmodel_datafield df
    join xmeta.asclmodeldatacollectin dc
        on dc.xmeta_repos_object_id_xmeta = df.container_rid
    join xmeta.asclmodel_dataschema ds
        on ds.xmeta_repos_object_id_xmeta = dc.container_rid
    join xmeta.asclmodel_database db
        on db.xmeta_repos_object_id_xmeta = ds.container_rid
    join xmeta.asclmodel_hostsystem hs
        on hs.xmeta_repos_object_id_xmeta = db.container_rid
    left join primary_keys pk
        on df.xmeta_repos_object_id_xmeta = pk.datafield_id
    left join foreign_keys fk
        on df.xmeta_repos_object_id_xmeta = fk.datafield_id
    where ds.name_xmeta = 'INT_ZWA_PO' 
		or ds.name_xmeta = 'INT_ZWA_PM' 
		or ds.name_xmeta = 'INT_ZWA_META' 
		or ds.name_xmeta = 'BDR_ZWA_PO' 
		or ds.name_xmeta = 'BDR_ZWA_PM'
        or ds.name_xmeta = 'OKV_IMF_PO' 
		or ds.name_xmeta = 'OKV_IMF_PM' 
		or ds.name_xmeta = 'OKV_REFERENTIE_DATA';
