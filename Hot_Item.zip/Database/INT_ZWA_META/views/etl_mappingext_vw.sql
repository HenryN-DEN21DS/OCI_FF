create or replace force view etl_mappingext_vw as
  with cte_me as
(select *
from dv_meta_mapping_vw
)
-- staging
,
cte_stg_hashkeys as
(select distinct me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
-- hier worden alle onderdelen van de keys en hashdiffs bij elkaar gebracht
,'cast(standard_hash(ltrim(coalesce(''''||x.'||listagg(distinct me.bron_kolom_naam ||' ,'''')' , '||''|''||coalesce(''''||x.') 
		within group (order by me.bron_kolom_naam asc) over (partition by me.doel_naam_volledig) ||', ''|'') ,''MD5'') as varchar2(4000)) as ' || me.doel_kolom_naam  as sql_deel_stmt
        --met ltrim worden alle leading pipes verwijderd. Mochten alle attributen leeg zijn, wordt de hash dus berekend over een leeg-waarde
        --dan resulteert dit in hashwaarde 'D41D8CD98F00B204E9800998ECF8427E'
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_STG'  escape '\' and me.regel_naam is not null and me.doel_schema_naam not like 'BDR\_%' escape '\')
,
cte_stg_insert as
(select distinct me.*
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam ||'(' || (listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' ||
    ' values (:' || (listagg(distinct 
        (case 
        when me.regel_naam is null 
        then me.bron_kolom_naam
        else me.doel_kolom_naam
        end
        )
        , ',:') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_STG'  escape '\'  and me.bron_schema_naam not like 'OKV\_%' escape '\' and me.bron_schema_naam <> 'INT_ZW_PO' and me.doel_schema_naam not like 'BDR\_%' escape '\')
,
cte_stg as
(select 
distinct 
cte_stg_hashkeys.*
, cte_stg_insert.insert_stmt
from cte_stg_hashkeys 
left join cte_stg_insert
on cte_stg_hashkeys.doel_tabel = cte_stg_insert.doel_tabel and cte_stg_hashkeys.bron_tabel = cte_stg_insert.bron_tabel)
--hub
,
cte_hub_hashkeys as
(select distinct me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
, ' ' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_HUB'  escape '\' and me.regel_naam is not null)
,
cte_hub_insert as
(select distinct me.*
, me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam || ' t ( t.DIM_AANMAAK_DATUM, t.DIM_BRON, t.' || (listagg(distinct me.doel_kolom_naam , ', t.') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' 
    ||' select distinct sysdate , ''' ||  me.bron_schema_naam || '.' || me.bron_tabel_naam || ''', stg.'  || (listagg(distinct me.bron_kolom_naam , ', stg.') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||
     ' from ' || me.bron_tabel_naam || ' stg'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_HUB'  escape '\')

,
cte_hub as
(select distinct
hk.*
, ins.insert_stmt
||
 ' left join '  || hk.doel_tabel_naam || ' t on stg.' || hk.bron_key_kolom || ' = t.' || hk.doel_key_kolom || ' where t.' || hk.doel_key_kolom || ' is null and stg.' || hk.bron_key_kolom || ' <> ''D41D8CD98F00B204E9800998ECF8427E'';'
    as insert_stmt
from cte_hub_hashkeys hk
left join cte_hub_insert ins
on hk.doel_tabel = ins.doel_tabel and hk.bron_tabel = ins.bron_tabel)

--link
,
cte_lnk_linkkeys as --selecteren van de primary keys van de link tabellen
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
,  ' ' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_LNK'  escape '\' and me.regel_naam = 'linkkey'
)
,
cte_lnk_insert as
(select distinct me.*
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam || ' t ( t.DIM_AANMAAK_DATUM, t.DIM_BRON, t.' || (listagg(distinct me.doel_kolom_naam , ', t.') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' 
    ||' select distinct sysdate , ''' ||  me.bron_schema_naam || '.' || me.bron_tabel_naam || ''', stg.'  || (listagg(distinct me.bron_kolom_naam , ', stg.') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||
     ' from ' || me.bron_tabel_naam || ' stg'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_LNK'  escape '\')
,
cte_lnk as -- samenvoegen van de link onderdelen
(select distinct
hk.*
, ins.insert_stmt
||
 ' left join '  || hk.doel_tabel_naam || ' t on stg.' || hk.bron_key_kolom || ' = t.' || hk.doel_key_kolom || ' where t.' || hk.doel_key_kolom || ' is null and stg.' || hk.bron_key_kolom || ' <> ''D41D8CD98F00B204E9800998ECF8427E'';'
    as insert_stmt
from cte_lnk_linkkeys hk
left join cte_lnk_insert ins
on hk.doel_tabel = ins.doel_tabel and hk.bron_tabel = ins.bron_tabel
)

, --sat
cte_sat_hashkeys as
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
,  ' ' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_SAT'  escape '\' and (me.regel_naam = 'hubkey' or me.regel_naam = 'linkkey'))
,
cte_sat_dim_hashdiff as
(select distinct 
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_hashdiff_naam
,me.doel_kolom_naam as doel_hashdiff_naam
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
,  ' ' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_SAT'  escape '\' and me.regel_naam = 'dim_hashdiff' )

,
cte_sat_beschr as -- selecteren van alle beschrijvende kolommen van de sat
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,listagg(distinct(me.bron_kolom_naam), ',') within group (order by me.bron_kolom_naam) over (partition by me.doel_tabel_naam) as bron_hashdiff_cols
,listagg(distinct(me.doel_kolom_naam), ',') within group (order by me.doel_kolom_naam) over (partition by me.doel_tabel_naam) as doel_hashdiff_cols
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
, ' ' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_SAT'  escape '\' and me.regel_naam is null) 

,
cte_sat_insert as
(select distinct me.*
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel

,'insert into ' || me.doel_tabel_naam || ' t ( t.DIM_AANMAAK_DATUM, t.DIM_BRON, t.DIM_IS_VERWIJDERD, t.' || (listagg(distinct me.doel_kolom_naam , ', t.') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')'  
   || ' select distinct sysdate , ''' ||  me.bron_schema_naam || '.' || me.bron_tabel_naam || ''', 0, '|| (listagg(distinct 'stg.' || me.bron_kolom_naam, ', ') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||
     ' from ' || me.bron_tabel_naam || ' stg'
        as insert_stmt_nieuwerecords

,'insert into ' || me.doel_tabel_naam || ' t ( t.DIM_AANMAAK_DATUM, t.DIM_BRON, t.DIM_IS_VERWIJDERD, t.' || (listagg(distinct me.doel_kolom_naam , ', t.') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')'  
   || ' select distinct sysdate , ''' ||  me.doel_schema_naam || '.' || me.doel_tabel_naam || ''', 1, ' || (listagg(distinct 'svw.' || me.doel_kolom_naam, ', ') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||
     ' from ' || me.doel_tabel_naam || '_VW svw'
        as insert_stmt_verwijderderecords
from cte_me me
where me.mapping_specificatie_naam like  '%\_SAT'  escape '\')

,
cte_sat as --samenvoegen van de verschillende onderdelen van de sat 
(select distinct
hk.mapping_specificatie as mapping_specificatie
, hk.bron_key_kolom
, hk.doel_key_kolom
, hk.bron_tabel
, hk.doel_tabel
, hk.bron_schema as bron_schema
, hk.doel_schema as doel_schema
, hd.bron_hashdiff_naam
, hd.doel_hashdiff_naam
, hk.stmt as stmt
, ins.insert_stmt_nieuwerecords
||
 ' left join '  || hk.doel_tabel_naam || '_VW svw on stg.' || hk.bron_key_kolom || ' = svw.' || hk.doel_key_kolom || ' and stg.' || hd.bron_hashdiff_naam || ' = svw.' || hd.doel_hashdiff_naam || ' and svw.dim_is_geldig = 1 where svw.' || hk.doel_key_kolom || ' is null and stg.' || hk.bron_key_kolom || ' <> ''D41D8CD98F00B204E9800998ECF8427E'';'
        as insert_stmt_nieuwerecords
, ins.insert_stmt_verwijderderecords
||
 ' left join '  || hk.bron_tabel_naam || ' stg on stg.' || hk.bron_key_kolom || ' = svw.' || hk.doel_key_kolom || ' and stg.' || hd.bron_hashdiff_naam || ' = svw.' || hd.doel_hashdiff_naam || ' and svw.dim_is_geldig = 1 where stg.' || hk.bron_key_kolom || ' is null;'
        as insert_stmt_verwijderderecords
from cte_sat_hashkeys hk
left join cte_sat_beschr s2
on hk.doel_tabel = s2.doel_tabel and hk.bron_tabel = s2.bron_tabel
join cte_sat_dim_hashdiff hd
on hd.doel_tabel = hk.doel_tabel and hk.bron_tabel = hd.bron_tabel
left join cte_sat_insert ins
on hk.doel_tabel = ins.doel_tabel and hk.bron_tabel = ins.bron_tabel
)

,
cte_dim_dimkeys as --Selecteren van de primary keys van de DIM tabellen
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,me.bron_kolom_naam as bron_key_kolom
,me.doel_kolom_naam as doel_key_kolom
,  'truncate table ' || me.doel_tabel_naam || ';' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_DIM'  escape '\' and me.regel_naam = 'dimkey'
)
,
cte_dim_insert as
(select distinct me.*
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam || ' t ( t.' || (listagg(distinct me.doel_kolom_naam , ', t.') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' 
    ||' select distinct '  || (listagg(distinct 'stg.' || me.bron_kolom_naam , ', ') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||
     ' from ' || me.bron_tabel_naam || ' stg;'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_DIM'  escape '\'
)
,
cte_dim as -- Samenvoegen van de DIM onderdelen
(select distinct
hk.*
, ins.insert_stmt as insert_stmt
from cte_dim_dimkeys hk
left join cte_dim_insert ins
on hk.doel_tabel = ins.doel_tabel and hk.bron_tabel = ins.bron_tabel
)

, --Fact staging tabellen
cte_fct_keys_stg as --Selecteren van de primary keys van de FCT tabellen
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,listagg(distinct me.bron_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam) as  bron_key_kolom
,listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam) as doel_key_kolom
,  'truncate table ' || me.doel_tabel_naam || ';' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_FCT\_STG'  escape '\' and me.regel_naam = 'fctkey'
)
,
cte_fct_insert_stg as
(select distinct me.*
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam || ' t ( t.' || (listagg(distinct me.doel_kolom_naam , ', t.') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' 
    ||' select distinct ' ||  (listagg(distinct 'stg.' || me.bron_kolom_naam , ', ') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||
     ' from ' || me.bron_tabel_naam || ' stg;'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_FCT\_STG'  escape '\'
)
,
cte_fct_stg as -- Samenvoegen van de FCT staging onderdelen
(select distinct
hk.*
, ins.insert_stmt as insert_stmt
from cte_fct_keys_stg hk
left join cte_fct_insert_stg ins
on hk.doel_tabel = ins.doel_tabel and hk.bron_tabel = ins.bron_tabel
)
,
cte_fct_keys as --Selecteren van de primary keys van de FCT tabellen
(select distinct
me.*
,me.mapping_specificatie_naam as mapping_specificatie
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
,me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,listagg(distinct me.bron_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam) as  bron_key_kolom
,listagg(distinct me.doel_kolom_naam , ',') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam) as doel_key_kolom
, 'truncate table ' || me.doel_tabel_naam || ';' as stmt
,me.bron_schema_naam as bron_schema
,me.doel_schema_naam as doel_schema
from cte_me me
where me.mapping_specificatie_naam like  '%\_FCT'  escape '\' and me.regel_naam = 'fctkey'
)
,
cte_fct_insert as
(select distinct me.*
,me.bron_schema_naam || '.' || me.bron_tabel_naam as bron_tabel
, me.doel_schema_naam || '.' || me.doel_tabel_naam as doel_tabel
,'insert into ' || me.doel_tabel_naam || ' t ( t.' || (listagg(distinct me.doel_kolom_naam , ', t.') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||')' 
    ||' select distinct ' ||  (listagg(distinct 'stg.' || me.bron_kolom_naam , ', ') within group (order by me.doel_kolom_naam asc) over (partition by me.doel_tabel_naam))||
     ' from ' || me.bron_tabel_naam || ' stg;'
        as insert_stmt
from cte_me me
where me.mapping_specificatie_naam like  '%\_FCT'  escape '\'
)
,
cte_fct as -- Samenvoegen van de FCT onderdelen
(select distinct
hk.*
, ins.insert_stmt as insert_stmt
from cte_fct_keys hk
left join cte_fct_insert ins
on hk.doel_tabel = ins.doel_tabel and hk.bron_tabel = ins.bron_tabel
)

select
cte_stg.mapping_specificatie
,cte_stg.bron_tabel
,cte_stg.doel_tabel
,cte_stg.bron_key_kolom
,cte_stg.doel_key_kolom
,cast('select x.*,' ||listagg(distinct cte_stg.sql_deel_stmt,',') within group (order by cte_stg.doel_tabel) over (partition by cte_stg.doel_tabel)|| ' from ' ||cte_stg.bron_tabel||' x' as varchar2(4000)) as stmt
,cte_stg.bron_schema
,cte_stg.doel_schema
,cte_stg.insert_stmt
from cte_stg

union all

select
cte_hub.mapping_specificatie
,cte_hub.bron_tabel
,cte_hub.doel_tabel
,cte_hub.bron_key_kolom
,cte_hub.doel_key_kolom
,cte_hub.stmt
,cte_hub.bron_schema
,cte_hub.doel_schema
,'lock table ' || cte_hub.doel_tabel ||' in exclusive mode; ' || cte_hub.insert_stmt as insert_stmt
from cte_hub

union all

select
cte_lnk.mapping_specificatie
,cte_lnk.bron_tabel
,cte_lnk.doel_tabel
,cte_lnk.bron_key_kolom
,cte_lnk.doel_key_kolom
,cte_lnk.stmt
,cte_lnk.bron_schema
,cte_lnk.doel_schema
,cte_lnk.insert_stmt
from cte_lnk

union all

select
cte_sat.mapping_specificatie
,cte_sat.bron_tabel
,cte_sat.doel_tabel
,cte_sat.bron_key_kolom
,cte_sat.doel_key_kolom
,cte_sat.stmt
,cte_sat.bron_schema
,cte_sat.doel_schema
,'lock table ' || cte_sat.doel_tabel ||' in exclusive mode; ' ||cte_sat.insert_stmt_nieuwerecords as insert_stmt
from cte_sat

union all

select
cte_sat.mapping_specificatie
,cte_sat.bron_tabel
,cte_sat.doel_tabel
,cte_sat.bron_key_kolom
,cte_sat.doel_key_kolom
,cte_sat.stmt
,cte_sat.bron_schema
,cte_sat.doel_schema
,'lock table ' || cte_sat.doel_tabel ||' in exclusive mode; ' ||cte_sat.insert_stmt_verwijderderecords as insert_stmt
from cte_sat

union all

select
cte_dim.mapping_specificatie
,cte_dim.bron_tabel
,cte_dim.doel_tabel
,cte_dim.bron_key_kolom
,cte_dim.doel_key_kolom
,cte_dim.stmt
,cte_dim.bron_schema
,cte_dim.doel_schema
,cte_dim.insert_stmt
from cte_dim

union all

select
cte_fct_stg.mapping_specificatie
,cte_fct_stg.bron_tabel
,cte_fct_stg.doel_tabel
,cte_fct_stg.bron_key_kolom
,cte_fct_stg.doel_key_kolom
,cte_fct_stg.stmt
,cte_fct_stg.bron_schema
,cte_fct_stg.doel_schema
,cte_fct_stg.insert_stmt
from cte_fct_stg

union all

select
cte_fct.mapping_specificatie
,cte_fct.bron_tabel
,cte_fct.doel_tabel
,cte_fct.bron_key_kolom
,cte_fct.doel_key_kolom
,cte_fct.stmt
,cte_fct.bron_schema
,cte_fct.doel_schema
,cte_fct.insert_stmt
from cte_fct;