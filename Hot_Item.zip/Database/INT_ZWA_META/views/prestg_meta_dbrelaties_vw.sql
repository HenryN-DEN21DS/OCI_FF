
--------------------------------------------------------
---  ddl for view prestg_meta_dbrelaties_vw
--------------------------------------------------------

create or replace force view prestg_meta_dbrelaties_vw as 
  with cte as (
	select distinct
		  dim_dummy
		, volledige_naam
		, mapping_naam
		, host_naam
		, database_naam
		, schema_naam
		, tabel_naam
		, kolom_naam
		, aanmaakdatum
		, modificatiedatum
		, dim_extractiedatum_xmeta
		, data_type
		, min_lengte 
		, max_lengte 
		, null_toegestaan 
		, default_waarde 
		, primary_key 
		, foreign_key
		, parent_host
		, parent_database
		, parent_schema
		, parent_tabel
		, parent_kolom
		, row_number() over (partition by host_naam ,database_naam, schema_naam, tabel_naam, kolom_naam, parent_host ,parent_database, parent_schema, parent_tabel ,parent_kolom  order by modificatiedatum desc) as rownumber
	from int_zwa_meta.prestg_meta_db_attributen_vw
	where foreign_key is not null)

select 
	  dim_dummy
	  , volledige_naam
	  , mapping_naam
	  , host_naam
	  , database_naam
	  , schema_naam
	  , tabel_naam
	  , kolom_naam
	  , aanmaakdatum
	  , modificatiedatum
	  , dim_extractiedatum_xmeta
	  , data_type
	  , min_lengte
	  , max_lengte
	  , null_toegestaan
	  , default_waarde
	  , primary_key
	  , foreign_key
	  , parent_host
	  , parent_database
	  , parent_schema
	  , parent_tabel
	  , parent_kolom
	  , rownumber 
from cte 
where rownumber = 1;
