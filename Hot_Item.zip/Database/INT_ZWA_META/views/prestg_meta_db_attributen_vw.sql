
--------------------------------------------------------
---  ddl for view prestg_meta_db_attributen_vw
--------------------------------------------------------

create or replace force view prestg_meta_db_attributen_vw as 
  with cte as (
    select
		'0' as dim_dummy
		, volledige_naam
		, mapping_naam
		, host_naam
		, database_naam
		, schema_naam
		, tabel_naam
		, case 
			when tabel_naam like '%\_H'  escape '\' then 'HUB'
			when tabel_naam like '%\_S'  escape '\' then 'SAT'
			when tabel_naam like '%\_S_VW'  escape '\' then 'SAT Einddatum view'
			when tabel_naam like '%\_L'  escape '\' then 'LINK'
			when tabel_naam like '%\_DT'  escape '\' then 'DIMENSIE'
			when tabel_naam like '%\_DV'  escape '\' then 'DIMENSIE'
			when tabel_naam like '%\_FT'  escape '\' then 'FEIT'
			when tabel_naam like '%\_FV'  escape '\' then 'FEIT'
			else 'UNKNOWN'
			end
																		as objecttype
		, kolom_naam
		, aanmaakdatum
		, modificatiedatum
		, extractiedatum_xmeta as dim_extractiedatum_xmeta
		, data_type
		, min_lengte 
		, max_lengte 
		, null_toegestaan 
		, default_waarde 
		, primary_key 
		, foreign_key
		, fk_parent_host     as parent_host
		, fk_parent_database as parent_database
		, fk_parent_schema   as parent_schema
		, fk_parent_tabel     as parent_tabel
		, fk_parent_kolom    as parent_kolom
		, row_number() over (partition by host_naam ,database_naam, schema_naam, tabel_naam, kolom_naam order by modificatiedatum desc) 
																		as rownumber
	from int_zwa_meta.xmeta_dbattributen_vw
	)
	
select 
	  dim_dummy 
	, volledige_naam 
	, mapping_naam 
	, host_naam 
	, database_naam 
	, schema_naam 
	, tabel_naam 
	, cast( objecttype  as varchar2(99)) 								as objecttype 
	, kolom_naam 
	, aanmaakdatum 
	, modificatiedatum 
	, dim_extractiedatum_xmeta 
	, data_type 
	, min_lengte 
	, max_lengte 
	, null_toegestaan 
	, default_waarde 
	, primary_key 
	, foreign_key 
	, parent_host 
	, parent_database 
	, parent_schema 
	, parent_tabel 
	, parent_kolom 
	, rownumber  
from cte where rownumber = 1;
