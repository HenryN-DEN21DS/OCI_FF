
--------------------------------------------------------
-- ddl for view dv_meta_mapping_vw
--------------------------------------------------------

  create or replace force view dv_meta_mapping_vw  as 
  with init as
(
select x.*
from prestg_meta_mappings_vw x
where rownumber = 1
),
dv as
(
select 
    m.mapping_specificatie_naam
, s.regel_naam 
, b.schema_naam as bron_schema_naam
, b.tabel_naam as bron_tabel_naam
, b.kolom_naam as bron_kolom_naam
, d.schema_naam as doel_schema_naam
, d.tabel_naam as doel_tabel_naam
, d.kolom_naam as doel_kolom_naam
from dv_mapping_specificatie_h m
left join dv_dbattr_dbattr_l            l       on l.dim_mapping_specificatie_h_hk = m.dim_mapping_specificatie_h_hk
left join dv_dbattr_dbattr_s_vw         s       on s.dim_dbattr_dbattr_l_hk = l.dim_dbattr_dbattr_l_hk
left join dv_dbattribuut_h                        b       on b.dim_dbattribuut_h_hk = l.dim_dbattribuut_h_hk_bron
left join dv_dbattribuut_h                        d       on d.dim_dbattribuut_h_hk = l.dim_dbattribuut_h_hk_doel
where s.dim_is_geldig = 1
    and s.dim_is_verwijderd = 0
)
select 
case when dv.mapping_specificatie_naam is null
then init.mapping_specificatie_naam
else dv.mapping_specificatie_naam
end as mapping_specificatie_naam
,
case when dv.regel_naam is null
then init.regel_naam
else dv.regel_naam
end as regel_naam
,
case when dv.bron_schema_naam is null
then init.bron_schema_naam
else dv.bron_schema_naam
end as bron_schema_naam
,
case when dv.bron_tabel_naam is null
then init.bron_tabel_naam
else dv.bron_tabel_naam
end as bron_tabel_naam
,
case when dv.bron_kolom_naam is null
then init.bron_kolom_naam
else dv.bron_kolom_naam
end as bron_kolom_naam
,
case when dv.bron_tabel_naam is null or dv.bron_kolom_naam is null
then init.bron_tabel_naam || '.' || init.bron_kolom_naam
else dv.bron_tabel_naam || '.' || dv.bron_kolom_naam
end as bron_naam_volledig
,
case when dv.doel_schema_naam is null
then init.doel_schema_naam
else dv.doel_schema_naam
end as doel_schema_naam
,
case when dv.doel_tabel_naam is null
then init.doel_tabel_naam
else dv.doel_tabel_naam
end as doel_tabel_naam
,
case when dv.doel_kolom_naam is null
then init.doel_kolom_naam
else dv.doel_kolom_naam
end as doel_kolom_naam
,
case when dv.doel_tabel_naam is null or dv.doel_kolom_naam is null
then init.doel_tabel_naam || '.' || init.doel_kolom_naam
else dv.doel_tabel_naam || '.' || dv.doel_kolom_naam
end as doel_naam_volledig

from init
full outer join dv
on init.bron_tabel_naam || '.' || init.bron_kolom_naam = dv.bron_tabel_naam || '.' || dv.bron_kolom_naam and init.doel_tabel_naam || '.' || init.doel_kolom_naam = dv.doel_tabel_naam || '.' || dv.doel_kolom_naam;

