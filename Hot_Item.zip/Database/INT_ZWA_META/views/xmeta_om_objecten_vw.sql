
--------------------------------------------------------
---  ddl for view xmeta_om_objecten_vw
--------------------------------------------------------

  create or replace force view xmeta_om_objecten_vw as 
  with bwt                                        as
    (
        select
          hs.name_xmeta                                     			as tabel_host
          , db.name_xmeta                                   			as tabel_database
          , ad.name_xmeta                             					as tabel_schema
          , a3.name_xmeta                             					as tabel_naam
          , substr(a1.xmeta_repos_object_id_xmeta,-10,10)   			as omobject_id
          , a1.name_xmeta                            					as om_naam
          , acs.value_xmeta                                 			as bewaartermijn
		  , cat.name_xmeta												as categorie_term
        from
            xmeta.glossaryxtnsnsclssfctn a0
            inner join
                xmeta.gctnclssfdbybsnsscncpt a2
                on
                    a0.xmeta_repos_object_id_xmeta = a2.classifiedbybusinessconceptxmt
            inner join
                xmeta.glossaryxtnsnsbsnsstrm a1
                on
                    a2.has_classification_xmeta = a1.xmeta_repos_object_id_xmeta
            inner join
                xmeta.gfsbjctrffrmclssfsbjct a4
                on
                    a0.xmeta_repos_object_id_xmeta = a4.classifies_object_xmeta
            inner join
                xmeta.asclmodeldatacollectin a3
                on
                    a4.reffromclassifiesobjectxmeta = a3.xmeta_repos_object_id_xmeta
            inner join
                xmeta.asclmodel_dataschema ad
                on
                    a3.container_rid = ad.xmeta_repos_object_id_xmeta
            inner join
                xmeta.asclmodel_database db
                on
                    to_char(db.xmeta_repos_object_id_xmeta) = to_char(ad.container_rid)
            inner join
                xmeta.asclmodel_hostsystem hs
                on
                    to_char(hs.xmeta_repos_object_id_xmeta) = to_char(db.container_rid)
            inner join 
                xmeta.glssryxtnsnsbsnssctgry cat
                on
                    cat.xmeta_repos_object_id_xmeta = a1.container_rid
            inner join 
                xmeta.asclcstmttrbtcstmtxtvl acs
                on
                    acs.objectrid_xmeta = a1.xmeta_repos_object_id_xmeta
            inner join 
                xmeta.amttrbtrffrmfcstmttrbt att
                on
                    att.of_customattribute_xmeta = acs.xmeta_repos_object_id_xmeta
            left join 
                xmeta.asclcstmttrbtcstmttrbt ca
                on
                    ca.xmeta_repos_object_id_xmeta = att.reffromofcustomattributexmeta
           where ca.name_xmeta = 'Bewaartermijn'
    )
  , be as
    (
        select
          hs.name_xmeta                                     as tabel_host
          , db.name_xmeta                                   as tabel_database
          , ad.name_xmeta                             		as tabel_schema
          , a3.name_xmeta                             		as tabel_naam
          , substr(a1.xmeta_repos_object_id_xmeta,-10,10)   as omobject_id
          , a1.name_xmeta                            		as om_naam
          , acs.value_xmeta                                 as bewaartermijn_eenheid
		  , cat.name_xmeta									as categorie_term
        from
            xmeta.glossaryxtnsnsclssfctn a0
            inner join
                xmeta.gctnclssfdbybsnsscncpt a2
                on
                    a0.xmeta_repos_object_id_xmeta = a2.classifiedbybusinessconceptxmt
            inner join
                xmeta.glossaryxtnsnsbsnsstrm a1
                on
                    a2.has_classification_xmeta = a1.xmeta_repos_object_id_xmeta
            inner join
                xmeta.gfsbjctrffrmclssfsbjct a4
                on
                    a0.xmeta_repos_object_id_xmeta = a4.classifies_object_xmeta
            inner join
                xmeta.asclmodeldatacollectin a3
                on
                    a4.reffromclassifiesobjectxmeta = a3.xmeta_repos_object_id_xmeta
            inner join
                xmeta.asclmodel_dataschema ad
                on
                    a3.container_rid = ad.xmeta_repos_object_id_xmeta
            inner join
                xmeta.asclmodel_database db
                on
                    to_char(db.xmeta_repos_object_id_xmeta) = to_char(ad.container_rid)
            inner join
                xmeta.asclmodel_hostsystem hs
                on
                    to_char(hs.xmeta_repos_object_id_xmeta) = to_char(db.container_rid)

            left join 
                xmeta.glssryxtnsnsbsnssctgry cat
                on
                    cat.xmeta_repos_object_id_xmeta = a1.container_rid
            left join 
                xmeta.alcstmttrbtcstmstrngvl acs
                on
                    acs.objectrid_xmeta = a1.xmeta_repos_object_id_xmeta
            left join 
                xmeta.amttrbtrffrmfcstmttrbt att
                on
                    att.of_customattribute_xmeta = acs.xmeta_repos_object_id_xmeta
            left join 
                xmeta.asclcstmttrbtcstmttrbt ca
                on
                    ca.xmeta_repos_object_id_xmeta = att.reffromofcustomattributexmeta
           where ca.name_xmeta = 'Bewaartermijn Eenheid'
    )
  , bs as
    (
        select
          hs.name_xmeta                                     as tabel_host
          , db.name_xmeta                                   as tabel_database
          , ad.name_xmeta                             		as tabel_schema
          , a3.name_xmeta                             		as tabel_naam
          , substr(a1.xmeta_repos_object_id_xmeta,-10,10)   as omobject_id
          , a1.name_xmeta                            		as om_naam
          , acs.value_xmeta                                 as bewaartermijn_ingangsdatum
		  , cat.name_xmeta									as categorie_term
        from
            xmeta.glossaryxtnsnsclssfctn a0
            inner join
                xmeta.gctnclssfdbybsnsscncpt a2
                on
                    a0.xmeta_repos_object_id_xmeta = a2.classifiedbybusinessconceptxmt
            inner join
                xmeta.glossaryxtnsnsbsnsstrm a1
                on
                    a2.has_classification_xmeta = a1.xmeta_repos_object_id_xmeta
            inner join
                xmeta.gfsbjctrffrmclssfsbjct a4
                on
                    a0.xmeta_repos_object_id_xmeta = a4.classifies_object_xmeta
            inner join
                xmeta.asclmodeldatacollectin a3
                on
                    a4.reffromclassifiesobjectxmeta = a3.xmeta_repos_object_id_xmeta
            inner join
                xmeta.asclmodel_dataschema ad
                on
                    a3.container_rid = ad.xmeta_repos_object_id_xmeta
            inner join
                xmeta.asclmodel_database db
                on
                    to_char(db.xmeta_repos_object_id_xmeta) = to_char(ad.container_rid)
            inner join
                xmeta.asclmodel_hostsystem hs
                on
                    to_char(hs.xmeta_repos_object_id_xmeta) = to_char(db.container_rid)

            left join 
                xmeta.glssryxtnsnsbsnssctgry cat
                on
                    cat.xmeta_repos_object_id_xmeta = a1.container_rid
            left join 
                xmeta.asclcstmttrbtcstmtxtvl acs
                on
                    acs.objectrid_xmeta = a1.xmeta_repos_object_id_xmeta
            left join 
                xmeta.amttrbtrffrmfcstmttrbt att
                on
                    att.of_customattribute_xmeta = acs.xmeta_repos_object_id_xmeta
            left join 
                xmeta.asclcstmttrbtcstmttrbt ca
                on
                    ca.xmeta_repos_object_id_xmeta = att.reffromofcustomattributexmeta
           where ca.name_xmeta = 'bewaartermijn startdatum'
    )
select
    to_char(regexp_substr(hs.name_xmeta,'[^.]+',1,1)) as tabel_host
 --   cast(hs.name_xmeta as                 varchar(500))              tabel_host
  , cast(db.name_xmeta as                 varchar(99))              tabel_database
  , cast(ad.name_xmeta as                 varchar(99))              tabel_schema
  , cast(a3.name_xmeta as                 varchar(99))              tabel_naam
  , cast(substr(a1.xmeta_repos_object_id_xmeta,-10,10) as varchar(99)) omobject_id
  , cast(a1.name_xmeta as                 varchar(99))              om_naam
  , cast(bwt.bewaartermijn as             varchar(99))              bewaartermijn
  , cast(be.bewaartermijn_eenheid as      varchar(99))              bewaartermijn_eenheid
  , cast(bs.bewaartermijn_ingangsdatum as varchar(99))              bewaartermijn_ingangsdatum
--  , cast('a' as                           varchar(500))              diagram_naam
  , to_timestamp('1970-01-01', 'YYYY-MM-DD') + numtodsinterval(((a1.xmeta_creation_timestamp_xmeta)/1000 + 7200), 'SECOND')	as aanmaakdatum
  , to_timestamp('1970-01-01', 'YYYY-MM-DD') + numtodsinterval(((a1.xmetamodificationtimestampxmet)/1000 + 7200), 'SECOND')	as modificatiedatum
  , cast(current_timestamp as 			  timestamp(6)) 			 extractiedatum_xmeta
  , cat.name_xmeta as                                                categorie
from
               xmeta.glossaryxtnsnsclssfctn a0
            inner join
                xmeta.gctnclssfdbybsnsscncpt a2
                on
                    a0.xmeta_repos_object_id_xmeta = a2.classifiedbybusinessconceptxmt
            inner join
                xmeta.glossaryxtnsnsbsnsstrm a1
                on
                    a2.has_classification_xmeta = a1.xmeta_repos_object_id_xmeta
            inner join
                xmeta.gfsbjctrffrmclssfsbjct a4
                on
                    a0.xmeta_repos_object_id_xmeta = a4.classifies_object_xmeta
            inner join
                xmeta.asclmodeldatacollectin a3
                on
                    a4.reffromclassifiesobjectxmeta = a3.xmeta_repos_object_id_xmeta
            inner join
                xmeta.asclmodel_dataschema ad
                on
                    a3.container_rid = ad.xmeta_repos_object_id_xmeta
            inner join
                xmeta.asclmodel_database db
                on
                    to_char(db.xmeta_repos_object_id_xmeta) = to_char(ad.container_rid)
            inner join
                xmeta.asclmodel_hostsystem hs
                on
                    to_char(hs.xmeta_repos_object_id_xmeta) = to_char(db.container_rid)
            inner join 
                xmeta.glssryxtnsnsbsnssctgry cat
                on
                    cat.xmeta_repos_object_id_xmeta = a1.container_rid  
    left join
        bwt
        on
            ad.name_xmeta    = bwt.tabel_schema
            and a3.name_xmeta  = bwt.tabel_naam
            and substr(a1.xmeta_repos_object_id_xmeta,-10,10) = bwt.omobject_id
    left join
        be
        on
            ad.name_xmeta    = be.tabel_schema
            and a3.name_xmeta  = be.tabel_naam
            and substr(a1.xmeta_repos_object_id_xmeta,-10,10) = be.omobject_id
    left join
        bs
        on
            ad.name_xmeta    = bs.tabel_schema
            and a3.name_xmeta  = bs.tabel_naam
            and substr(a1.xmeta_repos_object_id_xmeta,-10,10) = bs.omobject_id
	where cat.name_xmeta = 'ZW_Arbo';
