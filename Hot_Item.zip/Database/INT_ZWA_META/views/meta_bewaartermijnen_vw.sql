
--------------------------------------------------------
---  ddl for view meta_bewaartermijnen_vw
--------------------------------------------------------

create or replace force view meta_bewaartermijnen_vw as 
	with cte_ombewaartermijnen as
	( -- om objecten en bewaartermijnen
	select 
		 h.omobject_id as omobjectid
	   , s.om_naam as omnaam
	   , nullif(s.bewaartermijn       , '')  							as ombewaartermijn
	   , nullif(s.bewaartermijn_eenheid, '') 							as ombewaartermijneenheid
    from      dv_omobject_h            h
	inner join dv_omobject_s_vw s on s.dim_omobject_h_hk = h.dim_omobject_h_hk
	where s.dim_is_geldig = 1
    and s.dim_is_verwijderd = 0
	) 
	, cte_omrelaties as
	( -- Relaties tussen OM objecten en DV tabellen (hubs of links)
	select 
		  o.omobject_id 												as omobjectid
		, d.schema_naam 												as tabelschema
		, d.tabel_naam  												as tabelnaam
		, col_hk.column_name 											as tabelhashkey
    from      dv_omobject_h                     o
    inner join dv_dbobject_omobject_l            l      
		on l.dim_omobject_h_hk          = o.dim_omobject_h_hk
    inner join dv_dbobject_omobject_s_vw s      
		on s.dim_dbobject_omobject_l_hk = l.dim_dbobject_omobject_l_hk
    inner join dv_dbobject_h                     d      
		on d.dim_dbobject_h_hk          = l.dim_dbobject_h_hk
    left join sys.all_tab_cols         col_hk 
		on (     col_hk.owner   = d.schema_naam                 -- Left join met information schema voor auditing doeleinden:
	    and col_hk.table_name     = d.tabel_naam                -- als HashKey niet bepaald kan worden is er een mismatch tussen EA en de database
		and col_hk.column_name like 'DIM_'|| substr(d.tabel_naam, 4, 99) || '_HK')
	where s.dim_is_geldig = 1
    and s.dim_is_verwijderd = 0
	)
	, cte_dbbewaartermijnen as
	( -- bewaartermijnen op het niveau van dv tabellen (hubs of links)
	select 
		 h.schema_naam 													as tabelschema
	   , h.tabel_naam 													as tabelnaam
	from int_zwa_meta.dv_dbobject_h             h
	join int_zwa_meta.dv_dbobject_s_vw s 
		on s.dim_dbobject_h_hk = h.dim_dbobject_h_hk
	where s.dim_is_geldig = 1
    and s.dim_is_verwijderd = 0
)
		, cte_dbrelaties as
	( -- relaties tussen dv tabellen (inclusief bwt sats)
	select 
		  parap.schema_naam 											as parentschema
		, parap.tabel_naam        										as parentnaam
		, parap.kolom_naam        										as parenthashkey
		, parac.schema_naam       										as childschema
		, parac.tabel_naam        										as childnaam
		, parac.kolom_naam        										as childhashkey
	from dv_foreign_key_l fkl
	join dv_foreign_key_s_vw fks 
		on fkl.dim_foreign_key_l_hk = fks.dim_foreign_key_l_hk 
		and fks.dim_is_geldig = 1
	join dv_dbattribuut_h parap 
		on parap.dim_dbattribuut_h_hk = fkl.dim_dbattribuut_h_hk_doel
	join dv_dbattribuut_s_vw paraps 
		on paraps.dim_dbattribuut_h_hk = parap.dim_dbattribuut_h_hk 
		and paraps.dim_is_geldig = 1
	join dv_dbattribuut_h parac 
		on parac.dim_dbattribuut_h_hk = fkl.dim_dbattribuut_h_hk_bron
	join dv_dbattribuut_s_vw paracs 
		on paracs.dim_dbattribuut_h_hk = parac.dim_dbattribuut_h_hk 
		and paracs.dim_is_geldig = 1
	) 
		, cte_dbrelatiesbwt as
	( -- BWT sats
	select parap.schema_naam 	  										as parentschema
		, parap.tabel_naam        										as parentnaam
		, parap.kolom_naam        										as parenthashkey
		, parac.schema_naam       										as bwtschema
		, parac.tabel_naam        										as bwtnaam
		, parac.kolom_naam        										as bwthashkey
	from dv_foreign_key_l fkl
	join dv_foreign_key_s_vw fks 
		on fkl.dim_foreign_key_l_hk = fks.dim_foreign_key_l_hk 
		and fks.dim_is_geldig = 1
	join dv_dbattribuut_h parap 
		on parap.dim_dbattribuut_h_hk = fkl.dim_dbattribuut_h_hk_doel
	join dv_dbattribuut_s_vw paraps 
		on paraps.dim_dbattribuut_h_hk = parap.dim_dbattribuut_h_hk 
		and paraps.dim_is_geldig = 1
	join dv_dbattribuut_h parac 
		on parac.dim_dbattribuut_h_hk = fkl.dim_dbattribuut_h_hk_bron
join dv_dbattribuut_s_vw paracs 
	on paracs.dim_dbattribuut_h_hk = parac.dim_dbattribuut_h_hk 
	and paracs.dim_is_geldig = 1 
where parac.tabel_naam like '%_BWT'  -- Enkel BWT sats
)
, cte_omdb as
( -- Combineren OM en DB objecten en bewaartermijnen
  select omb.omobjectid
       , omb.omnaam
	   , omb.ombewaartermijn
	   , omb.ombewaartermijneenheid
	   , omr.tabelschema            as dvtabelschema
	   , omr.tabelnaam              as dvtabelnaam
	   , omr.tabelhashkey           as dvtabelhashkey
    from      cte_ombewaartermijnen omb                                                                           -- ophalen om objecten en bewaartermijnen
   inner join cte_omrelaties        omr on omr.omobjectid   = omb.omobjectid                                      -- ophalen relaties tussen om objecten en dv tabellen (hubs of links)
	left join cte_dbbewaartermijnen dbb on dbb.tabelschema  = omr.tabelschema and dbb.tabelnaam  = omr.tabelnaam  -- bewaartermijnen op het niveau van dv tabellen zijn optioneel
)
, cte_BaseUnion as
( -- Set van DV tabellen (hubs of links) die direct aan de OM objecten gerelateerd zijn
  select omd.omobjectid
       , omd.omnaam
	   , omd.ombewaartermijn
	   , omd.ombewaartermijneenheid
	   , omd.dvtabelschema
	   , omd.dvtabelnaam
	   , omd.dvtabelhashkey
       , 'OMDB'                     as relatietype  -- relatie van om => db
	   , null                       as parentschema
	   , null                       as parentnaam
	   , null                       as parenthashkey
       , null                       as parenttodvhashkey
	   , omd.dvtabelschema          as teschonentabelschema
	   , omd.dvtabelnaam            as teschonentabelnaam
	   , omd.dvtabelhashkey         as teschonentabelhashkey
    from cte_omdb omd
	     union
  -- Set van sats en links die gerelateerd zijn aan de DV tabellen (hubs of links) die direct aan de OM objecten gerelateerd zijn
  select omd.omobjectid
       , omd.omnaam
	   , omd.ombewaartermijn
	   , omd.ombewaartermijneenheid
	   , omd.dvtabelschema
	   , omd.dvtabelnaam
	   , omd.dvtabelhashkey
	   , 'OMDBDB1'                  as relatietype  -- Relatie van OM => DB => DB
	   , omd.dvtabelschema          as parentschema
	   , omd.dvtabelnaam            as parentnaam
	   , omd.dvtabelhashkey         as parenthashkey
       , null                       as parenttodvhashkey
	   , dbr.childschema            as teschonentabelschema
	   , dbr.childnaam              as teschonentabelnaam
	   , dbr.childhashkey           as teschonentabelhashkey
    from      cte_omdb       omd
   inner join cte_dbrelaties dbr on dbr.parentschema = omd.dvtabelschema and dbr.parentnaam = omd.dvtabelnaam  -- Ophalen sats en links die gerelateerd zijn aan de DV tabellen (hubs of links) die direct aan de OM objecten relateren
	     union all
  -- Set van linksats die gerelateerd zijn aan links die gerelateerd zijn aan de DV tabellen (hubs of links) die direct aan de OM objecten gerelateerd zijn
  select omd.omobjectid
       , omd.omnaam
	   , omd.ombewaartermijn
	   , omd.ombewaartermijneenheid
	   , omd.dvtabelschema
	   , omd.dvtabelnaam
	   , omd.dvtabelhashkey
	   , 'OMDBDB2'                  as relatietype  -- -- Relatie van OM => DB => DB => DB
	   , dls.parentschema           as parentschema
	   , dls.parentnaam             as parentnaam
 	   , dls.parenthashkey          as parenthashkey
       , dbr.childhashkey           as parenttodvhashkey
	   , dls.childschema            as teschonentabelschema
	   , dls.childnaam              as teschonentabelnaam
	   , dls.childhashkey           as teschonentabelhashkey
    from      cte_omdb       omd
   inner join cte_dbrelaties dbr on dbr.parentschema = omd.dvtabelschema and dbr.parentnaam = omd.dvtabelnaam  -- Ophalen sats en links die gerelateerd zijn aan de DV tabellen (hubs of links) die direct aan de OM objecten relateren
   inner join cte_dbrelaties dls on dls.parentschema = dbr.childschema   and dls.parentnaam = dbr.childnaam    -- Ophalen sats van de links die gerelateerd zijn aan de hubs die direct aan de OM objecten relateren
    )
, cte_baseverrijkt as
( select bsu.omobjectid
       , bsu.omnaam
	   , bsu.ombewaartermijn
	   , bsu.ombewaartermijneenheid
	   , bsu.dvtabelschema
	   , bsu.dvtabelnaam
	   , bsu.dvtabelhashkey
	   , bsu.relatietype
	   , bsu.parentschema
	   , bsu.parentnaam
	   , bsu.parenthashkey
       , bsu.parenttodvhashkey
	   , bsu.teschonentabelschema
	   , bsu.teschonentabelnaam
	   , bsu.teschonentabelhashkey
	   , case
       when substr(bsu.teschonentabelnaam, -3, 3) = 'BWT'
          -- when right(bsu.TeSchonenTabelNaam, 3) = 'BWT'and bsu.TeSchonenTabelNaam like split_part(DVTabelNaam,'_',1)||'%'  
           then 'Bwt'
	       when bsu.teschonentabelnaam like  '%\_H'  escape '\'
	         or bsu.teschonentabelnaam like  '%\_BH'  escape '\'
	         or bsu.teschonentabelnaam like  '%\_H\_%'  escape '\'
	         or bsu.teschonentabelnaam like  '%\_BH\_%' escape '\'
	       then 'Hub'
		   when bsu.teschonentabelnaam like '%\_L' escape '\'
		     or bsu.teschonentabelnaam like '%\_BL'  escape '\'
		     or bsu.teschonentabelnaam like '%\_L\_%' escape '\'
		     or bsu.teschonentabelnaam like '%\_BL\_%' escape '\'
		     or bsu.teschonentabelnaam like '%\_SL%' escape '\'
		     or bsu.teschonentabelnaam like '%\_SL\_%' escape '\'
		       then 'Link'
  		   when	bsu.teschonentabelnaam like '%\_S'   escape '\'
  		     or bsu.teschonentabelnaam like '%\_S\_%'   escape '\'
  		     or bsu.teschonentabelnaam like '%\_BS' escape '\'
  		     or bsu.teschonentabelnaam like '%\_BS\_%' escape '\'
  		     or	bsu.teschonentabelnaam like '%\_MS'  escape '\'
			 or	bsu.teschonentabelnaam like '%\_MS\_%'  escape '\'
			 or	bsu.teschonentabelnaam like '%\_BMS'  escape '\'
  		     or bsu.teschonentabelnaam like '%\_BMS\_%' escape '\'
			 or	bsu.teschonentabelnaam like '%\_TS'  escape '\'
  		     or	bsu.teschonentabelnaam like '%\_TS\_%'  escape '\'
  		     or	bsu.teschonentabelnaam like '%\_BTS'  escape '\'
  		     or bsu.teschonentabelnaam like '%\_BTS\_%' escape '\'
			 or	bsu.teschonentabelnaam like '%\_SS'  escape '\'
  		     or	bsu.teschonentabelnaam like '%\_SS\_%'  escape '\'
  		     or	bsu.teschonentabelnaam like '%\_BSS'  escape '\'
  		     or bsu.teschonentabelnaam like '%\_BSS\_%' escape '\'
			 or	bsu.teschonentabelnaam like '%\_SLS' escape '\'
  		     or	bsu.teschonentabelnaam like '%\_SLS\_%' escape '\'
  		     or	bsu.teschonentabelnaam like '%\_BSLS' escape '\'
  		     or bsu.teschonentabelnaam like '%\_BSLS\_%' escape '\'
           then 'Sat'
		   else 'Onbekend'
		 end			as TeSchonenTabelType
		 -- gebruik altijd bwt sat van de dvtabel!
	   , bwt_dv.bwtschema
       , bwt_dv.bwtnaam
	   , bwt_dv.bwthashkey
	   , relatietype as bwtrelatietype
          , case
	       when upper(bsu.ombewaartermijneenheid) in ('MAAND', 'MAANDEN') and 
	       to_number(bsu.ombewaartermijn) is not null
	  	   then cast(add_months(sysdate, bsu.ombewaartermijn * -1)as timestamp)
	       when upper(bsu.ombewaartermijneenheid) in ('JAAR', 'JAREN')    and 
	       to_number(bsu.ombewaartermijn) is not null
	  	   then cast(add_months(sysdate, bsu.ombewaartermijn * -12)as timestamp)
           else null
	     end as bwtmaxdatumom
    from      cte_baseunion             bsu
	left join cte_dbrelatiesbwt         bwt_dv  on bwt_dv.parentschema  = bsu.dvtabelschema        and bwt_dv.parentnaam  = bsu.dvtabelnaam         -- Ophalen BWT sat op basis van DV tabel (voor linksats op links zonder bwt sat). Left join voor auditing doeleinden; wel een bewaartermijn en geen BWT sat zou niet mogen voorkomen
), cte_base as
( select distinct
         bsv.omobjectid
       , bsv.omnaam
	   , bsv.ombewaartermijn
	   , bsv.ombewaartermijneenheid
	   , bsv.dvtabelschema
	   , bsv.dvtabelnaam
	   , bsv.dvtabelhashkey
	   , bsv.relatietype
	   , bsv.parentschema
	   , bsv.parentnaam
	   , bsv.parenthashkey
	   , bsv.teschonentabelschema
	   , bsv.teschonentabelnaam
	   , bsv.teschonentabelhashkey
       , bsv.parenttodvhashkey
	   , bsv.teschonentabeltype
	   , bsv.bwtschema
	   , bsv.bwtnaam
	   , bsv.bwthashkey
	   , bsv.bwtrelatietype
	   , bsv.bwtmaxdatumom as bwtmaxdatum
        , case
		   when bwtmaxdatumom is null and bsv.ombewaartermijn is not null
		   then 'geen valide bewaartermijn'
           when bsv.bwtmaxdatumom is not null and bsv.bwthashkey is null
		   then 'valide bewaartermijn, maar geen bwt sat gevonden'
	       when bsv.bwtnaam is not null and bsv.bwthashkey is null
		   then 'bwt sat in IDA, maar niet in de database'
		   when bsv.bwthashkey is not null and bsv.bwtmaxdatumom is null
		   then 'bwt sat gevonden, maar geen valide bewaartermijn'
	       when bsv.teschonentabelhashkey is null
	       then 'te schonen tabel bestaat niet in de database'
		   else null
	     end as bwtdqissue
    from cte_baseverrijkt bsv
)
select *
  from cte_base
order by omnaam, teschonentabelnaam;
