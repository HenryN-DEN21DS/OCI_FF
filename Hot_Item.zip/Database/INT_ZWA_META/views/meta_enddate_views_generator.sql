
--------------------------------------------------------
---  ddl for view meta_enddate_views_generator
--------------------------------------------------------

create or replace force view meta_enddate_views_generator as 
  with tabcols as (
	select 
		  owner
		, table_name
		, listagg( c.column_name,  chr(10) || ', ') within group (order by c.column_id)  vwcols
		, listagg( 'sat_tabel.' || c.column_name, chr(10) || ', ') within group (order by c.column_id) satcols
	from all_tab_columns c
	group by owner, table_name
	)
	,
	pkcols as (
		select 
			  owner
			, constraint_name
			, listagg( 'sat_tabel.' || pk_cols.column_name, chr(10) || ', ') within group (order by pk_cols.position) pkcols
		from all_cons_columns pk_cols
		where 1=1
		and pk_cols.column_name <> 'DIM_AANMAAK_DATUM'
		group by owner, constraint_name
	)

select 
      t.owner
	, t.object_name
    , lower(
	'create or replace force view '|| t.object_name || '_vw as ' || chr(10) || chr(10) || 'with cte as (select ' || 
	max(c.satcols) || ', lead(sat_tabel.dim_aanmaak_datum) over (partition by ' || max(pk_cols.pkcols) || ' order by sat_tabel.dim_aanmaak_datum) - interval ''0.000001'' second as dim_eind_datum ' || 
    chr(10) || 'from ' || 
	t.object_name || ' sat_tabel)' || chr(10) || chr(10) || 
    'select ' ||
	max(c.vwcols) ||
	', cast(nvl(dim_eind_datum, timestamp''8888-12-31 00:00:00'') as timestamp) as dim_eind_datum' ||
	', case' ||
	'  when dim_eind_datum is null ' || 
	'  then 1' || 
	'  else 0' || 
	' end as dim_is_geldig ' ||
	' 
	from cte where cte.dim_is_verwijderd = 0' || 
	';' )
																		as stmt
from tabcols c
join all_objects t on t.owner=c.owner 
and t.object_name = c.table_name
left join all_constraints cons 
	on cons.owner = t.owner 
	and cons.table_name = t.object_name 
	and cons.constraint_type = 'P' 
left join pkcols pk_cols 
	on cons.constraint_name = pk_cols.constraint_name 
	and cons.owner = pk_cols.owner 
where (
	1=1
	and t.owner in ('INT_ZWA_META', 'INT_ZWA_PO', 'INT_ZWA_PM')
	and t.object_type = 'TABLE'
	and (t.object_name like '%\_S' escape '\' or t.object_name like '%\_S\_%' escape '\')
	)
	group by t.owner, t.object_name
	order by t.owner, t.object_name;
