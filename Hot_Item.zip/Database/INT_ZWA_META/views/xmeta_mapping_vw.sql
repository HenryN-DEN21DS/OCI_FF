
--------------------------------------------------------
---  ddl for view xmeta_mapping_vw
--------------------------------------------------------

create or replace force view xmeta_mapping_vw as 
  select
	  cast(mpd.name_xmeta as varchar(99)) 								as mapping_specificatie_naam
	, cast(mm.name_xmeta as  varchar(999)) 								as mapping_naam
	--, cast(md_source.objectidentifier_xmeta as varchar(255)) as bron_naam_volledig
	, to_char(
		regexp_substr(regexp_substr(md_source.objectidentifier_xmeta, '[^"]+',1,1),'[^\]+',1,1)||
		regexp_substr(md_source.objectidentifier_xmeta, '[^"]+',1,2)
		)
																		as bron_naam_volledig 
--  , TO_CHAR(REGEXP_SUBSTR(md_source.OBJECTIDENTIFIER_XMETA,'[^.]+[^.]',1,1)) AS BRON_HOST_NAAM
	, to_char(
		regexp_substr(regexp_substr(md_source.objectidentifier_xmeta, '[^"]+',1,1),'[^\]+',1,1)
		)
																		as bron_host_naam
		, to_char(regexp_substr(md_source.objectidentifier_xmeta,'[^.]+[^.]',1,6)) 
																		as bron_database_naam
	, to_char(regexp_substr(md_source.objectidentifier_xmeta,'[^.]+[^.]',1,7)) 
																		as bron_schema_naam
	, to_char(regexp_substr(md_source.objectidentifier_xmeta,'[^.]+[^.]',1,8)) 
																		as bron_tabel_naam
	, cast(md_source.objectname_xmeta as varchar(99)) as bron_kolom_naam
--	, cast(md_target.objectidentifier_xmeta as varchar(255)) as doel_naam_volledig
	, to_char(
		regexp_substr(regexp_substr(md_target.objectidentifier_xmeta, '[^"]+',1,1),'[^\]+',1,1)||
		regexp_substr(md_target.objectidentifier_xmeta, '[^"]+',1,2)
		)
																		as doel_naam_volledig
--	, TO_CHAR(REGEXP_SUBSTR(md_target.OBJECTIDENTIFIER_XMETA,'[^.]+[^.]',1,1)) AS DOEL_HOST_NAAM
	, to_char(
		regexp_substr(regexp_substr(md_target.objectidentifier_xmeta, '[^"]+',1,1),'[^\]+',1,1)
		)
																		as doel_host_naam
	, to_char(regexp_substr(md_target.objectidentifier_xmeta,'[^.]+[^.]',1,6)) 
																		as doel_database_naam
	, to_char(regexp_substr(md_target.objectidentifier_xmeta,'[^.]+[^.]',1,7)) 
																		as doel_schema_naam
	, to_char(regexp_substr(md_target.objectidentifier_xmeta,'[^.]+[^.]',1,8)) 
																		as doel_tabel_naam
	, cast(md_target.objectname_xmeta as varchar(99)) 					as doel_kolom_naam
	, cast(mm.xform_xmeta as varchar(99)) 								as regel_naam
	, cast(mm.description_xmeta as varchar(999)) 						as mapping_omschrijving 
 -- , 'test' AS MAPPING_OMSCHRIJVING
	, cast(to_timestamp('1970-01-01', 'YYYY-MM-DD') + numtodsinterval((mpd.xmeta_creation_timestamp_xmeta)/1000, 'SECOND')	as timestamp(6)) 
																		as aanmaakdatum
	, cast(to_timestamp('1970-01-01', 'YYYY-MM-DD') + numtodsinterval((mpd.xmetamodificationtimestampxmet)/1000, 'SECOND')	as timestamp(6)) 
																		as modificatiedatum
	, cast(current_timestamp as timestamp(6)) 							as extractiedatum_xmeta
  from
    xmeta.mwbextensions_mapping mm
    join  xmeta.mwbextensionsmappingdc mpd
        on to_char(mm.container_rid) = to_char(mpd.xmeta_repos_object_id_xmeta)
    join  xmeta.mwbextensnsmppngdsgntr md_source
		on to_char(substr(mm.sources_xmeta, 2, 64)) = to_char(md_source.xmeta_repos_object_id_xmeta)
    join xmeta.mwbextensnsmppngdsgntr md_target
        on to_char(substr(mm.targets_xmeta, 2, 64)) = to_char(md_target.xmeta_repos_object_id_xmeta);
