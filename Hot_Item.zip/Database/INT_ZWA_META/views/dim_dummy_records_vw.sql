
--------------------------------------------------------
---  ddl for view dim_dummy_records_vw
--------------------------------------------------------

create or replace force view dim_dummy_records_vw 							as 
  (
	select 
		  -1 															as dim_id
		, 'onb' 														as omschrijving_kort
		, 'Onbekend' 													as omschrijving_lang
		, -1 															as nummer
		, rpad('p',32,'p') 												as hashkey
		, to_date('01-01-1900','dd-mm-yyyy') 							as dim_geldig_vanaf
		, to_date('31-12-9999','dd-mm-yyyy') 							as dim_geldig_tm
from dual
);
