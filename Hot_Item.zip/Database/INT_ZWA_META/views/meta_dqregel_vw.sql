create or replace force view meta_dqregel_vw as
with data as (
select 
		'UWVM2VLOAPP0004.odim.INT_ZWA_PO.DV_TAAK_S.ACTIVITEIT_OMSCHRIJVING' 	as volledige_naam
		, 'Lege veld controle'													as dq_regel
		, 'IS NULL'																as dq_syntax
		, 'DQ_CHECK'															as dq_procedure
		, 'ACTIVITEIT_OMSCHRIJVING wordt gecontroleerd op een leeg veld'		as regel_beschrijving
	from dual
)
select *
from data