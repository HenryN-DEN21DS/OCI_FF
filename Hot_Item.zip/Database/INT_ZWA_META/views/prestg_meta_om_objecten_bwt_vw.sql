
--------------------------------------------------------
---  ddl for view prestg_meta_om_objecten_bwt_vw
--------------------------------------------------------

create or replace force view prestg_meta_om_objecten_bwt_vw as 
  with cte as (
    select
          '0' 															as dim_dummy
		, omobject_id
		, om_naam
		, tabel_host 													as host_naam
		, tabel_database 												as database_naam
		, tabel_schema 													as schema_naam
		, tabel_naam 
		, bewaartermijn
		, bewaartermijn_eenheid
		, bewaartermijn_ingangsdatum
		, modificatiedatum
		, extractiedatum_xmeta 											as dim_extractiedatum_xmeta
		, row_number() over (partition by omobject_id, tabel_host, tabel_database, tabel_schema, tabel_naam order by modificatiedatum desc) 
																		as rownumber
	from int_zwa_meta.xmeta_om_objecten_vw)
  
select 
	  dim_dummy,omobject_id
	, om_naam,host_naam
	, database_naam
	, schema_naam
	, tabel_naam
	, bewaartermijn
	, bewaartermijn_eenheid
	, bewaartermijn_ingangsdatum
	, modificatiedatum
	, dim_extractiedatum_xmeta
	, rownumber 
from cte 
where rownumber = 1;
