
--------------------------------------------------------
---  ddl for view pbd_housekeeping_log_vw
--------------------------------------------------------

create or replace force view pbd_housekeeping_log_vw as 
  with cte as (
	select 
		  init.aantal_records_initieel
		, na.aantal_records_na_schoning
		, init.om_naam
		, init.tabel_naam
		, init.tijdstip_uitgevoerd as tijdstip_telling_voor_schoning
		, na.tijdstip_uitgevoerd as tijdstip_telling_na_schoning
		, init.run_id as run_id
	from int_zwa_meta.pbd_housekeeping_log_tb init
	join int_zwa_meta.pbd_housekeeping_log_tb na
		on (init.tabel_naam = na.tabel_naam 
			and init.om_naam = na.om_naam 
			and init.run_id = na.run_id
            and extract( second from na.tijdstip_uitgevoerd ) - extract( second from init.tijdstip_uitgevoerd ) between -60 and 60
            and extract( minute from na.tijdstip_uitgevoerd ) - extract( minute from init.tijdstip_uitgevoerd ) between -3 and 3
            and extract( hour from na.tijdstip_uitgevoerd ) - extract( hour from init.tijdstip_uitgevoerd ) between 0 and 0.5
            and extract( day from na.tijdstip_uitgevoerd ) - extract( day from init.tijdstip_uitgevoerd ) between 0 and 1
            )
	where init.aantal_records_initieel is not null 
	and na.aantal_records_na_schoning is not null
	)
	
select 
	cte.om_naam
	, cte.tabel_naam
	, cte.aantal_records_initieel
	, cte.aantal_records_na_schoning 
	, cte.aantal_records_initieel - cte.aantal_records_na_schoning as aantal_records_verwijderd
	, cte.tijdstip_telling_voor_schoning
	, cte.tijdstip_telling_na_schoning
	, cte.run_id
from cte;
