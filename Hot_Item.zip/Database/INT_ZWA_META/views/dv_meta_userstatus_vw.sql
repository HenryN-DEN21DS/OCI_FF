
--------------------------------------------------------
--  ddl for view dv_meta_userstatus_vw
--------------------------------------------------------

create or replace force view dv_meta_userstatus_vw as 
  with cte_sat as (
	select 
		me.*
	from int_zwa_meta.dv_meta_mappingext_vw me
	where me.mapping_specificatie like  '%\_SAT'  escape '\' 
	)
	, cte_hub as (
	select 
		me.*
	from int_zwa_meta.dv_meta_mappingext_vw me
	where me.mapping_specificatie like  '%\_HUB'  escape '\'
	)
	, cte_link as (
	select 
		me.*
	from int_zwa_meta.dv_meta_mappingext_vw me
	where me.mapping_specificatie like  '%\_LNK'  escape '\' 
	)
	, cte_stg as (
	select 
		me.*
	from int_zwa_meta.dv_meta_mappingext_vw me
	where me.mapping_specificatie like  '%\_STG'  escape '\'
	)
	, cte_dim as ( 
	select 
		me.*
	from int_zwa_meta.dv_meta_mappingext_vw me
	where me.mapping_specificatie like  '%\_DIM'  escape '\'
	)
	, cte_fct as ( 
	select 
		me.*
	from int_zwa_meta.dv_meta_mappingext_vw me
	where me.mapping_specificatie like  '%\_FCT'  escape '\'
	)
	select distinct
		  sat.mapping_specificatie
		, sat.bron_tabel || '~' ||
		  sat.doel_tabel || '~' ||
		  sat.bron_key_kolom || '~' ||
		  sat.doel_key_kolom || '~' ||
		  sat.bron_schema || '~' || 
		  sat.doel_schema as input_user_status
		, sat.stmt as select_stmt -- de parameters HASHDIFF_KOLOMMEN en HASHDIFF_KEY zitten in select_stmt
		, sat.insert_stmt
	from cte_sat sat
	union all
	select distinct
		  hub.mapping_specificatie
		, hub.bron_tabel || '~' || 
		hub.doel_tabel || '~' || 
		hub.bron_key_kolom || '~' || 
		hub.doel_key_kolom || '~' || 
		hub.bron_schema || '~' || 
		hub.doel_schema as input_user_status
		, ' ' as select_stmt
		, hub.insert_stmt
	from cte_hub hub
	union all
	select distinct
		  l.mapping_specificatie
		, l.bron_tabel || '~' ||
		  l.doel_tabel || '~' ||
		  l.bron_key_kolom || '~' ||
		  l.doel_key_kolom || '~' || 
		  l.bron_schema || '~' || 
		  l.doel_schema as input_user_status
		, ' ' as select_stmt
		, l.insert_stmt
	from cte_link l
	union all
	select distinct
		  s.mapping_specificatie
		, ' '|| '~' ||
		  s.doel_tabel || '~' ||
		  ' ' || '~' ||
		  ' ' || '~' || 
		  s.bron_schema || '~' || 
		  s.doel_schema as input_user_status
		, s.stmt as select_stmt
		, s.insert_stmt
	from cte_stg s
	union all
	select distinct
		  dim.mapping_specificatie
		, dim.bron_tabel || '~' ||
		  dim.doel_tabel || '~' || 
		  dim.bron_key_kolom || '~' ||
		  dim.doel_key_kolom || '~' || 
		  dim.bron_schema || '~' || 
		  dim.doel_schema as input_user_status
		, dim.stmt as select_stmt 
		, dim.insert_stmt
		from cte_dim dim
	union all
	select distinct
		  fct.mapping_specificatie
		, fct.bron_tabel || '~' ||
		  fct.doel_tabel || '~' || 
		  fct.bron_key_kolom || '~' ||
		  fct.doel_key_kolom || '~' || 
		  fct.bron_schema || '~' || 
		  fct.doel_schema as input_user_status
		, fct.stmt as select_stmt 
		, fct.insert_stmt
	from cte_fct fct;
