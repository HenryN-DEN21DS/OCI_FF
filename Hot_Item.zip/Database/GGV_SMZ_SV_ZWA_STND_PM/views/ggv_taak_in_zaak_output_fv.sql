create or replace force view ggv_taak_in_zaak_output_fv
as 
select dim_datum_key,
dim_snapshot_key,
dim_zaak_key,
dim_taakinzaak_key,
dim_taak_key,
dim_team_key_verantwoordelijk,
dim_team_key_taak,
aantal_output
from bdr_zwa_pm.bdr_taak_in_zaak_output_ft;