create or replace force view ggv_snapshot_dv
as 
select dim_snapshot_key,
dim_datum_key_ultimo_periode,
periode_type,
snapshot_periode,
snapshot_datum_vanaf,
snapshot_datum_tm,
snapshot_datum,
snapshot_type
from bdr_zwa_pm.bdr_snapshot_dt;