create or replace force view ggv_taak_dv
as 
select dim_taak_key,
taakcode,
taak
from bdr_zwa_pm.bdr_taak_dt;

