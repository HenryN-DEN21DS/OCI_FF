create or replace force view ggv_zaak_voorraad_fv
as 
select dim_datum_key,
dim_snapshot_key,
dim_zaak_key,
dim_team_key_verantwoordelijk,
dim_ouderdomscategorie_key,
aantal_voorraad,
ouderdom,
verzuimduur_tot_rapportagemoment
from bdr_zwa_pm.bdr_zaak_voorraad_ft;