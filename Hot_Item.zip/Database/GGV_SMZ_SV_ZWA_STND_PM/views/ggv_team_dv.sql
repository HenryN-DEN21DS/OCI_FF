create or replace force view ggv_team_dv
as 
select dim_team_key,
teamnummer,
teamnaam,
districtskantoor_nr,
districtskantoor_naam,
districtskantoor_sorteervolgnr,
regio_nr,
regio_naam,
regio_sorteervolgnr
from bdr_zwa_pm.bdr_team_dt;