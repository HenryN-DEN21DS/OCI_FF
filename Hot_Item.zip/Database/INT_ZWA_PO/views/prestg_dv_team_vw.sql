
--------------------------------------------------------
---  ddl for view prestg_dv_team_vw
--------------------------------------------------------

create or replace force view prestg_dv_team_vw 								as 
with teams as
(
    select distinct teamnummer, nr_dk
        from okv_imf_po.okv_persoon_hv
        where dim_recent_ind = 'J'

    UNION -- niet all, want we willen alle unieke waarden hebben

    select distinct teamnummer, nr_dk
        from okv_imf_po.okv_ao_akt_hv
        where dim_recent_ind = 'J'
)
, reforg as (
	select 
		  level1_code  													as districtskantoor_nr
        , level1_naam       											as districtskantoor_naam
		, level1_volgorde   											as districtskantoor_sorteervolgnr
		, level2_code       											as regio_nr
		, level2_naam       											as regio_naam
		, level2_volgorde   											as regio_sorteervolgnr
	from okv_referentie_data.ref_organisatie_ht
	where org_bron_id = 5 -- IMF
	and dim_ind_huidig = 'J'
	)
	select
		  cast(t.teamnummer as varchar2(9))               			    as teamnummer
		, cast(null as varchar2(99))                        			as teamnaam
		, cast(t.nr_dk as varchar2(99))                    			    as districtskantoor_nr
		, cast(reforg.districtskantoor_naam as varchar2(99))            as districtskantoor_naam
		/*, cast(reforg.districtskantoor_sorteervolgnr as number)      	as districtskantoor_sorteervolgnr*/
        , cast(t.nr_dk*10000+t.teamnummer as number)                    as districtskantoor_sorteervolgnr -- in reforg blijkt de sortering leeg te zijn
		, cast(reforg.regio_nr as number(38,10))            			as regio_nr
		, cast(reforg.regio_naam as varchar2(99))           			as regio_naam
		, cast(reforg.regio_sorteervolgnr as number(38,10)) 			as regio_sorteervolgnr
        , cast (null as timestamp(6))                       			as dim_ingangsdatum_bwt
	from teams t
	left outer join reforg
		on reforg.districtskantoor_nr = t.nr_dk
    ;
