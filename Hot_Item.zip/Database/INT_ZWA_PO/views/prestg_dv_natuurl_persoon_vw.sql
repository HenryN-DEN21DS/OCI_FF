create or replace force view prestg_dv_natuurl_persoon_vw as
with imf as
(
select 
pers.afg_bsn                                                 as bsn,
pers.status_persoon                                          as status_persoon, 
pers.gebdat                                                  as geboortedatum,
pers.afg_postcode_verbl_domic                                as domicilie_postcode,
pers.afg_postcode_verbl_domicgebied                          as domicilie_postcode_gebied,
pers.afg_postcode_verpl                                      as verpleeg_adres_postcode, 
pers.afg_postcode_verplgebied                                as verpleeg_adres_postcode_gebied, 
pers.nr_land_verpl                                           as verpleeg_adres_land_nr, 
land.omschrijving                                            as verpleeg_adres_land, 
pers.cd_verpleeg                                             as verpleeg_instelling_code,
inst.omschrijving                                            as verpleeg_instelling
from 
            okv_imf_po.okv_persoon_hv pers
left join   okv_imf_po.ref_imf_persoon_nr_land_verpl_hv land on land.nr_land_verpl = pers.nr_land_verpl
left join   okv_imf_po.ref_imf_persoon_cd_verpleeg_hv inst on inst.cd_verpleeg = pers.cd_verpleeg
where dim_recent_ind = 'J'
),
uzs as 
(
select distinct
bsn,
status_persoon,
geboortedatum,
domicilie_postcode,
domicilie_postcode_gebied,
verpleeg_adres_postcode,
verpleeg_adres_postcode_gebied,
verpleeg_adres_land_nr,
verpleeg_adres_land,
verpleeg_instelling_code,
verpleeg_instelling
from int_zwa_po.zaak_uzs_vw
)
select 
    cast(case when imf.bsn is null then uzs.bsn else imf.bsn end as varchar2(99))                                                       as bsn,
    cast(case when imf.bsn is null then uzs.status_persoon else imf.status_persoon end  as varchar(9))                                  as status_persoon,
    cast(case when imf.bsn is null then uzs.geboortedatum else imf.geboortedatum end as timestamp)                                      as geboortedatum,
    cast(case when imf.bsn is null then uzs.domicilie_postcode else imf.domicilie_postcode end as varchar2(9))                          as domicilie_postcode,
    cast(case when imf.bsn is null then uzs.domicilie_postcode_gebied else imf.domicilie_postcode_gebied end as varchar2(9))            as domicilie_postcode_gebied,
    cast(case when imf.bsn is null then uzs.verpleeg_adres_postcode else imf.verpleeg_adres_postcode end as varchar2(9))                as verpleeg_adres_postcode, 
    cast(case when imf.bsn is null then uzs.verpleeg_adres_postcode_gebied else imf.verpleeg_adres_postcode_gebied end as varchar2(9))  as verpleeg_adres_postcode_gebied, 
    cast(case when imf.bsn is null then uzs.verpleeg_adres_land_nr else imf.verpleeg_adres_land_nr end as varchar2(9))                  as verpleeg_adres_land_nr, 
    cast(case when imf.bsn is null then uzs.verpleeg_adres_land else imf.verpleeg_adres_land end as varchar2(99))                       as verpleeg_adres_land, 
    cast(case when imf.bsn is null then uzs.verpleeg_instelling_code else imf.verpleeg_instelling_code end as varchar2(9))              as verpleeg_instelling_code,
    cast(case when imf.bsn is null then uzs.verpleeg_instelling else imf.bsn end as varchar2(99))                                       as verpleeg_instelling,    
    case when imf.bsn is not null and uzs.bsn is not null then 'IMF-UZS' when imf.bsn is not null and uzs.bsn is null then 'IMF' else 'UZS' end as herkomst

from imf
full join uzs on imf.bsn = uzs.bsn