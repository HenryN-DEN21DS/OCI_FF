
--------------------------------------------------------
---  ddl for view zaak_imf_vw
--------------------------------------------------------

create or replace force view zaak_imf_vw as 
  with akt as
(select afg_bsn, cd_contract, afg_nr_aansl_bv, nr_buitenl_inst, bdat_ao
, count(*) aantal_act
, min(case  when    cd_aanw_pers in (1, 3, 5, 6, 7) -- daadwerkelijk persoon gesproken
                    and cd_srt_akt in (121, 122, 123, 131, 132, 133, 232, 233, 410, 411, 412, 415, 416, 417, 418, 426, 427, 632, 633, 732, 733 ) -- activiteiten gericht op de client 
            then dat_real_akt end ) eerste_contactmoment
, max(case  when cd_srt_akt = 162 and dat_real_akt is not null
            then 'J'
            end) as ind_gdbm
, max(case when cd_srt_akt = 502
           then 'J'
           end) as tweedelijn
from okv_imf_po.okv_ao_akt_hv
where dim_recent_ind = 'J'
group by afg_bsn, cd_contract, afg_nr_aansl_bv, nr_buitenl_inst, bdat_ao
)
, cte
as 
(
select
 pers.teamnummer
,pers.nr_dk
,ao.afg_bsn
,ao.afg_nr_aansl_bv
,ao.cd_contract
,ao.nr_buitenl_inst
,ao.bdat_ao                                                                                                         as begindatum_ao
,ao.aanvr_id_uzs
,ao.uzs_gevals_volgnr            
,ao.dat_ontv_ao_meld                  
,ao.dat_boeking_ao
,case when akt.tweedelijn = 'J' then '2e lijn' else '1e lijn' end                                                   as eerste_of_tweede_lijn
,ao.dat_overdr_ck                                                                                                   as datum_overdracht_ck
,ao.tijd_boeking_ao
,akt.eerste_contactmoment
,ao.dat_plausibel                                                                                                   as datum_plausibel
,ao.ind_plausibel
,ao.dat_meld_vz                           
,ao.dat_max_zw                                                                                                      as maximum_datum_ziektewet
,ao.dat_uda_ezwb                                                                                                    as dat_uda_ezwb
,ao.dat_nuda_ezwb                                                                                                   as dat_nuda_ezwb
,ao.dat_ontv_h_meld 
,ao.dat_boek_hm                                                                                                     as datum_hm
,ao.tijd_boeking_hm
,ao.edat_ao                                                                                                         as einddatum_ao
,coalesce(ao.edat_ao, ao.bdat_ao)                                                                                   as dim_ingangsdatum_bwt_zaak 
,to_date(null)                                                                                                      as datum_boeking_dienstverband
,ao.cd_cat_vangnet                                                                                                  as code_vangnetcategorie
,vnet.omschrijving                                                                                                  as vangnetcategorie
,ao.cd_ag_traj                                                                                                      as code_ag_traject
,ag.omschrijving                                                                                                    as ag_traject
,ao.cd_bron_hmel                                                                                                    as code_bron_hersteldmelding
,brhm.omschrijving                                                                                                  as bron_hersteldmelding
,ao.cd_reden_hmel                                                                                                   as code_uitstroomoorzaak
,hmel.omschrijving                                                                                                  as uitstroomoorzaak
,ao.ind_erd_zw                                                                                                      as ind_eigenrisicodrager
,akt.aantal_act
,akt.ind_gdbm
from okv_imf_po.okv_ao_geval_hv ao
left outer join okv_imf_po.okv_persoon_hv pers
        on pers.afg_bsn = ao.afg_bsn
        and pers.dim_recent_ind = 'J' 
left outer join okv_imf_po.ref_imf_ao_geval_cd_cat_vangnet_hv vnet
        on ao.cd_cat_vangnet = vnet.cd_cat_vangnet
left outer join okv_imf_po.ref_imf_ao_geval_cd_ag_traj_hv ag
        on ao.cd_ag_traj = ag.cd_ag_traj
left outer join okv_imf_po.ref_imf_ao_geval_cd_reden_hmel_hv hmel
        on ao.cd_reden_hmel = hmel.cd_reden_hmel 
left outer join akt 
        on akt.afg_bsn = ao.afg_bsn     
       and akt.cd_contract = ao.cd_contract
       and coalesce(akt.afg_nr_aansl_bv, '*$#') = coalesce(ao.afg_nr_aansl_bv, '*$#')
       and akt.nr_buitenl_inst = ao.nr_buitenl_inst
       and akt.bdat_ao = ao.bdat_ao
left outer join okv_imf_po.ref_imf_ao_geval_cd_bron_hmel_hv brhm
        on brhm.cd_bron_hmel = ao.cd_bron_hmel
where 1=1
  and ao.dim_recent_ind = 'J' 
)
select 
  cast(cte.afg_bsn as varchar2(99))                                                                                  as bsn
, cast(cte.afg_nr_aansl_bv as varchar2(99))                                                                          as aansluitingsnr
, cast(cte.cd_contract  as varchar2(9))                                                                              as contractcode
, cast(cte.nr_buitenl_inst as varchar2(9))                                                                           as buitenlandse_instellingsnr
, cast(cte.datum_boeking_dienstverband as timestamp)                                                                 as datum_boeking_dienstverband
, cast(cte.begindatum_ao as timestamp)                                                                               as begindatum_ao
, cast(cte.aanvr_id_uzs as number(38,10))                                                                            as uzs_aanvraagid
, cast(cte.uzs_gevals_volgnr as number(38,10))                                                                       as uzs_gevalsvolgnr
, cast(cte.dat_ontv_ao_meld as timestamp)                                                                            as datum_ontvangst_ao_melding
, cast(cte.dat_boeking_ao + (floor(cte.tijd_boeking_ao/100)/24 + mod(cte.tijd_boeking_ao,100)/(24*60)) as timestamp) as datum_boeking_ao
, cast(eerste_of_tweede_lijn as varchar2(99))                                                                        as eerste_of_tweede_lijn
, cast(cte.datum_overdracht_ck as timestamp)                                                                         as datum_overdracht_ck
, cast(cte.dat_meld_vz as timestamp)                                                                                 as datum_ziekmeld_door_verzekerde
, cast(cte.eerste_contactmoment as timestamp)                                                                        as eerste_contactmoment
, cast(cte.datum_plausibel as timestamp)                                                                             as datum_plausibel
, cast(cte.ind_plausibel as varchar2(9))                                                                             as indicatie_plausibel
, cast(cte.maximum_datum_ziektewet as timestamp)                                                                     as maximum_datum_ziektewet
, cast(cte.dat_uda_ezwb as timestamp)                                                                                as dat_uda_ezwb
, cast(cte.dat_nuda_ezwb as timestamp)                                                                               as dat_nuda_ezwb
, cast(cte.dat_ontv_h_meld as timestamp)                                                                             as datum_ontvangst_hersteldmelding
, cast(cte.datum_hm + (floor(cte.tijd_boeking_hm/100)/24 + mod(cte.tijd_boeking_hm,100)/(24*60))  as timestamp)      as datum_boeking_hersteldmelding
, cast(cte.einddatum_ao as timestamp)                                                                                as einddatum_ao
, cast(null as varchar2(99))                                                                                          as code_vangnetcategorie_bb
, cast(null as varchar2(99))                                                                                         as vangnetcategorie_bb
, cast(null as varchar2(99))                                                                                          as code_vangnetcategorie_szw
, cast(null as varchar2(99))                                                                                         as vangnetcategorie_szw
, cast(cte.code_vangnetcategorie as varchar2(99))                                                                    as code_vangnetcategorie_imf
, cast(cte.vangnetcategorie as varchar2(99))                                                                         as vangnetcategorie_imf
, cast(cte.code_ag_traject as varchar2(99))                                                                          as code_ag_traject
, cast(cte.ag_traject as varchar2(99))                                                                               as ag_traject
, cast(cte.code_bron_hersteldmelding as varchar2(99))                                                                as code_bron_hersteldmelding
, cast(cte.bron_hersteldmelding as varchar2(99))                                                                     as bron_hersteldmelding
, cast(cte.code_uitstroomoorzaak as varchar2(99))                                                                    as code_uitstroomoorzaak
, cast(cte.uitstroomoorzaak as varchar2(99))                                                                         as uitstroomoorzaak
, cast(null as varchar2(99))                                                                                          as cd_reden_einde_recht
, cast(null as varchar2(99))                                                                                         as reden_einde_recht
, coalesce(cast(ind_eigenrisicodrager as varchar2(9)), 'N')                                                          as ind_eigenrisicodrager
, cast(case when cte.aantal_act is null then 'J' else 'N' end as varchar2(9))                                        as ind_slapend
, coalesce(cast(cte.ind_gdbm as varchar2(9)), 'N')                                                                   as ind_gdbm
, cast(cte.dim_ingangsdatum_bwt_zaak as timestamp)                                                                   as dim_ingangsdatum_bwt
, cast(cte.teamnummer as varchar2(9))                                                                                as teamnummer
, cast(cte.nr_dk as varchar2(9))                                                                                     as districtskantoor_nr
, cast(null as varchar2(9))                                                                                          as dim_dummy
from cte
where 1=1
and coalesce(cte.einddatum_ao, to_date('31-12-9999','dd-mm-yyyy')) >= cte.begindatum_ao;