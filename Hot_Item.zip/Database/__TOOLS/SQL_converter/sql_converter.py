import os
import re
import csv
import argparse
import fnmatch
import subprocess
from pathlib import Path
import zipfile
import logging
import tkinter as tk
from tkinter import filedialog
from datetime import datetime
import xml.etree.ElementTree as ET
from collections import OrderedDict


def get_git_root():
    """
    Get the root directory of the current Git repository.
    
    Returns:
        str: The absolute path of the root directory if inside a Git repository, otherwise None.
    """
    
    try:
        git_root = subprocess.check_output(["git", "rev-parse", "--show-toplevel"]).strip().decode("utf-8")
        return git_root
    except subprocess.CalledProcessError:
        print("Error: Current directory is not a git repository")
        return None
    

def path_match(pattern, path):
    """
    Checks if a given path matches a pattern with wildcards.
    
    Parameters:
        pattern (str): The pattern to match against, which can include wildcards.
        path (str): The path to check.
        
    Returns:
        bool: True if the path matches the pattern, otherwise False.
    """
    
    pattern_parts = pattern.strip('/').split('/')
    path_parts = path.strip('/').split('/')
    
    # Check if the depth of the path is greater than or equal to the depth of the pattern
    if len(path_parts) < len(pattern_parts):
        return False
    
    for p, r in zip(pattern_parts, path_parts):
        if not fnmatch.fnmatch(r, p):
            return False
    
    return True


def find_files(base_path: str, folder_location: str, file_extension: str) -> list:
    """
    Search for files in a directory and its subdirectories that match a given folder location and file extension.
    
    Parameters:
        base_path (str): The base path to start the search from.
        folder_location (str): The folder location to search within, can include wildcards.
        file_extension (str): The file extension to look for.
        
    Returns:
        list: A list of found files that match the folder location and file extension.
    """
    
    git_root = get_git_root()
    if git_root is None:
        return []
    
    file_location = base_path + folder_location

    # Extract the directory before the first wildcard
    base_directory = os.path.join(git_root, file_location.split('*')[0].lstrip('./'))

    # Check if the base directory exists
    if not os.path.exists(base_directory):
        print("Error: Base folder does not exist")
        return []

    # List to store found files
    found_files = []

    # Walk through the base directory
    for dirpath, _, filenames in os.walk(base_directory):
        # Temporary list for the current directory
        temp_list = []
        
        # Check if the directory matches the wildcard pattern
        relative_dirpath = os.path.relpath(dirpath, git_root)
        if path_match(file_location.lstrip('./'), relative_dirpath.replace("\\", "/")):
            for filename in filenames:
                if filename.endswith(file_extension):
                    # Generate the relative path from the git root directory
                    relative_path = os.path.relpath(os.path.join(dirpath, filename), git_root)
                    relative_full_path = "./" + relative_path.replace("\\", "/")
                    temp_list.append("/" + relative_full_path.replace(base_path, ""))
        
        # Custom sort for the temporary list
        def custom_sort(file_name : str) -> tuple:
            if file_name.endswith('_s.sql') or file_name.endswith('_s_bwt.sql'):
                return (0, file_name)
            elif file_name.endswith('_l.sql'):
                return (1, file_name)
            elif file_name.endswith('_h.sql'):
                return (2, file_name)
            else:
                return (3, file_name)
        
        temp_list = sorted(temp_list, key=custom_sort)
        
        # Extend the main list with the sorted temporary list
        found_files.extend(temp_list)

    return found_files


def create_manifest_file(release_code: str) -> None:
    """
    Create a manifest file that lists files based on predefined folder locations and file extensions.
    
    Parameters:
        release_code (str): The release code to name the manifest file.
        
    Returns:
        None
    """
    
    # List of pairs (file_location, file_extension)
    # The order is important here! First the .dsx jobs, then the tables, then SP's then Views and finally the mappings!
    file_location_extension_pairs = [
        ('./Datastage/', '/', '.dsx'),
        ('./Database/', '*/tabellen/', '.sql'),
        ('./Database/', '*/stored_procedures/', '.sql'),
        ('./Database/', '*/views/', '.sql'),
        ('./IDA/05 Mappings/output/test/', '/', '.csv'),
        # Add more pairs as needed (in the right order)
    ]

    # Final list to store found files from all pairs
    final_found_files = []

    # Loop through each pair and find files
    for base_path, file_location, file_extension in file_location_extension_pairs:
        found_files = find_files(base_path, file_location, file_extension)
        final_found_files.extend(found_files)
        
    # Write manifest file by looping over each file and write each to its own line
    with open(get_git_root() + "/Deployment/test/{}.manifest".format(release_code), "w") as f:
        for line in final_found_files:
            # Write each item followed by a newline character
            f.write(line + "\n")
    
    return None


def replace_none_with_name_and_underscore(name, label):
    """
    Replaces None with name and spaces with underscore in the label.

    Args:
        name (str): Name of the entity.
        label (str): Label of the entity.

    Returns:
        str: Label after replacing None and spaces.
    """
    return (name if label is None else label).replace(" ", "_").lower()


def _row_to_list(row_xml: ET.Element, shared_strings: list) -> list:
    """
    Converts a row of XML to a list of cell values.

    Args:
        row_xml (ET.Element): XML element representing the row.
        shared_strings (list): List of shared strings in the document.

    Returns:
        list: List of cell values.
    """
    row_list = []
    
    for cell in row_xml.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        # Look up the value of the cell from the shared strings table
        cell_value = cell.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v')
        
        if cell_value is None:
            cell_result = None
        else:
            text_value = cell_value.text
            if cell.get('t') == 's': # if the cell contains a shared string
                cell_result = shared_strings[int(text_value)]
        row_list.append(cell_result)
    return row_list


def xlsx_file_to_list_of_dict(file_name: str, column_list: list) -> list:
    """
    Converts an Excel file to a list of dictionaries, each dictionary representing a row in the Excel file.

    Args:
        file_name (str): Name of the Excel file.
        column_list (str): list of column names in the order you want the dictionary rows returned

    Returns:
        list: List of dictionaries.
    """
    logging.info("Reading name_label_report file: %s", file_name)
    result_list = []
    with zipfile.ZipFile(file_name) as archive:
        
        # Find the shared strings file and parse it
        shared_strings_xml = archive.read('xl/sharedStrings.xml')
        shared_strings_tree = ET.fromstring(shared_strings_xml)
        shared_strings = []
        
        # Loop through each string in the shared strings table and extract the text value
        for si in shared_strings_tree.findall('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}si'):
            string_value = si.find('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t').text
            shared_strings.append(string_value)
        
        # Loop through every sheet to get all data at once
        sheet_files = [filename for filename in archive.namelist() if "/worksheets/" in filename]
            
        for sheet in sheet_files:
                       
            # Find the worksheet data file and parse it
            worksheet_xml = archive.read(sheet)
            worksheet_tree = ET.fromstring(worksheet_xml)
            
            # First row = headers
            first_row = worksheet_tree.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row')[0]
            headers = _row_to_list(first_row, shared_strings)
                 
            # Loop through each row in the worksheet and extract the data
            for row in worksheet_tree.findall('.//{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row')[1:]:
                cell_values = _row_to_list(row, shared_strings)
                row_dict = {k : v for k, v in zip(headers, cell_values)}
                
                sorted_row_dict = OrderedDict((key, row_dict.get(key, None)) for key in column_list)
                
                result_list.append(sorted_row_dict)
                
    logging.info("Finished converting Excel file to list of dictionaries.")
        
    return result_list


def clean_name_label_report(row_list: list, model_conversion: dict) -> list:
    
    # Delete all rows where "Persistent = false"
    row_list = [row for row in row_list if row["Persistent"] != "false"]
    
    # Clean each row
    for row in row_list:

        row["Attribute Name"] = replace_none_with_name_and_underscore(row["Attribute Name"], row["Attribute Label"])
        row["Table Name"] = replace_none_with_name_and_underscore(row["Entity Name"], row["Entity Label"])
        
        if row["Primary Key Name"] is not None:
            row["Primary Key Label"] = replace_none_with_name_and_underscore(row["Primary Key Name"], row["Primary Key Label"])
        
        try:
            row["Schema Name"] = model_conversion[row["Package Name"]]
        except:
            logging.warning("Conversion failed for table %s in model: %s", row["Table Name"], row["Package Name"])
        
        # Create unique identifier per table 
        row["Schema.Table"] = row["Schema Name"] + "." + row["Table Name"]
        
        # FK's not used at this time
        # if row["Foreign Key name"] is not None:
        #     row["Foreign Key label"] = replace_none_with_name_and_underscore(row["Foreign Key name"], row["Foreign Key label"])
            
    return row_list


def write_results_csv(result_rows: list, filename: str) -> None:
    """
    Writes a list of dictionaries to a CSV file.

    Args:
        result_rows (list): List of dictionaries to write to the CSV.
        filename (str): Name of the output CSV file.

    Returns:
        None
    """
    output_dir = "./output"
    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, filename + ".csv"), "w",  newline='', encoding="utf-8") as f:
        writer = csv.writer(f, delimiter=',')
        writer.writerow(result_rows[0].keys())
        for row in result_rows:
            writer.writerow(row.values())
    logging.debug("Finished writing file: ./output/%s.csv", filename)

def one_dict_per_table(list_of_dicts: list) -> list:
    """
    Groups rows by table name into separate dictionaries.

    Args:
        list_of_dicts (list): List of dictionaries representing rows in the Excel file.

    Returns:
        list: List of dictionaries grouped by table name.
    """
    result = {}
    table_list = [row["Schema.Table"] for row in list_of_dicts]
    for table in table_list:
        result[table] = [row for row in list_of_dicts if row["Schema.Table"] == table]
    
    logging.info("Finished grouping rows by table name.")
    
    return result

def parse_comments(table_rows: dict, query_args: dict) -> dict:
    """
    Parses comments for each column in a table.

    Args:
        table_name (str): Name of the table.
        table_dict (dict): Dictionary representing the table.
        query_args (dict): Dictionary of query arguments.

    Returns:
        dict: Updated dictionary of query arguments.
    """

    comment_template = "comment on column {table_name}.{column_name} is '{comment}'\n/"
    
    comment_list = []
    
    for row in table_rows:
        if row["Documentation"] is not None:
            comment_query_args = {
                "table_name": row["Table Name"],
                "column_name": row["Attribute Name"],
                "comment": row["Documentation"]
            }
            comment = comment_template.format(**comment_query_args)
            comment_list.append(comment)
    
    query_args["comments"] = "\n\n".join(comment_list)
    
    logging.info("Finished parsing comments for table: %s", row["Table Name"])
    logging.debug("Query arguments after parsing comments: %s", query_args)
    
    return query_args

def _parse_default_and_nullable(row_dict: OrderedDict):
    
    result = ""
    
    defaultvalue_template = " default on null {default_value}"
    
    if row_dict["Default Value"] is not None:
        result += defaultvalue_template.format(default_value=row_dict["Default Value"]) 
    
    if row_dict["Required"] == "true":
        result += " not null"
    
    return result


def _map_oracle_datatype(oracle_type: str, type_qualifier: str) -> str:
    numeric_types = [
        "NUMBER", "FLOAT", "BINARY_FLOAT", "BINARY_DOUBLE", "REAL", "TINY",
        "DEC", "DECIMAL", "INT", "INTEGER", "SMALLINT", "DOUBLE PRECISION"
    ]
    
    if oracle_type.upper() in numeric_types:
        return "number"
    
    # Check if oracle_type matches pattern like 'NUMERIC(38,10)'
    numeric_pattern = re.compile(r'NUMERIC\(\d+,\d+\)', re.IGNORECASE)
    
    if numeric_pattern.match(oracle_type):
        return "number"
    
    # Check if oracle_type matches pattern "VARCHAR(<digits>)"
    varchar_match = re.match(r'VARCHAR\((\d+)\)', oracle_type)
    
    if varchar_match:
        # Extract digits from the matched group
        digits = varchar_match.group(1)
               
        # Check type_qualifier
        if (type_qualifier == "CHAR") or type_qualifier is None:
            type_qualifier = " CHAR"
        else:
            type_qualifier = " {}".format(type_qualifier)
                
        return "VARCHAR2({0}{1})".format(digits, type_qualifier)
    
    return oracle_type
    
    
def _custom_sort_columns(item: OrderedDict):
    
    colname = item['Attribute Name']
    
    if ("_hk" in colname) or (colname.endswith("_key")):
        return (0, colname)  # 0 to prioritize "_hk" or "_key" ending
    elif colname.startswith("dim_"):
        return (1, colname)  # 1 to place "dim_" starting after "_hk" ending
    elif colname.endswith("_hashkey"):
        return (2, colname)  # 2 to place "_hashkey" after "_hk" and "_dim"
    else:
        return (3, colname)  # 3 for all others


def parse_columns(table_rows: dict, query_args: dict) -> dict:
    """
    Parses columns for a table.

    Args:
        table_name (str): Name of the table.
        table_dict (dict): Dictionary representing the table.
        query_args (dict): Dictionary of query arguments.

    Returns:
        dict: Updated dictionary of query arguments.
    """
    column_list = []
    counter = 0
    
    # Convert the OrderedDicts to tuples and deduplicate
    unique_data_as_tuples = set(tuple(item.items()) for item in table_rows)

    # Convert tuples back to OrderedDicts
    deduplicated_rows = [OrderedDict(t) for t in unique_data_as_tuples]
    
    # Sort the columns using the custom sort function
    sorted_rows = sorted(deduplicated_rows, key=_custom_sort_columns)
    
    max_column_length = max(len(row["Attribute Name"]) for row in sorted_rows)

    for row in sorted_rows:
        
        default_and_nullable_string = _parse_default_and_nullable(row)
        data_type = _map_oracle_datatype(row["Data Type"], row["Data Type Qualifier"]).lower()
                   
        # If it's the first col, put a tab in front of the column_name
        if counter == 0:
            column_list.append("\t{:<{}}\t{}{}".format(row["Attribute Name"], max_column_length, data_type, default_and_nullable_string))
            counter +=1
        else:
            column_list.append("{:<{}}\t{}{}".format(row["Attribute Name"], max_column_length, data_type, default_and_nullable_string))
            counter +=1
                   
    query_args["columns"] = ",\n\t".join(column_list)
    
    logging.info("Finished parsing columns for table: %s", row["Table Name"])
    logging.debug("Query arguments after parsing columns: %s", query_args)
    
    return query_args


def parse_pk_and_index(table_rows: dict, query_args: dict) -> dict:
    """
    Parses primary key and index for a table.

    Args:
        table_name (str): Name of the table.
        table_dict (dict): Dictionary representing the table.
        query_args (dict): Dictionary of query arguments.

    Returns:
        dict: Updated dictionary of query arguments.
    """
    
    
    index_template = "create index {index_name} on {table_name} ({column_list})\n/"
    pk_template = "alter table {table_name} add constraint {pk_name} primary key ({column_list}) using index {index_name} enable\n/"
    pk_column_list = []
    pk_col_present = False

    # First loop over cols to find all pk_cols
    for row in table_rows:
        if row["Primary Key Label"] is not None:
            pk_col_present = True
            pk_column_list.append(row["Attribute Name"])
            pk_name = row["Primary Key Label"]
            index_name = row["Primary Key Label"] + "_idx"

    if pk_col_present:
        pk_query_args = {
            "table_name": row["Table Name"],
            "pk_name": pk_name,
            "index_name": index_name,
            "column_list": ", ".join(pk_column_list)
        }

        index = index_template.format(**pk_query_args)
        pk = pk_template.format(**pk_query_args)        
        
        query_args["index_statement"] = index
        query_args["pk_statement"] = pk

    else:
        query_args["index_statement"] = ""
        query_args["pk_statement"] = ""
        
    logging.info("Finished parsing primary key and index for table: %s", row["Table Name"])
    logging.debug("Query arguments after parsing primary key and index: %s", query_args)
        
    return query_args


def parse_all_query_args(table_name: str, table_rows: dict) -> dict:
    """
    Parses all query arguments for a table.

    Args:
        table_name (str): Name of the table.
        table_dict (dict): Dictionary representing the table.
        release_code (str): Release code.

    Returns:
        dict: Dictionary of all query arguments.
    """
       
    query_args = {"table_name": table_name, "parameter_table_name": table_name.upper()}
    query_args = parse_columns(table_rows, query_args)
    query_args = parse_comments(table_rows, query_args)
    query_args = parse_pk_and_index(table_rows, query_args)
    
    logging.info("Finished parsing all query arguments for table: %s", table_name)
    logging.debug("All query arguments: %s", query_args)
    
    return query_args


def main(label_report, release_code, debug=False):
    """
    Main function to process the Excel file and generate SQL files.
    The function takes input file, release code, SQL template file, and output directory as command line arguments.
    """
    
    # Get the absolute path of the script
    script_path = os.path.abspath(__file__)

    # Get the directory part of the script path
    script_dir = os.path.dirname(script_path)

    # Change the current working directory to the script directory
    os.chdir(script_dir)
    
    CURRENT_DIR = Path(os.getcwd()).resolve()
    MODEL_CONVERSION = {"META" : "INT_ZWA_META", "INT_ZWA_PO": "INT_ZWA_PO", "BDV_STG": "INT_ZWA_PO", "INT_ZWA_STG": "INT_ZWA_PO", "INT_ZWA": "INT_ZWA_PO", "OKV IMF": "OKV_IMF_PO", "OKV IMF REF": "OKV_IMF_PO", "Bedrijfszone ZW-Arbo": "BDR_ZWA_PO", "BDR_ZWA": "BDR_ZWA_PO", "OKV_REFERENTIE_DATA":"OKV_REFERENTIE_DATA", "OKV REFERENTIE DATA":"OKV_REFERENTIE_DATA"}
    
    # Create logging folder if not exists
    if not os.path.exists("./logs"):
        os.makedirs("./logs")
        
        # Get current datetime
    current_datetime = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_filename = "./logs/conversion_{}_{}.log".format(release_code, current_datetime)
    
    # Configure logging
    logging.basicConfig(level=logging.DEBUG if debug else logging.INFO,
                        format='%(asctime)s - %(levelname)s - %(message)s')
    
    # Create a file handler and set the log file name
    file_handler = logging.FileHandler(log_filename)
    file_handler.setLevel(logging.DEBUG if debug else logging.INFO)
    file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_formatter)

    # Create a stream handler to print logs to the terminal
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.DEBUG if debug else logging.INFO)
    stream_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    stream_handler.setFormatter(stream_formatter)

    # Get the root logger and add the handlers
    logger = logging.getLogger()
    
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    logging.info("SQL Converter started")
    
    if debug:
        logging.info("Logging system set up with INFO as base level.")
    else:
        logging.info("Logging system set up with DEBUG as base level.")


    # Convert the name label report file to a list of dictionaries
    #column_list = ["Name", "Label", "Documentation", "Data Type", "Persistent", "Nullable", "Default Value", "Source Entity", "Source Label", "Primary Key Name", "Primary Key Label", "Foreign Key name", "Foreign Key label"]
    column_list = ["Entity Name", "Entity Label", "Persistent", "Attribute Name", "Attribute Label", "Documentation", "Data Type", "Data Type Qualifier", "Required", "Default Value", "Package Name", "Package Label", "History", "LoadPattern", "Primary Key Name", "Primary Key Label"]
    list_of_dicts = xlsx_file_to_list_of_dict(label_report, column_list)
    list_of_dicts = clean_name_label_report(list_of_dicts, MODEL_CONVERSION)
    
    # Write results for DEBUG purposes:
    if debug:
        write_results_csv(list_of_dicts, "debug_export_{}".format(current_datetime))
    
    # Parse the data from the Excel file to one dictionary per table
    table_dict = one_dict_per_table(list_of_dicts)
    table_names = list(table_dict.keys())
    
    # Create folder called 'output' if not exists
    output_folder_base = get_git_root() + "/Database/"

    if not os.path.exists(output_folder_base):
        raise Exception("Output folder '{0}' does not exist".format(output_folder_base))

    # For each table, parse all query arguments and generate the SQL file
    for table_schema_name in table_names:
               
        # Parse table query
        schema_name = table_schema_name.split(".")[0]
        table_name = table_schema_name.split(".")[1]
        
        # Get only the rows specific for the table to parse
        table_rows = table_dict[table_schema_name]
        
        # If schema is _PO, then create two schema names to loop over
        if schema_name.endswith("_PO"):
            schema_names = [schema_name, schema_name.replace("_PO", "_PM")]
        else:
            schema_names = [schema_name]
                    
        # Fetch history flag and choose the right template
        history_flag = table_dict[table_schema_name][0]["History"]
        
        if history_flag is None:
            template_filename = "template_zonder_historie.sql"
        elif history_flag.upper() == "JA":
            template_filename = "template_zonder_historie.sql"
        else:
            template_filename = "template_zonder_historie.sql"
            
        # Parse all query args
        query_args = parse_all_query_args(table_name, table_rows)
        query = (CURRENT_DIR / template_filename).read_text().format(**query_args)
                
        # Write the table for one or both (_PO, _PM) schema names
        for schema_name in schema_names:
            
            output_folder = Path("{0}/{1}/tabellen/".format(output_folder_base, schema_name))
            
            # Check if the output directory exists, create it if not
            output_folder.mkdir(parents=True, exist_ok=True)
            output_file = output_folder / "{}.sql".format(table_name)
                            
            # Write the query to the output file
            with output_file.open("w") as f:
                f.write(query)
        
        logging.info("Finished writing SQL file for table: %s", table_name)
    
    # Finally, create manifest file for deployment        
    create_manifest_file(release_code)
       
    logging.info("Finished processing Excel file and generating SQL files.")

if __name__ == "__main__":
    
    # Initialize Tkinter
    root = tk.Tk()
    # Hide the main window
    root.withdraw()
    
    # Configure parser
    parser = argparse.ArgumentParser(description='Process xlsx file and generate SQL files.')
    parser.add_argument('--release_code', '-rc', help='release code', required=True)
    parser.add_argument('--label_report', '-lr', help='Input label report')
    parser.add_argument('--debug', action='store_true', help='Enable debug mode')
    args = parser.parse_args()
    
    # If no input file is provided in the command line argument, open a file dialog
    if args.label_report is None:
        args.label_report = filedialog.askopenfilename(title="Select datatype_report")
    
    main(args.label_report, args.release_code, args.debug)