Voordat je een release doet moeten de name_label reports, het datatype_report geexporteerd zijn, en de mapping converter gedraaid hebben.
Daarna:

- Maak een mapje aan voor de release code in de /output folder. We zijn begonnen met ZW_ARBO_001, dat wordt hierna ZW_ARBO_002 etc.

- Kopieer de _DS_JOBS_TEMPLATE.manifest vanuit git_root/Deployments/test/ naar de zojuist aangemaakte folder in /output
	-- LET OP @MICHIEL: op dit moment worden er nog geen regels 'automatisch' aangemaakt voor de views die jij hebt aangepast.
	-- er ligt dus nog een taak voor je om de juiste regels toe te voegen in de _DS_JOBS_TEMPLATE.manifest file. Als je die daar
	-- standaard onderaan zet, zullen de views ook standaard meegaan in een deployment. Waar de init_table hoort, dat zou je even
	-- met Sandra moeten bespreken. Ik denk dat die gewoon alleen thuishoort in de eerste deployment en even handmatig moet worden 
	-- toegevoegd daar voor de eerste echte deployment van ZW_ARBO_001

- Pas de table_input_view.xlsx aan. Kopieer de sheet van de voorgaande release (ZW_ARBO_001) en verander de naam naar ZW_ARBO_002. Als er
  in de release tabellen zijn toegevoegd moet je die nu ook nog even met de hand hier als een rij invoegen. Let op: Je hoeft alleen
  de _PO variant in te voegen, hij maakt automatisch ook een _PM variant aan. Daarnaast kan je dus door in de kolom 'manifest_file' true of
  false aan te passen aangeven of je een tabel wel/niet in deze release wilt meenemen. De kolom history_flag geeft aan welke van de 2 
  .sql template files worden gebruikt voor het aanmaken van de SQL file. Voor nu heb ik de HISTORY_FLAG alleen voor de staging (dat is immiers
  een vluchtige laag) uitgezet.

- Als bovenstaande is gedaan kan je de SQL converter gaan draaien. Check of alles goed gedraaid heeft door het manifest file en de folder
  output/ZW_ARBO_xxx/ te bekijken. 

- Kopieer de nieuwe manifest file naar de map Deployments/test/ in de git. Kopieer daarnaast de .sql files in output/ZW_ARBO_xxx/ naar het
  /Database/ mapje in de git. Voeg de mappen per schema samen.

- Als alles is gedaan en op zn plek staat kan je op je huidige branch pushen. 
- Maak daarna een pull request aan van je huidige branch naar 'main' branch in Azure Devops
- Voer de pull request uit en check even nogmaals of alles goed staat op 'main'

- Nu kan je inloggen op de T-omgeving en daar de stored procedure uitvoeren om de deployment te starten. Je kan de logs van de deployment
  vinden in de Linux server op <root>/w001/shared_hot/deployment/dim_opleveringen/ZW_ARBO_xxx
- Voor meer info rondom de stappen voor deployment check Michiel.
