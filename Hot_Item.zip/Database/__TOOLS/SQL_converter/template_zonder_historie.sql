--------------------------------------------------------
--  Verwijder tabel {table_name} als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('{parameter_table_name}')

--------------------------------------------------------
--  DDL for Table {table_name}
--------------------------------------------------------
create table {table_name}
(
  {columns}
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

{comments}
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

{index_statement}

--------------------------------------------------------
--  Constraints for Table {table_name}
--------------------------------------------------------

{pk_statement}