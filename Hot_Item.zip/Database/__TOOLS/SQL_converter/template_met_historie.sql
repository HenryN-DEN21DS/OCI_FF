--------------------------------------------------------
--  {table_name} (Table) maak backup
--------------------------------------------------------

exec tabel_hulp.hernoem_tabel ('{parameter_table_name}', '&1')

--------------------------------------------------------
--  DDL for Table {table_name}
--------------------------------------------------------
create table {table_name}
(
  {columns}
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

{comments}
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

{index_statement}

--------------------------------------------------------
--  Constraints for Table {table_name}
--------------------------------------------------------

{pk_statement}

--------------------------------------------------------
-- {table_name}  (Table) zet de gegevens van de backup terug
--------------------------------------------------------
exec tabel_hulp.vul_tabel ('{parameter_table_name}', '&1')