
--------------------------------------------------------
--  DDL for Table {table_name}
--------------------------------------------------------
create table int_zwa_meta.count_log
(
	schema_ 			nvarchar2(50), 
	table_name 			nvarchar2(50), 
	count_value 		number(10,0), 
	log_timestamp 		timestamp (3), 
	formatted_date_time varchar2(19 byte)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/