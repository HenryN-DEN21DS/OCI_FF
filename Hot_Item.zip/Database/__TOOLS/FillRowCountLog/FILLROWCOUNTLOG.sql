create or replace PROCEDURE FillRowCountLog IS
    vRowCount    NUMBER;
    vSQL         VARCHAR2(1000);
    vSchemaName  VARCHAR2(255);
    vTableName   VARCHAR2(255);
BEGIN
    FOR r_schema IN (SELECT DISTINCT owner AS SchemaName
                     FROM all_tables
                     WHERE owner IN ('INT_ZWA_META', 'INT_ZWA_PO', 'INT_ZWA_PM', 'BDR_ZWA_PO', 'BDR_ZWA_PM')) LOOP

        vSchemaName := r_schema.SchemaName;

        FOR r_table IN (SELECT table_name AS TableName
                        FROM all_tables
                        WHERE owner = vSchemaName) LOOP

            vTableName := r_table.TableName;
            vSQL := 'SELECT COUNT(*) FROM ' || vSchemaName || '.' || vTableName || '';

            EXECUTE IMMEDIATE vSQL INTO vRowCount;

            BEGIN
                -- Attempt to update the row
                UPDATE INT_ZWA_META.COUNT_LOG
                SET COUNT_VALUE = vRowCount,
                    LOG_TIMESTAMP = SYSTIMESTAMP,
                    FORMATTED_DATE_TIME = TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS')
                WHERE SCHEMA_ = vSchemaName AND TABLE_NAME = vTableName
                AND COUNT_VALUE <> vRowCount;

                -- If no rows were updated, insert a new row
                IF SQL%ROWCOUNT = 0 THEN
                    INSERT INTO INT_ZWA_META.COUNT_LOG (SCHEMA_, TABLE_NAME, COUNT_VALUE, LOG_TIMESTAMP, FORMATTED_DATE_TIME)
                    VALUES (vSchemaName, vTableName, vRowCount, SYSTIMESTAMP, TO_CHAR(SYSTIMESTAMP, 'YYYY-MM-DD HH24:MI:SS'));
                END IF;
            EXCEPTION WHEN NO_DATA_FOUND THEN
                dbms_output.put_line(vSQL); -- Handle exception if needed
            END;
        END LOOP;
        commit;
    END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        dbms_output.put_line(vSQL);
        RAISE; -- Re-raise the exception
END FillRowCountLog;