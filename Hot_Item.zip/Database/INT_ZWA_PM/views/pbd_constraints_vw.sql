
--------------------------------------------------------
---  ddl for view pbd_constraints_vw
--------------------------------------------------------

create or replace force view pbd_constraints_vw as 
  with constr as (
    select 
		  uc.constraint_name 											as constraint_naam
		, ucc1.table_name 												as child_tabel
		, ucc1.column_name 												as child_kolom
		, ucc2.table_name 												as parent_tabel
		, ucc2.column_name 												as parent_kolom
        , uc.status
	from user_constraints uc , user_cons_columns ucc1 ,  user_cons_columns ucc2
	where uc.constraint_name = ucc1.constraint_name
	and uc.r_constraint_name = ucc2.constraint_name
	and ucc1.position        = ucc2.position -- correction for multiple column primary keys.
	and uc.constraint_type   = 'R'
	order by ucc1.table_name , uc.constraint_name
	)
    
    select dis.parent_tabel as parent_tabel_disable, en.parent_tabel as parent_tabel_enable, dis.disable, en.enable
    from
	
    (select
		  constr.parent_tabel
        , constr.constraint_naam
		, 'alter table ' || constr.child_tabel || ' disable constraint ' || constr.constraint_naam || ';' 
																		as disable
    from constr
    where constr.status = 'ENABLED') dis
    
    full outer join
    
    (select
		  constr.parent_tabel
        , constr.constraint_naam
		, 'alter table ' || constr.child_tabel || ' enable constraint ' || constr.constraint_naam || ';' 
																		as enable
	from constr
    where constr.status = 'DISABLED') en
    
    on (dis.constraint_naam  = en.constraint_naam)
    ;
