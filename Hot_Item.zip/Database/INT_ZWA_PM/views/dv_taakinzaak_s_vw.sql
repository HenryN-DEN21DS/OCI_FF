create or replace force view dv_taakinzaak_s_vw as 

with cte as (select sat_tabel.dim_taakinzaak_l_hk
, sat_tabel.dim_aanmaak_datum
, sat_tabel.datum_boeking_activiteit
, sat_tabel.code_aanleiding_activiteit
, sat_tabel.aanleiding_activiteit
, sat_tabel.datum_activiteit_plan
, sat_tabel.datum_activiteit_realisatie
, sat_tabel.datum_oproep
, sat_tabel.code_aanwezigheid_persoon
, sat_tabel.aanwezigheid_persoon
, sat_tabel.code_functie_medewerker
, sat_tabel.functie_medewerker
, sat_tabel.naam_medewerker
, sat_tabel.code_status_activiteit
, sat_tabel.status_activiteit
, sat_tabel.code_conclusie_activiteit
, sat_tabel.conclusie_activiteit
, sat_tabel.dim_hashdiff
, sat_tabel.dim_is_verwijderd
, sat_tabel.dim_bron, lead(sat_tabel.dim_aanmaak_datum) over (partition by sat_tabel.dim_taakinzaak_l_hk order by sat_tabel.dim_aanmaak_datum) - interval '0.000001' second as dim_eind_datum 
from dv_taakinzaak_s sat_tabel)

select dim_taakinzaak_l_hk
, dim_aanmaak_datum
, datum_boeking_activiteit
, code_aanleiding_activiteit
, aanleiding_activiteit
, datum_activiteit_plan
, datum_activiteit_realisatie
, datum_oproep
, code_aanwezigheid_persoon
, aanwezigheid_persoon
, code_functie_medewerker
, functie_medewerker
, naam_medewerker
, code_status_activiteit
, status_activiteit
, code_conclusie_activiteit
, conclusie_activiteit
, dim_hashdiff
, dim_is_verwijderd
, dim_bron, cast(nvl(dim_eind_datum, timestamp'8888-12-31 00:00:00') as timestamp) as dim_eind_datum, case  when dim_eind_datum is null   then 1  else 0 end as dim_is_geldig  
	from cte where cte.dim_is_verwijderd = 0;