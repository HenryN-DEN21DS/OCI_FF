create or replace force view dv_zaak_s_vw as 

with cte as (select sat_tabel.dim_zaak_h_hk
, sat_tabel.dim_aanmaak_datum
, sat_tabel.uzs_aanvraagid
, sat_tabel.uzs_gevalsvolgnr
, sat_tabel.datum_ontvangst_ao_melding
, sat_tabel.datum_boeking_ao
, sat_tabel.eerste_of_tweede_lijn
, sat_tabel.datum_overdracht_ck
, sat_tabel.datum_ziekmeld_door_verzekerde
, sat_tabel.eerste_contactmoment
, sat_tabel.datum_plausibel
, sat_tabel.indicatie_plausibel
, sat_tabel.maximum_datum_ziektewet
, sat_tabel.dat_uda_ezwb
, sat_tabel.dat_nuda_ezwb
, sat_tabel.datum_ontvangst_hersteldmelding
, sat_tabel.datum_boeking_hersteldmelding
, sat_tabel.einddatum_ao
, sat_tabel.code_vangnetcategorie_imf
, sat_tabel.vangnetcategorie_imf
, sat_tabel.code_vangnetcategorie_bb
, sat_tabel.vangnetcategorie_bb
, sat_tabel.code_vangnetcategorie_szw
, sat_tabel.vangnetcategorie_szw
, sat_tabel.code_ag_traject
, sat_tabel.ag_traject
, sat_tabel.code_bron_hersteldmelding
, sat_tabel.bron_hersteldmelding
, sat_tabel.code_uitstroomoorzaak
, sat_tabel.uitstroomoorzaak
, sat_tabel.code_reden_einde_recht
, sat_tabel.reden_einde_recht
, sat_tabel.ind_eigenrisicodrager
, sat_tabel.ind_slapend
, sat_tabel.ind_gdbm
, sat_tabel.dim_hashdiff
, sat_tabel.dim_is_verwijderd
, sat_tabel.dim_bron, lead(sat_tabel.dim_aanmaak_datum) over (partition by sat_tabel.dim_zaak_h_hk order by sat_tabel.dim_aanmaak_datum) - interval '0.000001' second as dim_eind_datum 
from dv_zaak_s sat_tabel)

select dim_zaak_h_hk
, dim_aanmaak_datum
, uzs_aanvraagid
, uzs_gevalsvolgnr
, datum_ontvangst_ao_melding
, datum_boeking_ao
, eerste_of_tweede_lijn
, datum_overdracht_ck
, datum_ziekmeld_door_verzekerde
, eerste_contactmoment
, datum_plausibel
, indicatie_plausibel
, maximum_datum_ziektewet
, dat_uda_ezwb
, dat_nuda_ezwb
, datum_ontvangst_hersteldmelding
, datum_boeking_hersteldmelding
, einddatum_ao
, code_vangnetcategorie_imf
, vangnetcategorie_imf
, code_vangnetcategorie_bb
, vangnetcategorie_bb
, code_vangnetcategorie_szw
, vangnetcategorie_szw
, code_ag_traject
, ag_traject
, code_bron_hersteldmelding
, bron_hersteldmelding
, code_uitstroomoorzaak
, uitstroomoorzaak
, code_reden_einde_recht
, reden_einde_recht
, ind_eigenrisicodrager
, ind_slapend
, ind_gdbm
, dim_hashdiff
, dim_is_verwijderd
, dim_bron, cast(nvl(dim_eind_datum, timestamp'8888-12-31 00:00:00') as timestamp) as dim_eind_datum, case  when dim_eind_datum is null   then 1  else 0 end as dim_is_geldig  
	from cte where cte.dim_is_verwijderd = 0;