
--------------------------------------------------------
---  ddl for view zaak_uzs_vw
--------------------------------------------------------

create or replace force view zaak_uzs_vw as 
with uzs as
(select --distinct -- moet anders worden (nieuwste signaal)
  cast(a.afg_sofinummer as varchar2(99)) as bsn
, afg_werkgevernummer
, afg_bv_nr
, cast(substr(afg_bv_nr, -3) || substr(afg_werkgevernummer, 4) as varchar2(99)) aansluitingsnr
, srt_verzekering
, cast(decode(srt_verzekering
        , 'WW', '20'
        , 'UZK', '00'
        , 'VVZ', '10'
        , 'DVB', '00'
        , 'OPK', '00'
        , 'ART', '00'
        , 'STG', '00'
        , 'DPL', '00'
        , 'GWB', '00'
        , 'MOW', '00'
        , 'OBD', '00'
        , 'ZEZ', '**' -- deze horen we niet tegen te komen, moeten weggefilterd worden
        , '**'        -- er horen geen andere categorieen te zijn dan de opgesomde. Mocht dat optreden dan zijn de sterretjes een signaal.
        ) as varchar2(9)) as contractcode
, cast(lpad('0', 5) as varchar2(9)) as buitenlandse_instellingsnr
, cast(null as timestamp(6)) as datum_boeking_dienstverband
, cast(dtm_eerste_ziektedag as timestamp(6)) as begindatum_ao
, cast(aan_id as number(38,10)) as uzs_aanvraagid
, cast(volgnummer_aanvraag as number(38,10)) as uzs_gevalsvolgnr
, cast(dtm_ontvangst as timestamp(6)) as datum_ontvangst_ao_melding
, cast(dtd_opgevoerd_aanvraag as timestamp(6)) as datum_boeking_ao
, cast('1e lijn' as varchar2(99)) as eerste_of_tweede_lijn
, cast(null as timestamp(6)) as datum_overdracht_ck
, cast(dtm_ontvangst_zm_wn as timestamp(6)) as datum_ziekmeld_door_verzekerde
, cast(null as timestamp(6)) as eerste_contactmoment
, cast(null as timestamp(6)) as datum_plausibel
, cast(null as varchar2(9)) as indicatie_plausibel
, cast(null as timestamp(6)) as maximum_datum_ziektewet
, cast(null as timestamp(6)) as dat_uda_ezwb
, cast(null as timestamp(6)) as dat_nuda_ezwb
, cast(null as timestamp(6)) as datum_ontvangst_hersteldmelding
, cast(dtd_registratie_hersteld as timestamp(6)) as datum_boeking_hersteldmelding
, cast(dtm_hersteld as timestamp(6)) as einddatum_ao
, cast(a.afg_ref_vangnet_bb as varchar2(99)) as code_vangnetcategorie_bb
, cast(bb.vangnet_bb_omschrijving as varchar2(99)) as vangnetcategorie_bb
, cast(a.afg_ref_vangnet_szw as varchar2(99)) as code_vangnetcategorie_szw
, cast(szw.vangnet_szw_omschrijving as varchar2(99)) as vangnetcategorie_szw
, cast(null as varchar2(99)) as code_vangnetcategorie_imf
, cast(null as varchar2(99)) as vangnetcategorie_imf
, cast(null as varchar2(99)) as code_ag_traject
, cast(null as varchar2(99)) as ag_traject
, cast(null as varchar2(99)) as code_bron_hersteldmelding
, cast(null as varchar2(99)) as bron_hersteldmelding
, cast(null as varchar2(99)) as code_uitstroomoorzaak
, cast(null as varchar2(99)) as uitstroomoorzaak
, cast(a.reden_einde_recht as varchar2(99)) as cd_reden_einde_recht
, cast(null as varchar(99)) as reden_einde_recht
, cast(null as varchar2(9)) as ind_eigenrisicodrager
, cast(null as varchar2(9)) as ind_slapend
, cast(null as varchar2(9)) as ind_gdbm
, cast(coalesce(a.dtm_hersteld, a.dtm_eerste_ziektedag) as timestamp(6)) as dim_ingangsdatum_bwt
, cast(null as varchar2(9)) as teamnummer
, cast(null as varchar2(9)) as districtskantoor_nr
, cast(null as varchar2(9)) as dim_dummy
, cast(null as varchar2(9)) as status_persoon
, cast(p.dtm_geboorte as timestamp) geboortedatum
, cast(substr(p.afg_postcode_domicilie, 1, 4) as varchar2(99)) domicilie_postcode_gebied
, cast(p.afg_postcode_domicilie as varchar(99)) domicilie_postcode
, cast(substr(p.afg_postcode_verpleegadres, 1, 4) as varchar(99)) verpleeg_adres_postcode_gebied
, cast(p.afg_postcode_verpleegadres as varchar(99)) verpleeg_adres_postcode
, cast(null as varchar2(9)) as verpleeg_adres_land_nr
, cast(null as varchar2(99)) verpleeg_adres_land
, cast(null as varchar2(9)) as verpleeg_instelling_code
, cast(null as varchar2(99)) as verpleeg_instelling
, a.volgnummer_hersteldmelding
, a.dtd_opgevoerd_aanvraag -- tbv bepaling nieuwste situatie
from int_zw_po.int_urs_zw_3_ht a
left join okv_referentie_data.ref_zw_vangnet_bb_tb bb on bb.ref_zw_vangnet_bb_id = a.afg_ref_vangnet_bb
left join okv_referentie_data.ref_zw_vangnet_szw_tb szw on szw.ref_zw_vangnet_szw_id = a.afg_ref_vangnet_szw
left join int_zw_po.int_personen_adressen_zw_3_ht p on p.afg_sofinummer = a.afg_sofinummer and p.afg_dim_eind_datum = to_date('31-12-9999', 'dd-mm-yyyy')
where srt_verzekering <> 'ZEZ' -- uit specs: per 1 juli 2019 gaat UZS de ZEZ-WAZO gevallen aan IMF leveren. IMF negeert deze gevallen, ze worden niet in de IMF-db opgenomen.
and a.afg_sofinummer is NOT null -- er blijken gevallen te bestaan zonder bsn. Maar dan kan het geen zaak zijn
and a.dtm_eerste_ziektedag is not null -- het moet wel over ziektegevallen gaan
and a.dtm_hersteld >= a.dtm_eerste_ziektedag -- als het herstel voor het moment van ziekworden valt, is dat een manier om de case 'weg te gooien'
and a.afg_dim_eind_datum = to_date('31-12-9999', 'dd-mm-yyyy') -- actuele versie van een aanvraag
and upper(a.reden_einde_recht) <> 'ADM' 
and afg_ind_administratieve_splitsing <> 1
and afg_ind_dubbele_melding <> 1
),
uzs_situaties as
(
select a.*,
row_number() over (partition by bsn, aansluitingsnr, contractcode, buitenlandse_instellingsnr, datum_boeking_dienstverband, begindatum_ao
                   order by dtd_opgevoerd_aanvraag desc, uzs_aanvraagid desc, uzs_gevalsvolgnr desc, volgnummer_hersteldmelding desc) as situatienr
from uzs a
)
select a.* 
from uzs_situaties a
where situatienr = 1
;


