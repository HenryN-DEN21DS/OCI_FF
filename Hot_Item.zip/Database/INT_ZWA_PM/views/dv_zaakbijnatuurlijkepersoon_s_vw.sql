create or replace force view dv_zaakbijnatuurlijkepersoon_s_vw as 

with cte as (select sat_tabel.dim_zaakbijnatuurlijkpers_l_hk
, sat_tabel.dim_aanmaak_datum
, sat_tabel.dim_hashdiff
, sat_tabel.dim_is_verwijderd
, sat_tabel.dim_bron, lead(sat_tabel.dim_aanmaak_datum) over (partition by sat_tabel.dim_zaakbijnatuurlijkpers_l_hk order by sat_tabel.dim_aanmaak_datum) - interval '0.000001' second as dim_eind_datum 
from dv_zaakbijnatuurlijkepersoon_s sat_tabel)

select dim_zaakbijnatuurlijkpers_l_hk
, dim_aanmaak_datum
, dim_hashdiff
, dim_is_verwijderd
, dim_bron, cast(nvl(dim_eind_datum, timestamp'8888-12-31 00:00:00') as timestamp) as dim_eind_datum, case  when dim_eind_datum is null   then 1  else 0 end as dim_is_geldig  
	from cte where cte.dim_is_verwijderd = 0;