
--------------------------------------------------------
---  ddl for view prestg_dv_zaak_vw
--------------------------------------------------------

create or replace force view prestg_dv_zaak_vw as 
select 
  case when imf.bsn is not null then imf.bsn else uzs.bsn end as bsn
, case when imf.bsn is not null then imf.aansluitingsnr else uzs.aansluitingsnr end as aansluitingsnr
, case when imf.bsn is not null then imf.contractcode else uzs.contractcode end as contractcode
, case when imf.bsn is not null then imf.buitenlandse_instellingsnr else uzs.buitenlandse_instellingsnr end as buitenlandse_instellingsnr
, case when imf.bsn is not null then imf.datum_boeking_dienstverband else uzs.datum_boeking_dienstverband end as datum_boeking_dienstverband
, case when imf.bsn is not null then imf.begindatum_ao else uzs.begindatum_ao end as begindatum_ao
, case when imf.bsn is not null then coalesce(imf.uzs_aanvraagid, uzs.uzs_aanvraagid) else uzs.uzs_aanvraagid end                   as uzs_aanvraagid -- uitzondering mappingrule
, case when imf.bsn is not null then coalesce(imf.uzs_gevalsvolgnr, uzs.uzs_gevalsvolgnr) else uzs.uzs_gevalsvolgnr end             as uzs_gevalsvolgnr -- uitzondering mappingrule
, case when imf.bsn is not null then imf.datum_ontvangst_ao_melding else uzs.datum_ontvangst_ao_melding end as datum_ontvangst_ao_melding
, case when imf.bsn is not null then imf.datum_boeking_ao else uzs.datum_boeking_ao end as datum_boeking_ao
, case when imf.bsn is not null then imf.eerste_of_tweede_lijn else uzs.eerste_of_tweede_lijn end as eerste_of_tweede_lijn
, case when imf.bsn is not null then imf.datum_overdracht_ck else uzs.datum_overdracht_ck end as datum_overdracht_ck
, case when imf.bsn is not null then imf.datum_ziekmeld_door_verzekerde else uzs.datum_ziekmeld_door_verzekerde end as datum_ziekmeld_door_verzekerde
, case when imf.bsn is not null then imf.eerste_contactmoment else uzs.eerste_contactmoment end as eerste_contactmoment
, case when imf.bsn is not null then imf.datum_plausibel else uzs.datum_plausibel end as datum_plausibel
, case when imf.bsn is not null then imf.indicatie_plausibel else uzs.indicatie_plausibel end as indicatie_plausibel
, case when imf.bsn is not null then imf.maximum_datum_ziektewet else uzs.maximum_datum_ziektewet end as maximum_datum_ziektewet
, case when imf.bsn is not null then imf.dat_uda_ezwb else uzs.dat_uda_ezwb end as dat_uda_ezwb
, case when imf.bsn is not null then imf.dat_nuda_ezwb else uzs.dat_nuda_ezwb end as dat_nuda_ezwb
, case when imf.bsn is not null then imf.datum_ontvangst_hersteldmelding else uzs.datum_ontvangst_hersteldmelding end as datum_ontvangst_hersteldmelding
, case when imf.bsn is not null then imf.datum_boeking_hersteldmelding else uzs.datum_boeking_hersteldmelding end as datum_boeking_hersteldmelding
, case when imf.bsn is not null then imf.einddatum_ao else uzs.einddatum_ao end as einddatum_ao
, uzs.code_vangnetcategorie_bb                                                                                                      as code_vangnetcategorie_bb  -- uitzondering mappingrule
, uzs.vangnetcategorie_bb                                                                                                           as vangnetcategorie_bb -- uitzondering mappingrule
, uzs.code_vangnetcategorie_szw                                                                                                     as code_vangnetcategorie_szw -- uitzondering mappingrule
, uzs.vangnetcategorie_szw                                                                                                          as vangnetcategorie_szw -- uitzondering mappingrule
, imf.code_vangnetcategorie_imf                                                                                                     as code_vangnetcategorie_imf -- uitzondering mappingrule
, imf.vangnetcategorie_imf                                                                                                          as vangnetcategorie_imf -- uitzondering mappingrule
, case when imf.bsn is not null then imf.code_ag_traject else uzs.code_ag_traject end as code_ag_traject
, case when imf.bsn is not null then imf.ag_traject else uzs.ag_traject end as ag_traject
, case when imf.bsn is not null then imf.code_bron_hersteldmelding else uzs.code_bron_hersteldmelding end as code_bron_hersteldmelding
, case when imf.bsn is not null then imf.bron_hersteldmelding else uzs.bron_hersteldmelding end as bron_hersteldmelding
, case when imf.bsn is not null then imf.code_uitstroomoorzaak else uzs.code_uitstroomoorzaak end as code_uitstroomoorzaak
, case when imf.bsn is not null then imf.uitstroomoorzaak else uzs.uitstroomoorzaak end as uitstroomoorzaak
, uzs.cd_reden_einde_recht                                                                                                          as code_reden_einde_recht -- uitzondering mappingrule
, uzs.reden_einde_recht                                                                                                             as reden_einde_recht -- uitzondering mappingrule
, case when imf.bsn is not null then imf.ind_eigenrisicodrager else uzs.ind_eigenrisicodrager end as ind_eigenrisicodrager
, case when imf.bsn is not null then imf.ind_slapend else uzs.ind_slapend end as ind_slapend
, case when imf.bsn is not null then imf.ind_gdbm else uzs.ind_gdbm end as ind_gdbm
, case when imf.bsn is not null then imf.dim_ingangsdatum_bwt else uzs.dim_ingangsdatum_bwt end as dim_ingangsdatum_bwt
, case when imf.bsn is not null then imf.teamnummer else uzs.teamnummer end as teamnummer
, case when imf.bsn is not null then imf.districtskantoor_nr else uzs.districtskantoor_nr end as districtskantoor_nr
, case when imf.bsn is not null then imf.dim_dummy else uzs.dim_dummy end as dim_dummy
, case when imf.bsn is not null and uzs.bsn is not null then 'IMF-UZS' when imf.bsn is not null and uzs.bsn is null then 'IMF' else 'UZS' end as herkomst
from zaak_imf_vw imf
full join zaak_uzs_vw uzs on 
            imf.bsn = uzs.bsn
            and 
            coalesce(imf.aansluitingsnr, '#*@') = coalesce(uzs.aansluitingsnr, '#*@')
            and
            imf.contractcode = uzs.contractcode
            and
            coalesce(imf.datum_boeking_dienstverband, to_date('31-12-9999','dd-mm-yyyy')) = coalesce(uzs.datum_boeking_dienstverband, to_date('31-12-9999','dd-mm-yyyy'))
            and 
            imf.buitenlandse_instellingsnr = uzs.buitenlandse_instellingsnr
            and 
            imf.begindatum_ao = uzs.begindatum_ao;