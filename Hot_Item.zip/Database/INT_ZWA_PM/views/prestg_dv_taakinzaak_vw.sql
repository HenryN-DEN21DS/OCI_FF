
--------------------------------------------------------
---  ddl for view prestg_dv_taakinzaak_vw
--------------------------------------------------------

create or replace force view prestg_dv_taakinzaak_vw 							as 
WITH cte as(  
		select 
			  act.afg_bsn     											as bsn 
			, act.afg_nr_aansl_bv 										as aansluitingsnr  
			, act.cd_contract 										    as contractcode 
			, act.nr_buitenl_inst   						            as buitenlandse_instellingsnr
			, cast(null as timestamp)  						            as datum_boeking_dienstverband
			, act.bdat_ao										        as begindatum_ao
			, act.cd_srt_akt 											as activiteitcode 
			, srt.omschrijving 											as activiteit_omschrijving
			, act.dat_ini_boeking_akt							        
			, act.tijd_ini_boeking_akt							        
			, act.dat_boeking_akt 										as datum_boeking_activiteit 
			, act.cd_aanl_akt 											as code_aanleiding_activiteit
			, aan.omschrijving 											as aanleiding_activiteit
			, act.dat_plan_akt 											as datum_activiteit_plan
			, act.dat_real_akt 											as datum_activiteit_realisatie
			, act.datum_oproep							                
			, act.tijd_oproep							                
			, act.cd_aanw_pers 											as code_aanwezigheid_persoon
			, pers.omschrijving 										as aanwezigheid_persoon
			, act.functie_medew 										as code_functie_medewerker
			, fct.omschrijving 											as functie_medewerker
            , act.naam_medew                                            as naam_medewerker
			, act.st_akt 												as code_status_activiteit
			, st.omschrijving 											as status_activiteit
			, act.cd_concl_akt 											as code_conclusie_activiteit
			, con.omschrijving 											as conclusie_activiteit
            , act.teamnummer                                            as teamnummer
            , act.nr_dk                                                 as districtskantoor_nr
        from okv_imf_pm.okv_ao_akt_hv act
        join int_zwa_pm.prestg_dv_zaak_vw ao                            -- alleen activiteiten die daadwerkelijk bij een ao geval horen.
            on  ao.bsn = act.afg_bsn
            and coalesce(ao.aansluitingsnr, 'ABCDEF') = coalesce(act.afg_nr_aansl_bv, 'ABCDEF')
            and ao.contractcode = act.cd_contract
            and ao.buitenlandse_instellingsnr = act.nr_buitenl_inst
            and ao.begindatum_ao = act.bdat_ao
		left join okv_imf_pm.ref_imf_ao_akt_cd_srt_akt_hv srt 
			on act.cd_srt_akt = srt.cd_srt_akt
		left join okv_imf_pm.ref_imf_ao_akt_cd_aanl_akt_hv aan 
			on act.cd_aanl_akt = aan.cd_aanl_akt
		left join okv_imf_pm.ref_imf_ao_akt_cd_aanw_pers_hv pers 
			on act.cd_aanw_pers = pers.cd_aanw_pers
		left join okv_imf_pm.ref_imf_ao_akt_functie_medew_hv fct 
			on act.functie_medew = fct.functie_medew
		left join okv_imf_pm.ref_imf_ao_akt_st_akt_hv st 
			on act.st_akt = st.st_akt
		left join okv_imf_pm.ref_imf_ao_akt_cd_concl_akt_hv con 
			on act.cd_concl_akt = con.cd_concl_akt
		left join okv_imf_pm.ref_imf_ao_akt_nr_dk_hv dk 
			on dk.nr_dk = act.nr_dk
		where act.dim_recent_ind = 'J' 
		)

	select
		  cast(cte.bsn as varchar2(99))                                 as bsn
		, cast(cte.aansluitingsnr as varchar2(99))                      as aansluitingsnr
		, cast(cte.contractcode as varchar2(9))                         as contractcode
		, cast(cte.buitenlandse_instellingsnr as varchar2(9))           as buitenlandse_instellingsnr
		, cast(cte.datum_boeking_dienstverband as timestamp)            as datum_boeking_dienstverband
		, cast(cte.begindatum_ao as timestamp)                          as begindatum_ao
		, cast(cte.activiteitcode as varchar2(9))                       as activiteitcode
		, cast(cte.activiteit_omschrijving as varchar2(99))             as activiteit_omschrijving
		, cast(cte.dat_ini_boeking_akt + (floor(cte.tijd_ini_boeking_akt/100)/24 + mod(cte.tijd_ini_boeking_akt,100)/(24*60)) 
																		as timestamp) 
																		as datum_initiele_boeking_act
		, cast(cte.datum_boeking_activiteit as timestamp)               as datum_boeking_activiteit
		, cast(cte.code_aanleiding_activiteit as varchar2(9))           as code_aanleiding_activiteit
		, cast(cte.aanleiding_activiteit as varchar2(99))               as aanleiding_activiteit
		, cast(cte.datum_activiteit_plan as timestamp)                  as datum_activiteit_plan
		, cast(cte.datum_activiteit_realisatie as timestamp)            as datum_activiteit_realisatie
		, cast(cte.datum_oproep + (floor(cte.tijd_oproep/100)/24 + mod(cte.tijd_oproep,100)/(24*60)) 
																		as timestamp) 
																		as datum_oproep
		, cast(cte.code_aanwezigheid_persoon as varchar2(9))            as code_aanwezigheid_persoon
		, cast(cte.aanwezigheid_persoon as varchar2(99))                as aanwezigheid_persoon
		, cast(cte.code_functie_medewerker as varchar2(9))              as code_functie_medewerker
		, cast(cte.functie_medewerker as varchar2(99))                  as functie_medewerker
        , cast(cte.naam_medewerker as varchar2(99))                     as naam_medewerker
		, cast(cte.code_status_activiteit as varchar2(9))               as code_status_activiteit
		, cast(cte.status_activiteit as varchar2(99))                   as status_activiteit
		, cast(cte.code_conclusie_activiteit as varchar2(9))            as code_conclusie_activiteit
		, cast(cte.conclusie_activiteit as varchar2(99))                as conclusie_activiteit
        , cast(cte.teamnummer as varchar2(9))                           as teamnummer
		, cast(cte.districtskantoor_nr as varchar2(99))                 as districtskantoor_nr
		, cast (null as timestamp(6))                                   as dim_ingangsdatum_bwt
        , cast('x' as varchar2(9))                                      as dim_dummy
		from cte;