--------------------------------------------------------
--  Verwijder tabel stg_dv_team als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('STG_DV_TEAM')

--------------------------------------------------------
--  DDL for Table stg_dv_team
--------------------------------------------------------
create table stg_dv_team
(
  	dim_team_h_hk                 	varchar2(99 char) not null,
	dim_hashdiff_team             	varchar2(99 char) not null,
	dim_hashdiff_team_bwt         	varchar2(99 char) not null,
	dim_ingangsdatum_bwt          	timestamp,
	districtskantoor_naam         	varchar2(99 char),
	districtskantoor_nr           	number,
	districtskantoor_sorteervolgnr	number,
	regio_naam                    	varchar2(99 char),
	regio_nr                      	number,
	regio_sorteervolgnr           	number,
	teamnaam                      	varchar2(99 char),
	teamnummer                    	varchar2(9 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column stg_dv_team.teamnaam is 'Blijft nu bewust even leeg'
/
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table stg_dv_team
--------------------------------------------------------

