--------------------------------------------------------
--  Verwijder tabel stg_dv_taakinzaak als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('STG_DV_TAAKINZAAK')

--------------------------------------------------------
--  DDL for Table stg_dv_taakinzaak
--------------------------------------------------------
create table stg_dv_taakinzaak
(
  	dim_taak_h_hk              	varchar2(99 char) not null,
	dim_taakinzaak_l_hk        	varchar2(99 char) not null,
	dim_team_h_hk              	varchar2(99 char) not null,
	dim_zaak_h_hk              	varchar2(99 char) not null,
	dim_hashdiff_taak          	varchar2(99 char) not null,
	dim_hashdiff_taakinzaak    	varchar2(99 char) not null,
	dim_ingangsdatum_bwt       	timestamp,
	aanleiding_activiteit      	varchar2(99 char),
	aansluitingsnr             	varchar2(99 char),
	aanwezigheid_persoon       	varchar2(99 char),
	activiteit_omschrijving    	varchar2(999 char),
	activiteitcode             	varchar2(9 char),
	begindatum_ao              	timestamp,
	bsn                        	varchar2(99 char),
	buitenlandse_instellingsnr 	varchar2(9 char),
	code_aanleiding_activiteit 	varchar2(99 char),
	code_aanwezigheid_persoon  	varchar2(99 char),
	code_conclusie_activiteit  	varchar2(99 char),
	code_functie_medewerker    	varchar2(99 char),
	code_status_activiteit     	varchar2(99 char),
	conclusie_activiteit       	varchar2(999 char),
	contractcode               	varchar2(9 char),
	datum_activiteit_plan      	timestamp,
	datum_activiteit_realisatie	timestamp,
	datum_boeking_activiteit   	timestamp,
	datum_boeking_dienstverband	timestamp,
	datum_initiele_boeking_act 	timestamp not null,
	datum_oproep               	timestamp,
	districtskantoor_nr        	number,
	functie_medewerker         	varchar2(99 char),
	naam_medewerker            	varchar2(99 char),
	status_activiteit          	varchar2(99 char),
	teamnummer                 	varchar2(9 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table stg_dv_taakinzaak
--------------------------------------------------------

