--------------------------------------------------------
--  Verwijder tabel dv_zaak_s_bwt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_ZAAK_S_BWT')

--------------------------------------------------------
--  DDL for Table dv_zaak_s_bwt
--------------------------------------------------------
create table dv_zaak_s_bwt
(
  	dim_zaak_h_hk       	varchar2(99 char) not null,
	dim_aanmaak_datum   	timestamp not null,
	dim_bron            	varchar2(99 char),
	dim_hashdiff        	varchar2(99 char) not null,
	dim_ingangsdatum_bwt	timestamp,
	dim_is_verwijderd   	number default on null 0 not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index zaak_s_bwt_pk_idx on dv_zaak_s_bwt (dim_aanmaak_datum, dim_zaak_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_zaak_s_bwt
--------------------------------------------------------

alter table dv_zaak_s_bwt add constraint zaak_s_bwt_pk primary key (dim_aanmaak_datum, dim_zaak_h_hk) using index zaak_s_bwt_pk_idx enable
/