--------------------------------------------------------
--  Verwijder tabel dv_team_s_bwt als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_TEAM_S_BWT')

--------------------------------------------------------
--  DDL for Table dv_team_s_bwt
--------------------------------------------------------
create table dv_team_s_bwt
(
  	dim_team_h_hk       	varchar2(99 char) not null,
	dim_aanmaak_datum   	timestamp not null,
	dim_bron            	varchar2(99 char),
	dim_hashdiff        	varchar2(99 char) not null,
	dim_ingangsdatum_bwt	timestamp,
	dim_is_verwijderd   	number default on null 0 not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index team_s_bwt_pk_idx on dv_team_s_bwt (dim_aanmaak_datum, dim_team_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_team_s_bwt
--------------------------------------------------------

alter table dv_team_s_bwt add constraint team_s_bwt_pk primary key (dim_aanmaak_datum, dim_team_h_hk) using index team_s_bwt_pk_idx enable
/