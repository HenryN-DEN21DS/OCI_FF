--------------------------------------------------------
--  Verwijder tabel dv_team_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_TEAM_S')

--------------------------------------------------------
--  DDL for Table dv_team_s
--------------------------------------------------------
create table dv_team_s
(
  	dim_team_h_hk                 	varchar2(99 char) not null,
	dim_aanmaak_datum             	timestamp not null,
	dim_bron                      	varchar2(99 char),
	dim_hashdiff                  	varchar2(99 char) not null,
	dim_is_verwijderd             	number default on null 0 not null,
	districtskantoor_naam         	varchar2(99 char),
	districtskantoor_sorteervolgnr	number,
	regio_naam                    	varchar2(99 char),
	regio_nr                      	number,
	regio_sorteervolgnr           	number,
	teamnaam                      	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index team_s_pk_idx on dv_team_s (dim_aanmaak_datum, dim_team_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_team_s
--------------------------------------------------------

alter table dv_team_s add constraint team_s_pk primary key (dim_aanmaak_datum, dim_team_h_hk) using index team_s_pk_idx enable
/