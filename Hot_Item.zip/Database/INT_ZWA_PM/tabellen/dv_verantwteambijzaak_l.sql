--------------------------------------------------------
--  Verwijder tabel dv_verantwteambijzaak_l als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_VERANTWTEAMBIJZAAK_L')

--------------------------------------------------------
--  DDL for Table dv_verantwteambijzaak_l
--------------------------------------------------------
create table dv_verantwteambijzaak_l
(
  	dim_team_h_hk              	varchar2(99 char) not null,
	dim_verantwteambijzaak_l_hk	varchar2(99 char) not null,
	dim_zaak_h_hk              	varchar2(99 char) not null,
	dim_aanmaak_datum          	timestamp not null,
	dim_bron                   	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index verantwteambijzaak_l_pk_idx on dv_verantwteambijzaak_l (dim_verantwteambijzaak_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_verantwteambijzaak_l
--------------------------------------------------------

alter table dv_verantwteambijzaak_l add constraint verantwteambijzaak_l_pk primary key (dim_verantwteambijzaak_l_hk) using index verantwteambijzaak_l_pk_idx enable
/