--------------------------------------------------------
--  Verwijder tabel dv_taakinzaak_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_TAAKINZAAK_S')

--------------------------------------------------------
--  DDL for Table dv_taakinzaak_s
--------------------------------------------------------
create table dv_taakinzaak_s
(
  	dim_taakinzaak_l_hk        	varchar2(99 char) not null,
	dim_aanmaak_datum          	timestamp not null,
	dim_bron                   	varchar2(99 char),
	dim_hashdiff               	varchar2(99 char) not null,
	dim_is_verwijderd          	number default on null 0 not null,
	aanleiding_activiteit      	varchar2(99 char),
	aanwezigheid_persoon       	varchar2(99 char),
	code_aanleiding_activiteit 	varchar2(99 char),
	code_aanwezigheid_persoon  	varchar2(99 char),
	code_conclusie_activiteit  	varchar2(99 char),
	code_functie_medewerker    	varchar2(99 char),
	code_status_activiteit     	varchar2(99 char),
	conclusie_activiteit       	varchar2(99 char),
	datum_activiteit_plan      	timestamp,
	datum_activiteit_realisatie	timestamp,
	datum_boeking_activiteit   	timestamp,
	datum_oproep               	timestamp,
	functie_medewerker         	varchar2(99 char),
	naam_medewerker            	varchar2(99 char),
	status_activiteit          	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index taakinzaak_s_pk_idx on dv_taakinzaak_s (dim_aanmaak_datum, dim_taakinzaak_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_taakinzaak_s
--------------------------------------------------------

alter table dv_taakinzaak_s add constraint taakinzaak_s_pk primary key (dim_aanmaak_datum, dim_taakinzaak_l_hk) using index taakinzaak_s_pk_idx enable
/