--------------------------------------------------------
--  Verwijder tabel stg_dv_zaak als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('STG_DV_ZAAK')

--------------------------------------------------------
--  DDL for Table stg_dv_zaak
--------------------------------------------------------
create table stg_dv_zaak
(
  	dim_natuurlijkepersoon_h_hk    	varchar2(99 char) not null,
	dim_team_h_hk                  	varchar2(99 char) not null,
	dim_verantwteambijzaak_l_hk    	varchar2(99 char) not null,
	dim_zaak_h_hk                  	varchar2(99 char) not null,
	dim_zaakbijnatuurlijkpers_l_hk 	varchar2(99 char) not null,
	dim_dummy                      	varchar2(9 char),
	dim_hashdiff_teambijzaak       	varchar2(99 char) not null,
	dim_hashdiff_zaak              	varchar2(99 char) not null,
	dim_hashdiff_zaak_bwt          	varchar2(99 char) not null,
	dim_hashdiff_zaakbijnatpers    	varchar2(99 char) not null,
	dim_ingangsdatum_bwt           	timestamp,
	aansluitingsnr                 	varchar2(99 char),
	ag_traject                     	varchar2(99 char),
	begindatum_ao                  	timestamp,
	bron_hersteldmelding           	varchar2(99 char),
	bsn                            	varchar2(99 char),
	buitenlandse_instellingsnr     	varchar2(9 char),
	code_ag_traject                	varchar2(99 char),
	code_bron_hersteldmelding      	varchar2(99 char),
	code_reden_einde_recht         	char(5),
	code_uitstroomoorzaak          	varchar2(99 char),
	code_vangnetcategorie_bb       	varchar2(99 char),
	code_vangnetcategorie_imf      	varchar2(99 char),
	code_vangnetcategorie_szw      	varchar2(99 char),
	contractcode                   	varchar2(9 char),
	dat_nuda_ezwb                  	timestamp,
	dat_uda_ezwb                   	timestamp,
	datum_boeking_ao               	timestamp,
	datum_boeking_dienstverband    	timestamp,
	datum_boeking_hersteldmelding  	timestamp,
	datum_ontvangst_ao_melding     	timestamp,
	datum_ontvangst_hersteldmelding	timestamp,
	datum_overdracht_ck            	timestamp,
	datum_plausibel                	timestamp,
	datum_ziekmeld_door_verzekerde 	timestamp,
	districtskantoor_nr            	number,
	eerste_contactmoment           	timestamp,
	eerste_of_tweede_lijn          	varchar2(99 char) not null,
	einddatum_ao                   	timestamp,
	ind_eigenrisicodrager          	varchar2(9 char),
	ind_gdbm                       	varchar2(9 char),
	ind_slapend                    	varchar2(9 char),
	indicatie_plausibel            	varchar2(9 char),
	maximum_datum_ziektewet        	timestamp,
	reden_einde_recht              	char(5),
	teamnummer                     	varchar2(9 char),
	uitstroomoorzaak               	varchar2(99 char),
	uzs_aanvraagid                 	number,
	uzs_gevalsvolgnr               	number,
	vangnetcategorie_bb            	varchar2(99 char),
	vangnetcategorie_imf           	varchar2(99 char),
	vangnetcategorie_szw           	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column stg_dv_zaak.ind_gdbm is 'Geen Duurzaam Benutbare Mogelijkheden'
/
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table stg_dv_zaak
--------------------------------------------------------

