--------------------------------------------------------
--  Verwijder tabel dv_zaak_h als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_ZAAK_H')

--------------------------------------------------------
--  DDL for Table dv_zaak_h
--------------------------------------------------------
create table dv_zaak_h
(
  	dim_zaak_h_hk              	varchar2(99 char) not null,
	dim_aanmaak_datum          	timestamp not null,
	dim_bron                   	varchar2(99 char),
	aansluitingsnr             	varchar2(99 char),
	begindatum_ao              	timestamp not null,
	bsn                        	varchar2(99 char) not null,
	buitenlandse_instellingsnr 	varchar2(9 char),
	contractcode               	varchar2(9 char) not null,
	datum_boeking_dienstverband	timestamp
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index zaak_h_pk_idx on dv_zaak_h (dim_zaak_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_zaak_h
--------------------------------------------------------

alter table dv_zaak_h add constraint zaak_h_pk primary key (dim_zaak_h_hk) using index zaak_h_pk_idx enable
/