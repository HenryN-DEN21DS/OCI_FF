--------------------------------------------------------
--  Verwijder tabel dv_zaak_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_ZAAK_S')

--------------------------------------------------------
--  DDL for Table dv_zaak_s
--------------------------------------------------------
create table dv_zaak_s
(
  	dim_zaak_h_hk                  	varchar2(99 char) not null,
	dim_aanmaak_datum              	timestamp not null,
	dim_bron                       	varchar2(99 char),
	dim_hashdiff                   	varchar2(99 char) not null,
	dim_is_verwijderd              	number default on null 0 not null,
	ag_traject                     	varchar2(99 char),
	bron_hersteldmelding           	varchar2(99 char),
	code_ag_traject                	varchar2(99 char),
	code_bron_hersteldmelding      	varchar2(99 char),
	code_reden_einde_recht         	char(5),
	code_uitstroomoorzaak          	varchar2(99 char),
	code_vangnetcategorie_bb       	varchar2(99 char),
	code_vangnetcategorie_imf      	varchar2(99 char),
	code_vangnetcategorie_szw      	varchar2(99 char),
	dat_nuda_ezwb                  	timestamp,
	dat_uda_ezwb                   	timestamp,
	datum_boeking_ao               	timestamp,
	datum_boeking_hersteldmelding  	timestamp,
	datum_ontvangst_ao_melding     	timestamp,
	datum_ontvangst_hersteldmelding	timestamp,
	datum_overdracht_ck            	timestamp,
	datum_plausibel                	timestamp,
	datum_ziekmeld_door_verzekerde 	timestamp,
	eerste_contactmoment           	timestamp,
	eerste_of_tweede_lijn          	varchar2(99 char) not null,
	einddatum_ao                   	timestamp,
	ind_eigenrisicodrager          	varchar2(9 char),
	ind_gdbm                       	varchar2(9 char),
	ind_slapend                    	varchar2(9 char),
	indicatie_plausibel            	varchar2(9 char),
	maximum_datum_ziektewet        	timestamp,
	reden_einde_recht              	char(5),
	uitstroomoorzaak               	varchar2(99 char),
	uzs_aanvraagid                 	number,
	uzs_gevalsvolgnr               	number,
	vangnetcategorie_bb            	varchar2(99 char),
	vangnetcategorie_imf           	varchar2(99 char),
	vangnetcategorie_szw           	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/

comment on column dv_zaak_s.ind_gdbm is 'Geen Duurzaam Benutbare Mogelijkheden'
/
--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index zaak_s_pk_idx on dv_zaak_s (dim_aanmaak_datum, dim_zaak_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_zaak_s
--------------------------------------------------------

alter table dv_zaak_s add constraint zaak_s_pk primary key (dim_aanmaak_datum, dim_zaak_h_hk) using index zaak_s_pk_idx enable
/