--------------------------------------------------------
--  Verwijder tabel dv_zaakbijnatuurlijkepersoon_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_ZAAKBIJNATUURLIJKEPERSOON_S')

--------------------------------------------------------
--  DDL for Table dv_zaakbijnatuurlijkepersoon_s
--------------------------------------------------------
create table dv_zaakbijnatuurlijkepersoon_s
(
  	dim_zaakbijnatuurlijkpers_l_hk	varchar2(99 char) not null,
	dim_aanmaak_datum             	timestamp not null,
	dim_bron                      	varchar2(99 char),
	dim_hashdiff                  	varchar2(99 char) not null,
	dim_is_verwijderd             	number default on null 0 not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index zaakbijnatpers_s_pk_idx on dv_zaakbijnatuurlijkepersoon_s (dim_aanmaak_datum, dim_zaakbijnatuurlijkpers_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_zaakbijnatuurlijkepersoon_s
--------------------------------------------------------

alter table dv_zaakbijnatuurlijkepersoon_s add constraint zaakbijnatpers_s_pk primary key (dim_aanmaak_datum, dim_zaakbijnatuurlijkpers_l_hk) using index zaakbijnatpers_s_pk_idx enable
/