--------------------------------------------------------
--  Verwijder tabel stg_dv_natuurlijkepersoon als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('STG_DV_NATUURLIJKEPERSOON')

--------------------------------------------------------
--  DDL for Table stg_dv_natuurlijkepersoon
--------------------------------------------------------
create table stg_dv_natuurlijkepersoon
(
  	dim_natuurlijkepersoon_h_hk   	varchar2(99 char) not null,
	dim_hashdiff_natuurlijke_pers 	varchar2(99 char) not null,
	bsn                           	varchar2(99 char) not null,
	domicilie_postcode            	varchar2(9 char),
	domicilie_postcode_gebied     	varchar2(9 char),
	geboortedatum                 	timestamp,
	status_persoon                	varchar2(9 char),
	verpleeg_adres_land           	varchar2(99 char),
	verpleeg_adres_land_nr        	varchar2(9 char),
	verpleeg_adres_postcode       	varchar2(9 char),
	verpleeg_adres_postcode_gebied	varchar2(9 char),
	verpleeg_instelling           	varchar2(99 char),
	verpleeg_instelling_code      	varchar2(9 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------



--------------------------------------------------------
--  Constraints for Table stg_dv_natuurlijkepersoon
--------------------------------------------------------

