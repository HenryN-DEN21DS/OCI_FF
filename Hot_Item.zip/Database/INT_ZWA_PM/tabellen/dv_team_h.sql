--------------------------------------------------------
--  Verwijder tabel dv_team_h als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_TEAM_H')

--------------------------------------------------------
--  DDL for Table dv_team_h
--------------------------------------------------------
create table dv_team_h
(
  	dim_team_h_hk      	varchar2(99 char) not null,
	dim_aanmaak_datum  	timestamp not null,
	dim_bron           	varchar2(99 char),
	districtskantoor_nr	varchar2(9 char) not null,
	teamnummer         	varchar2(9 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index team_h_pk_idx on dv_team_h (dim_team_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_team_h
--------------------------------------------------------

alter table dv_team_h add constraint team_h_pk primary key (dim_team_h_hk) using index team_h_pk_idx enable
/