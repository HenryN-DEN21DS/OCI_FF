--------------------------------------------------------
--  Verwijder tabel dv_natuurlijkepersoon_h als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_NATUURLIJKEPERSOON_H')

--------------------------------------------------------
--  DDL for Table dv_natuurlijkepersoon_h
--------------------------------------------------------
create table dv_natuurlijkepersoon_h
(
  	dim_natuurlijkepersoon_h_hk	varchar2(99 char) not null,
	dim_aanmaak_datum          	timestamp not null,
	dim_bron                   	varchar2(99 char),
	bsn                        	varchar2(99 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index natuurlijkepersoon_h_pk_idx on dv_natuurlijkepersoon_h (dim_natuurlijkepersoon_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_natuurlijkepersoon_h
--------------------------------------------------------

alter table dv_natuurlijkepersoon_h add constraint natuurlijkepersoon_h_pk primary key (dim_natuurlijkepersoon_h_hk) using index natuurlijkepersoon_h_pk_idx enable
/