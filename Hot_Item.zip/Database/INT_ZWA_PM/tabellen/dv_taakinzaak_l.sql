--------------------------------------------------------
--  Verwijder tabel dv_taakinzaak_l als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_TAAKINZAAK_L')

--------------------------------------------------------
--  DDL for Table dv_taakinzaak_l
--------------------------------------------------------
create table dv_taakinzaak_l
(
  	dim_taak_h_hk             	varchar2(99 char) not null,
	dim_taakinzaak_l_hk       	varchar2(99 char) not null,
	dim_team_h_hk             	varchar2(99 char) not null,
	dim_zaak_h_hk             	varchar2(99 char) not null,
	dim_aanmaak_datum         	timestamp not null,
	dim_bron                  	varchar2(99 char),
	datum_initiele_boeking_act	timestamp
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index taakinzaak_l_pk_idx on dv_taakinzaak_l (dim_taakinzaak_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_taakinzaak_l
--------------------------------------------------------

alter table dv_taakinzaak_l add constraint taakinzaak_l_pk primary key (dim_taakinzaak_l_hk) using index taakinzaak_l_pk_idx enable
/