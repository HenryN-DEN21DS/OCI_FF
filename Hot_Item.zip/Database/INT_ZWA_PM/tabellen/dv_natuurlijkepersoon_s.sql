--------------------------------------------------------
--  Verwijder tabel dv_natuurlijkepersoon_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_NATUURLIJKEPERSOON_S')

--------------------------------------------------------
--  DDL for Table dv_natuurlijkepersoon_s
--------------------------------------------------------
create table dv_natuurlijkepersoon_s
(
  	dim_natuurlijkepersoon_h_hk   	varchar2(99 char) not null,
	dim_aanmaak_datum             	timestamp not null,
	dim_bron                      	varchar2(99 char),
	dim_hashdiff                  	varchar2(99 char) not null,
	dim_is_verwijderd             	number default on null 0 not null,
	domicilie_postcode            	varchar2(9 char),
	domicilie_postcode_gebied     	varchar2(9 char),
	geboortedatum                 	timestamp,
	status_persoon                	varchar2(9 char),
	verpleeg_adres_land           	varchar2(99 char),
	verpleeg_adres_land_nr        	varchar2(9 char),
	verpleeg_adres_postcode       	varchar2(9 char),
	verpleeg_adres_postcode_gebied	varchar2(9 char),
	verpleeg_instelling           	varchar2(99 char),
	verpleeg_instelling_code      	varchar2(9 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index natuurlijkepersoon_s_pk_idx on dv_natuurlijkepersoon_s (dim_aanmaak_datum, dim_natuurlijkepersoon_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_natuurlijkepersoon_s
--------------------------------------------------------

alter table dv_natuurlijkepersoon_s add constraint natuurlijkepersoon_s_pk primary key (dim_aanmaak_datum, dim_natuurlijkepersoon_h_hk) using index natuurlijkepersoon_s_pk_idx enable
/