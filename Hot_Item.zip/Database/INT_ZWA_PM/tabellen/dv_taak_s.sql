--------------------------------------------------------
--  Verwijder tabel dv_taak_s als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_TAAK_S')

--------------------------------------------------------
--  DDL for Table dv_taak_s
--------------------------------------------------------
create table dv_taak_s
(
  	dim_taak_h_hk          	varchar2(99 char) not null,
	dim_aanmaak_datum      	timestamp not null,
	dim_bron               	varchar2(99 char),
	dim_hashdiff           	varchar2(99 char) not null,
	dim_is_verwijderd      	number default on null 0 not null,
	activiteit_omschrijving	varchar2(999 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index taak_s_pk_idx on dv_taak_s (dim_aanmaak_datum, dim_taak_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_taak_s
--------------------------------------------------------

alter table dv_taak_s add constraint taak_s_pk primary key (dim_aanmaak_datum, dim_taak_h_hk) using index taak_s_pk_idx enable
/