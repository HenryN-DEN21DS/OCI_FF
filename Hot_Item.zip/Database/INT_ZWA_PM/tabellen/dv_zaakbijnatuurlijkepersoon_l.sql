--------------------------------------------------------
--  Verwijder tabel dv_zaakbijnatuurlijkepersoon_l als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_ZAAKBIJNATUURLIJKEPERSOON_L')

--------------------------------------------------------
--  DDL for Table dv_zaakbijnatuurlijkepersoon_l
--------------------------------------------------------
create table dv_zaakbijnatuurlijkepersoon_l
(
  	dim_natuurlijkepersoon_h_hk   	varchar2(99 char) not null,
	dim_zaak_h_hk                 	varchar2(99 char) not null,
	dim_zaakbijnatuurlijkpers_l_hk	varchar2(99 char) not null,
	dim_aanmaak_datum             	timestamp not null,
	dim_bron                      	varchar2(99 char)
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index zaakbijnatpers_l_pk_idx on dv_zaakbijnatuurlijkepersoon_l (dim_zaakbijnatuurlijkpers_l_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_zaakbijnatuurlijkepersoon_l
--------------------------------------------------------

alter table dv_zaakbijnatuurlijkepersoon_l add constraint zaakbijnatpers_l_pk primary key (dim_zaakbijnatuurlijkpers_l_hk) using index zaakbijnatpers_l_pk_idx enable
/