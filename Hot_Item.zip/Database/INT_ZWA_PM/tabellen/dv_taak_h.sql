--------------------------------------------------------
--  Verwijder tabel dv_taak_h als aanwezig
--------------------------------------------------------

exec tabel_hulp.verwijder_tabel ('DV_TAAK_H')

--------------------------------------------------------
--  DDL for Table dv_taak_h
--------------------------------------------------------
create table dv_taak_h
(
  	dim_taak_h_hk    	varchar2(99 char) not null,
	dim_aanmaak_datum	timestamp not null,
	dim_bron         	varchar2(99 char),
	activiteitcode   	varchar2(99 char) not null
)
compress basic
nologging
nocache
parallel(degree 4 instances default)
monitoring
/


--------------------------------------------------------
--  DDL for Index
--------------------------------------------------------

create index taak_h_pk_idx on dv_taak_h (dim_taak_h_hk)
/

--------------------------------------------------------
--  Constraints for Table dv_taak_h
--------------------------------------------------------

alter table dv_taak_h add constraint taak_h_pk primary key (dim_taak_h_hk) using index taak_h_pk_idx enable
/