create or replace force view ggv_zaak_uitstroom_fv
as 
select dim_datum_key,
dim_snapshot_key,
dim_zaak_key,
dim_team_key_verantwoordelijk,
aantal_uitstroom,
verzuimduur
from bdr_zwa_po.bdr_zaak_uitstroom_ft;