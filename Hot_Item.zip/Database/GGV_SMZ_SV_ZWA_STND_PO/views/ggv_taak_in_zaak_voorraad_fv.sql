create or replace force view ggv_taak_in_zaak_voorraad_fv
as 
select dim_datum_key,
dim_snapshot_key,
dim_zaak_key,
dim_taakinzaak_key,
dim_taak_key,
dim_team_key_verantwoordelijk,
dim_team_key_taak,
dim_ouderdomscategorie_key,
aantal_voorraad,
ouderdom
from bdr_zwa_po.bdr_taak_in_zaak_voorraad_ft;