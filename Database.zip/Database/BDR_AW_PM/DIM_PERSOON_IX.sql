-- naam  : DIM_PERSOON_IX1.sql
-- datum : 2023-11-13
-- doel  : create index DIM_PERSOON_IX1 in BDR_AW_PO
--
-- 
-- datum naam omschrijving
-- ---------- ------ -------------------------------------------------------
-- 2023-11-13 wbe062 aangemaakt
-- -------------------------------------------------------------------------

BEGIN
    EXECUTE IMMEDIATE 'DROP INDEX DIM_PERSOON_IX1';
EXCEPTION
    WHEN OTHERS THEN
        IF sqlcode != -1418 THEN
            RAISE;
        END IF;
END;
/
CREATE UNIQUE INDEX DIM_PERSOON_IX1 ON BDR_AW_PM.DIM_PERSOON (BURGERSERVICENUMMER);