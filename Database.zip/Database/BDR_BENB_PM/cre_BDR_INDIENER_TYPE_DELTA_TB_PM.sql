﻿-- Naam  : cre_BDR_INDIENER_TYPE_DELTA_TB_PM.sql
-- Datum : 10-01-2022
-- Doel  : Script voor het creëeren van de Indiener Type delta tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 10-01-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_indiener_type_delta_tb') loop
            execute immediate 'drop table bdr_indiener_type_delta_tb';
    end loop;
end;
/


CREATE TABLE BDR_INDIENER_TYPE_DELTA_TB

(        
  DIM_INDIENER_TYPE_ID      	NUMBER,
  DIM_INDIENER_TYPE_KEY     	VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM        	TIMESTAMP (6) NOT NULL, 
  DIM_MD5                	VARCHAR2(99) NOT NULL,
  INDIENER_TYPE	 	        VARCHAR2(99),
  INDIENER_TYPE_OMSCHRIJVING    VARCHAR2(99)
) compress for oltp;

ALTER TABLE BDR_INDIENER_TYPE_DELTA_TB ADD CONSTRAINT BDR_INDIENER_TYPE_DELTA_TB_PK PRIMARY KEY (DIM_INDIENER_TYPE_KEY, DIM_START_DATUM);
