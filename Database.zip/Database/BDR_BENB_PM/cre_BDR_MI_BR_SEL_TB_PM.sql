﻿-- Naam  : cre_BDR_MI_BR_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_MI_BR_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 30-11-2022 mwo096 Toevoeging datamodel
-- 25-07-2022 mle134 Toevoegen INLOGNAAM_MBR
-- 21-07-2022 jsc226 Toevoegen REDEN_INTREKKING
-- 16-05-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_br_sel_tb') loop
            execute immediate 'drop table bdr_mi_br_sel_tb';
    end loop;
end;
/

create table BDR_MI_BR_SEL_TB
(
  dim_start_datum           TIMESTAMP,
  dim_eind_datum            TIMESTAMP,
  classid                   VARCHAR2(9),
  objectid                  VARCHAR2(99),
  classid_parent            VARCHAR2(9),
  objectid_parent           VARCHAR2(99),
  procesnaam                VARCHAR2(99),
  procesnaam_parent         VARCHAR2(99),
  us_dictum_uitspraak       VARCHAR2(999),
  wet                       VARCHAR2(999),
  kenmerk_prim_besl_1       VARCHAR2(99),
  kenmerk_prim_besl_2       VARCHAR2(99),
  code_geschil_1            VARCHAR2(99),
  code_geschil_2            VARCHAR2(99),
  dk_id                     VARCHAR2(99),
  team                      VARCHAR2(99),
  indiener                  VARCHAR2(99),
  naam_prim_afd_1           VARCHAR2(99),
  naam_prim_afd_2           VARCHAR2(99),
  naam_prim_afd_3           VARCHAR2(99),
  medisch_arbeidskundig     NUMBER(38,10),
  status                    VARCHAR2(99),
  verwijderd                NUMBER(38,10),
  dt_Intrekking             DATE,
  dt_start_proces           DATE,
  einddt_proces             DATE,
  dat_prrim_beslissing      DATE,
  zaaknummer                VARCHAR2(999),
  reden_intrekking          VARCHAR2(99),
  inlognaam_mbr             VARCHAR2(99 CHAR),
  registratienummer         VARCHAR2(99),
  erd                       NUMBER,
  griffierecht_bedrag       NUMBER,
  proceskosten_bedrag       NUMBER,
  schadevergoeding_bedrag   NUMBER
) compress for oltp;