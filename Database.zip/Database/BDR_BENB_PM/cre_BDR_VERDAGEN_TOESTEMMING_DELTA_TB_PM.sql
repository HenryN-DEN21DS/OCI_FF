﻿-- Naam  : cre_BDR_VERDAGEN_TOESTEMMING_DELTA_TB_PM.sql
-- Datum : 23-06-2022
-- Doel  : Script voor het creëeren van de verdagen toestemming delta tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-06-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_verdagen_toestemming_delta_tb') loop
            execute immediate 'drop table bdr_verdagen_toestemming_delta_tb';
    end loop;
end;
/

create table bdr_verdagen_toestemming_delta_tb
(
  DIM_VERDAGEN_TOESTEMMING_ID    number,
  DIM_VERDAGEN_TOESTEMMING_KEY   varchar2(99),
  DIM_START_DATUM                timestamp,
  DIM_MD5                        varchar2(99),
  TOESTEMMING_VEREISTE           varchar2(99),
  TOESTEMMING_TYPE               varchar2(99),
  TOESTEMMING                    varchar2(99)
) compress for oltp;

ALTER TABLE BDR_VERDAGEN_TOESTEMMING_DELTA_TB ADD CONSTRAINT BDR_VERDAGEN_TOESTEMMING_DELTA_TB_PK PRIMARY KEY (DIM_VERDAGEN_TOESTEMMING_KEY, DIM_START_DATUM);

