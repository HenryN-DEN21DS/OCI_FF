﻿-- Naam  : cre_BDR_SUB_HOORZITTING_DELTA_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SUB_HOORZITTING_DELTA_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-07-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_sub_hoorzitting_delta_tb') loop
            execute immediate 'drop table bdr_sub_hoorzitting_delta_tb';
    end loop;
end;
/

create table BDR_SUB_HOORZITTING_DELTA_TB
(
    DIM_SUB_HOORZITTING_ID          NUMBER,
    DIM_SUB_HOORZITTING_KEY         VARCHAR2(99) NOT NULL,
    DIM_START_DATUM                 TIMESTAMP NOT NULL,
    DIM_MD5                         CHAR(32) NOT NULL, 
    DIM_KANTOOR_ID                  NUMBER,
    DIM_DATUM_HOORZITTING_ID        NUMBER,
    DIM_DATUM_START_PROCES_ID       NUMBER,
    DIM_DATUM_EIND_PROCES_ID        NUMBER,
    DIM_DATUM_TOEZENDEN_VERSLAG_ID  NUMBER,
    DIM_PROCES_KEY                  VARCHAR2(99),
    HOORZITTING_STATUS              VARCHAR2(99),
    VERZEKERINGSARTS_AANWEZIG       VARCHAR2(99),
    ARBEIDSDESKUNDIGE_AANWEZIG      VARCHAR2(99),
    HOORZITTING_PROCESTYPE          VARCHAR2(99),
    PUIK_ARBEIDSDESKUNDIGE_BB       VARCHAR2(99),
    PUIK_VERZEKERINGSARTS_BB        VARCHAR2(99),
    PUIK_VERSLAGLEGGER              VARCHAR2(99),
    PUIK_HOORDER                    VARCHAR2(99),
    HOORZITTING_PROCES_STATUS       VARCHAR2(99),
    PLANNINGS_DAGEN                 NUMBER,
    REGISTRATIENUMMER	            VARCHAR2(99),
    DIM_JUNK_ID			    NUMBER
) compress for oltp
;
