﻿-- Naam  : cre_BDR_VERZOEKSCHRIFT_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SUB_VERZOEKSCHRIFT_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 30-11-2022 mwo096 Toevoeging datamodel
-- 07-07-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_verzoekschrift_sel_tb') loop
            execute immediate 'drop table bdr_verzoekschrift_sel_tb';
    end loop;
end;
/

create table BDR_VERZOEKSCHRIFT_SEL_TB
(
    DIM_VERZOEKSCHRIFT_KEY  VARCHAR2(99),
    DIM_START_DATUM         TIMESTAMP,
    ADV_BEDRAG              NUMBER,
    GECLAIMD_BEDRAG         NUMBER,
    GRI_BEDRAG              NUMBER,
    PRO_BEDRAG              NUMBER,
    PROCESKOSTEN            NUMBER,
    PROCUREURSKOSTEN        NUMBER,
    SCH_BEDRAG              NUMBER,
    TOT_BEDRAG              NUMBER,
    ADVOCAAT_UWV            NUMBER,
    CODE_GESCHIL_1          VARCHAR2(99),
    CODE_GESCHIL_2          VARCHAR2(99),
    DATUM_INTREKKING        NUMBER,
    DATUM_UITSPRAAK         NUMBER,
    DICTUM_UITSPRAAK        VARCHAR2(999),
    EINDDT_ZAAK             NUMBER,
    INDIENER                VARCHAR2(99),
    INLOGNAAM_MB            VARCHAR2(99),
    KENMERK_AI              VARCHAR2(999),
    KENMERK_PRIM_BESL_1     VARCHAR2(99),
    KENMERK_PRIM_BESL_2     VARCHAR2(99),
    REDEN_INTREKKING        VARCHAR2(99),
    SCHADEVERGOEDING        NUMBER,
    STARTDT_ZAAK            NUMBER,
    KANTOOR                 VARCHAR2(99),
    JUNK                    VARCHAR2(99),
    WET                     VARCHAR2(99),
    ZAAKNUMMER              VARCHAR2(999),
    ERD                     NUMBER
) compress for oltp;