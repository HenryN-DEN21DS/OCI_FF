﻿-- Naam  : cre_BDR_KENMERK_PB_TMP_TB_PM.sql
-- Datum : 06-01-2022
-- Doel  : Script voor het creëeren van de tijdelijke kenmerk primaire beslissing tussen tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 06-01-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_kenmerk_pb_tmp_tb') loop
            execute immediate 'drop table bdr_kenmerk_pb_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_KENMERK_PB_TMP_TB
(
  DIM_KENMERK_PB_KEY         VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM     	     TIMESTAMP (6) NOT NULL, 
  DIM_MD5                    VARCHAR2(99) NOT NULL,
  KENMERK_PB_CODE	     VARCHAR2(9),
  KENMERK_PB_OMSCHRIJVING    VARCHAR2(999)
) compress for oltp;
   
ALTER TABLE BDR_KENMERK_PB_TMP_TB ADD CONSTRAINT BDR_KENMERK_PB_TMP_TB_PK PRIMARY KEY (DIM_KENMERK_PB_KEY, DIM_START_DATUM);
