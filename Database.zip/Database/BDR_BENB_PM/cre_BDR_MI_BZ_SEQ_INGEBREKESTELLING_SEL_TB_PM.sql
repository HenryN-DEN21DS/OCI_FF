﻿-- Naam  : cre_BDR_MI_BZ_SEQ_INGEBREKESTELLING_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_MI_BZ_SEQ_INGEBREKESTELLING_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 04-07-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_bz_seq_ingebrekestelling_sel_tb') loop
            execute immediate 'drop table bdr_mi_bz_seq_ingebrekestelling_sel_tb';
    end loop;
end;
/

CREATE TABLE BDR_MI_BZ_SEQ_INGEBREKESTELLING_SEL_TB 
   (
        DIM_START_DATUM TIMESTAMP NOT NULL, 
	DIM_EIND_DATUM TIMESTAMP NOT NULL, 
	CLASSID VARCHAR2(9 CHAR), 
	OBJECTID VARCHAR2(99 CHAR), 
	DT_BEREKENING_DWANGSOM DATE,
	ANNULEREN_IGS NUMBER
   ) compress for oltp;