﻿-- Naam  : cre_BDR_RESULTAAT_AFHAND_TMP_TB_PM.sql
-- Datum : 22-12-2021
-- Doel  : Script voor het creëeren van de tijdelijke tussen tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 12-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_resultaat_afhand_tmp_tb') loop
            execute immediate 'drop table bdr_resultaat_afhand_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_RESULTAAT_AFHAND_TMP_TB
(
  DIM_RESULTAAT_AFHAND_KEY      VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM        	TIMESTAMP (6) NOT NULL, 
  DIM_MD5                	VARCHAR2(99) NOT NULL,
  CODE      			VARCHAR2(99),
  OMSCHRIJVING			VARCHAR2(99),
  BETALEN         		VARCHAR2(9),
  GELDIG_VAN          		DATE,
  GELDIG_TOT          		DATE
) compress for oltp;
   
ALTER TABLE BDR_RESULTAAT_AFHAND_TMP_TB ADD CONSTRAINT BDR_RESULTAAT_AFHAND_TMP_TB_PK PRIMARY KEY (DIM_RESULTAAT_AFHAND_KEY, DIM_START_DATUM);
