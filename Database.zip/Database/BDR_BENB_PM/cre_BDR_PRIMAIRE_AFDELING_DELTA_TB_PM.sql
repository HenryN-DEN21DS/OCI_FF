﻿-- Naam  : cre_BDR_PRIMAIRE_AFDELING_DELTA_TB_PM.sql
-- Datum : 13-01-2022
-- Doel  : Script voor het creëeren van de primaire afdeling delta tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-01-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_primaire_afdeling_delta_tb') loop
            execute immediate 'drop table bdr_primaire_afdeling_delta_tb';
    end loop;
end;
/

CREATE TABLE BDR_PRIMAIRE_AFDELING_DELTA_TB

(        
  DIM_PRIMAIRE_AFDELING_ID       NUMBER,
  DIM_PRIMAIRE_AFDELING_KEY      VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM                TIMESTAMP (6) NOT NULL, 
  DIM_MD5                        VARCHAR2(99) NOT NULL,
  PRIMAIRE_AFDELING_CODE         VARCHAR2(9) NOT NULL,
  PRIMAIRE_AFDELING_OMSCHRIJVING VARCHAR2(999),
  GELDIG_VAN                     DATE,
  GELDIG_TOT                     DATE
) compress for oltp;

ALTER TABLE BDR_PRIMAIRE_AFDELING_DELTA_TB ADD CONSTRAINT BDR_PRIMAIRE_AFDELING_DELTA_TB_PK PRIMARY KEY (DIM_PRIMAIRE_AFDELING_KEY, DIM_START_DATUM);
