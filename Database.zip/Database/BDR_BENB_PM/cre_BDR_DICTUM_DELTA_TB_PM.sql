﻿-- Naam  : cre_BDR_DICTUM_DELTA_TB_PM.sql
-- Datum : 22-12-2021
-- Doel  : Script voor het creëeren van de dictum delta tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 22-12-2021 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_dictum_delta_tb') loop
            execute immediate 'drop table bdr_dictum_delta_tb';
    end loop;
end;
/

CREATE TABLE BDR_DICTUM_DELTA_TB

(        
  DIM_DICTUM_ID       NUMBER,
  DIM_DICTUM_KEY      VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM     TIMESTAMP (6) NOT NULL, 
  DIM_MD5             VARCHAR2(99) NOT NULL,
  PROCEDURE           VARCHAR2(99),
  CATEGORIE           VARCHAR2(99),
  CODE                VARCHAR2(999),
  OMSCHRIJVING        VARCHAR2(999),
  OMSCHRIJVING_GROEP  VARCHAR2(99),
  GELDIG_VAN          DATE,
  GELDIG_TOT          DATE
) compress for oltp;

ALTER TABLE BDR_DICTUM_DELTA_TB ADD CONSTRAINT BDR_DICTUM_DELTA_TB_PK PRIMARY KEY (DIM_DICTUM_KEY, DIM_START_DATUM);
