﻿-- Naam  : cre_BDR_VOORLOPIGE_VOORZIENING_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_VOORLOPIGE_VOORZIENING_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 29-11-2022 mwo096 Toevoeging datamodel
-- 18-07-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_voorlopige_voorziening_sel_tb') loop
            execute immediate 'drop table bdr_voorlopige_voorziening_sel_tb';
    end loop;
end;
/


create table BDR_VOORLOPIGE_VOORZIENING_SEL_TB
(
    DIM_VOORLOPIGE_VOORZIENING_KEY  	VARCHAR2(99),
    DIM_START_DATUM         		TIMESTAMP,
    BEDRAG_GRIFFIERECHT 		NUMBER,
    BEDRAG_PROCESKOSTEN 		NUMBER,
    BEDRAG_SCHADEVERGOEDING 		NUMBER,
    GESCHIL_1          			VARCHAR2(99),
    GESCHIL_2        			VARCHAR2(99),
    DATUM_INTREKKING			NUMBER,
    DATUM_EIND_ZAAK			NUMBER,
    INDIENER				VARCHAR2(99),
    PRIM_BESLISSING1			VARCHAR2(99),
    PRIM_BESLISSING2			VARCHAR2(99),
    JUNK				VARCHAR2(99),
    REDEN_INTREKKING		        VARCHAR2(99),
    DATUM_START_ZAAK			NUMBER,
    KANTOOR				VARCHAR2(99),
    DICTUM				VARCHAR2(999),
    DATUM_DICTUM			NUMBER,
    DATUM_VERZENDING_UITSPRAAK		NUMBER,
    WET					VARCHAR2(99),
    GRIFFIERECHT_BETALEN		NUMBER,
    INLOGNAAM_MBR			VARCHAR2(99),
    PROCESKOSTEN_BETALEN		NUMBER,
    ZITTING				NUMBER,
    REGISTRATIENUMMER                   VARCHAR2(99),
    ERD                                 NUMBER
) compress for oltp;