﻿-- Naam  : cre_BDR_HOGER_BEROEP_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_HOGER_BEROEP_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 02-12-2022 mwo096 Toevoeging datamodel
-- 27-07-2021 mle134 Toevoeging JURIDISCH_MDW
-- 21-07-2022 jsc226 Toevoeging REDEN_INTREKKING
-- 16-05-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_hoger_beroep_sel_tb') loop
            execute immediate 'drop table bdr_hoger_beroep_sel_tb';
    end loop;
end;
/

CREATE TABLE BDR_HOGER_BEROEP_SEL_TB
(
        dim_hoger_beroep_key      VARCHAR2(99) NOT NULL,
        dim_start_datum           TIMESTAMP(6) NOT NULL,
        proces_type               VARCHAR2(9),
        productgroep              VARCHAR2(99),
        dictum                    VARCHAR2(999),
        wet                       VARCHAR2(999),
        prim_beslissing1          VARCHAR2(99),
        prim_beslissing2          VARCHAR2(99),
        geschil1                  VARCHAR2(99),
        geschil2                  VARCHAR2(99),
        kantoor                   VARCHAR2(99),
        indiener                  VARCHAR2(99),
        prim_afdeling1            VARCHAR2(999),
        prim_afdeling2            VARCHAR2(999),
        prim_afdeling3            VARCHAR2(999),
        junk                      VARCHAR2(99),
        juridisch_mdw             VARCHAR2(99),
        datum_beslissing          NUMBER,
        datum_start_proces        NUMBER,
        datum_eind_proces         NUMBER,
        datum_intrekking          NUMBER,
        zaaknummer                VARCHAR2(999),
        reden_intrekking          VARCHAR2(99),
        registratienummer         VARCHAR2(99),
        erd                       NUMBER,
        griffierecht_bedrag       NUMBER,
        proceskosten_bedrag       NUMBER,
        schadevergoeding_bedrag   NUMBER
) compress for oltp;