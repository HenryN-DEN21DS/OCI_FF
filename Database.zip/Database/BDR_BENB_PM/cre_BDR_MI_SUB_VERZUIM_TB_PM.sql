﻿-- Naam  : cre_BDR_MI_SUB_BEZWAAR_TB_PM.sql
-- Doel  : Script voor het creëeren van de bdr_mi_sub_verzuim_sel_tb tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_sub_verzuim_sel_tb') loop
            execute immediate 'drop table bdr_mi_sub_verzuim_sel_tb';
    end loop;
end;
/

create table bdr_mi_sub_verzuim_sel_tb
(
    dim_start_datum                 timestamp,
    dim_eind_datum                  timestamp,
    classid                         varchar2(9),
    objectid                        varchar2(99),
    verzuim_termijn                 number,
    dt_eind_proces                  date,
    dt_start_proces                 date,
    dt_verzuim_hersteld             date,
    dt_start_verzuim                date,
    soort_verzuim_gronden           number,
    soort_verzuim_handtekening      number,
    soort_verzuim_machtiging        number,
    soort_verzuim_naam_indiener     number,
    soort_verzuim_oms_besluit       number,
    soort_verzuim_splits_medisch    number,
    soort_verzuim_stukken           number,
    soort_verzuim_te_laat           number,
    vz_geannuleerd                  number,
    classid_parent                  varchar2(9),
    objectid_parent                 varchar2(99),
    vz_hersteld                     varchar2(99)
) compress for oltp;


  
