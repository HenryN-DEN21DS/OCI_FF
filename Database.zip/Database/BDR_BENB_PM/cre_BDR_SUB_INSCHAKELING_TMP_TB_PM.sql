﻿-- Naam  : cre_BDR_SUB_INSCHAKELING_TMP_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SUB_INSCHAKELING_TMP_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 19-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_sub_inschakeling_tmp_tb') loop
            execute immediate 'drop table bdr_sub_inschakeling_tmp_tb';
    end loop;
end;
/

create table bdr_sub_inschakeling_tmp_tb
(
    dim_sub_inschakeling_key        varchar2(99) not null,
    dim_start_datum                 timestamp not null,
    dim_md5                         char(32) not null,
    dim_datum_afgesproken_eind_id   number,
    dim_datum_start_proces_id       number,
    dim_datum_eind_proces_id        number,
    dim_datum_med_onderzk_ltst_id   number,
    dim_kantoor_id                  number,
    sequentienummer		    number,
    proceskey_parent                varchar2(99),
    externe_expertise               number,
    informatie_curatieve_sector     number,
    medisch_onderzoek               varchar2(9),
    procesnaam                      varchar2(9),  
    procesnaam_parent               varchar2(9), 
    soort_inschakeling_oms          varchar2(99),
    contrasigneren_status           varchar2(99),
    aantal_sub_inschakeling         number,
    registratienummer		    varchar2(99),
    dim_junk_id			    number
) compress for oltp;