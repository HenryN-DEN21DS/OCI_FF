﻿-- Naam  : cre_BDR_BRIEFCODE_TMP_TB_PM.sql
-- Datum : 19-04-2022
-- Doel  : Script voor het creëeren van de tijdelijke brief tussentabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 19-04-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_briefcode_tmp_tb') loop
            execute immediate 'drop table bdr_briefcode_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_BRIEFCODE_TMP_TB
(
  DIM_BRIEFCODE_KEY          VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM            TIMESTAMP (6) NOT NULL, 
  DIM_MD5                    VARCHAR2(99) NOT NULL,
  BRF_CODE 		     VARCHAR2(99),
  BRF_OMSCHRIJVING           VARCHAR2(999),
  GELDIG_VAN		     DATE,
  GELDIG_TOT                 DATE
) compress for oltp;
   
ALTER TABLE BDR_BRIEFCODE_TMP_TB ADD CONSTRAINT BDR_BRIEFCODE_TMP_TB_PK PRIMARY KEY (DIM_BRIEFCODE_KEY, DIM_START_DATUM);
