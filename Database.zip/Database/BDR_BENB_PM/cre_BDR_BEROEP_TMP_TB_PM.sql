﻿-- Naam  : cre_BDR_BEROEP_TMP_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_BEROEP_TMP_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 30-11-2022 mwo096 Toevoeging datamodel
-- 27-07-2022 jsc226 Toevoegen DIM_JURIDISCH_MDW_ID
-- 21-07-2022 jsc226 Toevoegen DIM_REDEN_INTREKKING_ID
-- 16-05-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_beroep_tmp_tb') loop
            execute immediate 'drop table bdr_beroep_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_BEROEP_TMP_TB
(
    DIM_BEROEP_KEY              VARCHAR2(99) NOT NULL,
    DIM_START_DATUM             TIMESTAMP (6) NOT NULL, 
    DIM_MD5                     CHAR(32) NOT NULL, 
    DIM_PROCES_TYPE_ID          NUMBER, 
    DIM_PRODUCTGROEP_ID         NUMBER, 
    DIM_DICTUM_ID               NUMBER, 
    DIM_WET_ID                  NUMBER, 
    DIM_PRIM_BESLISSING1_ID     NUMBER, 
    DIM_PRIM_BESLISSING2_ID     NUMBER, 
    DIM_GESCHIL1_ID             NUMBER, 
    DIM_GESCHIL2_ID             NUMBER, 
    DIM_KANTOOR_ID              NUMBER, 
    DIM_INDIENER_TYPE_ID        NUMBER, 
    DIM_PRIM_AFDELING1_ID       NUMBER, 
    DIM_PRIM_AFDELING2_ID       NUMBER, 
    DIM_PRIM_AFDELING3_ID       NUMBER, 
    DIM_JUNK_ID                 NUMBER,
    DIM_REDEN_INTREKKING_ID     NUMBER,
    DIM_JURIDISCH_MDW_ID        NUMBER,
    DIM_DATUM_BESLISSING_ID     NUMBER,
    DIM_DATUM_START_PROCES_ID   NUMBER,
    DIM_DATUM_EIND_PROCES_ID    NUMBER,
    DIM_DATUM_INTREKKING_ID     NUMBER,
    AANTAL_BEROEPEN             NUMBER,
    ZAAKNUMMER                  VARCHAR2(999),
    REGISTRATIENUMMER           VARCHAR2(99),
    ERD                         NUMBER,
    GRIFFIERECHT_BEDRAG         NUMBER,
    PROCESKOSTEN_BEDRAG         NUMBER,
    SCHADEVERGOEDING_BEDRAG     NUMBER
) compress for oltp;