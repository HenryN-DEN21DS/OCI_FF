﻿-- Naam  : cre_BDR_MI_BZ_SEQ_VD_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_MI_BZ_SEQ_VD_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 28-06-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_bz_seq_vd_sel_tb') loop
            execute immediate 'drop table bdr_mi_bz_seq_vd_sel_tb';
    end loop;
end;
/

CREATE TABLE BDR_MI_BZ_SEQ_VD_SEL_TB 
   (    DIM_START_DATUM TIMESTAMP, 
    DIM_EIND_DATUM TIMESTAMP , 
    CLASSID VARCHAR2(9), 
    OBJECTID VARCHAR2(99), 
    SEQUENTIENUMMER NUMBER, 
    TEL_TOESTEMMING VARCHAR2(99), 
    SCHRIFTELIJKE_TOESTEMMING VARCHAR2(99),
    EINDDT_NA_DEZE_VD DATE, 
    EINDDT_VOOR_DEZE_VD DATE,
    VERDAGEN_ANNULEREN NUMBER,
    DT_VERZEND_VDBRIEF_INDIENER DATE
) compress for oltp;