﻿-- Naam  : cre_BDR_JURIDISCH_MDW_TMP_TB_PM.sql
-- Datum : 25-07-2021
-- Doel  : Script voor het creëeren van de werktabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 25-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_juridisch_mdw_tmp_tb') loop
            execute immediate 'drop table bdr_juridisch_mdw_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_JURIDISCH_MDW_TMP_TB
(
  DIM_JURIDISCH_MDW_KEY         VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM        	TIMESTAMP (6) NOT NULL, 
  DIM_MD5                	VARCHAR2(99) NOT NULL,
  INLOG_NAAM   			VARCHAR2(99),
  MDW_NAAM			VARCHAR2(999)
) compress for oltp;
   
ALTER TABLE BDR_JURIDISCH_MDW_TMP_TB ADD CONSTRAINT BDR_JURIDISCH_MDW_TMP_TB_PK PRIMARY KEY (DIM_JURIDISCH_MDW_KEY, DIM_START_DATUM);
