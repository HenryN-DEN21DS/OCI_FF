﻿-- Naam  : cre_BDR_SMO_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SMO_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 27-07-2022 jsc226 Toevoegen INLOGNAAM_MB
-- 22-06-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_smo_sel_tb') loop
            execute immediate 'drop table bdr_smo_sel_tb';
    end loop;
end;
/

create table BDR_SMO_SEL_TB
(
    DIM_SMO_KEY             VARCHAR2(99),
    DIM_START_DATUM         TIMESTAMP,
    DATUM_START_ZAAK        NUMBER,
    DATUM_EINDE_ZAAK        NUMBER,
    DATUM_START_BENB        NUMBER,
    DATUM_SMO_AFGEROND      NUMBER,
    DATUM_UITERSTE_AFH      NUMBER,
    JUNK		    VARCHAR2(99),
    KANTOOR                 VARCHAR2(99),
    SOORT_ZAAK              VARCHAR2(99),
    MED_INFORMATIE          NUMBER,
    KOSTEN_MED_INFORMATIE   NUMBER,
    KOSTENPLAATS            VARCHAR2(99),
    NAAM_GEFACTUREERDE      VARCHAR2(999),
    RESULTAAT_PROCEDURE     VARCHAR2(999),
    INLOGNAAM_MB            VARCHAR2(99)
) compress for oltp;