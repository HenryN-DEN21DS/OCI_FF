﻿-- Naam  : cre_BDR_PRODUCTGROEP_TMP_TB_PM.sql
-- Datum : 19-04-2022
-- Doel  : Script voor het creëeren van de productgroep temp tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 19-04-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_productgroep_tmp_tb') loop
            execute immediate 'drop table bdr_productgroep_tmp_tb';
    end loop;
end;
/

create table bdr_productgroep_tmp_tb
(
  DIM_PRODUCTGROEP_KEY      varchar2(99),
  DIM_START_DATUM           timestamp,
  DIM_MD5                   varchar2(99),
  PRODUCTGROEP_CODE         varchar2(99),
  PRODUCTGROEP_OMSCHRIJVING varchar2(99)
) compress for oltp;

ALTER TABLE BDR_PRODUCTGROEP_TMP_TB ADD CONSTRAINT BDR_PRODUCTGROEP_TMP_TB_PK PRIMARY KEY (DIM_PRODUCTGROEP_KEY, DIM_START_DATUM);


