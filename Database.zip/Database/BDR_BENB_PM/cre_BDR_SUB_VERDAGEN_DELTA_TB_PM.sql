﻿-- Naam  : cre_BDR_SUB_VERDAGEN_DELTA_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SUB_VERDAGEN_DELTA_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 30-06-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_sub_verdagen_delta_tb') loop
            execute immediate 'drop table bdr_sub_verdagen_delta_tb';
    end loop;
end;
/

create table BDR_SUB_VERDAGEN_DELTA_TB
(
    DIM_SUB_VERDAGEN_ID             NUMBER,
    DIM_SUB_VERDAGEN_KEY            VARCHAR2(99) NOT NULL,
    DIM_START_DATUM                 TIMESTAMP NOT NULL,
    DIM_MD5                         CHAR(32) NOT NULL, 
    DIM_DATUM_EIND_VOOR_VERDAGEN_ID NUMBER,
    DIM_DATUM_EIND_NA_VERDAGEN_ID   NUMBER,
    DIM_BEZWAAR_KEY                 VARCHAR2(99),
    DIM_VERDAGEN_TOESTEMMING_ID     NUMBER,
    DIM_DATUM_VERZEND_VDBRIEF_INDIENER_ID NUMBER,
    AANTAL_VERDAGEN                 NUMBER,
    DIM_JUNK_ID			    NUMBER
) compress for oltp
;
