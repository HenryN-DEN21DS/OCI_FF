﻿-- Naam  : cre_BDR_VERZOEKSCHRIFT_TMP_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_VERZOEKSCHRIFT_TMP_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 30-11-2022 mwo096 Toevoeging datamodel
-- 26-07-2022 jsc226 Wijzigen INLOGNAAM_MB naar DIM_JURIDISCH_MDW_ID
-- 21-07-2022 jsc226 Wijziging REDEN_INTREKKING naar DIM_REDEN_INTREKKING_ID
-- 07-07-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_verzoekschrift_tmp_tb') loop
            execute immediate 'drop table bdr_verzoekschrift_tmp_tb';
    end loop;
end;
/

create table BDR_VERZOEKSCHRIFT_TMP_TB
(
    DIM_VERZOEKSCHRIFT_KEY      VARCHAR2(99) NOT NULL,
    DIM_START_DATUM             TIMESTAMP NOT NULL,
    DIM_MD5                     CHAR(32) NOT NULL, 
    DIM_GESCHIL_1_ID            NUMBER,
    DIM_GESCHIL_2_ID            NUMBER,
    DIM_DATUM_INTREKKING_ID     NUMBER,
    DIM_DATUM_UITSPRAAK_ID      NUMBER,
    DIM_DICTUM_ID               NUMBER,
    DIM_EINDDT_ZAAK_ID          NUMBER,
    DIM_INDIENER_TYPE_ID        NUMBER,
    DIM_KENMERK_PB_1_ID         NUMBER,
    DIM_KENMERK_PB_2_ID         NUMBER,
    DIM_STARTDT_ZAAK_ID         NUMBER,
    DIM_KANTOOR_ID              NUMBER,
    DIM_JUNK_ID                 NUMBER,
    DIM_WET_ID                  NUMBER,
    DIM_REDEN_INTREKKING_ID     NUMBER,
    DIM_JURIDISCH_MDW_ID        NUMBER,
    ADV_BEDRAG                  NUMBER,
    GECLAIMD_BEDRAG             NUMBER,
    GRI_BEDRAG                  NUMBER,
    PRO_BEDRAG                  NUMBER,
    PROCESKOSTEN                NUMBER,
    PROCUREURSKOSTEN            NUMBER,
    SCH_BEDRAG                  NUMBER,
    TOT_BEDRAG                  NUMBER,
    ADVOCAAT_UWV                NUMBER,
    KENMERK_AI                  VARCHAR2(999),
    SCHADEVERGOEDING            NUMBER,
    ZAAKNUMMER                  VARCHAR2(999),
    ERD                         NUMBER
) compress for oltp
;