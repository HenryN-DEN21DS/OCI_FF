﻿-- Naam  : cre_BDR_MI_VV_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_MI_VV_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 29-11-2022 mwo096 Toevoegen ERD
-- 18-07-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------


begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_vv_sel_tb') loop
            execute immediate 'drop table bdr_mi_vv_sel_tb';
    end loop;
end;
/

CREATE TABLE BDR_MI_VV_SEL_TB 
   (DIM_START_DATUM     		TIMESTAMP, 
    DIM_EIND_DATUM      		TIMESTAMP, 
    CLASSID             		VARCHAR2(99),
    OBJECTID            		VARCHAR2(99),
    BEDRAG_GRIFFIERECHT 		NUMBER,
    BEDRAG_PROCESKOSTEN 		NUMBER,
    BEDRAG_SCHADEVERGOEDING 		NUMBER,
    CODE_GESCHIL_1          		VARCHAR2(99),
    CODE_GESCHIL_2        		VARCHAR2(99),
    DT_INTREKKING    			DATE,
    EINDDT_ZAAK          		DATE,
    INDIENER				VARCHAR2(99),
    KENMERK_PRIM_BESL_1			VARCHAR2(99),
    KENMERK_PRIM_BESL_2			VARCHAR2(99),
    MEDISCH_ARBEIDSKUNDIG		NUMBER,
    REDEN_INTREKKING		        VARCHAR2(99),
    STARTDT_ZAAK			DATE,
    TEAM				VARCHAR2(99),
    KANTOORNAAM				VARCHAR2(99),
    US_DICTUM_UITSPRAAK			VARCHAR2(999),
    US_DT_UITSPRAAK			DATE,
    US_VERZ_DT_UITSPRAAK		DATE,
    WET					VARCHAR2(99),
    GRIFFIERECHT_BETALEN		NUMBER,
    INLOGNAAM_MBR			VARCHAR2(99),
    STATUS				VARCHAR2(99),
    PROCESKOSTEN_BETALEN		NUMBER,
    ZITTING				NUMBER,
    VERWIJDERD				NUMBER,
    REGISTRATIENUMMER		        VARCHAR2(99),
    ERD                                 NUMBER
) compress for oltp;