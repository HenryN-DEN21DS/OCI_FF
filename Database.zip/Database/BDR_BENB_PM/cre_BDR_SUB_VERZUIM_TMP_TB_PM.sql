﻿-- Naam  : cre_BDR_SUB_VERZUIM_TMP_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SUB_VERZUIM_TMP_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_sub_verzuim_tmp_tb') loop
            execute immediate 'drop table bdr_sub_verzuim_tmp_tb';
    end loop;
end;
/

create table bdr_sub_verzuim_tmp_tb
(
    dim_start_datum                 timestamp not null,
    dim_sub_verzuim_key             varchar2(99) not null,
    dim_md5			    char(32),
    dim_datum_start_proces_id       number,
    dim_datum_eind_proces_id        number,
    dim_datum_verzuim_hersteld_id   number,
    dim_datum_start_verzuim_id      number,
    verzuim_reden_gronden           number,
    verzuim_reden_handtekening      number,
    verzuim_reden_machtiging        number,
    verzuim_reden_naam_indiener     number,
    verzuim_reden_oms_besluit       number,
    verzuim_reden_splits_medisch    number,
    verzuim_reden_stukken           number,
    verzuim_reden_te_laat           number,
    dim_bezwaar_key                 varchar2(99),
    verzuim_status		    varchar2(99),
    verzuim_hersteld_status         varchar2(99),
    aantal_verzuim                  number,
    verzuim_termijn                 number,
    dim_junk_id			    number
) compress for oltp;