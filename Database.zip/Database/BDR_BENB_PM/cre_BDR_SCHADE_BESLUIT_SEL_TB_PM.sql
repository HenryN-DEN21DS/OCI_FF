﻿-- Naam  : cre_BDR_SCHADE_BESLUIT_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SCHADE_BESLUIT_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_schade_besluit_sel_tb') loop
            execute immediate 'drop table bdr_schade_besluit_sel_tb';
    end loop;
end;
/

CREATE TABLE BDR_SCHADE_BESLUIT_SEL_TB
(
    DIM_SCHADE_BESLUIT_KEY          VARCHAR2(99) NOT NULL,
    DIM_START_DATUM                 TIMESTAMP NOT NULL,
    BRIEF_PRIM_BESLISSING           VARCHAR2(99),
    GESCHIL1                        VARCHAR2(99),
    GESCHIL2                        VARCHAR2(99),
    KANTOOR                         VARCHAR2(99),
    JUNK                            VARCHAR2(9),
    WET                             VARCHAR2(99),
    INDIENER                        VARCHAR2(99),
    PRIM_BESLISSING1                VARCHAR2(99),
    PRIM_BESLISSING2                VARCHAR2(99),
    PRIM_AFDELING                   VARCHAR2(999),
    RESULTAAT_AFHAND                VARCHAR2(99),  
    DATUM_ONTVANGST_MACHT           NUMBER,
    DATUM_ONTVANGST_VERZOEK         NUMBER,
    DATUM_PRIM_BESLISSING      	    NUMBER,
    DATUM_UITERLIJKE_AFHAND         NUMBER,
    DATUM_START_ZAAK                NUMBER,
    DATUM_EINDE_ZAAK                NUMBER,
    KENMERK_SCHADEBESLUIT           VARCHAR2(999),
    INLOGNAAM_MB                    VARCHAR2(99),
    CLAIM_BEDRAG                    NUMBER(38,10),
    SCHADE_BEDRAG                   NUMBER(38,10)
) COMPRESS FOR OLTP;
