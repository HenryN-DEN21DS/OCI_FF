﻿-- Naam  : cre_BDR_VOORLOPIGE_VOORZIENING_DELTA_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_VOORLOPIGE_VOORZIENING_DELTA_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 30-11-2022 mwo096 Toevoeging datamodel
-- 27-07-2022 jsc226 Wijzigen INLOGNAAM_MBR naar DIM_JURIDISCH_MDW_ID
-- 18-07-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_voorlopige_voorziening_delta_tb') loop
            execute immediate 'drop table bdr_voorlopige_voorziening_delta_tb';
    end loop;
end;
/

create table BDR_VOORLOPIGE_VOORZIENING_DELTA_TB
(
    DIM_VOORLOPIGE_VOORZIENING_ID 	NUMBER,
    DIM_VOORLOPIGE_VOORZIENING_KEY      VARCHAR2(99) NOT NULL,
    DIM_START_DATUM             	TIMESTAMP NOT NULL,
    DIM_MD5                     	CHAR(32) NOT NULL, 
    BEDRAG_GRIFFIERECHT			NUMBER,
    BEDRAG_PROCESKOSTEN			NUMBER,
    BEDRAG_SCHADEVERGOEDING		NUMBER,
    DIM_GESCHIL_1_ID            	NUMBER,
    DIM_GESCHIL_2_ID            	NUMBER,
    DIM_DATUM_INTREKKING_ID		NUMBER,
    DIM_DATUM_EIND_ZAAK_ID		NUMBER,
    DIM_INDIENER_TYPE_ID		NUMBER,
    DIM_KENMERK_PB_1_ID         	NUMBER,
    DIM_KENMERK_PB_2_ID         	NUMBER,
    DIM_JUNK_ID				NUMBER,
    DIM_JURIDISCH_MDW_ID                NUMBER,
    REDEN_INTREKKING			VARCHAR(99),
    DIM_DATUM_START_ZAAK_ID		NUMBER,
    DIM_KANTOOR_ID			NUMBER,
    DIM_DICTUM_ID			NUMBER,
    DIM_DATUM_DICTUM_ID			NUMBER,
    DIM_DATUM_VERZENDING_UITSPRAAK_ID 	NUMBER,
    DIM_WET_ID				NUMBER,
    GRIFFIERECHT_BETALEN		NUMBER,
    PROCESKOSTEN_BETALEN		NUMBER,
    ZITTING				NUMBER,
    REGISTRATIENUMMER                   VARCHAR2(99),
    ERD                                 NUMBER
) compress for oltp
;
