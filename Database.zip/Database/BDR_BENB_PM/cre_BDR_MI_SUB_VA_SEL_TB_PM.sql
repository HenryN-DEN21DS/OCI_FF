﻿-- Naam  : cre_BDR_MI_SUB_VA_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_MI_SUB_VA_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 20-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_sub_va_sel_tb') loop
            execute immediate 'drop table bdr_mi_sub_va_sel_tb';
    end loop;
end;
/

create table bdr_mi_sub_va_sel_tb
(
    dim_start_datum     		timestamp,
    dim_eind_datum      		timestamp,
    classid             		varchar2(9),
    objectid            		varchar2(99),
    afgesproken_einddt  		date,
    dt_start_proces     		date,
    einddt_proces       		date, 
    team                		varchar2(99),
    kantoornaam         		varchar2(99),
    classid_parent      		varchar2(9),
    objectid_parent     		varchar2(99),
    sequentienummer     		number,
    procesnaam          		varchar2(9),
    procesnaam_parent   		varchar2(9),
    externe_expertise   		number,
    informatie_curatieve_sector 	number,
    usr_contrasign_rapp			varchar2(999),
    usr_contrasign_extra_rapp  		varchar2(999),
    va_bb_geannuleerd                   number,
    soort_inschakeling_omschrijving 	varchar2(99),
    registratienummer			varchar2(99)
) compress for oltp;