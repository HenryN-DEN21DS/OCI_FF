﻿-- Naam  : cre_BDR_MI_SMO_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_MI_SMO_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 25-07-2022 mle134 Toevoegen INLOGNAAM_MB
-- 27-06-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_smo_sel_tb') loop
            execute immediate 'drop table bdr_mi_smo_sel_tb';
    end loop;
end;
/

CREATE TABLE BDR_MI_SMO_SEL_TB 
   (	DIM_START_DATUM TIMESTAMP, 
	DIM_EIND_DATUM TIMESTAMP , 
	CLASSID VARCHAR2(9), 
	OBJECTID VARCHAR2(99), 
	KOSTEN_MED_INFORMATIE NUMBER, 
	DATUM_SMO_AFGEROND DATE, 
	DATUM_START_BENB DATE, 
	DATUM_UITERSTE_AFH DATE, 
	EINDDT_ZAAK DATE, 
	KOSTENPLAATS VARCHAR2(99), 
	MED_INFORMATIE NUMBER, 
	NAAM_GEFACTUREERDE VARCHAR2(999), 
	RESULTAAT_PROCEDURE VARCHAR2(999), 
	SOORT_ZAAK VARCHAR2(99), 
	STATUS VARCHAR2(99), 
	VERWIJDERD NUMBER, 
	STARTDT_ZAAK DATE, 
	TEAM VARCHAR2(99), 
	KANTOOR VARCHAR2(99),
        INLOGNAAM_MB VARCHAR2(99)
) compress for oltp;