﻿-- Naam  : cre_BDR_BRIDGE_TMP_TB_PM.sql
-- Datum : 24-05-2022
-- Doel  : Script voor het creëeren van de BRIDGE tmp tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 24-05-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_bridge_tmp_tb') loop
            execute immediate 'drop table bdr_bridge_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_BRIDGE_TMP_TB 
(	
  DIM_BRIDGE_KEY VARCHAR2(999), 
  DIM_BEZWAAR_KEY VARCHAR2(99), 
  DIM_BEROEP_KEY VARCHAR2(99), 
  DIM_HOGER_BEROEP_KEY VARCHAR2(99),
  DIM_START_DATUM TIMESTAMP, 
  DIM_EIND_DATUM TIMESTAMP
) compress for oltp;