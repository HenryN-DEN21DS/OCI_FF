﻿-- Naam  : cre_BDR_SUB_VERDAGEN_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SUB_VERDAGEN_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 28-06-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_sub_verdagen_sel_tb') loop
            execute immediate 'drop table bdr_sub_verdagen_sel_tb';
    end loop;
end;
/

create table BDR_SUB_VERDAGEN_SEL_TB
(
    DIM_SUB_VERDAGEN_KEY      VARCHAR2(99),
    DIM_START_DATUM           TIMESTAMP,
    DATUM_EIND_VOOR_VERDAGEN  NUMBER,
    DATUM_EIND_NA_VERDAGEN    NUMBER,
    BEZWAAR                   VARCHAR2(99),
    VERDAGEN_TOESTEMMING      VARCHAR2(99),
    DT_VERZEND_VDBRIEF_INDIENER NUMBER,
    JUNK		      VARCHAR2(99)
) compress for oltp;