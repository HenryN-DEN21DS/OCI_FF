﻿-- Naam  : cre_BDR_MI_SUB_VA_SEQ_MED_ONDERZOEK_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_MI_SUB_VA_SEQ_MED_ONDERZOEK_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 20-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_sub_va_seq_med_onderzoek_sel_tb') loop
            execute immediate 'drop table bdr_mi_sub_va_seq_med_onderzoek_sel_tb';
    end loop;
end;
/

create table bdr_mi_sub_va_seq_med_onderzoek_sel_tb
(
  dim_start_datum           	timestamp,
  dim_eind_datum            	timestamp,
  classid                   	varchar2(9),
  objectid                  	varchar2(99),
  soort_med_onderzoek   	varchar2(9),
  datum_med_onderzoek       	date,
  geannuleerd			number
) compress for oltp;	