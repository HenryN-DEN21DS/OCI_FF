-- Naam  : cre_BDR_WET_DELTA_TB_PM.sql
-- Datum : 28-07-2022
-- Doel  : Script voor het cre�eren van de wet delta tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 28-07-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_wet_delta_tb') loop
            execute immediate 'drop table bdr_wet_delta_tb';
    end loop;
end;
/

CREATE TABLE BDR_WET_DELTA_TB 
   (	
        DIM_WET_ID         NUMBER, 
	DIM_WET_KEY        VARCHAR2(99) NOT NULL, 
	DIM_START_DATUM    TIMESTAMP (6) NOT NULL, 
	DIM_MD5            VARCHAR2(99) NOT NULL, 
	CODE               VARCHAR2(99) NOT NULL, 
	OMSCHRIJVING       VARCHAR2(99), 
	WET_GROEP          VARCHAR2(99),
	GELDIG_VAN         DATE, 
	GELDIG_TOT         DATE
   ) compress for oltp;

 ALTER TABLE BDR_WET_DELTA_TB ADD CONSTRAINT BDR_WET_DELTA_TB_AK UNIQUE (DIM_WET_KEY, DIM_START_DATUM);