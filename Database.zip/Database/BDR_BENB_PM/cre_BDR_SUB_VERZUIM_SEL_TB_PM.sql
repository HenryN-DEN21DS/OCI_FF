﻿-- Naam  : cre_BDR_SUB_VERZUIM_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SUB_VERZUIM_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_sub_verzuim_sel_tb') loop
            execute immediate 'drop table bdr_sub_verzuim_sel_tb';
    end loop;
end;
/

create table bdr_sub_verzuim_sel_tb
(
    dim_start_datum                 timestamp,
    dim_sub_verzuim_key             varchar2(99),
    verzuim_termijn                 number,
    datum_start_proces              number,
    datum_eind_proces               number,
    datum_verzuim_hersteld          number,
    datum_start_verzuim             number,
    verzuim_reden_gronden           number,
    verzuim_reden_handtekening      number,
    verzuim_reden_machtiging        number,
    verzuim_reden_naam_indiener     number,
    verzuim_reden_oms_besluit       number,
    verzuim_reden_splits_medisch    number,
    verzuim_reden_stukken           number,
    verzuim_reden_te_laat           number,
    dim_bezwaar_key                 varchar2(99),
    verzuim_status		    varchar2(99),
    verzuim_hersteld_status         varchar2(99),
    junk			    varchar2(99)
) compress for oltp;
