﻿-- Naam  : cre_BDR_PROCES_TYPE_TMP_TB_PM.sql
-- Datum : 19-04-2022
-- Doel  : Script voor het creëeren van de tijdelijke proces type tussentabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 19-04-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_proces_type_tmp_tb') loop
            execute immediate 'drop table bdr_proces_type_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_PROCES_TYPE_TMP_TB
(
  DIM_PROCES_TYPE_KEY       VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM           TIMESTAMP (6) NOT NULL, 
  DIM_MD5                   VARCHAR2(99) NOT NULL,
  PROCES_TYPE_CODE          NUMBER,
  BZ_IND		    VARCHAR2(9),
  BR_IND		    VARCHAR2(9),
  HB_IND		    VARCHAR2(9),
  PROCES_TYPE_OMSCHRIJVING  VARCHAR2(99)
) compress for oltp;
   
ALTER TABLE BDR_PROCES_TYPE_TMP_TB ADD CONSTRAINT BDR_PROCES_TYPE_TMP_TB_PK PRIMARY KEY (DIM_PROCES_TYPE_KEY, DIM_START_DATUM);
