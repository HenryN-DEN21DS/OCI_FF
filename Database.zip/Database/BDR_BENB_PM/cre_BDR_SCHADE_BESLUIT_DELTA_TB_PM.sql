﻿-- Naam  : cre_BDR_SCHADE_BESLUIT_DELTA_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SCHADE_BESLUIT_DELTA_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 27-07-2022 jsc226 Wijzigen INLOGNAAM_MB naar DIM_JURIDISCH_MDW_ID
-- 12-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_schade_besluit_delta_tb') loop
            execute immediate 'drop table bdr_schade_besluit_delta_tb';
    end loop;
end;
/

CREATE TABLE BDR_SCHADE_BESLUIT_DELTA_TB
(
    DIM_SCHADE_BESLUIT_ID           NUMBER,
    DIM_SCHADE_BESLUIT_KEY          VARCHAR2(99) NOT NULL,
    DIM_START_DATUM                 TIMESTAMP NOT NULL,
    DIM_MD5                         CHAR(32) NOT NULL,
    DIM_WET_ID                      NUMBER,
    DIM_BRIEF_PRIM_BESLISSING_ID    NUMBER,
    DIM_GESCHIL1_ID                 NUMBER,
    DIM_GESCHIL2_ID                 NUMBER,
    DIM_PRIM_BESLISSING1_ID         NUMBER,
    DIM_PRIM_BESLISSING2_ID         NUMBER,
    DIM_PRIM_AFDELING_ID            NUMBER,
    DIM_KANTOOR_ID                  NUMBER,
    DIM_JUNK_ID                     NUMBER,
    DIM_INDIENER_TYPE_ID            NUMBER,  
    DIM_RESULTAAT_AFHAND_ID         NUMBER,
    DIM_JURIDISCH_MDW_ID            NUMBER,
    DIM_DATUM_ONTVANGST_MACHT_ID    NUMBER,
    DIM_DATUM_ONTVANGST_VERZOEK_ID  NUMBER,
    DIM_DATUM_PRIM_BESLISSING_ID    NUMBER,
    DIM_DATUM_UITERLIJK_AFHAND_ID   NUMBER,
    DIM_DATUM_START_ZAAK_ID         NUMBER,
    DIM_DATUM_EINDE_ZAAK_ID         NUMBER,
    KENMERK_SCHADEBESLUIT           VARCHAR2(99),
    CLAIM_BEDRAG                    NUMBER(38,10),
    SCHADE_BEDRAG                   NUMBER(38,10),
    AANTAL_SCHADE_BESLUIT           NUMBER
) COMPRESS FOR OLTP;
