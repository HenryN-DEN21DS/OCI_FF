﻿-- Naam  : cre_BDR_KANTOOR_DELTA_TB_PM.sql
-- Datum : 23-12-2021
-- Doel  : Script voor het creëeren van de KANTOOR delta tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-12-2021 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_kantoor_delta_tb') loop
            execute immediate 'drop table bdr_kantoor_delta_tb';
    end loop;
end;
/

CREATE TABLE BDR_KANTOOR_DELTA_TB

(        
  DIM_KANTOOR_ID          NUMBER,
  DIM_KANTOOR_KEY         VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM         TIMESTAMP (6) NOT NULL, 
  DIM_MD5                 VARCHAR2(99) NOT NULL,
  KANTOOR_ID              VARCHAR2(99),
  KANTOOR_NAAM            VARCHAR2(999),
  KANTOOR_NUMMER          NUMBER,
  TEAM_ID                 VARCHAR2(99),
  TEAM_NAAM               VARCHAR2(99),
  KANTOORDISTRICT         VARCHAR2(99),
  KANTOORDISTRICTGEBIED   VARCHAR2(99)
) compress for oltp;

ALTER TABLE BDR_KANTOOR_DELTA_TB ADD CONSTRAINT BDR_KANTOOR_DELTA_TB_PK PRIMARY KEY (DIM_KANTOOR_KEY, DIM_START_DATUM);
