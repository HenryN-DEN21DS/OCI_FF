﻿-- Naam  : cre_BDR_MI_SB_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_MI_SB_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 12-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_sb_sel_tb') loop
            execute immediate 'drop table bdr_mi_sb_sel_tb';
    end loop;
end;
/

CREATE TABLE BDR_MI_SB_SEL_TB 
   (	DIM_START_DATUM 		TIMESTAMP, 
	DIM_EIND_DATUM 			TIMESTAMP , 
	CLASSID 			VARCHAR2(9), 
	OBJECTID 			VARCHAR2(99), 
    	BRIEFCODE_BESLISSING_PRIMAIR    VARCHAR2(99),
    	CODE_GESCHIL_1                  VARCHAR2(99),
   	CODE_GESCHIL_2                  VARCHAR2(99),
   	DT_ONTVANGST_MACHT              DATE,
   	DT_ONTVANGST_VERZOEK            DATE,
    	DT_PRIMAIRE_BESLISSING          DATE,
    	DT_UITERLIJKE_AFHANDELING       DATE,
    	EINDDT_ZAAK                     DATE,
    	INDIENER                        VARCHAR2(99),
    	INLOGNAAM_MB                    VARCHAR2(99),
    	KENMERK_PRIM_BESL_1             VARCHAR2(99),
    	KENMERK_PRIM_BESL_2             VARCHAR2(99),
    	KENMERK_SCHADEBESLUIT           VARCHAR2(999),
    	NAAM_PRIM_AFDELING              VARCHAR2(999),
    	RESULTAAT_AFHANDELING           VARCHAR2(99),   
    	STARTDT_ZAAK                    DATE,
    	STATUS                          VARCHAR2(99),
        VERWIJDERD			NUMBER,
    	TEAM                            VARCHAR2(99),
    	KANTOOR                         VARCHAR2(99),
    	WET                             VARCHAR2(99),
    	CLAIM_BEDRAG                    NUMBER(38,10),
    	SCHADE_BEDRAG                   NUMBER(38,10)
) compress for oltp;