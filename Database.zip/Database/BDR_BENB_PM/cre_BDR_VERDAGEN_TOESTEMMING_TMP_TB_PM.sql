﻿-- Naam  : cre_BDR_VERDAGEN_TOESTEMMING_TMP_TB_PM.sql
-- Datum : 23-06-2022
-- Doel  : Script voor het creëeren van de tijdelijke verdagen toestemming tussen tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-06-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_verdagen_toestemming_tmp_tb') loop
            execute immediate 'drop table bdr_verdagen_toestemming_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_VERDAGEN_TOESTEMMING_TMP_TB
(
  DIM_VERDAGEN_TOESTEMMING_KEY  VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM               TIMESTAMP (6) NOT NULL, 
  DIM_MD5                       VARCHAR2(99) NOT NULL,
  TOESTEMMING_VEREISTE          VARCHAR2(99),
  TOESTEMMING_TYPE              VARCHAR2(99),
  TOESTEMMING                   VARCHAR2(99)
) compress for oltp;
   
ALTER TABLE BDR_VERDAGEN_TOESTEMMING_TMP_TB ADD CONSTRAINT BDR_VERDAGEN_TOESTEMMING_TMP_TB_PK PRIMARY KEY (DIM_VERDAGEN_TOESTEMMING_KEY, DIM_START_DATUM);
