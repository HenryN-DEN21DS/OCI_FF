﻿-- Naam  : cre_BDR_SMO_DELTA_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SMO_DELTA_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 27-07-2022 jsc226 Toevoegen DIM_JURIDISCH_MDW_ID
-- 22-06-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_smo_delta_tb') loop
            execute immediate 'drop table bdr_smo_delta_tb';
    end loop;
end;
/

create table BDR_SMO_DELTA_TB
(
    DIM_SMO_ID 			NUMBER,
    DIM_SMO_KEY              	VARCHAR2(99) NOT NULL,
    DIM_START_DATUM          	TIMESTAMP NOT NULL,
    DIM_MD5                     CHAR(32) NOT NULL, 
    DIM_DATUM_START_ZAAK_ID     NUMBER,
    DIM_DATUM_EINDE_ZAAK_ID     NUMBER,
    DIM_DATUM_SMO_AFGEROND_ID   NUMBER,
    DIM_DATUM_START_BENB_ID     NUMBER,
    DIM_DATUM_UITERSTE_AFH_ID   NUMBER,
    DIM_JUNK_ID                	NUMBER,
    DIM_KANTOOR_ID              NUMBER,
    DIM_JURIDISCH_MDW_ID        NUMBER,
    SOORT_ZAAK              	VARCHAR2(99),
    RESULTAAT_PROCEDURE         VARCHAR2(999),
    KOSTENPLAATS            	VARCHAR2(99),
    MED_INFORMATIE          	NUMBER,
    NAAM_GEFACTUREERDE      	VARCHAR2(999),
    KOSTEN_MED_INFORMATIE   	NUMBER,
    AANTAL_SMO			        NUMBER
) compress for oltp
;
