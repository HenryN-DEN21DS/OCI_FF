﻿-- Naam  : cre_BDR_MI_SUB_HZ_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_MI_SUB_HZ_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-07-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_mi_sub_hz_sel_tb') loop
            execute immediate 'drop table bdr_mi_sub_hz_sel_tb';
    end loop;
end;
/

CREATE TABLE BDR_MI_SUB_HZ_SEL_TB 
   (DIM_START_DATUM            TIMESTAMP, 
    DIM_EIND_DATUM             TIMESTAMP, 
    CLASSID                    VARCHAR2(99),
    OBJECTID                   VARCHAR2(99),
    CLASSID_PARENT             VARCHAR2(99),
    OBJECTID_PARENT            VARCHAR2(99),
    SEQUENTIENUMMER            NUMBER,
    DT_HOORZITTING             DATE,
    DT_START_PROCES            DATE,
    TEAM                       VARCHAR2(99),
    KANTOORNAAM                VARCHAR2(99),
    HZ_GEANNULEERD             NUMBER,
    HZ_NIET_DOORGEGAAN         NUMBER,
    VA_BB_AANWEZIG             NUMBER,
    AD_BB_AANWEZIG             NUMBER,
    PROCESNAAM_PARENT          VARCHAR2(99),
    AD_BB_CODE                 VARCHAR2(99),
    VA_BB_CODE                 VARCHAR2(99),
    VERSLAGLEGGER_CODE         VARCHAR2(99),
    HOORDER_CODE               VARCHAR2(99),
    EINDDT_PROCES              DATE,
    DT_TOEZENDEN_VERSLAG_VERZ  DATE,
    REGISTRATIENUMMER VARCHAR2(99)
) compress for oltp;