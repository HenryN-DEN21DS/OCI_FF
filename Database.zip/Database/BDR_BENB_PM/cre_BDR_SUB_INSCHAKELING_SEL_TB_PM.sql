﻿-- Naam  : cre_BDR_SUB_INSCHAKELING_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_SUB_INSCHAKELINGEN_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-07-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_sub_inschakeling_sel_tb') loop
            execute immediate 'drop table bdr_sub_inschakeling_sel_tb';
    end loop;
end;
/

create table bdr_sub_inschakeling_sel_tb
(
    dim_sub_inschakeling_key        varchar2(99) not null,
    dim_start_datum                 timestamp not null,
    datum_afgesproken_eind     	    number,
    datum_start_proces              number,
    datum_eind_proces               number,
    datum_med_onderzk_ltst          number,
    kantoor                         varchar2(99),
    sequentienummer		    number,
    proceskey_parent                varchar2(99),
    externe_expertise               number,
    informatie_curatieve_sector     number,
    medisch_onderzoek               varchar2(9),
    procesnaam                      varchar2(9),  
    procesnaam_parent               varchar2(9), 
    soort_inschakeling_oms          varchar2(99),
    contrasigneren_status           varchar2(99),
    registratienummer		    varchar2(99),
    junk			    varchar2(99)
) compress for oltp;
