﻿-- Naam  : cre_BDR_GESCHIL_DELTA_TB_PM.sql
-- Datum : 04-01-2022
-- Doel  : Script voor het creëeren van de geschil delta tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 04-01-2022 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_geschil_delta_tb') loop
            execute immediate 'drop table bdr_geschil_delta_tb';
    end loop;
end;
/

CREATE TABLE BDR_GESCHIL_DELTA_TB

(        
  DIM_GESCHIL_ID         NUMBER,
  DIM_GESCHIL_KEY        VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM        TIMESTAMP (6) NOT NULL, 
  DIM_MD5                VARCHAR2(99) NOT NULL,
  GESCHIL_CODE           VARCHAR2(9),
  GESCHIL_OMSCHRIJVING   VARCHAR(999)
) compress for oltp;

ALTER TABLE BDR_GESCHIL_DELTA_TB ADD CONSTRAINT BDR_GESCHIL_DELTA_TB_PK PRIMARY KEY (DIM_GESCHIL_KEY, DIM_START_DATUM);
