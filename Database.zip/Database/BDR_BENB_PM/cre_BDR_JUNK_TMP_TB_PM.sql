﻿-- Naam  : cre_BDR_JUNK_TMP_TB_PM.sql
-- Datum : 19-04-2022
-- Doel  : Script voor het creëeren van de tijdelijke junk tussentabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 19-04-2022 tgr033 Aangepast t.b.v. iteratie 2
-- 22-12-2021 jsc226 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_junk_tmp_tb') loop
            execute immediate 'drop table bdr_junk_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_JUNK_TMP_TB
(
  DIM_JUNK_KEY               VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM            TIMESTAMP (6) NOT NULL, 
  DIM_MD5                    VARCHAR2(99) NOT NULL,
  MED_ARBEIDS_DESKUNDIGE_IND VARCHAR2(9),
  MED_ARBEIDS_DESKUNDIGE_OMS VARCHAR2(99),
  STATUS_CODE		     VARCHAR2(9),
  STATUS_OMS                 VARCHAR2(99),
  VERWIJDERD_CODE	     VARCHAR2(9),
  VERWIJDERD_OMS	     VARCHAR2(99),
  GEANNULEERD_CODE	     VARCHAR2(9),
  GEANNULEERD_OMS	     VARCHAR2(99)
) compress for oltp;
   
ALTER TABLE BDR_JUNK_TMP_TB ADD CONSTRAINT BDR_JUNK_TMP_TB_PK PRIMARY KEY (DIM_JUNK_KEY, DIM_START_DATUM);
