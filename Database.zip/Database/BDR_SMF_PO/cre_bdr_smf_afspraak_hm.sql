------------------------------------------------------------------------------
-- Naam  : cre_bdr_smf_afspraak_hm.sql
-- Datum : 30-03-2023 
-- Doel  : Script voor aanmaken van gegevensvensters. 
-- -- Datum      Naam   Omschrijving 
-- ---------- ------ ------------------------------------------------------------ 
-- 28-06-2023 rha163 Aangemaakt 
-- ------------------------------------------------------------------------------
  
 
 
define  Dbs = null 
column  Dbs noprint new_value Dbs 
select  upper(instance_name) Dbs 
from    v$instance; 
spool   cre_bdr_smf_afspraak_hm_Dbs..lst 
set     ver off 
begin 
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW'  and upper(object_name) = 'SMF_AFSPRAAK_HM') loop 
            execute immediate 'drop materialized view BDR_SMF_PO.SMF_AFSPRAAK_HM'; 
    end loop; 
end; 
/ 

CREATE MATERIALIZED  VIEW  SMF_AFSPRAAK_HM
 PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
AS
SELECT 
    DIM_START_DATUM		
   ,DIM_EIND_DATUM		
   ,DIM_RECENT_IND		
   ,DIM_STATUS		
   ,DIM_BRON		
   ,DIM_ARCHIEFVERNIETIGING_STATUS		
   ,DIM_DATUM_AANMAAK		
   ,DIM_USER_AANMAAK		
   ,DIM_DATUM_GEWIJZIGD		
   ,DIM_USER_GEWIJZIGD		
   ,SMF_CASUS_ID		
   ,STARTDATUM_TIJD		
   ,ONDERZOEKS_ID		
   ,VERSION		
   ,STATUS_AFSPRAAK_SMF		
   ,PUIK_ID_VA		
   ,LOKATIE		
   ,NAAM_REG		
   ,PUIK_ID_SMV		
   ,PUIK_ID_MS		
   ,LAATST_BIJGEWERKT_OP		
   ,ID		
   ,E_AFSPRAAK_ID		
   ,TYPE_ONDERZOEK		
   ,PUIK_ID_AD		
   ,STATUS_AFSPRAAK_E_AFSPRAAK		
   ,NAAM_AD		
   ,NAAM_VA		
   ,PUIK_ID_REG		
   ,CONTACT_TYPE		
   ,NAAM_SMV		
   ,NAAM_MS		
FROM OKV_SMF_PO.OKV_SMF_AFSPRAAK_HV
;		
spo off 	
column Dbs clear 	
-- End of script --	

