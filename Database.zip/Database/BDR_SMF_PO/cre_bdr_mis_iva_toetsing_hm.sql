------------------------------------------------------------------------------
-- Naam  : cre_bdr_mis_iva_toetsing_hm.sql
-- Datum : 30-03-2023 
-- Doel  : Script voor aanmaken van gegevensvensters. 
-- -- Datum      Naam   Omschrijving 
-- ---------- ------ ------------------------------------------------------------ 
-- 28-06-2023 rha163 Aangemaakt 
-- ------------------------------------------------------------------------------
 
 
 
define  Dbs = null 
column  Dbs noprint new_value Dbs 
select  upper(instance_name) Dbs 
from    v$instance; 
spool   cre_bdr_mis_iva_toetsing_hm_Dbs..lst 
set     ver off 
begin 
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW'  and upper(object_name) = 'MIS_IVA_TOETSING_HM') loop 
            execute immediate 'drop materialized view BDR_SMF_PO.MIS_IVA_TOETSING_HM'; 
    end loop; 
end; 
/ 

CREATE MATERIALIZED  VIEW  MIS_IVA_TOETSING_HM
 PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
AS
SELECT 
    DIM_START_DATUM		
   ,DIM_EIND_DATUM		
   ,DIM_RECENT_IND		
   ,DIM_STATUS		
   ,DIM_BRON		
   ,DIM_ARCHIEFVERNIETIGING_STATUS		
   ,DIM_DATUM_AANMAAK		
   ,DIM_USER_AANMAAK		
   ,DIM_DATUM_GEWIJZIGD		
   ,DIM_USER_GEWIJZIGD		
   ,PCS_ID		
   ,DATUM_ONTVANGST_IVA		
   ,REDEN_IVA_NIET_AKKOORD		
   ,IND_IVA_BEOORDEELD		
   ,IVA_SVA		
   ,ID		
   ,DATUM_VERZEND_IVA		
   ,IND_IVA_AKKOORD		
   ,DATUM_IVA_BEOORDEELD		
   ,IVA_SAD		
FROM OKV_SMF_PO.OKV_MIS_IVA_TOETSING_HV
;		
spo off 	
column Dbs clear 	
-- End of script --	

