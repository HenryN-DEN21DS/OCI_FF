------------------------------------------------------------------------------
-- Naam  : cre_bdr_mis_info_uitstel_hm.sql
-- Datum : 30-03-2023 
-- Doel  : Script voor aanmaken van gegevensvensters. 
-- -- Datum      Naam   Omschrijving 
-- ---------- ------ ------------------------------------------------------------ 
-- 28-06-2023 rha163 Aangemaakt 
-- ------------------------------------------------------------------------------
  
 
 
define  Dbs = null 
column  Dbs noprint new_value Dbs 
select  upper(instance_name) Dbs 
from    v$instance; 
spool   cre_bdr_mis_info_uitstel_hm_Dbs..lst 
set     ver off 
begin 
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW'  and upper(object_name) = 'MIS_INFO_UITSTEL_HM') loop 
            execute immediate 'drop materialized view BDR_SMF_PO.MIS_INFO_UITSTEL_HM'; 
    end loop; 
end; 
/ 

CREATE MATERIALIZED  VIEW  MIS_INFO_UITSTEL_HM
 PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
AS
SELECT 
    DIM_START_DATUM		
   ,DIM_EIND_DATUM		
   ,DIM_RECENT_IND		
   ,DIM_STATUS		
   ,DIM_BRON		
   ,DIM_ARCHIEFVERNIETIGING_STATUS		
   ,DIM_DATUM_AANMAAK		
   ,DIM_USER_AANMAAK		
   ,DIM_DATUM_GEWIJZIGD		
   ,DIM_USER_GEWIJZIGD		
   ,PCS_ID		
   ,VOLGNR_INFO_UITSTEL		
   ,UITSTELVORM		
   ,DATUM_VERSTUURD_INFO		
   ,DATUM_ONTVANGST_INFO		
   ,DATUM_AANVANG_UITSTEL		
   ,DATUM_VERSTUURD_RAPPEL		
   ,AANTAL_RAPPEL		
   ,ID		
   ,SOORT_INFO_UITSTEL		
   ,NAAM_INFO_UITSTEL		
   ,AANTAL_DAGEN_INFO_UITSTEL		
   ,DATUM_VERWACHT_INFO		
   ,DATUM_ANNULEREN		
   ,DATUM_EINDE_UITSTEL		
   ,DATUM_VERWACHT_RAPPEL		
FROM OKV_SMF_PO.OKV_MIS_INFO_UITSTEL_HV
;		
spo off 	
column Dbs clear 	
-- End of script --	
