------------------------------------------------------------------------------
-- Naam  : cre_bdr_casus_behandelrelatie_hm.sql
-- Datum : 30-03-2023 
-- Doel  : Script voor aanmaken van gegevensvensters. 
-- -- Datum      Naam   Omschrijving 
-- ---------- ------ ------------------------------------------------------------ 
-- 28-06-2023 rha163 Aangemaakt 
-- ------------------------------------------------------------------------------
  
 
 
define  Dbs = null 
column  Dbs noprint new_value Dbs 
select  upper(instance_name) Dbs 
from    v$instance; 
spool   cre_bdr_casus_behandelrelatie_hm._Dbs..lst 
set     ver off 
begin 
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW'  and upper(object_name) = 'CASUS_BEHANDELRELATIE_HM') loop 
            execute immediate 'drop materialized view BDR_SMF_PO.CASUS_BEHANDELRELATIE_HM'; 
    end loop; 
end; 
/ 

CREATE MATERIALIZED  VIEW  CASUS_BEHANDELRELATIE_HM
 PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
AS
SELECT 
    DIM_START_DATUM		
   ,DIM_EIND_DATUM		
   ,DIM_RECENT_IND		
   ,DIM_STATUS		
   ,DIM_BRON		
   ,DIM_ARCHIEFVERNIETIGING_STATUS		
   ,DIM_DATUM_AANMAAK		
   ,DIM_USER_AANMAAK		
   ,DIM_DATUM_GEWIJZIGD		
   ,DIM_USER_GEWIJZIGD		
   ,VOLGNUMMER		
   ,KANTOORNUMMER		
   ,PB_ID		
   ,IND_ACTIEF		
   ,SOORT_OVERDRACHT		
   ,DAT_CREATIE		
   ,OBJ_VERSION		
   ,SMF_CASUS_ID		
   ,PUIKID		
   ,TEAMNUMMER		
   ,TO_ID		
   ,IND_REGIE		
   ,DATUM_TIJD_OVERDRACHT		
   ,DAT_MUTATIE		
FROM OKV_SMF_PO.OKV_CASUS_BEHANDELRELATIE_HV
;		
spo off 	
column Dbs clear 	

-- End of script --


