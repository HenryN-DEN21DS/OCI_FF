-----------------------------------------------------------------------------
-- Naam  : cre_bdr_mis_casus_signaal_codes_hm.sql 
-- Datum : 30-03-2023 
-- Doel  : Script voor aanmaken van gegevensvensters. 
-- -- Datum      Naam   Omschrijving 
-- ---------- ------ ------------------------------------------------------------ 
-- 28-06-2023 rha163 Aangemaakt 
-- ------------------------------------------------------------------------------
  
 
 
define  Dbs = null 
column  Dbs noprint new_value Dbs 
select  upper(instance_name) Dbs 
from    v$instance; 
spool   cre_bdr_mis_casus_signaal_codes_hm_Dbs..lst 
set     ver off 
begin 
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW'  and upper(object_name) = 'MIS_CASUS_SIGNAAL_CODES_HM') loop 
            execute immediate 'drop materialized view BDR_SMF_PO.MIS_CASUS_SIGNAAL_CODES_HM'; 
    end loop; 
end; 
/ 

CREATE MATERIALIZED  VIEW  MIS_CASUS_SIGNAAL_CODES_HM
 PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
AS
SELECT 
    DIM_START_DATUM		
   ,DIM_EIND_DATUM		
   ,DIM_RECENT_IND		
   ,DIM_STATUS		
   ,DIM_BRON		
   ,DIM_ARCHIEFVERNIETIGING_STATUS		
   ,DIM_DATUM_AANMAAK		
   ,DIM_USER_AANMAAK		
   ,DIM_DATUM_GEWIJZIGD		
   ,DIM_USER_GEWIJZIGD		
   ,OMSCHRIJVING_SIGNAAL		
   ,CASUS_CODE_SIGNAAL		
   ,DCT_CODE		
FROM OKV_SMF_PO.OKV_MIS_CASUS_SIGNAAL_CODES_HV
;		
spo off 	
column Dbs clear 	
-- End of script --	
