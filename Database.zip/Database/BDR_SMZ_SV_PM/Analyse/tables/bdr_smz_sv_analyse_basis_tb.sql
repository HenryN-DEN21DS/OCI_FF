--
-- BDR_SMZ_SV_ANALYSE_BASIS_TB  (Table)
--
exec tabel_hulp.verwijder_tabel ('BDR_SMZ_SV_ANALYSE_BASIS_TB') 

create table bdr_smz_sv_analyse_basis_tb
  (
    pcs_id                         number 
  , productcode                    varchar2 (999) 
  , afg_bsn                        varchar2 (99) 
  , afg_case_id                    varchar2 (999) 
  , smf_casus_id                   varchar2 (99) 
  , proces                         varchar2 (999) 
  , proces_startdatum              date 
  , afg_datum_afgesloten           date 
  , afg_datum_uiterste_afhandeling date 
  , afg_reden_einde                varchar2 (999) 
  , code_conclusie_mdi             number 
  , code_soort_aanvrager           varchar2 (99) 
  , code_soort_recht               varchar2 (99) 
  , code_school                    number 
  , datum_eerste_ao_dag            date 
  , geldende_datum_ewt             date 
  , datum_ingang_recht             date 
  , datum_ontvangstaanvraag        date 
  , awb_startdatum                 date 
  , awb_einddatum                  date 
  , ind_afwijken_overdracht        number 
  , ind_casus_bz_internationaal    number 
  , indicatie_medisch_80_100       varchar2 (99) 
  , naam_partij_suwi               varchar2 (999) 
  , sco_reintegratie_spoor_1       varchar2 (10) 
  , code_eigen_risico_drager       varchar2 (10) 
  , ind_voorschot_gewenst          varchar2 (10) 
  , code_klanttype                 number 
  , dim_product_key                varchar2 (999) 
  , dim_uitslag_claim_key          varchar2 (999) 
  , dim_soort_dienst_key           varchar2 (20) 
  , dim_soort_aanvrager_key        varchar2 (22) 
  , dim_procesfase_key             varchar2 (199) 
  , streefdatum_actuele_procesfase date 
  , oed_startdatum                 date 
  , oed_streefdatum                date 
  , oed_einddatum                  date 
  , intake_regie_startdatum        date 
  , intake_regie_einddatum         date 
  , intake_startdatum              date 
  , intake_einddatum               date 
  , riv_beoordeling_startdatum     date 
  , riv_beoordeling_einddatum      date 
  , med_beoordeling_startdatum     date 
  , med_beoordeling_einddatum      date 
  , ad_beoordeling_startdatum      date 
  , ad_beoordeling_einddatum       date 
  , pp_startdatum                  date 
  , pp_einddatum                   date 
  , rdh_startdatum                 date 
  , rdh_einddatum                  date 
  , intake_ind                     number 
  , intake_tijdig_ind              number 
  , geboortedatum                  date 
  , land_omschrijving              varchar2 (99) 
  , actief_ktr_id                  number 
  , regie_ktr_id                   number 
  , smo_ktr_id                     number 
  , datum_tijd_overdracht_regie    date 
  , datum_tijd_overdracht_smo      date
  , resultaat_riv                  varchar2 (999) 
  , reden_resultaat_riv            number 
  , code_reden_tekortkoming_riv_zw number 
  , code_vangnet                   varchar2 (10) 
  , ind_iva_akkoord                number 
  , reden_iva_niet_akkoord         number 
  , datum_iva_beoordeeld           date 
  , ind_iva_beoordeeld             number 
  , gerealiseerde_einddatum_riv_va date 
  , gerealiseerde_einddatum_riv_ad date 
  , afg_volgnr                     number 
  , afg_ind_5_6                    number 
  , afg_ind_7_8                    number 
  , afg_ind_1_11_2_12              number 
  , afg_ind_1_11_2_12_3_4          number 
  , parent_pcs_id                  number 
  , productcode_geplande_herbo     varchar2 (999) 
  , datum_geplande_herbo           date 
  , code_kans_op_herstel           number 
  , uitstel_totaal                 number 
  , uitstel_av_aantal              number 
  , uitstel_av_duur                number 
  , uitstel_ca_aantal              number 
  , uitstel_ca_duur                number 
  , uitstel_cado_aantal            number 
  , uitstel_cado_duur              number 
  , uitstel_glv_aantal             number 
  , uitstel_glv_duur               number 
  , uitstel_kbiap_aantal           number 
  , uitstel_kbiap_duur             number 
  , uitstel_ma_aantal              number 
  , uitstel_ma_duur                number 
  , uitstel_mb_aantal              number 
  , uitstel_mb_duur                number 
  , uitstel_me_aantal              number 
  , uitstel_me_duur                number 
  , uitstel_mi_aantal              number 
  , uitstel_mi_duur                number 
  , uitstel_min_aantal             number 
  , uitstel_min_duur               number 
  , uitstel_mvb_aantal             number 
  , uitstel_mvb_duur               number 
  , uitstel_nmi_aantal             number 
  , uitstel_nmi_duur               number 
  , uitstel_oamib_aantal           number 
  , uitstel_oamib_duur             number 
  , uitstel_obmb_aantal            number 
  , uitstel_obmb_duur              number 
  , uitstel_osbi_aantal            number 
  , uitstel_osbi_duur              number 
  , uitstel_ou_aantal              number 
  , uitstel_ou_duur                number 
  , uitstel_ovtlb_aantal           number 
  , uitstel_ovtlb_duur             number 
  , uitstel_psb_aantal             number 
  , uitstel_psb_duur               number 
  , uitstel_rivwa_aantal           number 
  , uitstel_rivwa_duur             number 
  , uitstel_rnc_aantal             number 
  , uitstel_rnc_duur               number 
  , uitstel_rncwg_aantal           number 
  , uitstel_rncwg_duur             number 
  , uitstel_uv_aantal              number 
  , uitstel_uv_duur                number 
  , uitstel_vaw_aantal             number 
  , uitstel_vaw_duur               number 
  , uitstel_viaw_aantal            number 
  , uitstel_viaw_duur              number 
  , uitstel_vr_aantal              number 
  , uitstel_vr_duur                number 
  , uitstel_vrt_aantal             number 
  , uitstel_vrt_duur               number 
  , uitstel_vwv_aantal             number 
  , uitstel_vwv_duur               number 
  , uitstel_wa_aantal              number 
  , uitstel_wa_duur                number 
  , dim_uitslag_svb_key            varchar2 (999)
  )
  parallel 4 compress nologging
/  
  
alter table bdr_smz_sv_analyse_basis_tb 
add constraint bdr_smz_sv_analyse_basis_pk primary key (pcs_id)
using index 
/