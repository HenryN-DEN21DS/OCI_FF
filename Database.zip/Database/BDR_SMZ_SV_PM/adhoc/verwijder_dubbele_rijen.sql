begin
  for r in 
           (with base                   as
             (select 
               dim_organisatie_key 
             , count (1)                aantal
             from 
               bdr_smz_sv_organisatie_dt t
             group by 
               dim_organisatie_key
             having 
               count (1) > 1
             order by 
               aantal desc 
             )
             /*--*/
           , sorteer                    as
             (select 
               t.rowid                  row_id
             , t.dim_organisatie_key
             , t.dim_start_datum
             , row_number() over ( 
                                partition by t.dim_organisatie_key 
                                order by 
                                  t.dim_start_datum) rn
             from 
               bdr_smz_sv_organisatie_dt t
             inner join 
               base                     b
               on t.dim_organisatie_key = b.dim_organisatie_key 
             )
           select 
             row_id
           from 
             sorteer
           where rn                      > 1
  ) 
  loop
    delete bdr_smz_sv_organisatie_dt where rowid = r.row_id;
  
  end loop;
  commit;
end;