declare
  l_rowcount integer := 0;
begin
  for r in
           (with missend                as
             (select
               t.rowid                  fct_row_id
             , pcs_id
             , s.snapshot_datum
             , t.dim_snapshot_id
             from
               bdr_smz_sv_pm.bdr_smz_sv_do_ft t
             inner join
               bdr_smz_sv_pm.bdr_smz_sv_snapshot_dv s
               on s.dim_snapshot_id          = t.dim_snapshot_id
             where dim_organisatie_id_actief = -2
               or dim_organisatie_id_regie   = -2
               or dim_organisatie_id_smo     = -2
             )
           /*--*/
           select
             b.fct_row_id
           , i.pcs_id
           , b.dim_snapshot_id
           , i.actief_kantoor_id
           , i.regie_kantoor_id
           , i.smo_kantoor_id
           , nvl (o1.dim_organisatie_id, -2) dim_organisatie_id_actief
           , nvl (o2.dim_organisatie_id, -2) dim_organisatie_id_regie
           , nvl (o3.dim_organisatie_id, -2) dim_organisatie_id_smo
           from
             int_smz_sv_pm.int_smz_sv_beoordeling_ht i
           inner join
             missend                    b
             on i.pcs_id              = b.pcs_id
               and i.dim_start_datum <= snapshot_datum
               and i.dim_eind_datum   > b.snapshot_datum
           left outer join
             bdr_smz_sv_pm.bdr_smz_sv_organisatie_dt o1
             on o1.dim_organisatie_key = to_char (i.actief_kantoor_id)
           left outer join
             bdr_smz_sv_pm.bdr_smz_sv_organisatie_dt o2
             on o2.dim_organisatie_key = to_char (i.regie_kantoor_id)
           left outer join
             bdr_smz_sv_pm.bdr_smz_sv_organisatie_dt o3
             on o3.dim_organisatie_key = to_char (i.smo_kantoor_id)
  )
  loop
    update
      bdr_smz_sv_pm.bdr_smz_sv_do_ft f
    set dim_organisatie_id_actief = r.dim_organisatie_id_actief
    , dim_organisatie_id_regie    = r.dim_organisatie_id_regie
    , dim_organisatie_id_smo      = r.dim_organisatie_id_smo
    where rowid                   = r.fct_row_id;
    
    l_rowcount := l_rowcount + 1;
  end loop;
  dbms_output.put_line ('aantal updates : ' ||   l_rowcount) ;
  commit;
end;