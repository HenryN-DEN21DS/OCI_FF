begin
  dbms_mview.refresh ('BDR_SMZ_SV_DO_AM', 'C') ;
  dbms_mview.refresh ('BDR_SMZ_SV_HERBO_AM', 'C') ;
  dbms_mview.refresh ('BDR_SMZ_SV_PW_BEOORDELING_AM', 'C') ;
  dbms_mview.refresh ('BDR_SMZ_SV_WIA_1ECLAIM_AM', 'C') ;
end;
/
