set serveroutput on
declare
  v_username varchar2 (100) ;
  v_table    varchar2 (100) ;
begin
  select
    user
  into
    v_username
  from
    dual;
  
  dbms_output.put_line ('Actieve gebruiker: ' || v_username) ;
  for t in
  (
  select table_name from user_tables where table_name like '%_PRD%'
  )
  loop
    v_table := t.table_name;
    dbms_output.put_line ('Verwijderen tabel: ' ||  v_table) ;
	commit;
    execute immediate 'DROP TABLE ' || v_table;
  end loop;
exception
when others then
  dbms_output.put_line (sqlerrm) ;
end;
/