----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_dv_hm.sql
-- Datum : 13-02-2023
-- Doel  : Script voor aanmaken van dv gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-02-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   brv_dv_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_dv_hm') loop
            execute immediate 'drop materialized view bdr_imf_po.brv_dv_hm';
    end loop;
end;
/

create materialized view bdr_imf_po.brv_dv_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
select 
 CAST(afg_bsn as VARCHAR2(9 CHAR) ) as afg_bsn
,afg_nr_aansl_bv
,bsn
,cd_aard_ink_verh
,cd_contract
,dat_boeking_dv
,dim_archiefvernietiging_status
,dim_bron
,dim_datum_aanmaak
,dim_datum_gewijzigd
,dim_eind_datum
,dim_recent_ind
,dim_start_datum
,dim_status
,dim_user_aanmaak
,dim_user_gewijzigd
,edat_dv
,nr_aansl_bv
,nr_buitenl_inst
,nr_loonheffingen
,risicogroep
,sector
from okv_imf_po.okv_dv_hv dv
where  not exists 
    (
            select '1'
            from dim_beveiliging.bev_vip_po_mv vip
			where vip.afg_bsn = dv.afg_bsn
    )
;    

spo off
column Dbs clear

-- End of script --