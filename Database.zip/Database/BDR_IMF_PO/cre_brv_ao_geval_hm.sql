----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_ao_geval_hm.sql
-- Datum : 13-02-2023
-- Doel  : Script voor aanmaken van ao geval gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-02-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   brv_ao_geval_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_ao_geval_hm') loop
            execute immediate 'drop materialized view bdr_imf_po.brv_ao_geval_hm';
    end loop;
end;
/

create materialized view bdr_imf_po.brv_ao_geval_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
select 
 aant_opsch_ezwb
,aant_opsch_tvb2
,aant_verl_ezwb
,aant_verl_tvb2
,aanvr_id_uzs
,CAST(afg_bsn as VARCHAR2(9 CHAR)) as afg_bsn
,afg_nr_aansl_bv
,bdat_ao
,bsn
,cd_ag_traj
,cd_art_29_a
,cd_art_44_1a
,cd_art_46
,cd_besl_verk_ewt_wia
,cd_bron_hmel
,cd_cat_vangnet
,cd_contract
,cd_diagnose_nw
,cd_klacht
,cd_mary_brown
,cd_ocv
,cd_oudrecht
,cd_proces_hmel
,cd_rd_afw_maxdat
,cd_reden_hmel
,cd_regres
,cd_result_ezwb
,cd_result_screen_ezwb
,cd_result_tvb2
,cd_sign_tlzm
,cd_srt_aanvr
,cd_srt_ontv
,cd_toel_reden_hmel
,cd_wijze_ontv_hmel
,dat_beschik_ezwb
,dat_beschik_tvb2
,dat_besl_verk_ewt_wia
,dat_beval
,dat_boek_hm
,dat_boeking_ao
,dat_brief_44_weken
,dat_ewt_wia
,dat_ewt_wia_oorspr
,dat_max_zw
,dat_meld_vz
,dat_nuda_ezwb
,dat_nuda_tvb2
,dat_ontv_ao_meld
,dat_ontv_h_meld
,dat_ontv_verk_ewt_wia
,dat_ontv_verl_ewt_wia
,dat_overdr_ck
,dat_plan_ck
,dat_plausibel
,dat_riv_loondoorbet
,dat_toets_ezwb
,dat_toets_tvb2
,dat_uda_ezwb
,dat_uda_tvb2
,dat_verz_hmel
,dat_1e_dag_65prc_ezwb
,dat_1e_dag_65prc_tvb2
,dim_archiefvernietiging_status
,dim_bron
,dim_datum_aanmaak
,dim_datum_gewijzigd
,dim_eind_datum
,dim_recent_ind
,dim_start_datum
,dim_status
,dim_user_aanmaak
,dim_user_gewijzigd
,edat_ao
,gesel_arb_mogelijkh
,ind_aow_plus
,ind_erd_zw
,ind_plausibel
,ind_rig
,ind_uitsluiten_ezwb
,ind_1e_lijn_cons
,medew_plausibel
,nr_aansl_bv
,nr_buitenl_inst
,nr_dk
,nr_laatste_werkg
,productcode
,st_pva
,tijd_boeking_ao
,tijd_boeking_hm
,uzs_gevals_volgnr
,verv_actie_ck
from okv_imf_po.okv_ao_geval_hv ao
where not exists 
    (
            select '1'
            from dim_beveiliging.bev_vip_po_mv vip
			where vip.afg_bsn  = ao.afg_bsn 
    )
;    

spo off
column Dbs clear

-- End of script --