----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_werkhervatting_hm.sql
-- Datum : 13-02-2023
-- Doel  : Script voor aanmaken van werkhervatting gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-02-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   brv_werkhervatting_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_werkhervatting_hm') loop
            execute immediate 'drop materialized view bdr_imf_po.brv_werkhervatting_hm';
    end loop;
end;
/

create materialized view bdr_imf_po.brv_werkhervatting_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
select 
CAST(afg_bsn as VARCHAR2(9) ) as afg_bsn
,afg_nr_aansl_bv
,afg_nr_loonheffingen
,bdat_ao
,bdat_werkherv
,bsn
,cd_arb_thera
,cd_cat_werkherv
,cd_contract
,dat_boeking_ao
,dat_boeking_werkherv
,dim_archiefvernietiging_status
,dim_bron
,dim_datum_aanmaak
,dim_datum_gewijzigd
,dim_eind_datum
,dim_recent_ind
,dim_start_datum
,dim_status
,dim_user_aanmaak
,dim_user_gewijzigd
,edat_werkherv
,ind_cuu
,loonwaarde
,nm_werkgever
,nr_aansl_bv
,nr_buitenl_inst
,nr_loonheffingen
,nr_risicogroep
,nr_sector
,perc_ao
,tijd_boeking_werkh
,toelichting
from okv_imf_po.okv_werkhervatting_hv whv
where not exists 
    (
            select '1'
            from dim_beveiliging.bev_vip_po_mv vip
			where vip.afg_bsn = whv.afg_bsn
    )
;    

spo off
column Dbs clear

-- End of script --