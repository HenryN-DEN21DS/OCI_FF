----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_desk_oordeel_hm.sql
-- Datum : 13-02-2023
-- Doel  : Script voor aanmaken van desk oordeel gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-02-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   brv_desk_oordeel_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_desk_oordeel_hm') loop
            execute immediate 'drop materialized view bdr_imf_po.brv_desk_oordeel_hm';
    end loop;
end;
/

create materialized view bdr_imf_po.brv_desk_oordeel_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
select 
 aant_wkn_verhaal
,CAST(afg_bsn as VARCHAR2(12 CHAR)) as afg_bsn
,afg_nr_aansl_bv
,bdat_ao
,bdat_verzuim
,CAST(bsn as VARCHAR2(12 CHAR)) as bsn
,cd_aanl_des_od
,cd_aanvrager
,cd_concl_des_od
,cd_contract
,cd_des_od
,cd_zw_riv_aanw
,cd_zw_riv_compl
,dat_boeking_ao
,dat_boeking_real_do
,dat_meld_do
,dat_ontv_bo
,dat_real_do
,dim_archiefvernietiging_status
,dim_bron
,dim_datum_aanmaak
,dim_datum_gewijzigd
,dim_eind_datum
,dim_recent_ind
,dim_start_datum
,dim_status
,dim_user_aanmaak
,dim_user_gewijzigd
,edat_verzuim
,ind_intentie_wg
,ind_rig
,nr_aansl_bv
,nr_buitenl_inst
,nr_dk
,nr_dk_des_od
from okv_imf_po.okv_desk_oordeel_hv dol
where  not exists 
    (
            select '1'
            from dim_beveiliging.bev_vip_po_mv vip
			where vip.afg_bsn = dol.afg_bsn
    )
;    


spo off
column Dbs clear

-- End of script --