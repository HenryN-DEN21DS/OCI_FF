----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_ao_akt_hm.sql
-- Datum : 13-02-2023
-- Doel  : Script voor aanmaken van ao akt gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-02-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   brv_ao_akt_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_ao_akt_hm') loop
            execute immediate 'drop materialized view bdr_imf_po.brv_ao_akt_hm';
    end loop;
end;
/

create materialized view bdr_imf_po.brv_ao_akt_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
select 
 CAST(afg_bsn as VARCHAR2(9 CHAR) ) as afg_bsn
,afg_nr_aansl_bv
,bdat_ao
,bsn
,cd_aanl_akt
,cd_aanw_pers
,cd_concl_akt
,cd_contract
,cd_srt_akt
,dat_boeking_akt
,dat_boeking_ao
,dat_ini_boeking_akt
,dat_plan_akt
,dat_real_akt
,datum_oproep
,dim_archiefvernietiging_status
,dim_bron
,dim_datum_aanmaak
,dim_datum_gewijzigd
,dim_eind_datum
,dim_recent_ind
,dim_start_datum
,dim_status
,dim_user_aanmaak
,dim_user_gewijzigd
,functie_medew
,info_uitkadm
,info_uitkadm1
,naam_medew
,nr_aansl_bv
,nr_buitenl_inst
,nr_dk
,puik_id
,st_akt
,teamnummer
,tijd_ini_boeking_akt
,tijd_oproep
from okv_imf_po.okv_ao_akt_hv akt
where not exists 
    (
            select '1'
            from dim_beveiliging.bev_vip_po_mv vip
			where akt.afg_bsn = vip.afg_bsn
    );    

spo off
column Dbs clear

-- End of script --