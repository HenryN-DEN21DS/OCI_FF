----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_persoon_hm.sql
-- Datum : 13-02-2023
-- Doel  : Script voor aanmaken van persoon gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-02-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   brv_persoon_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_persoon_hm') loop
            execute immediate 'drop materialized view bdr_imf_po.brv_persoon_hm';
    end loop;
end;
/

create materialized view bdr_imf_po.brv_persoon_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
select 
 CAST(afg_bsn as VARCHAR2(9 CHAR) ) as afg_bsn
,afg_postcode_verbl_domic
,afg_postcode_verbl_domicgebied
,afg_postcode_verpl
,afg_postcode_verplgebied
,bsn
,cd_verpleeg
,dat_boeking_pers
,dim_archiefvernietiging_status
,dim_bron
,dim_datum_aanmaak
,dim_datum_gewijzigd
,dim_eind_datum
,dim_recent_ind
,dim_start_datum
,dim_status
,dim_user_aanmaak
,dim_user_gewijzigd
,gebdat
,nr_dk
,nr_dk_verhuizing
,nr_land_verpl
,postcode_verbl_domic
,postcode_verpl
,status_persoon
,teamnummer 
from okv_imf_po.okv_persoon_hv prs
where   not exists 
    (
            select '1'
            from dim_beveiliging.bev_vip_po_mv vip
			where vip.afg_bsn = prs.afg_bsn
    )
;    

spo off
column Dbs clear

-- End of script --