--
-- BDR_SMO_FB_MEETWAARDEN_TB  (table)
--
exec tabel_hulp.verwijder_tabel ( 'BDR_SMO_FB_MEETWAARDEN_TB' )
--
create table bdr_smo_fb_meetwaarden_tb
  (
    functie_id             number not null 
  , functiebeschrijving_id number not null
  , display_functienummer  varchar2 (99 char) 
  , gebruik                number
  )
  nologging
/

-- Create/Recreate primary, unique and foreign key constraints
alter table bdr_smo_fb_meetwaarden_tb add constraint bdr_smo_fb_meetwaarden_pk primary key (functie_id, functiebeschrijving_id)
/