--
-- BDR_SMO_MEDEWERKER_DELTA_TB (Table)
--
exec tabel_hulp.verwijder_tabel ('BDR_SMO_MEDEWERKER_DELTA_TB')

 create table bdr_smo_medewerker_delta_tb (
  dim_medewerker_key            varchar2(99 char)  not null enable
  , dim_medewerker_id           varchar2(999 byte) 
  , dim_md5                     varchar2(99 char) not null enable
  , dim_start_datum             timestamp(6)
  , puik                        varchar2(999 byte) 
  , naam                        varchar2(99 byte)    
  , ind_verzekeringsarts        varchar2(9 byte)     
  , ind_bezwaar_beroep          varchar2(9 byte)    
);

