--
-- BDR_smo_medewerker_TMP_TB (Table)
--
exec tabel_hulp.verwijder_tabel ('BDR_SMO_MEDEWERKER_TMP_TB')

 create table bdr_smo_medewerker_tmp_tb (
  dim_medewerker_key            varchar2(99 char)  not null enable
  , dim_md5                     varchar2(99 char) not null enable
  , dim_start_datum             timestamp(6)
  , puik                        varchar2(999 byte) 
  , naam                        varchar2(99 byte)    
  , ind_verzekeringsarts        varchar2(9 byte)     
  , ind_bezwaar_beroep          varchar2(9 byte)    
);
