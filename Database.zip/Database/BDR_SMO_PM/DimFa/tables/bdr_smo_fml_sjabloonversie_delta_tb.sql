--
-- BDR_SMO_FML_SJABLOONVERSIE_DELTA_TB (Table)
--
exec tabel_hulp.verwijder_tabel ('BDR_SMO_FML_SJABLOONVERSIE_DELTA_TB')

 create table bdr_smo_fml_sjabloonversie_delta_tb (
    dim_fml_sjabloonversie_key          number    not null enable
  , dim_fml_sjabloonversie_id           number    
  , dim_md5                     varchar2(99 char) not null enable
  , dim_start_datum             timestamp(6)
  , versienummer                number            not null enable
  , aanvang_geldigheid          date
  , omschrijving                varchar2(4000 byte)
  , fml_versie                  varchar2(99 byte)
  , regel_versie                varchar2(99 byte)
  , functieversie               varchar2(99 byte)
  , einde_geldigheid            date   
);