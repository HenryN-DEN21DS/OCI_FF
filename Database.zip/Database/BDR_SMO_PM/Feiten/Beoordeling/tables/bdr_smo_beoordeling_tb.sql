﻿-- BDR_SMO_BEOORDELING_TB (table)
--
exec tabel_hulp.verwijder_tabel ( 'BDR_SMO_BEOORDELING_TB' )
--------------------------------------------------------
--  DDL for Table BDR_SMO_BEOORDELING_TB
--------------------------------------------------------

create table bdr_smo_beoordeling_tb 
(
medische_beoordeling_id                number, 
arbeidskundige_beoordeling_id          number,
ind_meest_recente_smo                  varchar2(9 char), 
aantal                                 number,  
ind_beo_bezwaar_en_beroep              varchar2(9 char), 
ind_voldoende_functies_eind            varchar2(9 byte), 
dim_diagnose_key1                      varchar2(99 char), 
dim_diagnose_key2                      varchar2(99 char), 
dim_diagnose_key3                      varchar2(99 char), 
dim_type_beoordeling_key               varchar2(9 char), 
dim_oorzaak_key1                       varchar2(9 char), 
dim_oorzaak_key2                       varchar2(9 char), 
dim_oorzaak_key3                       varchar2(9 char), 
dim_mbo_status_key                     varchar2(9 char), 
dim_abo_status_key                     varchar2(9 char), 
dim_crao_key                           number, 
dim_duurzaamheid_aob_key               number, 
dim_fml_zit_staan_lopen_key            varchar2(99 byte), 
dim_fml_werktijden_key                 varchar2(99 byte), 
dim_geslacht_key                       varchar2(9 char), 
dim_leeftijd_id_vaststelling_mbo_key   number, 
dim_leeftijd_id_vaststelling_abo_key   number, 
dim_opleidingsniveau_key               number, 
dim_abo_werktijden_key                 varchar2(999 byte), 
dim_abo_ao_klasse_key                  number, 
dim_fml_sjabloonversie_key             number, 
aanvang                                date,
toelichting_aob_code                   varchar2(9 char), 
conclusie_aob_code                     varchar2(9 char)
)
nologging
/
