--
-- BDR_SMO_BEOORDELING_FT  (Table) maak backup
--
--exec tabel_hulp.hernoem_tabel ('BDR_SMO_BEOORDELING_FT', 'PRD-xxxxx')
exec tabel_hulp.verwijder_tabel ( 'BDR_SMO_BEOORDELING_FT' )

--------------------------------------------------------
--  DDL for Table BDR_SMO_BEOORDELING_FT
--------------------------------------------------------

create table 
        bdr_smo_beoordeling_ft (
		medische_beoordeling_id                   number not null,
		arbeidskundige_beoordeling_id             number,
		ind_meest_recente_smo                     varchar2(9) default 'j/n',
		aantal                                    number default 1,
		ind_beo_bezwaar_en_beroep                 varchar2(9) default 'j/n',
		ind_voldoende_functies_eind               varchar2(9) default 'j/n',
		dim_snapshot_id                           number not null,
		dim_diagnose_id_1                         number not null,
		dim_diagnose_id_2                         number not null,
		dim_diagnose_id_3                         number not null,
		dim_type_beoordeling_id                   number not null,
		dim_aob_id                                number not null,
		dim_oorzaak_id_1                          number not null,
		dim_oorzaak_id_2                          number not null,
		dim_oorzaak_id_3                          number not null,
		dim_medische_beoordelingsstatus_id        number not null,
		dim_criterium_arbeidsongeschiktheid_id    number not null,
		dim_duurzaamheid_aob_id                   number not null,
		dim_fml_zitten_staan_lopen_id             number not null,
		dim_fml_werktijden_id                     number not null,
		dim_geslacht_id                           number not null,
		dim_leeftijd_id_vaststelling_mbo          number not null,
		dim_opleidingsniveau_id                   number not null,
		dim_abo_werktijden_id                     number not null,
		dim_abo_ao_klasse_id                      number not null,
		dim_fml_sjabloonversie_id                 number not null,
		dim_arbeidskundige_beoordelingsstatus_id  number not null,
		dim_klant_id                              number not null,           
		dim_leeftijd_id_vaststelling_abo          number not null,
        dim_datum_aanmaak                         date
	)
compress basic
tablespace dim_bedrijfszone
nologging
partition by list (dim_snapshot_id) automatic (partition part_dummy values ( - 1 ) no inmemory) 
nocache
parallel(degree 4 instances default)
monitoring
/


-- Add comments to the columns

-- To Do


-- create/recreate primary, unique and foreign key constraints 
alter table BDR_SMO_BEOORDELING_FT
  add constraint bdr_smo_beoordeling_pk primary key (medische_beoordeling_id, arbeidskundige_beoordeling_id, dim_snapshot_id);
  
--
-- BDR_SMO_BEOORDELING_FT  (Table) zet de gegevens van de backup terug
--
--exec tabel_hulp.vul_tabel ('BDR_SMO_BEOORDELING_FT', 'PRD-xxxxx')  
