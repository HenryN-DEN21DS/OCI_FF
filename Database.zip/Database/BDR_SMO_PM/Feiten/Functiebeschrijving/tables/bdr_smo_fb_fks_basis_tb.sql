--
-- BDR_SMO_FB_FKS_BASIS_TB  (table)
--
exec tabel_hulp.verwijder_tabel ( 'BDR_SMO_FB_FKS_BASIS_TB' )
--
create table bdr_smo_fb_fks_basis_tb
  (
    functie_id              number not null 
  , sbc_code_id             number 
  , display_functienummer   varchar2 (99 char) 
  , bedrijf_id              number 
  , functiebeschrijving_id  number 
  , datum_functie_onderzoek date 
  , bek_code_opl_niv        number 
  , opleidingsrichting_id   number 
  , medewerker_creatie_id   number 
  , medewerker_mutatie_id   number 
  , code_type               varchar2 (9 char) 
  , code_status             number 
  , code_reden              number
  )
  nologging
/
