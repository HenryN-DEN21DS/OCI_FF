--
-- BDR_SMO_FB_FKS_TB  (Table)
--
exec tabel_hulp.verwijder_tabel ( 'BDR_SMO_FB_FKS_TB' )
create table bdr_smo_fb_fks_tb
  (
    functie_id                   number not null
  , functiebeschrijving_id       number not null	
  , functie_naam                 varchar2 (999 char)
  , ind_actieve_functiebeschr    number
  , sbc_code                     varchar2 (99 char)
  , code_type_onderzoek          varchar2 (9 char)
  , code_status                  number
  , code_reden                   number
  , display_functienummer        varchar2 (99 char)
  , datum_functie_onderzoek      date
  , ouderdom_functiebeschrijving number
  , bek_code_opl_niv             number
  , opleidingsrichting_code      varchar2 (9 char)
  , puik_id_creatie              varchar2 (999 char)
  , puik_id_mutatie              varchar2 (999 char)
  , bedrijf_id                   number
  , cbbs_regio_nummer            varchar2 (9 char)
  )
  nologging
/
