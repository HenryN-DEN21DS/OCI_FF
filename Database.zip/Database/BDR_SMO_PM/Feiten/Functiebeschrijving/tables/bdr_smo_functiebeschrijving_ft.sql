--
-- BDR_SMO_FUNCTIEBESCHRIJVING_FT  (Table) maak backup
--
--exec tabel_hulp.hernoem_tabel ('BDR_SMO_FUNCTIEBESCHRIJVING_FT', 'PRD-xxxxx')
exec tabel_hulp.verwijder_tabel ( 'BDR_SMO_FUNCTIEBESCHRIJVING_FT' )

--------------------------------------------------------
--  DDL for Table BDR_SMO_FUNCTIEBESCHRIJVING_FT
--------------------------------------------------------
create table bdr_smo_functiebeschrijving_ft
(
  functie_id                number ,
  functiebeschrijving_id    number ,
  ind_actieve_functiebeschr number ,
  display_functienummer     varchar2(99) ,
  gebruik                   number ,
  dim_sbc_id                number ,
  dim_bedrijf_id            number ,
  dim_oud_func_besch_id     number ,
  dim_cbbs_regio_id         number ,
  dim_opleidingsniveau_id   number ,
  dim_opleidingsrichting_id number ,
  dim_type_onderzoek_id     number ,
  dim_snapshot_id           number not null,
  dim_status_id             number ,
  dim_medewerker_creatie_id number ,
  dim_medewerker_mutatie_id number ,
  dim_datum_aanmaak         date not null
)
compress basic
tablespace dim_bedrijfszone
nologging
partition by list (dim_snapshot_id) automatic (partition part_dummy values ( - 1 ) no inmemory) 
nocache
parallel(degree 4 instances default)
monitoring
/

-- Add comments to the columns
comment on column bdr_smo_functiebeschrijving_ft.display_functienummer
is
  'DIsplay Functie nummer is de concatinatie van SBI code || ''.'' Volgenummer SBI || ''.'' Volgenummer functie'
/
comment on column bdr_smo_functiebeschrijving_ft.dim_sbc_id
is
  'Primaire Sleutel = SBC CODE'
/
comment on column bdr_smo_functiebeschrijving_ft.dim_type_onderzoek_id
is
  'GECOMBINEERDE SLEUTEL : TYPE ONDERZOEK, TYPE FUNCTIE, AANLEIDING CODE'
/
comment on column bdr_smo_functiebeschrijving_ft.dim_status_id
is
  'PK = gecombineerde sleutel van Code Reden en Code Status'
/

-- create/recreate primary, unique and foreign key constraints 
/*
alter table bdr_smo_functiebeschrijving_ft
  add constraint bdr_smo_functiebeschrijving_pk primary key (functie_id, functiebeschrijving_id, dim_snapshot_id);
*/  
  
--
-- BDR_SMO_FUNCTIEBESCHRIJVING_FT  (Table) zet de gegevens van de backup terug
--
--exec tabel_hulp.vul_tabel ('BDR_SMO_FUNCTIEBESCHRIJVING_FT', 'PRD-xxxxx')  