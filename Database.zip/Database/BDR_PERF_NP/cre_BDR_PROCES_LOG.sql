﻿-- Naam  : cre_BDR_PROCES_LOG.sql
-- Datum : 10-02-2022
-- Doel  : Script voor het creëeren van de tijdelijke logging tabel voor de DIM platform performance datamarts
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 24-11-2022 tgr033 Tabel verwijderd, overstap naar ETL framework gemaakt middels DPUT-709
-- 10-02-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------


begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_proces_log') loop
            execute immediate 'drop table bdr_proces_log';
    end loop;
end;
/

/*
CREATE TABLE "BDR_PERF_NP"."BDR_PROCES_LOG" 
(  
  "PROCES_NAAM" VARCHAR2(99 BYTE), 
  "STATUS" VARCHAR2(99 BYTE), 
  "EIND_DATUM_VORIGE_VERWERKING" TIMESTAMP (6), 
  "EIND_DATUM_HUIDIGE_VERWERKING" TIMESTAMP (6)
);
*/
