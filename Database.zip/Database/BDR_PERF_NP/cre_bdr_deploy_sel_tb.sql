﻿-- Naam  : cre_bdr_deploy_sel_tb.sql
-- Datum : 16-09-2022
-- Doel  : Script voor het creëeren van de deployment feit selectie tabel 
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 16-09-2022 jsc226 Aangemaakt t.b.v. DPUT-2007
-- ------------------------------------------------------------------------------

--DROP TABLE BDR_PERF_NP.BDR_DEPLOY_SEL_TB;
CREATE TABLE BDR_PERF_NP.BDR_DEPLOY_SEL_TB 
(	
  DIM_START_DATUM TIMESTAMP NOT NULL, 
  DIM_DEPLOY_KEY VARCHAR2(999 CHAR), 
  USER_STORY VARCHAR2(99),
  OMGEVING VARCHAR2(9),
  DATUM_DEPLOYMENT NUMBER,
  AANTAL_DEPLOYMENTS NUMBER,
  AANTAL_FIRST_TIME_RIGHT NUMBER
) compress basic;
   