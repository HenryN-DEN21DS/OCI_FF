﻿-- Naam  : cre_bdr_status_tmp_tb.sql
-- Datum : 14-02-2022
-- Doel  : Script voor het creëeren van de tijdelijke status tussen tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 14-02-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

--DROP TABLE BDR_PERF_NP.BDR_STATUS_TMP_TB;
CREATE TABLE BDR_PERF_NP.BDR_STATUS_TMP_TB
(
  DIM_STATUS_KEY                VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM     	        TIMESTAMP (6) NOT NULL, 
  DIM_MD5                       VARCHAR2(99) NOT NULL,
  STATUS	     	        VARCHAR2(99),
  STATUS_OMSCHRIJVING  		VARCHAR2(99)
) compress basic;
   
ALTER TABLE BDR_PERF_NP.BDR_STATUS_TMP_TB ADD CONSTRAINT BDR_STATUS_TMP_TB_PK PRIMARY KEY (DIM_STATUS_KEY, DIM_START_DATUM);
