﻿-- Naam  : cre_bdr_perf_sel_tb.sql
-- Datum : 21-02-2022
-- Doel  : Script voor het creëeren van de performance feit selectie tabel met daarin informatie over de main sequences
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 21-02-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

--DROP TABLE BDR_PERF_NP.BDR_PERF_SEL_TB;
CREATE TABLE BDR_PERF_NP.BDR_PERF_SEL_TB 
(	
  DIM_START_DATUM TIMESTAMP NOT NULL, 
  DIM_PERF_KEY VARCHAR2(999 CHAR), 
  STATUS VARCHAR2(99 CHAR), 
  JOB VARCHAR2(999 CHAR), 
  DATUM_START_RUN NUMBER,
  DATUM_END_RUN NUMBER,
  RUNENDTIMESTAMP TIMESTAMP,
  RUNSTARTTIMESTAMP TIMESTAMP, 
  DIM_RUN_ID NUMBER,
  LEVERING VARCHAR2(999 CHAR),
  AANTAL_OP_TIJD NUMBER,
  AANTAL_BINNEN_LIMIET NUMBER,
  AANTAL_TE_LAAT NUMBER,
  BRUTO_DOORLOOPTIJD_SEC NUMBER,
  NETTO_DOORLOOPTIJD_SEC NUMBER
) compress basic;
   