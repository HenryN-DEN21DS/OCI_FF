﻿-- Naam  : cre_bdr_levering_tmp_tb.sql
-- Datum : 15-02-2022
-- Doel  : Script voor het creëeren van de tijdelijke levering tussen tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 22-08-2022 tgr033 Team toegevoegd
-- 15-02-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select NULL from user_objects where upper(object_type) = 'TABLE' and lower(object_name) = 'bdr_levering_tmp_tb') loop
            execute immediate 'DROP TABLE bdr_perf_np.bdr_levering_tmp_tb';
    end loop;
end;
/

CREATE TABLE BDR_PERF_NP.BDR_LEVERING_TMP_TB
(
  DIM_LEVERING_KEY       	VARCHAR2(99) NOT NULL, 
  DIM_START_DATUM     	        TIMESTAMP (6) NOT NULL, 
  DIM_MD5                       VARCHAR2(99) NOT NULL,
  BRON_NAAM	     		VARCHAR2(99),
  LEVERING_NAAM  		VARCHAR2(99),
  TEAM				VARCHAR2(99),
  DIM_FREQUENTIE_INFO           VARCHAR2(99),
  LEVERING_FREQUENTIE  		VARCHAR2(99),
  LEVERING_TYPE                 VARCHAR2(99),
  LEVERING_SUBTYPE              VARCHAR2(99),
  MAX_WACHT_DUUR                NUMBER,
  MAX_LEVERING_TIJDSTIP         VARCHAR2(99)
) compress basic;
   
ALTER TABLE BDR_PERF_NP.BDR_LEVERING_TMP_TB ADD CONSTRAINT BDR_LEVERING_TMP_TB_PK PRIMARY KEY (DIM_LEVERING_KEY, DIM_START_DATUM);
