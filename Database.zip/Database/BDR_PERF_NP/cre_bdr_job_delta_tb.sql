﻿-- Naam  : cre_bdr_job_delta_tb.sql
-- Datum : 18-02-2022
-- Doel  : Script voor het creëeren van de run minorstatus delta tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-02-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

-- DROP TABLE BDR_PERF_NP.BDR_JOB_DELTA_TB;
CREATE TABLE BDR_PERF_NP.BDR_JOB_DELTA_TB

(        
  DIM_JOB_ID      		NUMBER,
  DIM_JOB_KEY     		VARCHAR2(999) NOT NULL, 
  DIM_START_DATUM        	TIMESTAMP (6) NOT NULL, 
  DIM_MD5                	VARCHAR2(99) NOT NULL,
  JOB_NAAM	     		VARCHAR2(999),
  INVOCATIONID  		VARCHAR2(999),
  JOB_OMSCHRIJVING		CLOB	
) compress basic;

ALTER TABLE BDR_PERF_NP.BDR_JOB_DELTA_TB ADD CONSTRAINT BDR_JOB_DELTA_TB_PK PRIMARY KEY (DIM_JOB_KEY, DIM_START_DATUM);
