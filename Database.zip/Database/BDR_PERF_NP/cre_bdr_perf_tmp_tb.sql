﻿-- Naam  : cre_bdr_perf_tmp_tb.sql
-- Datum : 22-02-2022
-- Doel  : Script voor het creëeren van de performance feit tijdelijke tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 22-02-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

--DROP TABLE BDR_PERF_NP.BDR_PERF_TMP_TB;
CREATE TABLE BDR_PERF_NP.BDR_PERF_TMP_TB 
(	
  DIM_PERF_KEY VARCHAR2(999 CHAR), 
  DIM_START_DATUM TIMESTAMP,
  DIM_DATUM_START_RUN_ID NUMBER,
  DIM_DATUM_END_RUN_ID NUMBER,
  RUNENDTIMESTAMP TIMESTAMP,
  RUNSTARTTIMESTAMP TIMESTAMP, 
  DIM_LEVERING_ID NUMBER,
  DIM_JOB_ID NUMBER,
  DIM_STATUS_ID NUMBER,
  AANTAL_OP_TIJD NUMBER,
  AANTAL_BINNEN_LIMIET NUMBER,
  AANTAL_TE_LAAT NUMBER,
  BRUTO_DOORLOOPTIJD_SEC NUMBER,
  NETTO_DOORLOOPTIJD_SEC NUMBER,
  AANTAL_VERWERKINGEN NUMBER,
  GEM_NETTO_DOORLOOPTIJD_SEC NUMBER,
  PERC_DOORLOOPTIJD_GROEI NUMBER
) compress basic;