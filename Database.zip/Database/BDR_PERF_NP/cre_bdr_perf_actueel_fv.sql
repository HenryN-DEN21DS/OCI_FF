-- Naam  : cre_bdr_perf_actueel_fv.sql
-- Datum : 01-03-2022
-- Doel  : Script voor het cre�eren van de actuele performance feit view
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 29-03-2022 tgr033 Aanpassing op actuele view om dubbele invocationid verschijningen te voorkomen
-- 01-03-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

create or replace view bdr_perf_np.bdr_perf_actueel_fv as
  select levering_naam,job_naam,invocationid,job_duur,runstarttimestamp,runendtimestamp,job_run_status,job_eind_status,rank_nr 
  from 
    (select 
      pd.paramvalue                                                             as levering_naam,
      e.jobname                                                                 as job_naam,
      r.invocationid                                                            as invocationid,
      (sysdate + (r.runendtimestamp - r.runstarttimestamp)*24*60*60 - sysdate)  as job_duur,      
      from_tz(r.runstarttimestamp, 'GMT') at time zone 'Europe/Amsterdam'       as runstarttimestamp,
      from_tz(r.runendtimestamp, 'GMT') at time zone 'Europe/Amsterdam'         as runendtimestamp,
      case 
         when r.runmajorstatus = 'FIN' then 'Beeindigd' 
         else 'Lopend' 
      end                                                                       as job_run_status,
      case 
        when r.runminorstatus = 'FOK' then 'Correct' 
        when r.runminorstatus = 'RUN' then '-' 
        else 'Fout' 
      end                                                                       as job_eind_status,
      rank() over (partition by pd.paramvalue order by r.runstarttimestamp desc) rank_nr
    from okv_dsodb_np.okv_jobrun_vw r
    inner join okv_dsodb_np.okv_jobexec_vw e on (r.jobid = e.jobid)
    inner join okv_dsodb_np.okv_jobrunparamsview_vw pd on (r.runid = pd.runid and pd.paramname = 'pmDlNaam')
    inner join okv_dsodb_np.okv_jobrun_vw rc on (r.runid = rc.controlling_runid)
    inner join okv_dsodb_np.okv_jobexec_vw ec on (rc.jobid = ec.jobid and ec.jobname = 'job_DL_LeesRunId')
    inner join bdr_perf_np.ref_perf_gia_hv gia on (pd.paramvalue = gia.levering_naam 
                                                    and r.runstarttimestamp >= gia.dim_start_datum
                                                    and r.runstarttimestamp < gia.dim_eind_datum)
    left outer join bdr_perf_np.bdr_levering_dt lev on (pd.paramvalue = lev.dim_levering_key 
                                                    and r.runstarttimestamp >= lev.dim_start_datum 
                                                    and r.runstarttimestamp < lev.dim_eind_datum))
    where rank_nr = 1;
