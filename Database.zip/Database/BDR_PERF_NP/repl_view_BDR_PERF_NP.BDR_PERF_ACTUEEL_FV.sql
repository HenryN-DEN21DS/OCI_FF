--------------------------------------------------------
--  DDL for View BDR_PERF_ACTUEEL_FV
--------------------------------------------------------

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "BDR_PERF_NP"."BDR_PERF_ACTUEEL_FV" ("LEVERING_NAAM", "JOB_NAAM", "INVOCATIONID", "JOB_DUUR", "RUNSTARTTIMESTAMP", "RUNENDTIMESTAMP", "JOB_RUN_STATUS", "JOB_EIND_STATUS", "RANK_NR") AS 
  WITH w_data AS  
(
SELECT pd.paramvalue                   AS levering_naam ,
        e.jobname                       AS job_naam ,
        r.invocationid                  AS invocationid ,
      (sysdate + (r.runendtimestamp - r.runstarttimestamp)*24*60*60 - sysdate)  as job_duur,      
      from_tz(r.runstarttimestamp, 'GMT') at time zone 'Europe/Amsterdam'       as runstarttimestamp,
      from_tz(r.runendtimestamp, 'GMT') at time zone 'Europe/Amsterdam'         as runendtimestamp,
        r.runmajorstatus                AS runmajorstatus ,
        r.runminorstatus                AS runminorstatus , 
        CASE WHEN r.runmajorstatus = 'FIN' THEN 'Beeindigd' ELSE 'Lopend' END AS job_run_status ,
        CASE WHEN r.runminorstatus = 'FOK' THEN 'Correct' WHEN r.runminorstatus = 'RUN' THEN '-' ELSE 'Fout' END AS job_eind_status ,
        RANK() OVER (PARTITION BY pd.paramvalue ORDER BY r.runstarttimestamp DESC) AS rank_nr
FROM okv_dsodb_np.okv_jobrun_vw r
INNER JOIN okv_dsodb_np.okv_jobexec_vw e ON (r.jobid = e.jobid)
INNER JOIN okv_dsodb_np.okv_jobrunparamsview_vw pd ON (r.runid = pd.runid AND pd.paramname = 'pmDlNaam')
INNER JOIN okv_dsodb_np.okv_jobrun_vw rc ON (r.runid = rc.controlling_runid)
INNER JOIN okv_dsodb_np.okv_jobexec_vw ec ON (rc.jobid = ec.jobid AND ec.jobname = 'job_DL_LeesRunId')
)  

SELECT  dtd.levering_naam ,
        dtd.job_naam  ,
        dtd.invocationid ,
        dtd.job_duur ,
        dtd.runstarttimestamp,
        dtd.runendtimestamp ,
        dtd.job_run_status ,
        dtd.job_eind_status ,
        dtd.rank_nr         
FROM w_data dtd 
INNER JOIN      bdr_perf_np.ref_perf_gia_hv gia ON (dtd.levering_naam = gia.levering_naam    AND dtd.runstarttimestamp >= gia.dim_start_datum AND dtd.runstarttimestamp < gia.dim_eind_datum)
LEFT OUTER JOIN bdr_perf_np.bdr_levering_dt lev ON (dtd.levering_naam = lev.dim_levering_key AND dtd.runstarttimestamp >= lev.dim_start_datum AND dtd.runstarttimestamp < lev.dim_eind_datum)
WHERE rank_nr = 1
;
 
