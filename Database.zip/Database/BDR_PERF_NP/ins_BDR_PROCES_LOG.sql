-- Naam  : ins_BDR_PROCES_LOG.sql
-- Datum : 08-03-2022
-- Doel  : Script voor het inserten van de eerste regels in de tijdelijke logging tabel voor de DIM platform performance datamarts
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 08-03-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

Insert into BDR_PERF_NP.BDR_PROCES_LOG (PROCES_NAAM,STATUS,EIND_DATUM_VORIGE_VERWERKING,EIND_DATUM_HUIDIGE_VERWERKING) values ('DIMPlatformPerformanceBedrijfszone','Klaar',to_date('01-01-2000','DD-MM-YYYY'),null);
Insert into BDR_PERF_NP.BDR_PROCES_LOG (PROCES_NAAM,STATUS,EIND_DATUM_VORIGE_VERWERKING,EIND_DATUM_HUIDIGE_VERWERKING) values ('DIMPlatformPerformanceIntegratie','Klaar',to_date('01-01-2000','DD-MM-YYYY'),null);

commit;
