----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_REF_PERF_GIA_HV.sql
-- Datum : 22-08-2022
-- Doel  : Script voor aanmaken GIA referentie ontkoppelview
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 22-08-2022 tgr033 Aangepast naar standaarden en team toegevoegd
-- 01-01-1900 iemand Aangemaakt
-- ------------------------------------------------------------------------------


create or replace view ref_perf_gia_hv as
    select
        leverancier,
        team,
        levering_naam,
        levering_frequentie,
        max_levering_tijdstip,
        dim_start_datum,
        dim_eind_datum
    from
        okv_referentie_data.ref_perf_gia_tb;