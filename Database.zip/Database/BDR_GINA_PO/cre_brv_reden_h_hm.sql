----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_reden_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van reden gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_reden_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'reden_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.reden_h_hm';
    end loop;
end;
/

  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_reden_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_reden_h_hm';
    end loop;
end;
/

create materialized view bdr_gina_po.reden_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select rdn.dim_start_datum
,      rdn.dim_eind_datum
,      rdn.dim_recent_ind
,      rdn.changetype
,      rdn.soort
,      rdn.volgnr
,      rdn.userid
,      rdn.afg_timestamp
,      rdn.id_hist
,      rdn.id
,      rdn.regelnr
,      rdn.signaalid
,      rdn.timestamp
,      sgl.afg_bsn
from  okv_gina_po.okv_reden_h_hv rdn  
inner join  bdr_gina_po.signaal_h_hm sgl
on    rdn.signaalid = sgl.id
;               

begin 
 dbms_stats.gather_schema_stats('BDR_GINA_PO');
end;
/  

spo off
column Dbs clear

-- End of script --