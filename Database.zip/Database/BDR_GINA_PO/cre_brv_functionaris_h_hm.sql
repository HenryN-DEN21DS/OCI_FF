----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_functionaris_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van functionaris gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_functionaris_h_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'functionaris_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.functionaris_h_hm';
    end loop;
end;
/
  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_functionaris_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_functionaris_h_hm';
    end loop;
end;
/

create materialized view bdr_gina_po.functionaris_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select fuc.dim_start_datum
,      fuc.dim_eind_datum
,      fuc.dim_recent_ind
,      fuc.changetype
,      fuc.functionarisnr
,      fuc.uitkeringsgerechtigdeid
,      fuc.timestamp
,      fuc.id_hist
,      fuc.id
,      fuc.organisatiegroepid
,      fuc.userid
,      fuc.afg_timestamp
,      ugt.afg_bsn
from  okv_gina_po.okv_functionaris_h_hv fuc
inner join bdr_gina_po.uitkeringsgerechtigde_h_hm ugt 
on    fuc.uitkeringsgerechtigdeid = ugt.id  
and   ugt.dim_eind_datum = to_timestamp('31-12-9999 00:00:00' , 'DD-MM-YYYY HH24:MI:SS')
;   

spo off
column Dbs clear

-- End of script --