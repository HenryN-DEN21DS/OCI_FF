----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_organisatiegroep_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van organisatiegroep gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_organisatiegroep_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'organisatiegroep_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.organisatiegroep_hm';
    end loop;
end;
/


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_organisatiegroep_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_organisatiegroep_hm';
    end loop;
end;
/

create materialized view bdr_gina_po.organisatiegroep_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select org.dim_start_datum
,      org.dim_eind_datum
,      org.dim_recent_ind
,      org.materiesysteem
,      org.adgroep
,      org.timestamp
,      org.id
,      org.kantoorid
,      org.userid
,      org.afg_timestamp
from  okv_gina_po.okv_organisatiegroep_hv org
;

spo off
column Dbs clear

-- End of script --