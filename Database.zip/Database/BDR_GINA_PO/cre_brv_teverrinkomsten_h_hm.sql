----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_teverrinkomsten_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van teverrinkomsten gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_teverrinkomsten_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'teverrinkomsten_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.teverrinkomsten_h_hm';
    end loop;
end;
/
  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_teverrinkomsten_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_teverrinkomsten_h_hm';
    end loop;
end;
/

create materialized view bdr_gina_po.teverrinkomsten_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select  tkm.dim_start_datum
,      tkm.dim_eind_datum
,      tkm.dim_recent_ind
,      tkm.changetype
,      tkm.categorieteverr
,      tkm.aanturen
,      tkm.userid
,      tkm.afg_timestamp
,      tkm.id_hist
,      tkm.id
,      tkm.bdrinkomsten
,      tkm.leveringteverrinkomstenid
,      tkm.timestamp
,      lkm.afg_bsn
from  okv_gina_po.okv_teverrinkomsten_h_hv tkm 
inner join  bdr_gina_po.leveringteverrinkomsten_h_hm lkm
on    tkm.leveringteverrinkomstenid = lkm.id 
and  lkm.dim_eind_datum = to_timestamp('31-12-9999 00:00:00' , 'DD-MM-YYYY HH24:MI:SS')
;

spo off
column Dbs clear

-- End of script --