----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_aangifteinkomsten_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van aangifteinkomsten gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_aangifteinkomsten_h_hm&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
	,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
	for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'aangifteinkomsten_h_hm') loop
			execute immediate 'drop materialized view bdr_gina_po.aangifteinkomsten_h_hm';
	end loop;
end;
/
  
  begin
	for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_aangifteinkomsten_h_hm') loop
			execute immediate 'drop materialized view bdr_gina_po.brv_aangifteinkomsten_h_hm';
	end loop;
end;
/

create materialized view bdr_gina_po.aangifteinkomsten_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select ank.dim_start_datum
,      ank.dim_eind_datum
,      ank.dim_recent_ind
,      ank.changetype
,      ank.aantgewurennadeeltijdontslag
,      ank.aantverloondeurenpolis
,      ank.bdrloonsvpolis
,      ank.bdrvakantietoeslagpolis
,      ank.indbijlageaanwezig
,      ank.indrisicoikv
,      ank.indmaandelijksverloondevt
,      ank.soortinkomstenbron
,      ank.aangiftemaandid
,      ank.timestamp
,      ank.id_hist
,      ank.id
,      ank.aantgewerkteurenug
,      ank.bdrloonsvug
,      ank.bdrvakantietoeslagug
,      ank.indalleurenwerkloos
,      ank.indinkomstenpartner
,      ank.indugakkoordmetpolis
,      ank.naamadministratieveeenheid
,      ank.toelichtingug
,      ank.userid
,      ank.afg_timestamp
,      anm.afg_bsn
from  okv_gina_po.okv_aangifteinkomsten_h_hv ank
inner join  bdr_gina_po.aangiftemaand_h_hm  anm 
on    ank.aangiftemaandid = anm.id 
;

spo off
column Dbs clear

-- End of script --