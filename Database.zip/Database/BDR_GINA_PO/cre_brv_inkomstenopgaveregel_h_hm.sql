----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_inkomstenopgaveregel_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van inkomstenopgaveregel gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbsh
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_inkomstenopgaveregel_h_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'inkomstenopgaveregel_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.inkomstenopgaveregel_h_hm';
    end loop;
end;
/

  
  begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_inkomstenopgaveregel_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_inkomstenopgaveregel_h_hm';
    end loop;
end;
/

create materialized  view bdr_gina_po.inkomstenopgaveregel_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select irg.dim_start_datum
,      irg.dim_eind_datum
,      irg.dim_recent_ind
,      irg.changetype
,      irg.regelnr
,      irg.bdrloonsvpolis
,      irg.aantgewerkteurennaewdug
,      irg.bdrvakantietoeslagug
,      irg.toelichtingug
,      irg.bdrloonsvvast
,      irg.bdrvakantietoeslagvast
,      irg.cdincinkvermindering
,      irg.bdrloonsvmed
,      irg.bdrvakantietoeslagmed
,      irg.inkomstenbronid
,      irg.userid
,      irg.afg_timestamp
,      irg.dataanvangltvpolis
,      irg.dateindeltvpolis
,      irg.dataanvangltvvast
,      irg.dateindeltvvast
,      irg.dataanvangltvmed
,      irg.dateindeltvmed
,      irg.dataanvangltvug
,      irg.dateindeltvug
,      irg.bdrvervvakantietoeslagmed
,      irg.indziekte
,      irg.id_hist
,      irg.id
,      irg.aantverloondeurenpolis
,      irg.bdrvakantietoeslagpolis
,      irg.aantgewerkteurenug
,      irg.bdrinkomstenug
,      irg.indugakkoordmetpolis
,      irg.aantgewerkteurenvast
,      irg.bdrvervloonvast
,      irg.indbijlageaanwezig
,      irg.aantgewerkteurenmed
,      irg.bdrvervloonmed
,      irg.motivatiebeslissingmed
,      irg.inkomstenopgaveid
,      irg.timestamp
,      irg.indeenmaligkortenrisicoikv
,      irg.afg_dataanvangltvpolis
,      irg.afg_dateindeltvpolis
,      irg.afg_dataanvangltvvast
,      irg.afg_dateindeltvvast
,      irg.afg_dataanvangltvmed
,      irg.afg_dateindeltvmed
,      irg.afg_dataanvangltvug
,      irg.afg_dateindeltvug
,      irg.bdrvervvakantietoeslagvast
,      irg.indbeeindigd
,      irg.srtuitkering
,      irg.bronuitkering
,      irg.indgeheleloontijdvakziek
,      ikb.afg_bsn
from  okv_gina_po.okv_inkomstenopgaveregel_h_hv irg
inner join bdr_gina_po.inkomstenbron_h_hm ikb
on    irg.inkomstenbronid = ikb.id 
;

declare
v_test_var number;
begin

	select
    		count(*)
	into v_test_var
	from
	    all_indexes
	where lower(index_name) = 'inkomstenopgaveregelid_ix1'
	and lower(owner) = 'bdr_gina_po';

	if v_test_var = 1 then
		execute immediate 'drop index bdr_gina_po.inkomstenopgaveregelid_ix1';
	end if;
end;
/
create index  bdr_gina_po.inkomstenopgaveregelid_ix1 on  bdr_gina_po.inkomstenopgaveregel_h_hm (id);

spo off
column Dbs clear

-- End of script --