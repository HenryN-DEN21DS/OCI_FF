----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_aangifte_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van aangifte gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_aangifte_h_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'aangifte_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.aangifte_h_hm';
    end loop;
end;
/
  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_aangifte_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_aangifte_h_hm';
    end loop;
end;
/

create materialized  view bdr_gina_po.aangifte_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select aan.dim_start_datum
,      aan.dim_eind_datum
,      aan.dim_recent_ind
,      aan.changetype
,      aan.aangifteberichtnummer
,      aan.afg_bsn
,      aan.communicatiekanaal
,      aan.afg_datumontvangst
,      aan.timestamp
,      aan.id_hist
,      aan.id
,      aan.bsn
,      aan.cdwetarchivering
,      aan.datumontvangst
,      aan.userid
,      aan.afg_timestamp
from  okv_gina_po.okv_aangifte_h_hv aan
;
   
declare
v_test_var number;
begin

	select
    		count(*)
	into v_test_var
	from
	    all_indexes
	where lower(index_name) = 'aangifteid_ix1'
	and lower(owner) = 'bdr_gina_po';

	if v_test_var = 1 then
		execute immediate 'drop index bdr_gina_po.aangifteid_ix1';
	end if;
end;
/

create index  bdr_gina_po.aangifteid_ix1 on  bdr_gina_po.aangifte_h_hm (id);

spo off
column Dbs clear

-- End of script --