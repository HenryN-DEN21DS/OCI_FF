----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_signaal_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van signaal gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_signaal_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'signaal_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.signaal_h_hm';
    end loop;
end;
/
  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_signaal_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_signaal_h_hm';
    end loop;
end;
/

create materialized view bdr_gina_po.signaal_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select sgl.dim_start_datum
,      sgl.dim_eind_datum
,      sgl.dim_recent_ind
,      sgl.id_hist
,      sgl.id
,      sgl.afg_dataangemaakt
,      sgl.afg_datafgehandeld
,      sgl.userid
,      sgl.afg_timestamp
,      sgl.changetype
,      sgl.dataangemaakt
,      sgl.datafgehandeld
,      sgl.inkomstenopgaveid
,      sgl.timestamp
,      ipg.afg_bsn
from  okv_gina_po.okv_signaal_h_hv sgl
inner join  bdr_gina_po.inkomstenopgave_h_hm ipg
on    sgl.inkomstenopgaveid = ipg.id 
;                    
  
declare
v_test_var number;
begin

	select
    		count(*)
	into v_test_var
	from
	    all_indexes
	where lower(index_name) = 'signaalid_ix1'
	and lower(owner) = 'bdr_gina_po';

	if v_test_var = 1 then
		execute immediate 'drop index bdr_gina_po.signaalid_ix1';
	end if;
end;
/
create index  bdr_gina_po.signaalid_ix1 on  bdr_gina_po.signaal_h_hm (id);  

spo off
column Dbs clear

-- End of script --