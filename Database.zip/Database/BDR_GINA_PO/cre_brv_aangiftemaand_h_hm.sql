----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_aangiftemaand_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van aangiftemaand gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_aangiftemaand_h_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'aangiftemaand_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.aangiftemaand_h_hm';
    end loop;
end;
/

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_aangiftemaand_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_aangiftemaand_h_hm';
    end loop;
end;
/

create materialized view bdr_gina_po.aangiftemaand_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select anm.dim_start_datum
,      anm.dim_eind_datum
,      anm.dim_recent_ind
,      anm.changetype
,      anm.datumaanvang
,      anm.datumeinde
,      anm.indcontrolemaand
,      anm.userid
,      anm.afg_timestamp
,      anm.indtoeslagpartner
,      anm.id_hist
,      anm.id
,      anm.afg_datumaanvang
,      anm.afg_datumeinde
,      anm.aangifteid
,      anm.timestamp
,      anm.indtoeslag
,      ang.afg_bsn
from  okv_gina_po.okv_aangiftemaand_h_hv anm 
inner join  bdr_gina_po.aangifte_h_hm ang 
on    anm.aangifteid = ang.id
and ang.dim_eind_datum = to_timestamp('31-12-9999 00:00:00' , 'DD-MM-YYYY HH24:MI:SS')
;

declare
v_test_var number;
begin

	select
    		count(*)
	into v_test_var
	from
	    all_indexes
	where lower(index_name) = 'aangiftemaandid_ix1'
	and lower(owner) = 'bdr_gina_po';

	if v_test_var = 1 then
		execute immediate 'drop index bdr_gina_po.aangiftemaandid_ix1';
	end if;
end;
/
create index  bdr_gina_po.aangiftemaandid_ix1 on  bdr_gina_po.aangiftemaand_h_hm (id);

spo off
column Dbs clear

-- End of script --