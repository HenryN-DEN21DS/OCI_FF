----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_inkomstenopgave_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van inkomstenopgave gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_inkomstenopgave_h_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'inkomstenopgave_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.inkomstenopgave_h_hm';
    end loop;
end;
/  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_inkomstenopgave_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_inkomstenopgave_h_hm';
    end loop;
end;
/

create materialized  view bdr_gina_po.inkomstenopgave_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select ipg.dim_start_datum
,      ipg.dim_eind_datum
,      ipg.dim_recent_ind
,      ipg.changetype
,      ipg.dataanvang
,      ipg.dateinde
,      ipg.datinzendenvanaf
,      ipg.status
,      ipg.datumontvangst
,      ipg.indondertekendpartner
,      ipg.indvolledigformulier
,      ipg.initiatorcontrole
,      ipg.userid
,      ipg.afg_timestamp
,      ipg.afg_datdagtekening
,      ipg.tijdvaknummer
,      ipg.indherinneringeitverzonden
,      ipg.id_hist
,      ipg.id
,      ipg.afg_dataanvang
,      ipg.afg_dateinde
,      ipg.afg_datinzendenvanaf
,      ipg.statusaangifteiko
,      ipg.afg_datumontvangst
,      ipg.indondertekend
,      ipg.initiatoropgave
,      ipg.uitkeringsgerechtigdeid
,      ipg.timestamp
,      ipg.datdagtekening
,      ipg.indallebronnenaanwezig
,      ipg.cdcommunicatiekanaal
,      ipg.indpolisbeschikbaarverzonden
,      ugt.afg_bsn
from  okv_gina_po.okv_inkomstenopgave_h_hv ipg
inner join   bdr_gina_po.uitkeringsgerechtigde_h_hm ugt 
on    ipg.uitkeringsgerechtigdeid = ugt.id  
and   ugt.dim_eind_datum= to_timestamp('31-12-9999 00:00:00' , 'DD-MM-YYYY HH24:MI:SS')
;
  
declare
v_test_var number;
begin

	select
    		count(*)
	into v_test_var
	from
	    all_indexes
	where lower(index_name) = 'inkomstenopgaveid_ix1'
	and lower(owner) = 'bdr_gina_po';

	if v_test_var = 1 then
		execute immediate 'drop index bdr_gina_po.inkomstenopgaveid_ix1';
	end if;
end;
/
create index  bdr_gina_po.inkomstenopgaveid_ix1 on  bdr_gina_po.inkomstenopgave_h_hm (id);  

spo off
column Dbs clear

-- End of script --