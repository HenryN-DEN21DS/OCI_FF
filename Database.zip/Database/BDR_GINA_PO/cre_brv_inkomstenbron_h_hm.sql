----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_inkomstenbron_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van inkomstenbron gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_inkomstenbron_h_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'inkomstenbron_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.inkomstenbron_h_hm';
    end loop;
end;
/  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_inkomstenbron_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_inkomstenbron_h_hm';
    end loop;
end;
/

create materialized  view bdr_gina_po.inkomstenbron_h_hm
 PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
 as
select ikb.dim_start_datum
,      ikb.dim_eind_datum
,      ikb.dim_recent_ind
,      ikb.changetype
,      ikb.soort
,      ikb.datumaanvang
,      ikb.datumeinde
,      ikb.indalleurenwerkloos
,      ikb.indhandmbeoordelen
,      ikb.indrisicoikvzw
,      ikb.cdaardarbeidsverhouding
,      ikb.loonheffingennr
,      ikb.naam
,      ikb.indnoodzaakscholing
,      ikb.userid
,      ikb.afg_timestamp
,      ikb.indkortenrisicoikv
,      ikb.datumaanvangrisicoikvww
,      ikb.id_hist
,      ikb.id
,      ikb.type
,      ikb.afg_datumaanvang
,      ikb.afg_datumeinde
,      ikb.indicatiebuitenland
,      ikb.indinkomstenpartner
,      ikb.motivatiemutatie
,      ikb.cdsoortikv
,      ikb.afg_loonheffingennr
,      ikb.nrikv
,      ikb.uitkeringsgerechtigdeid
,      ikb.timestamp
,      ikb.indaanspraakvaktoeslag
,      ikb.indaangiftefreq4wk
,      ikb.afg_datumaanvangrisicoikvww
,      ikb.indverrekenentoeslag
,      ugt.afg_bsn
from  okv_gina_po.okv_inkomstenbron_h_hv ikb
inner join bdr_gina_po.uitkeringsgerechtigde_h_hm ugt 
on    ikb.uitkeringsgerechtigdeid = ugt.id  
and ugt.dim_eind_datum=to_timestamp('31-12-9999 00:00:00' , 'DD-MM-YYYY HH24:MI:SS')
;


declare
v_test_var number;
begin

	select
    		count(*)
	into v_test_var
	from
	    all_indexes
	where lower(index_name) = 'inkomstenbronid_ix1'
	and lower(owner) = 'bdr_gina_po';

	if v_test_var = 1 then
		execute immediate 'drop index bdr_gina_po.inkomstenbronid_ix1';
	end if;
end;
/
create index  bdr_gina_po.inkomstenbronid_ix1 on  bdr_gina_po.inkomstenbron_h_hm (id);

spo off
column Dbs clear

-- End of script --