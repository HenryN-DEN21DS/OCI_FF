----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_inkomstenorteverr_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van inkomstenorteverr gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbsh
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_aangifte_h_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'inkomstenorteverr_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.inkomstenorteverr_h_hm';
    end loop;
end;
/  
  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_inkomstenorteverr_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_inkomstenorteverr_h_hm';
    end loop;
end;
/

create materialized  view bdr_gina_po.inkomstenorteverr_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select ivt.dim_start_datum
,      ivt.dim_eind_datum
,      ivt.dim_recent_ind
,      ivt.id_hist
,      ivt.id
,      ivt.bdrinkomsten
,      ivt.szproduct
,      ivt.userid
,      ivt.afg_timestamp
,      ivt.changetype
,      ivt.categorieteverr
,      ivt.aanturen
,      ivt.inkomstenopgaveregelid
,      ivt.timestamp
,      irg.afg_bsn
from  okv_gina_po.okv_inkomstenorteverr_h_hv ivt
inner join  inkomstenopgaveregel_h_hm irg
on    ivt.inkomstenopgaveregelid =  irg.id 
;


spo off
column Dbs clear

-- End of script --