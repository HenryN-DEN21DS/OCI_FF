----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_periodeindicatie_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van periodeindicatie gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_periodeindicatie_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'periodeindicatie_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.periodeindicatie_h_hm';
    end loop;
end;
/

 begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_periodeindicatie_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_periodeindicatie_h_hm';
    end loop;
end;
/

create materialized view bdr_gina_po.periodeindicatie_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select pdt.dim_start_datum
,      pdt.dim_eind_datum
,      pdt.dim_recent_ind
,      pdt.changetype
,      pdt.dataanvang
,      pdt.dateinde
,      pdt.type
,      pdt.uitkeringsgerechtigdeid
,      pdt.timestamp
,      pdt.id_hist
,      pdt.id
,      pdt.afg_dataanvang
,      pdt.afg_dateinde
,      pdt.aanturen
,      pdt.userid
,      pdt.afg_timestamp
,      ugt.afg_bsn
from  okv_gina_po.okv_periodeindicatie_h_hv  pdt
inner join   bdr_gina_po.uitkeringsgerechtigde_h_hm ugt 
on    ugt.id = pdt.uitkeringsgerechtigdeid
and ugt.dim_eind_datum = to_timestamp('31-12-9999 00:00:00' , 'DD-MM-YYYY HH24:MI:SS')
;                

	
spo off
column Dbs clear

-- End of script --