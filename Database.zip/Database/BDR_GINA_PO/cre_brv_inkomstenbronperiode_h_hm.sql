----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_brv_inkomstenbronperiode_h_hm.sql
-- Datum : 23-01-2023
-- Doel  : Script voor aanmaken van inkomstenbronperiode gegevensvensters.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 23-01-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_brv_inkomstenbronperiode_h_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'inkomstenbronperiode_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.inkomstenbronperiode_h_hm';
    end loop;
end;
/  
begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_inkomstenbronperiode_h_hm') loop
            execute immediate 'drop materialized view bdr_gina_po.brv_inkomstenbronperiode_h_hm';
    end loop;
end;
/

create materialized  view bdr_gina_po.inkomstenbronperiode_h_hm
PCTFREE 0
 COMPRESS 
 BUILD DEFERRED 
    DISABLE QUERY REWRITE
as
select ipd.dim_start_datum
,      ipd.dim_eind_datum
,      ipd.dim_recent_ind
,      ipd.changetype
,      ipd.cdsoortattribuutinkomstenbron
,      ipd.afg_datumaanvang
,      ipd.inkomstenbronid
,      ipd.timestamp
,      ipd.id_hist
,      ipd.id
,      ipd.datumaanvang
,      ipd.indicatie
,      ipd.userid
,      ipd.afg_timestamp
,      ipd.bedrag
,      ikb.afg_bsn
from  okv_gina_po.okv_inkomstenbronperiode_h_hv ipd
inner join  bdr_gina_po.inkomstenbron_h_hm ikb
on    ipd.inkomstenbronid = ikb.id 
;

spo off
column Dbs clear

-- End of script --