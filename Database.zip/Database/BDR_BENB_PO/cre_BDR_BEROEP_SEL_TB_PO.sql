﻿-- Naam  : cre_BDR_BEROEP_SEL_TB_PM.sql
-- Doel  : Script voor het creëeren van de BDR_BEROEP_SEL_TB tabel
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 30-11-2022 mwo096 Toevoeging datamodel
-- 27-07-2022 jsc226 Toevoegen INLOGNAAM_MBR
-- 21-07-2022 jsc226 Toevoegen REDEN_INTREKKING
-- 16-05-2022 mle134 Aangemaakt
-- ------------------------------------------------------------------------------

begin
    for i in (select null from user_objects where object_type = 'TABLE' and lower(object_name) = 'bdr_beroep_sel_tb') loop
            execute immediate 'drop table bdr_beroep_sel_tb';
    end loop;
end;
/

CREATE TABLE BDR_BEROEP_SEL_TB
(
    DIM_BEROEP_KEY            VARCHAR2(99) NOT NULL,
    DIM_START_DATUM           TIMESTAMP(6) NOT NULL, 
    PROCES_TYPE               VARCHAR2(9), 
    PRODUCTGROEP              VARCHAR2(99), 
    DICTUM                    VARCHAR2(999), 
    WET                       VARCHAR2(999),
    PRIM_BESLISSING1          VARCHAR2(99), 
    PRIM_BESLISSING2          VARCHAR2(99), 
    GESCHIL1                  VARCHAR2(99), 
    GESCHIL2                  VARCHAR2(99), 
    KANTOOR                   VARCHAR2(99),
    INDIENER                  VARCHAR2(99), 
    PRIM_AFDELING1            VARCHAR2(999),
    PRIM_AFDELING2            VARCHAR2(999), 
    PRIM_AFDELING3            VARCHAR2(999),
    JUNK                      VARCHAR2(99),
    DATUM_BESLISSING          NUMBER,
    DATUM_START_PROCES        NUMBER,
    DATUM_EIND_PROCES         NUMBER,
    DATUM_INTREKKING          NUMBER,
    ZAAKNUMMER                VARCHAR2(999),
    REDEN_INTREKKING          VARCHAR2(99),
    INLOGNAAM_MBR             VARCHAR2(99),
    REGISTRATIENUMMER         VARCHAR2(99),
    ERD                       NUMBER,
    GRIFFIERECHT_BEDRAG       NUMBER,
    PROCESKOSTEN_BEDRAG       NUMBER,
    SCHADEVERGOEDING_BEDRAG   NUMBER
) compress for oltp;