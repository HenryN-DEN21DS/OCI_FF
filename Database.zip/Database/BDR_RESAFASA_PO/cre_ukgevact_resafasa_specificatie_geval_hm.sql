----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_ukgevact_resafasa_specificatie_geval_hm.sql
-- Datum : 04-01-2023
-- Doel  : Script voor aanmaken van rf.specificatie geval gegevensvensters t.b.v. Uitkeren.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 04-08-2023 rha163 voor code_verzekerde_wao, _waz en _wia null vervangen door 0
-- 04-01-2023 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_ukgevact_resafasa_specificatie_geval_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_ukgevact_specificatie_geval_hm') loop
            execute immediate 'drop materialized view bdr_resafasa_po.brv_ukgevact_specificatie_geval_hm';
    end loop;
end;
/

create materialized view bdr_resafasa_po.brv_ukgevact_specificatie_geval_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
select
spe_gev.volgnummer_geval                                    as volgnummer_geval,
spe_gev.code_verzekerde_wia                                 as code_verzekerde_wia,
spe_gev.code_verzekerde_wao                                 as code_verzekerde_wao,
spe_gev.code_verzekerde_wajong                              as code_verzekerde_wajong,
spe_gev.code_verzekerde_waz                                 as code_verzekerde_waz,
spe_gev.datum_beeindiging                                   as datum_beeindiging,
spe_gev.code_beeindiging                                    as code_beeindiging,
gev.dk_nummer                                               as dk_nummer,
spe_gev.dim_start_datum                                     as dim_start_datum,
spe_gev.dim_eind_datum                                      as dim_eind_datum, 
case 
    when to_char(spe_gev.dim_eind_datum, 'yyyymmdd') = '99991231' then 'J'
    else 'N'
end                                                         as dim_recent_ind, 
rtrim(
    decode(spe_gev.code_verzekerde_wajong,'33','NWAJONG-',NULL)||
    decode(spe_gev.code_verzekerde_wajong,'34','NWAJONG-',NULL)||
    decode(spe_gev.code_verzekerde_wajong,'39','NWAJONG-',NULL)||
    decode(spe_gev.code_verzekerde_wajong,'35','NWAJONG2015-',NULL)||
    decode(spe_gev.code_verzekerde_wajong,'30','OWAJONG-',NULL)||
    decode(spe_gev.code_verzekerde_wajong,'31','OWAJONG-',NULL)||
    decode(spe_gev.code_verzekerde_wao,0,'','WAO-')||
    decode(spe_gev.code_verzekerde_waz,0,'','WAZ-')||
    decode(spe_gev.code_verzekerde_wia,0,'','WIA-')
    , '-')                                                  as wetten
from okv_resafasa_po.okv_specificatie_geval_hv spe_gev
    left join okv_resafasa_po.okv_geval_hv  gev
        on spe_gev.volgnummer_geval = gev.volgnummer_geval
        and to_char(gev.dim_eind_datum, 'dd-mm-yyyy')='31-12-9999' 
where gev.dk_nummer not in
    (
        8,
        20,
        43,
        46
    )
and gev.afg_burgerservicenummer not in
    (
            select afg_bsn
            from dim_beveiliging.bev_vip_po_mv vip
    );



    
BEGIN 
    DBMS_MVIEW.REFRESH('brv_ukgevact_specificatie_geval_hm', '?', '', true, false, 0,0,0, true,false,false); 
END;
/

spo off
column Dbs clear

-- End of script --