----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_ukgevact_resafasa_regie_locatie_hm.sql
-- Datum : 04-01-2023
-- Doel  : Script voor aanmaken van rf.regie locatie gegevensvensters t.b.v. Uitkeren.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 04-01-2023 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_ukgevact_resafasa_regie_locatie_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_ukgevact_regie_locatie_hm') loop
            execute immediate 'drop materialized view bdr_resafasa_po.brv_ukgevact_regie_locatie_hm';
    end loop;
end;
/

create materialized view bdr_resafasa_po.brv_ukgevact_regie_locatie_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
    select
        locatie.districtsnummer,
        district.district_naam,
        district.district_afko,
        locatie.nummer_dk,
        locatie.vestigingsnaam,
        locatie.bron,
        locatie.dim_start_datum,
        locatie.dim_eind_datum,
        case
            when to_char(locatie.dim_eind_datum, 'yyyymmdd') = '99991231' then
                'J'
            else
                'N'
        end as dim_recent_ind
    from
        okv_resafasa_po.ref_resafasa_regie_locatie_nummer_dk_hv      locatie
        left outer join okv_resafasa_po.ref_resafasa_districten_districtsnummer_hv   district on locatie.districtsnummer = district.
        districtsnummer;

BEGIN 
    DBMS_MVIEW.REFRESH('brv_ukgevact_regie_locatie_hm', '?', '', true, false, 0,0,0, true,false,false); 
END;
/

spo off
column Dbs clear

-- End of script --