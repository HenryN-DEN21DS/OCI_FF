----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_ggv_actie_hm.sql
-- Datum : 18-08-2022
-- Doel  : Script voor aanmaken van rf.actie gegevensvensters t.b.v. DMAP.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-08-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_ggv_actie_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'actie_hm') loop
            execute immediate 'DROP MATERIALIZED VIEW bdr_resafasa_po.actie_hm';
    end loop;
end;
/

create materialized view bdr_resafasa_po.actie_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
    select
        bsn,
        volgnummer_geval,
        datum_beeindiging,
        nummer_hoofdgroep,
        verantw_funct_nr_rf_kantoor,
        code_geslacht_verantw_funct,
        code_actie,
        startdatum_actie,
        datum_afhandeling,
        geplande_datum_rappeldatum,
        aantal_rappels,
        uitvoerende_functionaris,
        datum_creatie,
        nummer_dk,
        afg_registratienummer,
        afg_bsn,
        datum_ew,
        naam_verzekerde,
        nummer_dk_team,
        verantw_funct_personeelsnr,
        naam_verantw_functionaris,
        omschrijving_actie,
        code_afhandeling,
        code_opmerking,
        datum_volgende_rappel,
        uitvoerend_dk,
        datum_mutatie,
        volgnummer_dim,
        dim_start_datum,
        dim_eind_datum,
        dim_recent_ind,
        dim_status,
        dim_bron,
        dim_archiefvernietiging_status,
        dim_datum_aanmaak,
        dim_user_aanmaak,
        dim_datum_gewijzigd,
        dim_user_gewijzigd,
        registratienummer
    from
        okv_resafasa_po.okv_actie_hv;


BEGIN 
    DBMS_MVIEW.REFRESH (  'actie_hm', '?', '', true, false, 0,0,0, true,false,false); 
END;
/

spo off
column Dbs clear

-- End of script --