----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_ukgevact_resafasa_acties_hm.sql
-- Datum : 04-01-2023
-- Doel  : Script voor aanmaken van rf.actie gegevensvensters t.b.v. Uitkeren.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 04-01-2023 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_ukgevact_resafasa_acties_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'brv_ukgevact_acties_hm') loop
            execute immediate 'drop materialized view bdr_resafasa_po.brv_ukgevact_acties_hm';
    end loop;
end;
/

create materialized view bdr_resafasa_po.brv_ukgevact_acties_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
    select
        act.volgnummer_geval              as volgnummer_geval,
        act.datum_afhandeling             as datum_afhandeling,
        act.startdatum_actie              as startdatum_actie,
        act.afg_bsn                       as bsn,
        act.geplande_datum_rappeldatum    as geplande_datum_rappeldatum,
        act.datum_volgende_rappel         as datum_volgende_rappel,
        act.datum_ew                      as datum_eindewachttijd,
        act.code_afhandeling              as code_afhandeling,
        act.code_actie                    as code_actie,
        act.nummer_hoofdgroep             as nummer_hoofdgroep,
        act.nummer_dk                     as dk_nummer,
        act.afg_registratienummer         as registratienummer,
        act.uitvoerende_functionaris      as uitvoerende_functionaris,
        act.verantw_funct_personeelsnr    as verantw_funct_personeelsnr,
        act.naam_verantw_functionaris     as naam_verantw_functionaris,
        act.verantw_funct_nr_rf_kantoor   as verantw_funct_nr_rf_kantoor,
        act.nummer_dk_team                as nummer_dk_team,
        act.datum_creatie                 as datum_creatie,
        act.volgnummer_dim                as volgnummer_dim,
        act.dim_start_datum               as dim_start_datum,
        act.dim_eind_datum                as dim_eind_datum,
        case
            when to_char(dim_eind_datum, 'yyyymmdd') = '99991231' then
                'J'
            else
                'N'
        end as dim_recent_ind
    from
        okv_resafasa_po.okv_actie_hv act
    where
        act.nummer_dk not in (
            46,
            8,
            20,
            43
        )
        and act.afg_bsn not in (
            select
                afg_bsn
            from
                dim_beveiliging.bev_vip_po_mv
            where
                to_char(dim_eind_datum, 'dd-mm-yyyy') = '31-12-9999'
        );

BEGIN 
    DBMS_MVIEW.REFRESH('brv_ukgevact_acties_hm', '?', '', true, false, 0,0,0, true,false,false); 
END;
/

spo off
column Dbs clear

-- End of script --