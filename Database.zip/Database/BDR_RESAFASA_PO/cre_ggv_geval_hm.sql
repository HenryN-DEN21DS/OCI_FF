----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_ggv_geval_hm.sql
-- Datum : 18-08-2022
-- Doel  : Script voor aanmaken van rf.actie gegevensvensters t.b.v. DMAP.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-08-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_ggv_geval_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'geval_hm') loop
            execute immediate 'DROP MATERIALIZED VIEW bdr_resafasa_po.geval_hm';
    end loop;
end;
/

create materialized view bdr_resafasa_po.geval_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
    select
        dim_start_datum,
        dim_eind_datum,
        dim_recent_ind,
        dim_status,
        dim_bron,
        dim_archiefvernietiging_status,
        dim_datum_aanmaak,
        dim_user_aanmaak,
        dim_datum_gewijzigd,
        dim_user_gewijzigd,
        registratienummer,
        sorteerveld,
        afg_burgerservicenummer,
        registratienummer_oud,
        indicatie_inrichting,
        code_categorie_ind,
        nummer_hoofdgroep,
        nummer_werkplaats_wsw,
        diagnosecode_2,
        nr_regielocatie,
        volgnummer_geval,
        dk_nummer,
        afg_registratienummer,
        burgerservicenummer,
        dk_nummer_oud,
        afg_registratienummer_oud,
        code_oorzaak_ao,
        ind_nieuw_geval,
        ind_oud_nieuw,
        diagnosecode_1,
        diagnosecode_3,
        oudste_wao_dag
    from
        okv_resafasa_po.okv_geval_hv;

BEGIN 
    DBMS_MVIEW.REFRESH (  'geval_hm', '?', '', true, false, 0,0,0, true,false,false); 
END;
/

spo off
column Dbs clear

-- End of script --