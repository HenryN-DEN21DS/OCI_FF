----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_ggv_koppel_hm.sql
-- Datum : 18-08-2022
-- Doel  : Script voor aanmaken van rf.koppel gegevensvensters t.b.v. DMAP.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-08-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_ggv_actie_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'koppel_hm') loop
            execute immediate 'DROP MATERIALIZED VIEW bdr_resafasa_po.koppel_hm';
    end loop;
end;
/

create materialized view bdr_resafasa_po.koppel_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
    select
        dim_start_datum,
        dim_eind_datum,
        dim_recent_ind,
        dim_status,
        dim_bron,
        dim_archiefvernietiging_status,
        dim_datum_aanmaak,
        dim_user_aanmaak,
        dim_datum_gewijzigd,
        dim_user_gewijzigd,
        bsn,
        registratienummer,
        code_verzekerde_wia,
        code_verzekerde_wajong,
        datum_aanvang_wia,
        datum_aanvang_wajong_2015,
        datum_aanvang_oude_wajong,
        nummer_dk,
        afg_bsn,
        afg_registratienummer,
        code_verzekerde_waz,
        code_verzekerde_wao,
        datum_aanvang_waz,
        datum_aanvang_wajong_2010,
        datum_aanvang_wao
    from
        okv_resafasa_po.okv_koppel_hv;

BEGIN 
    DBMS_MVIEW.REFRESH (  'koppel_hm', '?', '', true, false, 0,0,0, true,false,false); 
END;
/

spo off
column Dbs clear

-- End of script --