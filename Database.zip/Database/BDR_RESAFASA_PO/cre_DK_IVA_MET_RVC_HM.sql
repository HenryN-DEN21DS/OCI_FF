
  CREATE MATERIALIZED VIEW BDR_RESAFASA_PO.DK_IVA_MET_RVC_HM
  BUILD IMMEDIATE
  USING INDEX 
  REFRESH FORCE ON DEMAND
  AS with spec_wia_uniek as (
    select 
    sio.volgnummer_geval,
    sni.sorteerveld,
    sni.begindatum_spec,
    sni.code_soort_recht,
    sni.restverdiencapaciteit,
    sni.code_soort_uitkering,
    sni.code_overdracht,
    sni.volgnummer_spec,
    hub.dim_start_datum,
    code_kenmerk_wijziging,
    row_number() over (partition by sio.volgnummer_geval, sni.begindatum_spec order by hub.dim_start_datum desc) volgnr_mutatie
    from brz_resafasa.brz_specificatie_wia_hub_ht hub
    join brz_resafasa.brz_specificatie_wia_sio_ht sio
        on hub.dim_key_brz = sio.dim_key_brz
    join brz_resafasa.brz_specificatie_wia_sni_ht sni
        on hub.dim_key_brz = sni.dim_key_brz
)



select 
    bsn.burgerservicenummer BSN
    , swu.volgnummer_geval
    , swu.code_overdracht 
    , co.OMSCHRIJVING code_overdracht_oms
    , nvl(swu.code_kenmerk_wijziging, 0) code_kenmerk_wijziging
    , nvl(ckw.OMSCHRIJVING,' ') code_kenmerk_wijziging_oms
    , swu.code_soort_recht
    , swu.restverdiencapaciteit
    , case 
        when swu.restverdiencapaciteit > 0 then 'J' else 'N'
      end as rvc_groter_dan_nul
    , swu.begindatum_spec
    , cast(swu.dim_start_datum as date) dim_start_datum

from spec_wia_uniek swu

    inner join (select 
volgnummer_geval,
burgerservicenummer
from brz_resafasa.brz_geval_hub_ht hub
    join brz_resafasa.brz_geval_sio_ht sio
        on hub.dim_key_brz = sio.dim_key_brz
    join brz_resafasa.brz_geval_sni_ht sni
        on hub.dim_key_brz = sni.dim_key_brz
where dim_eind_datum = date'9999-12-31') bsn on swu.volgnummer_geval = bsn.volgnummer_geval

left join okv_referentie_data.ref_resafasa_specificatie_wia_code_overdracht_tb co on swu.code_overdracht = co.code_overdracht and co.dim_eind_datum = date'9999-12-31'
left join okv_referentie_data.ref_resafasa_specificatie_wia_code_kenmerk_wijziging_tb ckw on swu.code_kenmerk_wijziging = ckw.code_kenmerk_wijziging and ckw.dim_eind_datum = date'9999-12-31'

where swu.volgnr_mutatie = 1
and code_soort_recht in ('I','G');

   COMMENT ON MATERIALIZED VIEW "BDR_RESAFASA_PO"."DK_IVA_MET_RVC_HM"  IS 'Resafasa datakwaliteit: IVA-uitkeringen met restverdiencapaciteit';



