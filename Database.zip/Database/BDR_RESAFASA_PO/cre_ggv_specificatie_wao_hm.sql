----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_ggv_specificatie_wao_hm.sql
-- Datum : 18-08-2022
-- Doel  : Script voor aanmaken van rf.recht gegevensvensters t.b.v. DMAP.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-08-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_ggv_specificatie_wao_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'specificatie_wao_hm') loop
            execute immediate 'DROP MATERIALIZED VIEW bdr_resafasa_po.specificatie_wao_hm';
    end loop;
end;
/

create materialized view bdr_resafasa_po.specificatie_wao_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
    select
        dim_start_datum,
        dim_eind_datum,
        dim_recent_ind,
        dim_status,
        dim_bron,
        dim_archiefvernietiging_status,
        dim_datum_aanmaak,
        dim_user_aanmaak,
        dim_datum_gewijzigd,
        dim_user_gewijzigd,
        sorteerveld,
        datum_overdracht,
        code_overdracht,
        code_kenmerk_wijziging,
        uitkeringspercentage,
        code_dagloon,
        pro_rata_breuk,
        code_sanctie,
        maatregel_perc_wao,
        volgnummer_spec,
        begindatum_spec,
        afg_datum_overdracht,
        code_index,
        ao_klasse,
        bedrag_dagloon,
        bedrag_geindexeerd_dagloon,
        percentage_parttime,
        indicatie_aof_aok,
        volgnummer_geval
    from
        okv_resafasa_po.okv_specificatie_wao_hv;

BEGIN 
    DBMS_MVIEW.REFRESH (  'specificatie_wao_hm', '?', '', true, false, 0,0,0, true,false,false); 
END;
/

spo off
column Dbs clear

-- End of script --