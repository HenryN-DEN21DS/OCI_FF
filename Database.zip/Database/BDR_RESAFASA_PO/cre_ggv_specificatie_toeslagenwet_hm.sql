----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_ggv_specificatie_toeslagenwet_hm.sql
-- Datum : 18-08-2022
-- Doel  : Script voor aanmaken van rf.recht gegevensvensters t.b.v. DMAP.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-08-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_ggv_specificatie_toeslagenwet_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'specificatie_toeslagenwet_hm') loop
            execute immediate 'DROP MATERIALIZED VIEW bdr_resafasa_po.specificatie_toeslagenwet_hm';
    end loop;
end;
/

create materialized view bdr_resafasa_po.specificatie_toeslagenwet_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
    select
        dim_start_datum,
        dim_eind_datum,
        dim_recent_ind,
        dim_status,
        dim_bron,
        dim_archiefvernietiging_status,
        dim_datum_aanmaak,
        dim_user_aanmaak,
        dim_datum_gewijzigd,
        dim_user_gewijzigd,
        begindatum_spec,
        afg_datum_overdracht,
        code_index,
        code_toeslag,
        code_korting,
        code_leefvorm,
        bedrag_garantie_alleenstaa,
        volgnummer_geval,
        sorteerveld,
        datum_overdracht,
        code_overdracht,
        code_kenmerk_wijziging,
        bedrag_toeslag,
        bedrag_korting,
        ind_garantie_alleenstaanden,
        maatregel_perc_tw,
        volgnummer_spec
    from
        okv_resafasa_po.okv_specificatie_toeslagenwet_hv;

BEGIN 
    DBMS_MVIEW.REFRESH (  'specificatie_toeslagenwet_hm', '?', '', true, false, 0,0,0, true,false,false); 
END;
/

spo off
column Dbs clear

-- End of script --
