----------------------------------------------------------------------------------------------------------------------------------------
-- Naam  : cre_ggv_specificatie_geval_hm.sql
-- Datum : 18-08-2022
-- Doel  : Script voor aanmaken van rf.recht gegevensvensters t.b.v. DMAP.
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 18-08-2022 tgr033 Aangemaakt
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_ggv_specificatie_geval_hm_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;


begin
    for i in (select NULL from user_objects where upper(object_type) = 'MATERIALIZED VIEW' and lower(object_name) = 'specificatie_geval_hm') loop
            execute immediate 'DROP MATERIALIZED VIEW bdr_resafasa_po.specificatie_geval_hm';
    end loop;
end;
/

create materialized view bdr_resafasa_po.specificatie_geval_hm
    build immediate
    refresh
        force
        on demand
disable query rewrite as
    select
        dim_start_datum,
        dim_eind_datum,
        dim_recent_ind,
        dim_status,
        dim_bron,
        dim_archiefvernietiging_status,
        dim_datum_aanmaak,
        dim_user_aanmaak,
        dim_datum_gewijzigd,
        dim_user_gewijzigd,
        begindatum_spec,
        code_overdracht,
        datum_einde_wachttijd,
        datum_beeindiging,
        code_verzekerde_wao,
        datum_schorsing,
        afg_aansluitnummer_wg1,
        nummer_vestiging,
        code_verdragsland,
        code_verdragsland_3,
        nummer_sector,
        code_verzekerde_wajong,
        afg_aansluitnummer_wg2,
        nummer_contract_2,
        oorspr_datum_einde_wachttijd,
        nummer_bv_3,
        nummer_werkgever_3,
        nummer_vestiging_3,
        perc_pro_rata_pdi_werkgever_2,
        nr_loonheffing_werkgever_1,
        nr_loonheffing_werkgever_2,
        nr_loonheffing_werkgever_3,
        indicatie_ex_uvi,
        volgnummer_geval,
        sorteerveld,
        datum_overdracht,
        datum_melding,
        code_beeindiging,
        code_melding,
        code_verzekerde_wia,
        nummer_bv,
        nummer_werkgever,
        nummer_contract,
        code_verdragsland_2,
        code_cib,
        code_verzekerde_waz,
        nummer_bv_2,
        nummer_werkgever_2,
        nummer_vestiging_2,
        datum_1e_ao_dag,
        afg_aansluitnummer_wg3,
        nummer_contract_3,
        perc_pro_rata_pdi_werkgever_1,
        perc_pro_rata_pdi_werkgever_3,
        afg_nr_loonheffing_werkgever_1,
        afg_nr_loonheffing_werkgever_2,
        afg_nr_loonheffing_werkgever_3,
        indicatie_overheidswerknemer
    from
        okv_resafasa_po.okv_specificatie_geval_hv;

BEGIN 
    DBMS_MVIEW.REFRESH (  'specificatie_geval_hm', '?', '', true, false, 0,0,0, true,false,false); 
END;
/

spo off
column Dbs clear

-- End of script --