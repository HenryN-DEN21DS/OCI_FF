-- naam  : FCT_WAJONG_RECHT_IX1.sql
-- datum : 2023-11-21
-- doel  : create index FCT_WAJONG_RECHT_IX1 in BDR_AW_PO
--
-- 
-- datum naam omschrijving
-- ---------- ------ -------------------------------------------------------
-- 2023-11-21 wbe062 aangemaakt
-- -------------------------------------------------------------------------

BEGIN
    EXECUTE IMMEDIATE 'DROP INDEX FCT_WAJONG_RECHT_IX1';
EXCEPTION
    WHEN OTHERS THEN
        IF sqlcode != -1418 THEN
            RAISE;
        END IF;
END;
/
CREATE UNIQUE INDEX FCT_WAJONG_RECHT_IX1 ON BDR_AW_PO.FCT_WAJONG_RECHT (GEVAL_ALGEMEEN_ID,WAJONG_START_DATUM_ADMINISTRATIE_ID,WAJONG_START_DATUM_GELDIGHEID_ID);