BEGIN                                     -- Toevoegen kolom
  execute immediate 'ALTER TABLE BDR_DETENTIE_SIGNALEN_FT 
                     ADD (VOLGNRAANVRAAGUITKERING2 NUMBER(38, 10) )';
  dbms_output.put_line( chr(10) ||'Kolom VOLGNRAANVRAAGUITKERING aangemaakt');
EXCEPTION
  when others then null;
END;
/