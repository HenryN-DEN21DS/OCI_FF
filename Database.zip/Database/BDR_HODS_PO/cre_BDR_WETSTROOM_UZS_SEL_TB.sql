-- Naam  : cre_BDR_WETSTROOM_UZS_TMP_TB.sql
-- Datum : 13-11-20243
-- Doel  : Script voor het creëeren van de temp tabel hods 
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 01-02-2024 rha163 Aangemaakt
-- ------------------------------------------------------------------------------
exec system.tabel_hulp.verwijder_tabel('BDR_HODS_PO.BDR_WETSTROOM_UZS_SEL_TB');
create table BDR_HODS_PO.BDR_WETSTROOM_UZS_SEL_TB (
BURGERSERVICENUMMER varchar2(99),
BURGERSERVICENUMMER_ZW varchar2(99),
VOLGNRAANVRAAGUITKERING varchar2(9) ,
DATBDETENTIE timestamp(6) ,
DATTIJDREGISTRATIE timestamp(6),
DATUM_AANVANG_UITKERING date,
DTM_EERSTE_ZIEKTEDAG date,
DATUM_EINDE_RECHT date,
CDSZWETDRL varchar2(99) ,
DK_NUMMER NUMBER(38,10),
AFG_DETAIL_STATUS_RECHT	VARCHAR2(9),
DIM_START_DATUM_ZW	TIMESTAMP(6),
REDEN_EINDE_RECHT	VARCHAR2(9),
DIM_EIND_DATUM	TIMESTAMP(6),
STATUS VARCHAR2(9),
RANK_SEL VARCHAR2(9),
DATTIJDSEND timestamp(6) null
);