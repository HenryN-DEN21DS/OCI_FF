exec system.tabel_hulp.verwijder_tabel('BDR_HODS_PO.FCT_RESAFASA');
exec system.tabel_hulp.verwijder_tabel('BDR_HODS_PO.BDR_RESAFASA_FT');
create table BDR_HODS_PO.BDR_RESAFASA_FT (
BSN varchar2(99) not null,
DATUM_DETENTIE timestamp(6) not null,
DATUM_DETENTIE_REGISTRATIE timestamp(6),
DATUM_AANVANG_UITKERING date,
DATUM_AANVANG_RECHT date,
DATUM_EINDE_UITKERING date,
DATUM_EINDE_RECHT date,
DIM_CODE_KENMERK_WIJZIGING number,
DIM_WET varchar2(9) not null,
DIM_LOCATIE NUMBER(38,10),
STATUS_DETENTIE_SIGNAAL varchar2(99),
DIM_STATUS_RECHT varchar(99)
,constraint BDR_RESAFASA_FT_PK primary key (BSN,DATUM_DETENTIE,DIM_WET)
);