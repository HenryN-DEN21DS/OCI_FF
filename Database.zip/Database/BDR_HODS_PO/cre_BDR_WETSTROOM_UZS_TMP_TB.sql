-- Naam  : cre_BDR_WETSTROOM_UZS_TMP_TB.sql
-- Datum : 13-11-20243
-- Doel  : Script voor het creëeren van de temp tabel hods 
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 13-11-2023 rha163 Aangemaakt
-- ------------------------------------------------------------------------------
exec system.tabel_hulp.verwijder_tabel('BDR_HODS_PO.BDR_WETSTROOM_UZS_TMP_TB');
create table BDR_HODS_PO.BDR_WETSTROOM_UZS_TMP_TB (
BSN varchar2(99) null,
DATUM_DETENTIE timestamp(6) null,
DATUM_DETENTIE_REGISTRATIE timestamp(6),
DATUM_AANVANG_UITKERING date,
DATUM_AANVANG_RECHT date,
DATUM_EINDE_UITKERING date,
DATUM_EINDE_RECHT date,
DIM_CODE_KENMERK_WIJZIGING number,
DIM_WET varchar2(9)  null,
DIM_LOCATIE NUMBER(38,10),
STATUS_DETENTIE_SIGNAAL varchar2(99),
DIM_STATUS_RECHT varchar(99),
ZW_RIJ number,
DETENTIE_RIJ number,
VOLGNRAANVRAAGUITKERING VARCHAR2(9),
AFG_DETAIL_STATUS_RECHT	VARCHAR2(9)
);