DECLARE

l_nummer NUMBER;

BEGIN

  SELECT COUNT(*)
  INTO   l_nummer
  FROM   user_mviews
  WHERE  mview_name = 'BDR_IOW0112D_HM'
  ;
  --
  IF l_nummer = 1
  THEN
    EXECUTE IMMEDIATE 'drop materialized view BDR_IOW_PO.BDR_IOW0112D_HM';
  END IF;

END;
/

CREATE MATERIALIZED VIEW BDR_IOW_PO.BDR_IOW0112D_HM
BUILD DEFERRED
REFRESH FORCE ON DEMAND
AS
SELECT dim_start_datum
,      dim_eind_datum
,      dim_recent_ind
,      dim_status
,      aansltngsnr
,      afg_sof_nr
,      cd_maatrgl_waarschwng
,      dtm_tijd_reg
,      dtm_tijd_vervlln_iow
,      dtm_aanvng_ovrtrdng
,      dtm_primr_beslssng
,      cd_gebrkr
,      cd_verwtbr
,      bedrg_maatrgl
,      mutt_nr
,      sof_nr
,      volg_nr_aanvrg
,      dtm_begn_perd
,      dtm_eind_perd
,      perc_maatrgl
,      dtm_eind_ovrtrdng
,      ind_recdv
,      dtm_tijd_reg_wijzgng
,      perc_toegpst
,      cd_gebrkr_wijzgng
FROM   okv_iow_po.okv_iow0112d_hv;

