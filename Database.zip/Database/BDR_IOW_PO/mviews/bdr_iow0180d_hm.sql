DECLARE

l_nummer NUMBER;

BEGIN

  SELECT COUNT(*)
  INTO   l_nummer
  FROM   user_mviews
  WHERE  mview_name = 'BDR_IOW0180D_HM'
  ;
  --
  IF l_nummer = 1
  THEN
    EXECUTE IMMEDIATE 'drop materialized view BDR_IOW_PO.BDR_IOW0180D_HM';
  END IF;

END;
/

CREATE MATERIALIZED VIEW BDR_IOW_PO.BDR_IOW0180D_HM
BUILD DEFERRED
REFRESH FORCE ON DEMAND
AS
SELECT dim_start_datum
,      dim_eind_datum
,      dim_recent_ind
,      dim_status
,      sof_nr
,      cd_signl
,      stats_afhndlng_signl
,      cd_gebrkr
,      dtm_tonn_signl_handmtg
,      mutt_nr
,      afg_sof_nr
,      stats_signl
,      dtm_tijd_afhndlng_signl
,      vrije_tekst
,      dtm_tijd_aanmk_signl
FROM   okv_iow_po.okv_iow0180d_hv;

