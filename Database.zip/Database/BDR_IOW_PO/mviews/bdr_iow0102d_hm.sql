DECLARE

l_nummer NUMBER;

BEGIN

  SELECT COUNT(*)
  INTO   l_nummer
  FROM   user_mviews
  WHERE  mview_name = 'BDR_IOW0102D_HM'
  ;
  --
  IF l_nummer = 1
  THEN
    EXECUTE IMMEDIATE 'drop materialized view BDR_IOW_PO.BDR_IOW0102D_HM';
  END IF;

END;
/

CREATE MATERIALIZED VIEW BDR_IOW_PO.BDR_IOW0102D_HM
BUILD DEFERRED
REFRESH FORCE ON DEMAND
AS
SELECT dim_start_datum
,      dim_eind_datum
,      dim_recent_ind
,      dim_status
,      aansltngsnr
,      afg_sof_nr
,      dtm_ingng_recht_iow
,      cd_redn_afwzng_iow
,      dtm_tijd_defntf
,      cd_gebrkr
,      dtm_tijd_verfct_reknr
,      cd_gebrkr_reknr_verfct
,      afg_rek_nr_buitnlnd
,      afg_rek_nr_buitnlnd_iban
,      afg_rek_nr_buitnlnd_reknr
,      dtm_ovrldn
,      dtm_tijd_in_behndlng
,      dtm_tijd_reg_ingng_recht
,      ind_resttt
,      afg_rek_nr_34
,      afg_rek_nr_34_iban
,      afg_rek_nr_34_reknr
,      stats_iow
,      cd_stats_dossr
,      gebrkr_in_behndlng
,      dtm_beslssng_uitstl
,      cd_gebrkr_beslssng_uitstl
,      dtm_eind_resttt
,      mutt_nr
,      sof_nr
,      volg_nr_aanvrg
,      dtm_afwzng
,      dtm_eind_av_iow
,      dtm_tijd_reg
,      cd_gebrkr_reknr
,      dtm_intk
,      rek_nr_buitnlnd
,      naam_bank_buitnlnd
,      swift_adrs_bank_buitnlnd
,      ind_wn_op_pensnlst
,      pnr_in_behndlng
,      ind_tw
,      dtm_beslssng
,      rek_nr_34
,      ind_tw_autmtsch
,      ind_wwz
,      dagln_ww_wga
,      dtm_tijd_wijzgng_reknr
,      dtm_stats_dossr
,      cd_gebrkr_beslssng_aanvrg
,      dtm_beslssng_uitgstld
,      dtm_begn_resttt
,      dtm_begn_ww_wga
FROM   okv_iow_po.okv_iow0102d_hv;

