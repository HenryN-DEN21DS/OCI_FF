DECLARE

l_nummer NUMBER;

BEGIN

  SELECT COUNT(*)
  INTO   l_nummer
  FROM   user_mviews
  WHERE  mview_name = 'BDR_IOW0118D_HM'
  ;
  --
  IF l_nummer = 1
  THEN
    EXECUTE IMMEDIATE 'drop materialized view BDR_IOW_PO.BDR_IOW0118D_HM';
  END IF;

END;
/

CREATE MATERIALIZED VIEW BDR_IOW_PO.BDR_IOW0118D_HM
BUILD DEFERRED
REFRESH FORCE ON DEMAND
AS
SELECT dim_start_datum
,      dim_eind_datum
,      dim_recent_ind
,      dim_status
,      aansltngsnr
,      afg_sof_nr
,      cd_excss
,      dtm_begn_betlpdrcht
,      dtm_eind_betlpdrcht
,      cd_loonbrkng
,      dtm_tijd_vervlln_iow
,      dtm_tijd_betlpdrcht_vervlln
,      srt_uitk
,      ind_door_wg_belst_vw
,      srt_begnstgd
,      ind_vw_regm
,      id_fonds
,      ind_reeds_toegknd
,      ind_verwtbr
,      mutt_nr
,      sof_nr
,      volg_nr_aanvrg
,      srt_vergdng_naar_excss
,      volgnr_betlpdrcht
,      bedrg_betlpdrcht_iow
,      dtm_tijd_reg
,      dtm_tijd_nr_excss
,      srt_ovrg_relt
,      stats_betlpdrcht
,      id_begnstgd_fa
,      ind_verplcht_verzkrd
,      srt_fonds_uitk
,      ind_oud
,      aantl_uitk_dgn
,      ind_resttt
FROM   okv_iow_po.okv_iow0118d_hv;

