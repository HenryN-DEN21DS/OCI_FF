DECLARE

l_nummer NUMBER;

BEGIN

  SELECT COUNT(*)
  INTO   l_nummer
  FROM   user_mviews
  WHERE  mview_name = 'BDR_IOW0103D_HM'
  ;
  --
  IF l_nummer = 1
  THEN
    EXECUTE IMMEDIATE 'drop materialized view BDR_IOW_PO.BDR_IOW0103D_HM';
  END IF;

END;
/

CREATE MATERIALIZED VIEW BDR_IOW_PO.BDR_IOW0103D_HM
BUILD DEFERRED
REFRESH FORCE ON DEMAND
AS
SELECT dim_start_datum
,      dim_eind_datum
,      dim_recent_ind
,      dim_status
,      mutt_nr
,      sof_nr
,      volg_nr_aanvrg
,      dtm_begn_perd
,      dtm_eind_perd
,      aantl_dgn_iow
,      bedrg
,      omschrvng_bedrg_iow
,      dtm_tijd_nr_excss_vervlln
,      srt_vergdng_naar_excss
,      vrw_verlgng_aog
,      pnr_fiat
,      ind_belstn_rw
,      dtm_tijd_betln
,      ind_handmtg
,      relt_nr
,      ind_voor_of_na
,      pnr_vervlln
,      aansltngsnr
,      afg_sof_nr
,      cd_bedrg_iow
,      dtm_tijd_reg
,      dtm_tijd_vervlln_iow
,      bedrg_per_dag
,      bedrg_volldg
,      dtm_tijd_nr_excss
,      cd_uitkrng_naar_excss
,      ind_voorlpg
,      dtm_tijd_fiat
,      pnr_inbrng
,      ind_ophgng
,      ind_op_not
,      cd_loonbrkng
,      dtm_tijd_betlpdrcht_vervlln
,      ind_maatrgl_kortng
,      pnr_betln
FROM   okv_iow_po.okv_iow0103d_hv;

