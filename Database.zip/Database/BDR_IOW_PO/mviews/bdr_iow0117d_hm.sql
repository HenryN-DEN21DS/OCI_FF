DECLARE

l_nummer NUMBER;

BEGIN

  SELECT COUNT(*)
  INTO   l_nummer
  FROM   user_mviews
  WHERE  mview_name = 'BDR_IOW0117D_HM'
  ;
  --
  IF l_nummer = 1
  THEN
    EXECUTE IMMEDIATE 'drop materialized view BDR_IOW_PO.BDR_IOW0117D_HM';
  END IF;

END;
/

CREATE MATERIALIZED VIEW BDR_IOW_PO.BDR_IOW0117D_HM
BUILD DEFERRED
REFRESH FORCE ON DEMAND
AS
SELECT dim_start_datum
,      dim_eind_datum
,      dim_recent_ind
,      dim_status
,      aansltngsnr
,      afg_sof_nr
,      dtm_begn
,      dtm_eind
,      dagbdrg_inkmstn
,      cd_gebrkr
,      inkmstnprd
,      mutt_nr
,      sof_nr
,      volg_nr_aanvrg
,      dtm_tijd_reg
,      cd_inkmstn
,      dtm_tijd_vervlln_iow
,      dtm_tijd_reg_wijzgng
,      cd_gebrkr_wijzgng
FROM   okv_iow_po.okv_iow0117d_hv;

