--
-- BDR_PT_REF_ACTIVITEIT_FT (Table)
-- 
--
exec tabel_hulp.verwijder_tabel ('BDR_PT_REF_ACTIVITEIT_FT')

create table bdr_pt_ref_activiteit_ft (
   dim_snapshot_id                        number not null 
  ,dim_klant_id                           number not null           
  ,dim_organisatie_id                     number not null                      
  ,volgnummer_geval                       number default on null 0 not null
  ,afg_bsn                                varchar(99 byte)
  ,datum_afhandeling                      date
  ,afg_registratienummer                  varchar(99 byte)
  ,code_actie                             number default on null 0 not null
  ,cd_land                                number default on null 0 not null
  ,ai15                                   number default on null 0 not null
  ,ai16                                   number default on null 0 not null
  ,ai27                                   number default on null 0 not null
  ,ai29                                   number default on null 0 not null
  ,aj15                                   number default on null 0 not null
  ,aj16                                   number default on null 0 not null
  ,an15                                   number default on null 0 not null
  ,an16                                   number default on null 0 not null
  ,ao15                                   number default on null 0 not null
  ,ao16                                   number default on null 0 not null
  ,av15                                   number default on null 0 not null
  ,av16                                   number default on null 0 not null
  ,az15                                   number default on null 0 not null
  ,az16                                   number default on null 0 not null
  ,tw15                                   number default on null 0 not null
  ,tw16                                   number default on null 0 not null
  ,tw17                                   number default on null 0 not null
  ,tw18                                   number default on null 0 not null
)
nocompress
tablespace dim_bedrijfszone
logging
partition by list (dim_snapshot_id) automatic
(
  partition part_dummy values (-1)
    nologging
    compress basic
)
nocache
parallel ( degree 4 instances default )
monitoring
/

comment on column bdr_pt_ref_activiteit_ft.dim_organisatie_id is 'Verwijzing naar Organisatie dimensie'
/

comment on column bdr_pt_ref_activiteit_ft.dim_klant_id is 'volgnummer obv. Afgeleide BSN'
/

--
-- DR_PT_REF_ACTIVITEIT_FT_PK  (Index)
--
create unique index bdr_pt_ref_activiteit_pk on bdr_pt_ref_activiteit_ft
(volgnummer_geval, dim_snapshot_id)
logging
tablespace dim_bedrijfszone
/

--
-- Non Foreign Key Constraints for Table DR_PT_REF_ACTIVITEIT_FT
--
alter table bdr_pt_ref_activiteit_ft add (
  constraint bdr_pt_ref_activiteit_pk
  primary key
  (volgnummer_geval, dim_snapshot_id)
  using index bdr_pt_ref_activiteit_pk
  enable validate)
/

 --exec tabel_hulp.vul_tabel ('BDR_PT_REF_ACTIVITEIT_FT', 'PRD-xxxxx')