--
-- BDR_PT_REF_BEHEER_FT (Table)
-- 
--
exec tabel_hulp.verwijder_tabel ('BDR_PT_REF_BEHEER_FT')

create table bdr_pt_ref_beheer_ft (
   dim_snapshot_id                        number not null 
  ,dim_klant_id                           number not null           
  ,dim_organisatie_id                     number not null                      
  ,volgnummer_geval                       number not null
  ,ind_srt_toerekening                    varchar(9 byte)
  ,code_soort_recht                       varchar(9 byte)
  ,nummer_vestiging                       number
  ,ai35                                   number default on null 0 not null
  ,ao35                                   number default on null 0 not null
  ,az35                                   number default on null 0 not null
  ,aj35                                   number default on null 0 not null
  ,av35                                   number default on null 0 not null
  ,an35                                   number default on null 0 not null
  ,ai40                                   number default on null 0 not null
  ,ai46                                   number default on null 0 not null
  ,aw153                                  number default on null 0 not null
  ,aw163                                  number default on null 0 not null
  ,aw173                                  number default on null 0 not null
  ,av40                                   number default on null 0 not null
  ,an40                                   number default on null 0 not null
)
nocompress
tablespace dim_bedrijfszone
logging
partition by list (dim_snapshot_id) automatic
(
  partition part_dummy values (-1)
    nologging
    compress basic
)
nocache
parallel ( degree 4 instances default )
monitoring
/

comment on column bdr_pt_ref_beheer_ft.dim_organisatie_id is 'Verwijzing naar Organisatie dimensie'
/

comment on column bdr_pt_ref_beheer_ft.dim_klant_id is 'volgnummer obv. Afgeleide BSN'
/

--
-- DR_PT_REF_BEHEER_FT_PK  (Index)
--
--create unique index bdr_pt_ref_beheer_pk on bdr_pt_ref_beheer_ft
--(volgnummer_geval, dim_snapshot_id)
--logging
--tablespace dim_bedrijfszone
/

--
-- Non Foreign Key Constraints for Table DR_PT_REF_BEHEER_FT
--
--alter table bdr_pt_ref_beheer_ft add (
--  constraint bdr_pt_ref_beheer_pk
--  primary key
--  (volgnummer_geval, dim_snapshot_id)
--  using index bdr_pt_ref_beheer_pk
--  enable validate)
/

 --exec tabel_hulp.vul_tabel ('BDR_PT_REF_BEHEER_FT', 'PRD-xxxxx')