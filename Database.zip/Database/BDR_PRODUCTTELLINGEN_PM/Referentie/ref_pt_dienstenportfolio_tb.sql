--
-- REF_PT_DIENSTENPORTFOLIO_TB  (Table)
--
--exec tabel_hulp.hernoem_tabel ('REF_PT_DIENSTENPORTFOLIO_TB', 'PRD-xxxxx')

exec tabel_hulp.verwijder_tabel ('REF_PT_DIENSTENPORTFOLIO_TB')

create table ref_pt_dienstenportfolio_tb
(
  product                   varchar2(99 byte),
  productgroep              varchar2(99 byte),
  productnummer             number,
  indicatie_inkoop_leveren  varchar2(99 byte),
  productnaam               varchar2(999 byte),
  wet                       varchar2(99 char),
  datum_aanmaak             timestamp(6)
)
tablespace dim_bedrijfszone
logging
nocompress
nocache
monitoring
/

comment on table ref_pt_dienstenportfolio_tb is 'Referentie tabel waarin de meetwaarden zijn opgenomen die van toepassing zijn binnen de producttellingen'
/

--
-- REF_PT_DIENSTENPORTFOLIO_PK  (Index)
--
create unique index ref_pt_dienstenportfolio_pk on ref_pt_dienstenportfolio_tb
(product)
logging
tablespace dim_bedrijfszone
/

--
-- Non Foreign Key Constraints for Table REF_PT_DIENSTENPORTFOLIO_TB
--
alter table ref_pt_dienstenportfolio_tb add (
  constraint ref_pt_dienstenportfolio_pk
  primary key
  (product)
  using index ref_pt_dienstenportfolio_pk
  enable validate)
/

--exec tabel_hulp.vul_tabel ('REF_PT_DIENSTENPORTFOLIO_TB', 'PRD-xxxxx')