--
-- BDR_PT_RF_SOFT_DELETE  (Materialized View)
--
begin
   execute immediate 'DROP MATERIALIZED VIEW BDR_PT_RF_SOFT_DELETE';
exception
   when others
   then
      if sqlcode != -12003
      then
         raise;
      end if;
end;
/

create materialized view bdr_pt_rf_soft_delete
    (CASUS_KEY)
tablespace dim_bedrijfszone
nocache
nologging
nocompress
build immediate
refresh complete on demand
with primary key
as
select /*+  PARALLEL (p, 4) */
       'RESAFASA'||'|'|| volgnummer_geval CASUS_KEY
from okv_resafasa_pm.okv_geval_hv p
where upper(dim_recent_ind) = 'J' and upper(dim_status) = 'S'
/


comment on materialized view bdr_pt_rf_soft_delete is 'snapshot table for snapshot BDR_PT_RF_SOFT_DELETE'
/
