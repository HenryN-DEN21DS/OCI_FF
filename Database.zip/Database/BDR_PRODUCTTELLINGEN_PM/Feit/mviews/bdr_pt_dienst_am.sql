--
-- BDR_PT_DIENST_AM  (Materialized View)
--
exec tabel_hulp.verwijder_mv ( 'BDR_PT_DIENST_AM' )

create materialized view bdr_pt_dienst_am 
tablespace dim_bedrijfszone
logging
partition by list (dim_snapshot_id)
   automatic(partition part_dummy values (-1) logging nocompress)
nocache
nocompress
parallel (degree 4 instances default)
build immediate
refresh complete on demand with primary key
as
select
  dim_snapshot_id
, dim_dienstenportfolio_id
, dim_districtskantoor_id
, sum (aantal) aantal
from
  BDR_PT_DIENST_FT f
join BDR_PT_CASUS_DT d on f.DIM_CASUS_ID = d.DIM_CASUS_ID  
where
  not exists (
    select 1 
    from
     BDR_PT_RF_SOFT_DELETE sd
    where
      sd.CASUS_KEY = d.DIM_CASUS_KEY
  )
group by
 dim_snapshot_id
, dim_dienstenportfolio_id
, dim_districtskantoor_id
/

comment on materialized view bdr_pt_dienst_am is 'snapshot table for snapshot BDR_PRODUCTTELLINGEN_PM.BDR_PT_DIENST_AM'
/  
