--
-- BDR_RF_PT_INC_BETALING_TB (Table)
-- 
-- JHI048 20230914 volgorde -> varchar
-- JHI048 20230901 Initieel
--

exec tabel_hulp.verwijder_tabel ('BDR_RF_PT_INC_BETALING_TB');

create table bdr_rf_pt_inc_betaling_tb (
   dim_snapshot_id                        number not null 
  ,volgorde                               varchar(99 byte)
  ,dim_dienstenportfolio_key              varchar(99 byte)
  ,dim_casus_key                          varchar(99 byte)          
  ,dim_incidenteel_beheer_key             varchar(99 byte)                 
  ,dim_organisatie_key                    varchar(99 byte)    
  ,dim_districtskantoor_key               varchar(99 byte)
  ,waarde                                 number default on null 0 not null
)
tablespace dim_bedrijfszone logging compress basic nocache monitoring
;
