--
-- BDR_PT_DIENST_FT (Table)
-- 
--

exec tabel_hulp.verwijder_tabel ('BDR_PT_DIENST_FT')

create table bdr_pt_dienst_ft (
   dim_snapshot_id                        number not null 
  ,volgnummer                             number
  ,dim_dienstenportfolio_id               number not null
  ,dim_casus_id                           number not null           
  ,dim_incidenteel_beheer_id              number not null                   
  ,dim_organisatie_id                     number not null     
  ,dim_districtskantoor_id                number not null
  ,aantal                                 number default on null 0 not null
)
nocompress
tablespace dim_bedrijfszone
logging
partition by list (dim_snapshot_id) automatic
(
  partition part_dummy values (-1)
    nologging
    compress basic
)
nocache
parallel ( degree 4 instances default )
monitoring
/

comment on column bdr_pt_dienst_ft.volgnummer is 'Oplopend nummer indien meerdere keren een gelijk product'
/

comment on column bdr_pt_dienst_ft.dim_dienstenportfolio_id  is 'Verwijzing naar de Producten dimensie'
/

comment on column bdr_pt_dienst_ft.dim_casus_id is 'Verwijzing naar de Casus dimensie'
/

comment on column bdr_pt_dienst_ft.dim_incidenteel_beheer_id is 'Verwijzing naar de dimensie welk aangeeft of het incidenteel beheer betreft'
/

comment on column bdr_pt_dienst_ft.dim_organisatie_id is 'Verwijzing naar Organisatie dimensie'
/

comment on column bdr_pt_dienst_ft.dim_districtskantoor_id is 'Verwijzing naar de kantoren dimensie'
/

comment on column bdr_pt_dienst_ft.aantal is 'aantal per uniek gegeven per product'
/

--
-- BDR_PT_DIENST_FT_PK  (Index)
--
create index bdr_pt_dienst_pk on bdr_pt_dienst_ft
(dim_snapshot_id, dim_casus_id, dim_dienstenportfolio_id, dim_incidenteel_beheer_id, volgnummer)
logging
tablespace dim_bedrijfszone
/

--
-- Non Foreign Key Constraints for Table bdr_pt_dienst_ft
--
alter table bdr_pt_dienst_ft add (
  constraint bdr_pt_dienst_pk
  primary key
  (dim_snapshot_id, dim_casus_id, dim_dienstenportfolio_id, dim_incidenteel_beheer_id, volgnummer)
  using index bdr_pt_dienst_pk
  enable validate)
/


--
-- BDR_PT_DIENST_FT_IX  (Index)
--
create index bdr_pt_dienst_ix1 on bdr_pt_dienst_ft
(dim_snapshot_id, dim_dienstenportfolio_id)
logging
tablespace dim_bedrijfszone
/


--exec tabel_hulp.vul_tabel ('BDR_PT_DIENST_FT', 'PRD-xxxxx')