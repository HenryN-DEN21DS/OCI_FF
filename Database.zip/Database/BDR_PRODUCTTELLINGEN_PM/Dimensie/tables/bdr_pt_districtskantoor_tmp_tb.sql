--
-- BDR_PT_DISTRICTSKANTOOR_TMP_TB (Table)
--
exec tabel_hulp.verwijder_tabel ('BDR_PT_DISTRICTSKANTOOR_TMP_TB')

 create table bdr_pt_districtskantoor_tmp_tb (
  dim_districtskantoor_key      varchar2(99 char)  not null enable
  , dim_md5                     varchar2(99 char) not null enable
  , dim_start_datum             timestamp(6)
  , dk_nummer_uk                varchar2(99 char)
  , dk_naam_uk                  varchar2(999 char)
  , dk_naam_uk_regie            varchar2(999 char)
  , districtsnummer_uk          varchar2(999 char)
  , dk_nummer_av                varchar2(99 char)
  , dk_naam_av                  varchar2(999 char)
);
