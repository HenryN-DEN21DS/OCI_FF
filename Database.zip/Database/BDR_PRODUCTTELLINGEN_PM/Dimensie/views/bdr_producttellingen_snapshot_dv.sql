--
-- BDR_PRODUCTTELLINGEN_SNAPSHOT_DV  (View)
--
create or replace force view bdr_producttellingen_snapshot_dv
bequeath definer
as
select
  dim_snapshot_id
, periode_type
, snapshot_periode
, snapshot_datum
, snapshot_datum_vanaf
from
  bdr_conforme_dimensies.bdr_snapshot_dm
/