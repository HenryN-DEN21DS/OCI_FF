-- Naam  : cre_fun_Feestdagen_ind.sql
-- Datum : 20-06-2022
-- Doel  : Script bepalen voor feestdagen
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 20-06-2022 sar022  Aangemaakt
-- ------------------------------------------------------------------------------


create or replace FUNCTION Feestdagen 
(
  in_jaartal IN NUMBER 
) RETURN date AS 
l_feestdag date;

BEGIN

with paasdatum as (
select g,c,x,y,z,e,
((n+7) - mod((z+n),7)) as p
from (
select g,c,x,y,z,e
, Case when (44-e) < 21 then ((44-e)+30) else (44-e) end as n
from (
    select 
        g, c , x, y, z, 
        Case when 
                mod (((11*g)+20+y-x),30) in (24,25) and g > 11 
            then 
                mod (((11*g)+20+y-x),30)+1 else mod (((11*g)+20+y-x),30) 
        End as e  
    from (
            select 
                mod(in_jaartal,19)+1 as g
                , floor(in_jaartal/100)+1 as c
                , floor(((3*(floor(in_jaartal/100)+1))/4)-12) as x
                , floor((((8*(floor(in_jaartal/100)+1))+5)/25)-5) as y
                , floor((((5*in_jaartal)/4)-10) - floor(((3*(floor(in_jaartal/100)+1))/4)-12)) as z
            from dual
    ) a 
) e
)n
) 


    select 
        case when p > 31 
         then to_date( in_jaartal||'04'||(p-31), 'yyyymmdd')
         else to_date( in_jaartal||'03'||p, 'yyyymmdd')
        end as paasdatum into l_feestdag
    from paasdatum
 ;
  RETURN  l_feestdag;
END Feestdagen;
/