-- Naam  : cre_conforme_datum_dimensie_tabel.sql
-- Datum : 21-12-2021
-- Doel  : Script voor aanmaken van conforme datum dimensie
--
-- Notities
--    drop   table ... 
--    create table ...
--    create unique index ..._pk

--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 21-07-2023 gso014 kolommen allemaal > not null
-- 31-10-2022 epa037 Aanpassing PK's
-- 25-01-2021 epa037 Drop table alleen als deze al bestaat
-- 21-12-2021 epa037 Aangepast formaat + feestdag_indicatie PRD-1174
-- 10-09-2021 kja048 Aangemaakt
-- ------------------------------------------------------------------------------


exec tabel_hulp.hernoem_tabel ('BDR_DATUM_DT', 'PRD-22921_2');

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   cre_conforme_datum_dimensie_Tabel_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     to_char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

-- DROP TABLE

BEGIN
    FOR i IN (SELECT NULL FROM USER_OBJECTS WHERE OBJECT_TYPE = 'TABLE' AND OBJECT_NAME = 'BDR_DATUM_DT') LOOP
            EXECUTE IMMEDIATE 'DROP TABLE BDR_DATUM_DT CASCADE CONSTRAINTS';
    END LOOP;
END;
/


CREATE TABLE "BDR_DATUM_DT" (
    datum_id                  NUMBER NOT NULL,
    datum                     DATE NOT NULL,
    dagnaam                   VARCHAR2(9 CHAR) NOT NULL,
    dagnummer_week            NUMBER NOT NULL,
    dagnummer_maand           NUMBER NOT NULL,
    dagnummer_jaar            NUMBER NOT NULL,
    ind_weekend               VARCHAR2(9 CHAR) NOT NULL,
    week_nummer               NUMBER NOT NULL,
    jaarweek_nummer           NUMBER NOT NULL,
    eerste_dag_van_de_week    DATE NOT NULL,
    laatste_dag_van_de_week   DATE NOT NULL,
    ind_week_begin            VARCHAR2(9 CHAR) NOT NULL,
    maandnaam                 VARCHAR2(9 CHAR) NOT NULL,
    maand_nummer              NUMBER NOT NULL,
    jaarmaand_nummer          NUMBER NOT NULL,
    maand_dagen               NUMBER NOT NULL,
    kwartaal_nummer           NUMBER NOT NULL,
    kwartaal                  VARCHAR2(9 CHAR) NOT NULL,
    jaarkwartaal_nummer       NUMBER NOT NULL,
    tertaal_nummer            NUMBER NOT NULL,
    tertaal                   VARCHAR2(9 CHAR) NOT NULL,
    jaartertaal_nummer        NUMBER NOT NULL,
    jaartal                   NUMBER NOT NULL,
    jaar_dagen                NUMBER NOT NULL,
    seizoennaam               VARCHAR2(9 CHAR) NOT NULL,
    feestdag_indicatie        VARCHAR2(9 CHAR) NOT NULL
);


CREATE UNIQUE INDEX "BDR_CONFORME_DIMENSIES"."BDR_DATUM_PK" ON "BDR_CONFORME_DIMENSIES"."BDR_DATUM_DT" (datum_id) 
  PCTFREE 1 COMPUTE STATISTICS 
  TABLESPACE "DIM_BEDRIJFSZONE" ;

ALTER TABLE "BDR_CONFORME_DIMENSIES"."BDR_DATUM_DT" ADD CONSTRAINT "BDR_DATUM_PK" PRIMARY KEY (datum_id)
  USING INDEX "BDR_CONFORME_DIMENSIES"."BDR_DATUM_PK"  ENABLE;

--------------------------------------------------------
--  DDL for Index INDEX1
--------------------------------------------------------

CREATE UNIQUE INDEX "BDR_CONFORME_DIMENSIES"."BDR_DATUM_UX1" ON "BDR_CONFORME_DIMENSIES"."BDR_DATUM_DT" ("DATUM") 
  PCTFREE 1 COMPUTE STATISTICS 
  TABLESPACE "DIM_BEDRIJFSZONE" ;


spo off
column Dbs clear

-- End of script --





