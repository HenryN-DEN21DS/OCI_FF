-- Naam  : ins_BDR_DATUM_DT.sql
-- Datum : 20-06-2022
-- Doel  : Script voor initiaal vullen van tabel BDR_DATUM_DT
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 20-06-2022 sar022  Aangemaakt
-- ------------------------------------------------------------------------------

ALTER SESSION SET NLS_TERRITORY = 'THE NETHERLANDS';
ALTER SESSION SET NLS_DATE_LANGUAGE = 'DUTCH';
ALTER SESSION SET NLS_LANGUAGE = 'DUTCH';
ALTER SESSION SET NLS_ISO_CURRENCY = 'THE NETHERLANDS';

DECLARE
    start_jaartal   CHAR(200);
    eind_jaartal    CHAR(200);
BEGIN
    start_jaartal := 1900;
    eind_jaartal := 2200;
    bdr_conforme_dimensies.insert_feestdagen_ind_datum_dim(start_jaartal, eind_jaartal);
--rollback; 
END;
/