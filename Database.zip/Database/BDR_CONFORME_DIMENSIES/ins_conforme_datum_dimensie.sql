-- Naam  : ins_Conforme_Datum_Dimensie.sql
-- Datum : 10-09-2021
-- Doel  : Script voor onderhouden van de inhoud van conforme datum dimensie.
--

--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 2022-10-31 epa037 Aanpassing eerste en laatste dag van de week (IW)
-- 2022-10-19 epa037 Aanpassing NLS Dutch in IND_WEEKEND / JAARWEEK_NUMMER
-- 2021-12-22 epa037 Formaat aangepast en 31-12-9999 toegevoegd
-- 2021-09-10 kja048 Aangemaakt 
-- ------------------------------------------------------------------------------

define  Dbs = ''
column  Dbs noprint new_value Dbs
  select  upper(instance_name) Dbs
  from    v$instance;

spool   ins_Conforme_Datum_Dimensie_&Dbs..lst
set     ver off
  select  'Database: &Dbs' as "Run Info"
    ,     To_Char(sysdate, 'yyyy-mm-dd hh24-mi-ss') as "Tijdstip"
  from dual;

prompt  Tabel BDR_CONFORME_DIMENSIES.BDR_DATUM_DT
prompt
prompt  --> Opschonen
  select  count(*) as Vooraf from BDR_CONFORME_DIMENSIES.BDR_DATUM_DT;

  delete  BDR_CONFORME_DIMENSIES.BDR_DATUM_DT;
  commit;

prompt Alter NLS_SETTINGS
ALTER SESSION SET NLS_TERRITORY = 'THE NETHERLANDS';
ALTER SESSION SET NLS_DATE_LANGUAGE = 'DUTCH';
ALTER SESSION SET NLS_LANGUAGE = 'DUTCH';
ALTER SESSION SET NLS_ISO_CURRENCY = 'THE NETHERLANDS';

prompt  --> Vullen
prompt

insert into BDR_CONFORME_DIMENSIES.BDR_DATUM_DT 
(DATUM_ID,
DATUM ,
DAGNAAM  ,
DAGNUMMER_WEEK ,
DAGNUMMER_MAAND  ,
DAGNUMMER_JAAR  ,
IND_WEEKEND ,
WEEK_NUMMER  ,
JAARWEEK_NUMMER  ,
EERSTE_DAG_VAN_DE_WEEK  ,
LAATSTE_DAG_VAN_DE_WEEK ,
IND_WEEK_BEGIN  ,
MAANDNAAM  ,
MAAND_NUMMER  ,
JAARMAAND_NUMMER  ,
MAAND_DAGEN  ,
KWARTAAL_NUMMER  ,
KWARTAAL  ,
JAARKWARTAAL_NUMMER ,
TERTAAL_NUMMER  ,
TERTAAL  ,
JAARTERTAAL_NUMMER ,
JAARTAL  ,
JAAR_DAGEN  ,
SEIZOENNAAM  ,
FEESTDAG_INDICATIE
 )
select
  to_number(To_Char(d, 'yyyymmdd')) as DATUM_ID,
  d as DATUM,
  trim(To_Char(d,'DAY','NLS_DATE_LANGUAGE=DUTCH')) as DAGNAAM,   
  To_Char(d,'D')   as DAGNUMMER_WEEK, 
  To_Char(d,'DD')  as DAGNUMMER_MAAND,  
  To_Char(d,'DDD') as DAGNUMMER_JAAR,
  decode(To_Char(d,'DY','NLS_DATE_LANGUAGE=DUTCH'),'ZA','J','ZO','J','N') as IND_WEEKEND,  
  To_Char(d,'IW')  as WEEK_NUMMER,
  To_Char(d,'IYYYIW') as JAARWEEK_NUMMER,  
  TRUNC(d, 'iw') as EERSTE_DAG_VAN_DE_WEEK,
  TRUNC(d, 'iw') + 7 - 1/86400 as LAATSTE_DAG_VAN_DE_WEEK,
  decode(To_Char(d,'D'),'1','J','N') as IND_WEEK_BEGIN,  
  trim(To_Char(d,'MONTH','NLS_DATE_LANGUAGE=DUTCH')) as MAANDNAAM,
  To_Char(d,'MM') as MAAND_NUMMER,
  To_Char(d,'YYYYMM') as JAARMAAND_NUMMER,
  EXTRACT(DAY FROM LAST_DAY(d)) as MAAND_DAGEN,
  To_Char(d,'Q') as KWARTAAL_NUMMER,
  'Q'||To_Char(d,'Q') as KWARTAAL ,
  To_Char(d,'YYYYQ') as JAARKWARTAAL_NUMMER, 
  Case When To_Char (d, 'MM') In (1,2,3,4) Then 1    When To_Char (d, 'MM') In (5,6,7,8) Then 2    When To_Char (d, 'MM') In (9,10,11,12) Then 3    End As Tertaal_Nummer,
  Case When To_Char (d, 'MM') In (1,2,3,4) Then 'T1' When To_Char (d, 'MM') In (5,6,7,8) Then 'T2' When To_Char (d, 'MM') In (9,10,11,12) Then 'T3' End As Tertaal,
  Case 
   When To_Char (d, 'MM') In (1,2,3,4)    Then Concat(To_Char (d, 'YYYY'),1) 
   When To_Char (d, 'MM') In (5,6,7,8)    Then Concat(To_Char (d, 'YYYY'),2) 
   When To_Char (d, 'MM') In (9,10,11,12) Then Concat(To_Char (d, 'YYYY'),3) 
   End Jaartertaal_Nummer,
  To_Char(d,'YYYY') as JAARTAL,
  add_months(trunc(d,'year'), 12) - trunc(d,'year') as JAAR_DAGEN,
  Case 
   When To_Char(d, 'MM') In (12,1,2)  Then 'WINTER' 
   When To_Char(d, 'MM') In (3,4,5)   Then 'LENTE'
   When To_Char(d, 'MM') In (6,7,8)   Then 'ZOMER'
   When To_Char(d, 'MM') In (9,10,11) Then 'HERFST'
   End As Seizoennaam,  
  'N' as FEESTDAG_INDICATIE
from (
  select d from (
    select to_date('18991231','YYYYMMDD')+level d from dual connect by level<=366*300
  )
  where To_Char(d,'YYYY')
  between 1900 and 2300
);

  commit;


prompt  --> Vullen record 99991231
prompt  

  insert into BDR_CONFORME_DIMENSIES.BDR_DATUM_DT 
(DATUM_ID,
DATUM ,
DAGNAAM  ,
DAGNUMMER_WEEK ,
DAGNUMMER_MAAND  ,
DAGNUMMER_JAAR  ,
IND_WEEKEND ,
WEEK_NUMMER  ,
JAARWEEK_NUMMER  ,
EERSTE_DAG_VAN_DE_WEEK  ,
LAATSTE_DAG_VAN_DE_WEEK ,
IND_WEEK_BEGIN  ,
MAANDNAAM  ,
MAAND_NUMMER  ,
JAARMAAND_NUMMER  ,
MAAND_DAGEN  ,
KWARTAAL_NUMMER  ,
KWARTAAL  ,
JAARKWARTAAL_NUMMER ,
TERTAAL_NUMMER  ,
TERTAAL  ,
JAARTERTAAL_NUMMER ,
JAARTAL  ,
JAAR_DAGEN  ,
SEIZOENNAAM  ,
FEESTDAG_INDICATIE
 )
select
  99991231 as DATUM_ID,   --hardcoded
  d as DATUM,
  trim(To_Char(d,'DAY','NLS_DATE_LANGUAGE=DUTCH')) as DAGNAAM,   
  To_Char(d,'D') as DAGNUMMER_WEEK, 
  To_Char(d,'DD') as DAGNUMMER_MAAND,  
  To_Char(d,'DDD') as DAGNUMMER_JAAR,
  decode(To_Char(d,'DY','NLS_DATE_LANGUAGE=DUTCH'),'ZA','J','ZO','J','N') as IND_WEEKEND,  
  To_Char(d,'IW') as WEEK_NUMMER,
  To_Char(d,'IYYYIW') as JAARWEEK_NUMMER,
  TRUNC(d, 'iw') as EERSTE_DAG_VAN_DE_WEEK,
  d as LAATSTE_DAG_VAN_DE_WEEK,     --- HIGHER DATE THAN 31-12-9999 is not possible
  decode(To_Char(d,'D'),'1','J','N') as IND_WEEK_BEGIN,  
  trim(To_Char(d,'MONTH','NLS_DATE_LANGUAGE=DUTCH')) as MAANDNAAM,
  To_Char(d,'MM') as MAAND_NUMMER,
  To_Char(d,'YYYYMM') as JAARMAAND_NUMMER,
  EXTRACT(DAY FROM LAST_DAY(d)) as MAAND_DAGEN,
  To_Char(d,'Q') as KWARTAAL_NUMMER,
  'Q'||To_Char(d,'Q') as KWARTAAL ,
  To_Char(d,'YYYY')||To_Char(d,'Q') as JAARKWARTAAL_NUMMER, 
  3 TERTAAL_NUMMER,   --hardcoded
  'T3' as TERTAAL,  --hardcoded
  To_Char(d,'YYYY')||'3' as JAARTERTAAL_NUMMER,  --hardcoded
  To_Char(d,'YYYY') as JAARTAL,
  add_months(trunc(d,'year'), 12) - trunc(d,'year') as JAAR_DAGEN,
   Case 
   When To_Char(d, 'MM')  In (12,1,2) Then 'WINTER' 
   When To_Char(d, 'MM') In (3,4,5) Then 'LENTE'
   When To_Char(d, 'MM') In (6,7,8) Then 'ZOMER'
   When To_Char(d, 'MM') In (9,10,11) Then 'HERFST'
   End As Seizoennaam, 
   'N' as FEESTDAG_INDICATIE
from  (select to_date('99991231','YYYYMMDD')  d from dual)
;

commit; 
  
  select  count(*) as Achteraf from BDR_CONFORME_DIMENSIES.BDR_DATUM_DT;

spo off
column Dbs clear

-- End of Script