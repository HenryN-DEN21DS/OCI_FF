-- Naam  : cre_sp_vullen_feestdagen_ind.sql
-- Datum : 20-06-2022
-- Doel  : Script voor vullen feestdagen_ind
--
-- Notities
--
-- Datum      Naam   Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 21-10-2022 epa037 Query up to date gemaakt met ins script (NLS settings) 
-- 20-06-2022 sar022 Aangemaakt
-- ------------------------------------------------------------------------------

create or replace Procedure Insert_Feestdagen_ind_Datum_Dim (Start_Jaartal char, Eind_Jaartal char)
Is 

Begin

	Merge Into BDR_DATUM_DT TT
		Using 
		(
			Select
				To_Number (To_Char(ProcesDatum, 'YYYYMMDD')) As Datum_Id
				, ProcesDatum As Datum
				, trim(To_Char (ProcesDatum, 'DAY')) As Dagnaam
				, To_Char (ProcesDatum, 'D') As Dagnummer_Week
				, To_Char (ProcesDatum, 'DD') As Dagnummer_Maand
				, To_Char (ProcesDatum, 'DDD') As Dagnummer_Jaar
        , decode(To_Char(ProcesDatum,'DY'),'ZA','J','ZO','J','N') as Ind_Weekend
				, To_Char (ProcesDatum, 'IW') As Week_Nummer
				, To_Char (ProcesDatum, 'IYYYIW') As Jaarweek_Nummer
        , TRUNC(ProcesDatum, 'iw') as Eerste_Dag_Van_De_Week
        , TRUNC(ProcesDatum, 'iw') + 7 - 1/86400 as Laatste_Dag_Van_De_Week
				, Case When To_Char (ProcesDatum, 'D')  = '1' Then 'J' Else 'N' End As Ind_Week_Begin
				, trim(To_Char (ProcesDatum, 'MONTH')) As Maandnaam
				, To_Char (ProcesDatum, 'MM') As Maand_Nummer
				, To_Char (ProcesDatum, 'YYYYMM') As Jaarmaand_Nummer
				, To_Char (last_day(ProcesDatum),'dd') As Maand_Dagen
				, To_Char (ProcesDatum, 'Q') As Kwartaal_Nummer
				, Concat('Q', To_Char (ProcesDatum, 'Q')) As Kwartaal
				, To_Char (ProcesDatum, 'YYYYQ') As Jaarkwartaal_Nummer
				, Case 
          When To_Char (ProcesDatum, 'MM') In (1,2,3,4)    Then 1    
          When To_Char (ProcesDatum, 'MM') In (5,6,7,8)    Then 2    
          When To_Char (ProcesDatum, 'MM') In (9,10,11,12) Then 3    
        End As Tertaal_Nummer
				, Case 
          When To_Char (ProcesDatum, 'MM') In (1,2,3,4)    Then 'T1' 
          When To_Char (ProcesDatum, 'MM') In (5,6,7,8)    Then 'T2' 
          When To_Char (ProcesDatum, 'MM') In (9,10,11,12) Then 'T3' 
        End As Tertaal
				, Case 
          When To_Char (ProcesDatum, 'MM') In (1,2,3,4)    Then Concat(To_Char (ProcesDatum, 'YYYY'),1) 
          When To_Char (ProcesDatum, 'MM') In (5,6,7,8)    Then Concat(To_Char (ProcesDatum, 'YYYY'),2) 
          When To_Char (ProcesDatum, 'MM') In (9,10,11,12) Then Concat(To_Char (ProcesDatum, 'YYYY'),3) 
        End As Jaartertaal_Nummer
				, To_Char (ProcesDatum, 'YYYY') As Jaartal
				, Add_Months(Trunc(ProcesDatum,'YYYY'),12) - Trunc(ProcesDatum,'YYYY') As Jaar_Dagen
				, Case 
					When To_Char(ProcesDatum, 'MM') In (12,1,2)  Then 'WINTER' 
					When To_Char(ProcesDatum, 'MM') In (3,4,5)   Then 'LENTE'
					When To_Char(ProcesDatum, 'MM') In (6,7,8)   Then 'ZOMER'
					When To_Char(ProcesDatum, 'MM') In (9,10,11) Then 'HERFST' 
				End As Seizoennaam
				, Case 
					When  To_Char (ProcesDatum, 'DDD') = 1 Then 'J' -- Nieuwjaar
					When (feestdagen(To_Char(ProcesDatum, 'YYYY')) + Interval '-2' day) = ProcesDatum Then 'J' -- GoedeVrijdag
					When feestdagen(To_Char(ProcesDatum, 'YYYY')) = ProcesDatum Then 'J' -- Eerste PaAsdag
					When (feestdagen(To_Char(ProcesDatum, 'YYYY')) + Interval '1' day)  = ProcesDatum Then 'J' -- Tweede PaAsdag
					When To_Date(To_Char(ProcesDatum,'yyyy')||'0427', 'yyyymmdd') = ProcesDatum Then 'J' -- KonIngdag
					When (feestdagen(To_Char(ProcesDatum, 'YYYY')) + Interval '39' day) = ProcesDatum Then 'J' -- Hemelvaartsdag
					When (feestdagen(To_Char(ProcesDatum, 'YYYY')) + Interval '49' day) = ProcesDatum Then 'J' -- Eerste PInksteren
					When (feestdagen(To_Char(ProcesDatum, 'YYYY')) + Interval '50' day) = ProcesDatum Then 'J' -- Tweede PInksteren
					When To_Date(To_Char(ProcesDatum,'yyyy')||'1225', 'yyyymmdd') = ProcesDatum Then 'J' -- Eerste Kerstdag
					When To_Date(To_Char(ProcesDatum,'yyyy')||'1226', 'yyyymmdd') = ProcesDatum Then 'J' -- Tweede Kerstdag
					Else 'N'
				End As Feestdag_Indicatie
			From 
				(
					Select  
						(v_Start_Jaartal + level - 1)  ProcesDatum
					From 
						(
							Select 
								To_Date(Insert_Feestdagen_ind_Datum_Dim.Start_Jaartal||'0101', 'yyyymmdd') As v_Start_Jaartal, To_Date(Insert_Feestdagen_ind_Datum_Dim.Eind_Jaartal||'1231', 'yyyymmdd') As v_Eind_Jaartal 
							From dual 
						)
				CONNECT BY level <= v_Eind_Jaartal - v_Start_Jaartal + 1)
		) ST
			On ( ST.datum = TT.datum)
				When 
					Matched 
				Then 
					Update Set  TT.Feestdag_Indicatie = ST.Feestdag_Indicatie 
					Where TT.Feestdag_Indicatie <> ST.Feestdag_Indicatie
				 When 
					Not Matched 
				Then 
					Insert (	
							Datum_Id
							,Datum
							,Dagnaam
							,Dagnummer_Week
							,Dagnummer_Maand
							,Dagnummer_Jaar
							,Ind_Weekend
							,Week_Nummer
							,Jaarweek_Nummer
							,Eerste_Dag_Van_De_Week
							,Laatste_Dag_Van_De_Week
							,Ind_Week_Begin
							,Maandnaam
							,Maand_Nummer
							,Jaarmaand_Nummer
							,Maand_Dagen
							,Kwartaal_Nummer
							,Kwartaal
							,Jaarkwartaal_Nummer
							,Tertaal_Nummer
							,Tertaal
							,Jaartertaal_Nummer
							,Jaartal
							,Jaar_Dagen
							,Seizoennaam
							,Feestdag_Indicatie
						)
						values 
						(	
							ST.Datum_Id
							,ST.Datum
							,ST.Dagnaam
							,To_Number(ST.Dagnummer_Week)
							,To_Number(ST.Dagnummer_Maand)
							,To_Number(ST.Dagnummer_Jaar)
							,ST.Ind_Weekend
							,To_Number(ST.Week_Nummer)
							,To_Number(ST.Jaarweek_Nummer)
							,ST.Eerste_Dag_Van_De_Week
							,ST.Laatste_Dag_Van_De_Week
							,ST.Ind_Week_Begin
							,ST.Maandnaam
							,To_Number(ST.Maand_Nummer)
							,To_Number(ST.Jaarmaand_Nummer)
							,To_Number(ST.Maand_Dagen)
							,To_Number(ST.Kwartaal_Nummer)
							,ST.Kwartaal
							,To_Number(ST.Jaarkwartaal_Nummer)
							,To_Number(ST.Tertaal_Nummer)
							,ST.Tertaal
							,To_Number(ST.Jaartertaal_Nummer)
							,To_Number(ST.Jaartal)
							,To_Number(ST.Jaar_Dagen)
							,ST.Seizoennaam
							,ST.Feestdag_Indicatie
						);
End Insert_Feestdagen_ind_Datum_Dim;
/