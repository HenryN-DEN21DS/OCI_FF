-- Naam : cre_bdr_conforme_dimensies_bdr_snapshot_dm.sql
-- Datum : 13-07-2022
-- Doel : Create script voor aanmaken van BDR_SNAPSHOT_DM tabel
--
-- Notities
--
-- Datum      Naam Omschrijving
-- ---------- ------ ------------------------------------------------------------
-- 21-07-2023 gso014 kolommen not nullable met alter script. lag veroorzaakt een NULL bij eerste week en maand 2009, opgelost met default in de lag.
-- 13-07-2022 gso014 Initieel a
-- ------------------------------------------------------------------------------

DECLARE
    ncount NUMBER;
BEGIN
    SELECT
        COUNT(1)
    INTO ncount
    FROM
        user_tables
    WHERE
        table_name = 'BDR_SNAPSHOT_DM';

    IF ( ncount = 1 ) THEN
        EXECUTE IMMEDIATE 'drop MATERIALIZED VIEW BDR_CONFORME_DIMENSIES.BDR_SNAPSHOT_DM';
    END IF;
END;
/

CREATE MATERIALIZED VIEW BDR_CONFORME_DIMENSIES.BDR_SNAPSHOT_DM AS 

with base as 
( 
select
  datum_id                                        dim_snapshot_id
, cast( 'WEEK' as varchar2( 9 ) )                 periode_type
, jaarweek_nummer                                 snapshot_periode
, datum                                           snapshot_datum
from
  bdr_conforme_dimensies.bdr_datum_dt
where
  dagnummer_week = 7
and datum_id between 20090101 and 20991231
union all
select
  datum_id * -1                                   dim_snapshot_id
, cast( 'MAAND' as varchar2( 9 ) )                periode_type
, jaarmaand_nummer                                snapshot_periode
, datum                                           snapshot_datum
from
  bdr_conforme_dimensies.bdr_datum_dt
where
  dagnummer_maand = maand_dagen
and datum_id between 20090101 and 20991231
)
--
select
  dim_snapshot_id
, periode_type
, snapshot_periode
, snapshot_datum
, lag( snapshot_datum,1,TRUNC(snapshot_datum, 'MM')-1) 
   over( partition by periode_type 
             order by snapshot_datum ) + 1        snapshot_datum_vanaf
from
  base;

alter table BDR_CONFORME_DIMENSIES.BDR_SNAPSHOT_DM modify (     DIM_SNAPSHOT_ID not null,
                                                                PERIODE_TYPE not null,
                                                                SNAPSHOT_DATUM not null,
                                                                SNAPSHOT_DATUM_VANAF not null,
                                                                SNAPSHOT_PERIODE not null);

COMMENT ON MATERIALIZED VIEW BDR_CONFORME_DIMENSIES.BDR_SNAPSHOT_DM IS 'snapshot table for snapshot BDR_CONFORME_DIMENSIES.BDR_SNAPSHOT_DM';
